// Offline GLSL syntax/type check for the preset shaders using glslang (WebAssembly build).
//
// IMPORTANT LIMITS: glslang validates against Vulkan-style GLSL, so each shader is adapted
// before checking: "#version 300 es" -> "310 es", loose uniforms -> one uniform block,
// the fragment output gets a location, gl_VertexID -> gl_VertexIndex. This catches syntax errors,
// type errors, implicit conversions and undeclared identifiers. It does NOT replace compiling on a
// real GPU driver, which can be stricter or differ in precision and loop-limit behaviour.
//
// Usage:  cd tools/validate-glsl && npm install && node validate.cjs ../../app/src/main/assets/shaders
const fs = require('fs');
const path = require('path');

function adaptFragment(src) {
  const members = [];
  let out = src.replace(/^#version 300 es/m, '#version 310 es');
  out = out.replace(/^uniform\s+(?:(?:highp|mediump|lowp)\s+)?(\w+)\s+(\w+)\s*;(.*)$/gm, (_m, type, name, rest) => {
    members.push(`${type === 'bool' ? 'int' : type} ${name};`);
    return `// (uniform ${type} ${name};)${rest}`;
  });
  if (members.length) {
    const block = `layout(std140, set = 0, binding = 0) uniform ShaderArtUniforms {\n  ${members.join('\n  ')}\n};\n`;
    out = out.replace(/(precision highp int;\s*\n)/, `$1${block}`);
  }
  out = out.replace(/^out\s+vec4\s+(\w+)\s*;/m, 'layout(location = 0) out vec4 $1;');
  return out;
}

function adaptVertex(src) {
  return src.replace(/^#version 300 es/m, '#version 310 es').replace(/gl_VertexID/g, 'gl_VertexIndex');
}

function run(glslang) {
  const dir = process.argv[2];
  if (!dir) { console.error('usage: node validate.cjs <shader-dir>'); process.exit(2); }
  let failed = 0;
  let checked = 0;
  for (const file of fs.readdirSync(dir).sort()) {
    const isFrag = file.endsWith('.frag');
    const isVert = file.endsWith('.vert');
    if (!isFrag && !isVert) continue;
    const src = fs.readFileSync(path.join(dir, file), 'utf8');
    const adapted = isFrag ? adaptFragment(src) : adaptVertex(src);
    checked++;
    try {
      glslang.compileGLSL(adapted, isFrag ? 'fragment' : 'vertex', false);
      console.log(`OK    ${file}`);
    } catch (e) {
      failed++;
      console.log(`FAIL  ${file}\n${String(e.message || e)}`);
    }
  }
  console.log(`\n${checked - failed}/${checked} shaders passed`);
  process.exit(failed ? 1 : 0);
}

// NOTE: the glslang module object is "thenable"; `await`-ing it never resolves. Use a callback.
const init = require('@webgpu/glslang/dist/node-devel/glslang.js');
(typeof init === 'function' ? init() : init.default()).then((g) => run(g));
