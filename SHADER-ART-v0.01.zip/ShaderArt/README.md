# SHADER ART — Real-Time GPU Visual Laboratory (v0.01)

SHADER ART is a native Android app for making, tuning and exporting real-time GPU shader art. It runs fully offline: **no internet permission, no accounts, no analytics, no ads.**

- Package: `com.shaderart.studio` · Version: `0.01` (versionCode 1)
- Kotlin, Jetpack Compose, OpenGL ES 3.0 (GLSL ES 3.00), minSdk 26, Gradle Kotlin DSL
- Build output: a **debug APK**

> **Honesty note.** This project was written in a sandbox that could not reach the Android SDK or Maven, so the full app has **not been built or run on a device by its author**. What *was* verified, and what was not, is listed in [Verification status](#verification-status). The first real build happens in GitHub Actions; if it fails, the log tells you exactly why.

---

## What is in the app

| Destination | What it does |
|---|---|
| **Home** | Continue recent projects, featured presets, quick actions, compatibility warning if the GPU is too old. |
| **Explore** | 23 presets in 5 categories (Fluid, Math, Geometric, Raymarch, Digital). Search, category filter, favourites. Previews are rendered by your own GPU. |
| **Visual Studio** | Live preview with sliders, numeric fields, switches, colour picker, palettes, Randomize, Variation, Reset, speed, zoom (pinch), quality. Save, rename, export. |
| **Code Studio** | GLSL editor: syntax colours, line numbers, completion, auto-indent, undo/redo, find, format, fragment and vertex tabs, templates, Run / Stop / auto-compile, GPU-driver error messages you can tap to jump to the line, Output / Uniforms / Info panel. |
| **Gallery** | Saved projects with thumbnails, search, filter, sort, favourites, rename, duplicate, delete, import and export (`.shaderart`). |
| **Settings** | Default quality, performance panel, 30 FPS limit, device and GPU info, about. |

Also: PNG/JPEG image export up to the real limit of your GPU (progress, cancel, save with the system file picker, share), phone wallpaper sizes, lifecycle-aware rendering (the GPU is idle when the app is not on screen), GPU context-loss recovery, edge-to-edge dark AMOLED UI, accessibility labels.

### Shader parameters from comments

In Code Studio, controls are created from annotations next to a `uniform`:

```glsl
uniform float u_amount;   // @slider 0 1 0.5 "Amount"
uniform vec3  u_tint;     // @color 1.0 0.5 0.2 "Tint"
uniform bool  u_invert;   // @toggle 0 "Invert"
```

### Built-in uniforms

`u_time` (seconds), `u_resolution` (px), `u_mouse` (vec4: xy = touch position from 0 to 1 across the preview, origin bottom-left; z = 1 while a finger is down, otherwise 0; w unused), `u_deltaTime`, `u_frame`, `u_speed`, `u_zoom` (pinch). Shaders are GLSL ES 3.00: start with `#version 300 es`, declare `out vec4`, and write your colour in `main`.

Coordinates: `gl_FragCoord` has its origin at the **bottom-left**. Exported images are flipped to normal orientation.

---

## Getting the APK from your phone (no computer needed)

You need a free GitHub account. GitHub's servers build the app for you.

### 1. Upload the two files
1. In the GitHub app or in a mobile browser (use "Desktop site" if offered), create a **new repository** (private is fine). Do not add any files yet.
2. Open the repository → **Add file → Upload files**.
3. Upload **`SHADER-ART-v0.01.zip`** (the ZIP itself — do **not** unzip it).
4. Create the workflow file. Easiest: **Add file → Create new file**, type the name exactly `.github/workflows/build-apk.yml` (typing the slashes creates the folders), paste the contents of the provided `build-apk.yml`, and commit.

The repository root must look like this:

```
your-repo/
├── SHADER-ART-v0.01.zip
└── .github/
    └── workflows/
        └── build-apk.yml
```

(The ZIP also contains a copy of the workflow and the full project, so you may alternatively upload the extracted project; the workflow handles both.)

### 2. Start the build
- Committing to `main`/`master` starts it automatically, **or**
- Open the **Actions** tab → **Build SHADER ART debug APK** → **Run workflow**.
- If the Actions tab asks you to enable workflows, press the green button.

A build takes roughly 8–15 minutes the first time. Green tick = success.

### 3. Download and install
1. Open the finished run → scroll to **Artifacts** → tap **`SHADER-ART-v0.01-debug-APK`**. GitHub downloads a ZIP.
2. Open your Files app, unzip it, and tap `SHADER-ART-v0.01-debug.apk`.
3. Android will ask to allow installs from this source (your browser or Files app). Allow it for this install, then press **Install**.
4. Google Play Protect may warn that the app is unrecognised. That is normal for any app not from the Play Store: this is a debug build signed with a debug key.

If the build fails, open the run, tap the red step, and copy the error. The `SHADER-ART-v0.01-reports` artifact also holds test and lint reports.

---

## Building in Android Studio (optional)

1. Install Android Studio (Ladybug or newer) with JDK 17.
2. Unzip the ZIP, **File → Open** the `ShaderArt` folder, let Gradle sync.
3. Run on a device or emulator with OpenGL ES 3.0, or from a terminal:
   ```
   ./gradlew testDebugUnitTest      # unit tests (JVM)
   ./gradlew lintDebug              # lint
   ./gradlew assembleDebug          # APK in app/build/outputs/apk/debug/
   ./gradlew connectedDebugAndroidTest   # GPU + storage tests, needs a device/emulator
   ```

Toolchain: AGP 8.7.3 · Gradle 8.9 (wrapper) · Kotlin 2.1.0 · KSP 2.1.0-1.0.29 · Compose BOM 2024.12.01 · Room 2.6.1 · compileSdk/targetSdk 35 · Java 17.

---

## Project layout

```
app/src/main/java/com/shaderart/studio/
  app/            Application, AppContainer (hand-wired dependencies), MainActivity, navigation
  core/
    gpu/          ShaderCapabilities, ShaderProgram, fullscreen triangle, render targets
    compiler/     ShaderCompiler (real driver logs), ShaderDiagnostic + log parser
    uniforms/     ShaderUniformManager (type-checked uniform binding)
    renderer/     ShaderRenderer, ShaderSurfaceView, RenderSession, RenderRequest/Stats
    export/       OffscreenRenderer (EGL pbuffer, tiled), ExportEngine, size/format limits
    model/        Project, preset and parameter models and logic
    storage/      Room index + atomic file storage, migrations, serializer
    importing/    Validated import (.shaderart, .glsl, .frag, .vert), Storage Access helpers
    presets/      Preset catalog + code templates
    security/     Import limits and safe-name rules
    shader/       Annotation parser, source checks
    json/         Strict JSON parser
  feature/        library, studio (shared ViewModel), params (palettes), codeeditor, export, settings
  ui/             theme, components (editor, parameter panel, canvas), screens
app/src/main/assets/   shaders/*.frag, presets/catalog.json, templates/*.frag
app/src/test/          JVM unit tests (131)
app/src/androidTest/   GPU and storage tests (run on a device)
tools/                 GLSL sources, preset generator, glslang validation script
```

Presets are generated from `tools/shader-src` by `python3 tools/build_presets.py`; `node tools/validate-glsl/validate.cjs app/src/main/assets/shaders` checks every shader with glslang.

---

## Verification status

**Actually run by the author (in a sandbox without the Android SDK):**
- All 23 preset shaders and 4 code templates validated with glslang (as GLSL ES 3.10 equivalents; the check confirms syntax and types, not what your GPU driver will accept). Deliberately broken shaders were confirmed to be rejected.
- The pure-Kotlin logic (JSON, models, parameters, storage, import limits, archive reader/writer, annotation parser, log parser, editor logic) was compiled with the real Kotlin 2.1.0 compiler and **131 unit tests passed** — run with a small stand-in for JUnit, not through Gradle.
- Workflow YAML parsed, and each script in it syntax-checked.

**Not run by the author — first verified by your GitHub build or your phone:**
- The Gradle build, KSP/Room, Compose compilation, lint, `assembleDebug`.
- Everything that needs Android or a GPU: the renderer, driver compile/link, context-loss recovery, offscreen export, the UI, the file pickers, sharing, performance on real hardware.
- The instrumentation tests (written, never executed). GitHub Actions does not run them.
- Installing and launching the APK.

Expect that a first build of a project this size written without a compiler may contain compile errors. If the Actions build fails, send the error text and it can be fixed quickly.

---

## Security and privacy

- No `INTERNET` permission (the workflow fails the build if one appears). No analytics, ads or accounts.
- Imports are validated: size limits, a fixed list of allowed archive entries, zip-bomb limits, safe file names, strict JSON, and **imported shaders never run until you press Run**.
- Files are written atomically; shared images go through a restricted `FileProvider` (export cache only).
- A slow shader is automatically paused after three frames longer than one second.

## Known limitations

- Debug build only (debug signature). Not published to any store.
- Dark theme only. The UI is monochrome; the artwork, syntax colours and error/success messages are the only coloured elements.
- Large exports use tiled rendering, which is exact only for single-pass shaders that depend on `gl_FragCoord`. Very large sizes can still run out of memory on low-RAM phones; the app reports the failure.
- Saving through the system file picker may append `.txt` or `.bin` on some storage providers.
- Preset previews are rendered on first view and then cached, so Explore fills in progressively.
- Editor: lines do not wrap (the editor scrolls sideways); no replace, multi-cursor or bracket matching.
- Accessibility labels are provided, but v0.01 was not tested with TalkBack.

## Deferred (not in v0.01)

Video and GIF export · live wallpaper service · multi-pass shaders and texture inputs · transparent PNG · audio-reactive input · the full 33-effect library (v0.01 ships 23 presets plus 7 post effects: pixelate, glitch, RGB split, scanlines, grain, dither, halftone) · cloud features.

## Troubleshooting

| Problem | What to do |
|---|---|
| Actions says "Could not find settings.gradle.kts" | The ZIP is not in the repository root, or was unzipped incorrectly. Upload `SHADER-ART-v0.01.zip` itself, next to `.github`. |
| Build fails in "Unit tests" or "Assemble" | Open the red step and copy the first `error:` line. |
| "App not installed" | Uninstall any older copy first; make sure you downloaded the unzipped `.apk`. |
| Black preview, message about OpenGL ES | The device does not support OpenGL ES 3.0. |
| A shader is slow | Lower the quality (25–50%) or enable the 30 FPS limit. |
| Compile error in Code Studio | The Output tab shows the driver's own message; tap a line to jump to it. |
