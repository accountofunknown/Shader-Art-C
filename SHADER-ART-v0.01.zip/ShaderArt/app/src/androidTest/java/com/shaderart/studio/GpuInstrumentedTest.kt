package com.shaderart.studio

import android.graphics.BitmapFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.shaderart.studio.core.export.ExportConfig
import com.shaderart.studio.core.export.ExportEngine
import com.shaderart.studio.core.export.ExportException
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.core.storage.ProjectFactory
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * These tests need a real OpenGL ES 3.0 context, so they run on a device or emulator
 * (`./gradlew connectedDebugAndroidTest`). They are NOT run by the GitHub Actions workflow.
 */
@RunWith(AndroidJUnit4::class)
class GpuInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var cache: File
    private lateinit var engine: ExportEngine
    private lateinit var presets: PresetRepository

    @Before
    fun setUp() {
        cache = File(context.cacheDir, "gpu-test-${System.nanoTime()}").also { it.mkdirs() }
        engine = ExportEngine(cache)
        presets = PresetRepository(context.assets)
    }

    @After
    fun tearDown() {
        cache.deleteRecursively()
    }

    @Test
    fun catalogLoads(): Unit {
        assertTrue("catalog must load", presets.catalog.isSuccess)
        assertTrue("expected at least 18 presets", presets.presets.size >= 18)
    }

    /** The strongest check in the project: every bundled preset must compile and render on this GPU. */
    @Test
    fun everyPresetRendersAThumbnail(): Unit = runBlocking {
        val failures = mutableListOf<String>()
        for (preset in presets.presets) {
            try {
                val file = engine.presetThumbnail(preset)
                val bmp = BitmapFactory.decodeFile(file.path)
                if (bmp == null || bmp.width <= 0) failures += "${preset.id}: unreadable image"
            } catch (e: Exception) {
                failures += "${preset.id}: ${e.message}"
            }
        }
        assertTrue("Presets failed on this GPU:\n" + failures.joinToString("\n"), failures.isEmpty())
    }

    @Test
    fun exportsPngAtRequestedSize(): Unit = runBlocking {
        val preset = presets.presets.first()
        val project = ProjectFactory.fromPreset(preset, "test-id", 1L)
        val file = engine.exportImage(project, ExportConfig(300, 200, ImageFormat.PNG), "t.png") { }
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, opts)
        assertEquals(300, opts.outWidth)
        assertEquals(200, opts.outHeight)
    }

    @Test
    fun invalidShaderFailsWithDriverDiagnostics(): Unit = runBlocking {
        val bad = ProjectFactory.newCode(
            "bad", "bad-id", 1L, presets.vertexSource,
            "#version 300 es\nprecision highp float;\nout vec4 o;\nvoid main(){ o = vec4(undefined_symbol); }\n",
        )
        try {
            engine.exportImage(bad, ExportConfig(64, 64), "bad.png") { }
            throw AssertionError("expected ExportException")
        } catch (e: ExportException) {
            assertTrue("driver should report at least one diagnostic", e.diagnostics.isNotEmpty())
        }
    }

    @Test
    fun thumbnailIsJpeg(): Unit = runBlocking {
        val project = ProjectFactory.fromPreset(presets.presets.first(), "thumb-id", 1L)
        val bytes = engine.renderThumbnail(project)
        assertNotNull(bytes)
        assertEquals(0xFF, bytes[0].toInt() and 0xFF)
        assertEquals(0xD8, bytes[1].toInt() and 0xFF)
        assertEquals(ProjectType.VISUAL, project.type)
    }

    @Test
    fun maxImageSideIsReported(): Unit = runBlocking {
        val side = engine.maxImageSide()
        assertNotNull(side)
        assertTrue(side!! >= 2048)
    }
}
