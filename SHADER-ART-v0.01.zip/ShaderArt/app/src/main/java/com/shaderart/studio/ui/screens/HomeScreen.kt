package com.shaderart.studio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.gpu.DeviceGles
import com.shaderart.studio.core.model.ProjectSummary
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SecondaryButton
import com.shaderart.studio.ui.components.SectionLabel
import com.shaderart.studio.ui.components.StatusBanner
import com.shaderart.studio.ui.components.clickableWithRole
import com.shaderart.studio.ui.theme.ShaderArtColors

@Composable
fun HomeScreen(
    lib: LibraryViewModel,
    onNewVisual: () -> Unit,
    onNewCode: () -> Unit,
    onExplore: () -> Unit,
    onGallery: () -> Unit,
    onImport: () -> Unit,
    onOpenProject: (String) -> Unit,
    onOpenPreset: (String) -> Unit,
) {
    val projects by lib.projects.collectAsStateWithLifecycle()
    val recents = projects.sortedByDescending { it.lastOpenedAt }.take(6)
    val featured = lib.presets.take(8)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)) {
        item(key = "title") {
            Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp)) {
                Text("SHADER ART", style = MaterialTheme.typography.headlineMedium)
                Text(
                    "Real-time GPU visual laboratory · v0.01",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (!lib.gles3Supported) {
            item(key = "compat") {
                StatusBanner(
                    "This device reports OpenGL ES ${DeviceGles.describe(lib.reportedGlesVersion)}. SHADER ART needs OpenGL ES 3.0 or newer, so the studios and previews cannot run here.",
                    ShaderArtColors.Error, R.drawable.ic_error,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }
        lib.catalogProblem?.let { problem ->
            item(key = "catalog") {
                StatusBanner(problem, ShaderArtColors.Error, R.drawable.ic_error, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }

        item(key = "actions") {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Explore presets", onExplore, Modifier.weight(1f), icon = R.drawable.ic_explore)
                    SecondaryButton("New shader", onNewCode, Modifier.weight(1f), icon = R.drawable.ic_code)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SecondaryButton("Visual Studio", onNewVisual, Modifier.weight(1f), icon = R.drawable.ic_tune)
                    SecondaryButton("Import", onImport, Modifier.weight(1f), icon = R.drawable.ic_import)
                }
            }
        }

        if (recents.isNotEmpty()) {
            item(key = "recent_label") { SectionLabel("Continue where you left off") }
            item(key = "recent") {
                LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recents, key = { it.id }) { p -> ProjectCard(lib, p, onOpenProject) }
                }
            }
            item(key = "gallery_link") {
                SecondaryButton("Open Gallery", onGallery, Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        } else {
            item(key = "empty") {
                Text(
                    "Nothing saved yet. Open a preset, adjust it, and press Save to keep it in your Gallery.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }

        if (featured.isNotEmpty() && lib.gles3Supported) {
            item(key = "featured_label") { SectionLabel("Featured presets") }
            item(key = "featured") {
                LazyRow(contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(featured, key = { it.id }) { preset ->
                        Column(
                            Modifier.width(140.dp).clickableWithRole { onOpenPreset(preset.id) }
                                .semantics { contentDescription = "Open preset ${preset.name}" },
                        ) {
                            PresetThumb(lib, preset, Modifier.size(140.dp))
                            Text(preset.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
                            Text(preset.category.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProjectCard(lib: LibraryViewModel, p: ProjectSummary, onOpen: (String) -> Unit) {
    Column(
        Modifier.width(140.dp).clickableWithRole { onOpen(p.id) }
            .semantics { contentDescription = "Open project ${p.name}" },
    ) {
        ProjectThumb(lib, p, Modifier.size(140.dp))
        Text(p.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 6.dp), maxLines = 1)
        Text(
            (if (p.type == ProjectType.CODE) "Code" else "Visual") + " · " + formatDate(p.modifiedAt),
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
        )
    }
}
