package com.shaderart.studio.core.storage

import com.shaderart.studio.core.json.JsonException

/** The manifest cannot be understood (damaged, wrong shape, invalid values). */
open class ProjectFormatException(message: String) : Exception(message)

/** The manifest was written by a newer (or unknown) format version. */
class UnsupportedProjectVersionException(val version: Int) :
    ProjectFormatException("Unsupported project format version $version (this app understands up to ${ProjectMigrations.CURRENT_FORMAT}).")

/**
 * Upgrades older manifests, step by step, to [CURRENT_FORMAT].
 *
 * - v0: early drafts without "shaderVersion", "animation", "render" or "values".
 * - v1: current format.
 */
object ProjectMigrations {
    const val CURRENT_FORMAT = 1

    fun migrate(manifest: Map<String, Any?>): Map<String, Any?> {
        val raw = manifest["formatVersion"]
        val version = when (raw) {
            null -> 0
            is Number -> {
                val d = raw.toDouble()
                if (d != Math.floor(d)) throw ProjectFormatException("formatVersion must be a whole number")
                raw.toInt()
            }
            else -> throw ProjectFormatException("formatVersion must be a number")
        }
        if (version < 0 || version > CURRENT_FORMAT) throw UnsupportedProjectVersionException(version)
        var current: Map<String, Any?> = manifest
        var v = version
        while (v < CURRENT_FORMAT) {
            current = when (v) {
                0 -> from0to1(current)
                else -> throw UnsupportedProjectVersionException(v)
            }
            v++
        }
        return current
    }

    private fun from0to1(m: Map<String, Any?>): Map<String, Any?> {
        val out = LinkedHashMap(m)
        out.putIfAbsent("type", "CODE")
        out.putIfAbsent("shaderVersion", "300 es")
        out.putIfAbsent("params", emptyList<Any?>())
        out.putIfAbsent("values", emptyMap<String, Any?>())
        out.putIfAbsent("animation", linkedMapOf("playing" to true, "speed" to 1.0, "time" to 0.0))
        out.putIfAbsent("render", linkedMapOf("qualityScale" to 1.0, "previewWidth" to 0L, "previewHeight" to 0L, "zoom" to 1.0))
        out["formatVersion"] = 1L
        return out
    }

    @Suppress("unused")
    internal fun wrap(e: JsonException): ProjectFormatException = ProjectFormatException(e.message ?: "Invalid project data")
}
