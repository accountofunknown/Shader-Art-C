package com.shaderart.studio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.model.Performance
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.PresetCategory
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.ui.components.EmptyState
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.ScreenTitle
import com.shaderart.studio.ui.components.StatusBanner
import com.shaderart.studio.ui.components.clickableWithRole
import com.shaderart.studio.ui.theme.ShaderArtColors

private const val FILTER_ALL = "ALL"
private const val FILTER_FAVORITES = "FAVORITES"

@Composable
fun ExploreScreen(lib: LibraryViewModel, onOpenPreset: (String) -> Unit) {
    val settings by lib.settings.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(FILTER_ALL) }

    val all = lib.presets
    val shown = all.filter { p ->
        val matchesFilter = when (filter) {
            FILTER_ALL -> true
            FILTER_FAVORITES -> p.id in settings.favoritePresets
            else -> p.category.name == filter
        }
        val q = query.trim()
        matchesFilter && (q.isEmpty() || p.name.contains(q, ignoreCase = true) || p.description.contains(q, ignoreCase = true) || p.category.label.contains(q, ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Explore", subtitle = "${all.size} presets, rendered live on your GPU")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search presets") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item(key = "all") { Pill("All", filter == FILTER_ALL, { filter = FILTER_ALL }) }
            item(key = "fav") { Pill("Favorites", filter == FILTER_FAVORITES, { filter = FILTER_FAVORITES }) }
            items(PresetCategory.entries.toList(), key = { it.name }) { c -> Pill(c.label, filter == c.name, { filter = c.name }) }
        }

        lib.catalogProblem?.let {
            StatusBanner(it, ShaderArtColors.Error, R.drawable.ic_error, Modifier.padding(16.dp))
        }

        if (shown.isEmpty()) {
            EmptyState(
                icon = R.drawable.ic_search,
                title = if (filter == FILTER_FAVORITES) "No favorites yet" else "No presets match",
                body = if (filter == FILTER_FAVORITES) "Tap the star on a preset to keep it here." else "Try a different search or category.",
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(shown, key = { it.id }) { p ->
                    PresetCard(lib, p, favorite = p.id in settings.favoritePresets, onOpen = onOpenPreset)
                }
                item(span = { GridItemSpan(maxLineSpan) }, key = "footer") { Box(Modifier.padding(8.dp)) }
            }
        }
    }
}

@Composable
private fun PresetCard(lib: LibraryViewModel, p: Preset, favorite: Boolean, onOpen: (String) -> Unit) {
    Column(Modifier.semantics { contentDescription = "Preset ${p.name}. ${p.description}" }) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clickableWithRole { onOpen(p.id) }) {
            PresetThumb(lib, p, Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.TopEnd)) {
                SIconButton(
                    if (favorite) R.drawable.ic_star else R.drawable.ic_star_outline,
                    if (favorite) "Remove ${p.name} from favorites" else "Add ${p.name} to favorites",
                    { lib.toggleFavoritePreset(p.id) },
                )
            }
        }
        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(p.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1)
            Text(
                when (p.performance) { Performance.LIGHT -> "Light"; Performance.MEDIUM -> "Medium"; Performance.HEAVY -> "Heavy" },
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Text(p.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
    }
}
