package com.shaderart.studio.core.uniforms

import android.opengl.GLES20
import android.opengl.GLES30
import com.shaderart.studio.core.gpu.ActiveUniform
import com.shaderart.studio.core.gpu.GlTypes
import com.shaderart.studio.core.gpu.ShaderProgram
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamType

/** Per-frame values for the standard uniforms (documented in the template and README). */
data class FrameUniforms(
    val time: Float,
    val width: Int,
    val height: Int,
    /** Touch position 0..1, origin bottom-left (the same origin as gl_FragCoord). */
    val mouseX: Float,
    val mouseY: Float,
    val mouseDown: Boolean,
    val deltaTime: Float,
    val frame: Int,
    val speed: Float,
    val zoom: Float,
)

/**
 * Binds uniforms. Only uniforms that the linked program really contains are touched, and every value is
 * checked against the uniform's actual GLSL type first; a mismatch is skipped and reported, never forced.
 */
class ShaderUniformManager {
    fun bindFrame(p: ShaderProgram, f: FrameUniforms, warnings: MutableList<String>? = null) {
        p.uniforms["u_time"]?.let { if (expect(it, GLES20.GL_FLOAT, warnings)) GLES30.glUniform1f(it.location, f.time) }
        p.uniforms["u_resolution"]?.let { if (expect(it, GLES20.GL_FLOAT_VEC2, warnings)) GLES30.glUniform2f(it.location, f.width.toFloat(), f.height.toFloat()) }
        p.uniforms["u_mouse"]?.let { if (expect(it, GLES20.GL_FLOAT_VEC4, warnings)) GLES30.glUniform4f(it.location, f.mouseX, f.mouseY, if (f.mouseDown) 1f else 0f, 0f) }
        p.uniforms["u_deltaTime"]?.let { if (expect(it, GLES20.GL_FLOAT, warnings)) GLES30.glUniform1f(it.location, f.deltaTime) }
        p.uniforms["u_frame"]?.let { if (expect(it, GLES20.GL_INT, warnings)) GLES30.glUniform1i(it.location, f.frame) }
        p.uniforms["u_speed"]?.let { if (expect(it, GLES20.GL_FLOAT, warnings)) GLES30.glUniform1f(it.location, f.speed) }
        p.uniforms["u_zoom"]?.let { if (expect(it, GLES20.GL_FLOAT, warnings)) GLES30.glUniform1f(it.location, f.zoom) }
    }

    /**
     * Sets every control value whose uniform exists in the program.
     * @param warnings if non-null, receives a message for each type mismatch (pass it only when the
     * program or the parameter list changed, so the list is not rebuilt every frame).
     */
    fun bindParams(p: ShaderProgram, params: List<ParamDef>, values: Map<String, List<Float>>, warnings: MutableList<String>? = null) {
        for (def in params) {
            val u = p.uniforms[def.uniform] ?: continue
            val v = values[def.id] ?: def.defaults
            when (def.type) {
                ParamType.FLOAT -> if (expect(u, GLES20.GL_FLOAT, warnings, "a float control")) GLES30.glUniform1f(u.location, v.firstOr(def.defaults))
                ParamType.INT -> if (expect(u, GLES20.GL_INT, warnings, "an integer control")) GLES30.glUniform1i(u.location, v.firstOr(def.defaults).toInt())
                ParamType.BOOL -> if (expect(u, GLES20.GL_BOOL, warnings, "a toggle")) GLES30.glUniform1i(u.location, if (v.firstOr(def.defaults) >= 0.5f) 1 else 0)
                ParamType.COLOR -> {
                    val r = v.getOrElse(0) { 0f }
                    val g = v.getOrElse(1) { 0f }
                    val b = v.getOrElse(2) { 0f }
                    when (u.type) {
                        GLES20.GL_FLOAT_VEC3 -> GLES30.glUniform3f(u.location, r, g, b)
                        GLES20.GL_FLOAT_VEC4 -> GLES30.glUniform4f(u.location, r, g, b, 1f)
                        else -> warnings?.add(mismatch(u, "vec3 or vec4", "a color control"))
                    }
                }
            }
        }
    }

    private fun List<Float>.firstOr(defaults: List<Float>): Float = firstOrNull() ?: defaults.firstOrNull() ?: 0f

    private fun expect(u: ActiveUniform, glType: Int, warnings: MutableList<String>?, source: String = "the app"): Boolean {
        if (u.type == glType) return true
        warnings?.add(mismatch(u, GlTypes.name(glType), source))
        return false
    }

    private fun mismatch(u: ActiveUniform, expected: String, source: String) =
        "Uniform '${u.name}' is declared as ${GlTypes.name(u.type)} but $source provides $expected. The value was not applied."
}
