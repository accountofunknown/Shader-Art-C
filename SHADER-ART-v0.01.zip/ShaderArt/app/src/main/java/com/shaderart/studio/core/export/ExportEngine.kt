package com.shaderart.studio.core.export

import android.graphics.Bitmap
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ShaderProject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Runs every offscreen GPU job (image export, thumbnails, preset previews) one at a time on a single
 * dedicated thread. That keeps EGL contexts on one thread and stops several heavy renders from
 * competing for the GPU.
 */
class ExportEngine(private val cacheDir: File) {
    private val gpuThread = Executors.newSingleThreadExecutor { r -> Thread(r, "shaderart-offscreen") }.asCoroutineDispatcher()
    private val renderer = OffscreenRenderer()

    private val exportDir get() = File(cacheDir, "exports")
    private val presetThumbDir get() = File(cacheDir, "preset_thumbs")

    /** Removes previously exported files from the share cache. */
    fun clearExportCache() {
        exportDir.listFiles()?.forEach { it.delete() }
    }

    suspend fun maxImageSide(): Int? = withContext(gpuThread) { renderer.queryMaxSide() }

    /**
     * Renders [project] at the requested size and writes an image file into the share cache.
     * Cancelling the calling coroutine stops the render between tiles.
     * Throws [ExportException] on failure; a file is returned only if the image really was written.
     */
    suspend fun exportImage(
        project: ShaderProject,
        config: ExportConfig,
        fileName: String,
        onProgress: (Float) -> Unit,
    ): File = withContext(gpuThread) {
        ExportLimits.problem(config)?.let { throw ExportException(it) }
        val dir = exportDir
        if (!dir.exists() && !dir.mkdirs()) throw ExportException("Could not create the export folder.")
        val bitmap = renderer.render(
            requestFor(project, config.width, config.height, config.timeSeconds),
            onProgress = { onProgress(it * 0.95f) },
            isCancelled = { !isActive },
        )
        try {
            val out = File(dir, fileName)
            try {
                FileOutputStream(out).use { stream ->
                    val format = if (config.format == ImageFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    val ok = bitmap.compress(format, if (config.format == ImageFormat.PNG) 100 else config.quality, stream)
                    if (!ok) throw ExportException("The image could not be encoded.")
                    stream.flush()
                }
            } catch (e: IOException) {
                out.delete()
                throw ExportException("The image could not be written: ${e.message}")
            } catch (e: ExportException) {
                out.delete()
                throw e
            }
            if (!isActive) {
                out.delete()
                throw kotlinx.coroutines.CancellationException("Export cancelled")
            }
            onProgress(1f)
            out
        } finally {
            bitmap.recycle()
        }
    }

    /** Small JPEG used as a project thumbnail. */
    suspend fun renderThumbnail(project: ShaderProject, size: Int = THUMB_SIZE): ByteArray = withContext(gpuThread) {
        val bitmap = renderer.render(requestFor(project, size, size, project.animation.time))
        try {
            val out = ByteArrayOutputStream()
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)) throw ExportException("Thumbnail encoding failed.")
            out.toByteArray()
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * Returns a cached preview image of a built-in preset, rendering it with the real shader on first use.
     * The cache key contains the preset version, so updated presets get fresh previews.
     */
    suspend fun presetThumbnail(preset: Preset): File = withContext(gpuThread) {
        val file = File(presetThumbDir, "${preset.id}_v${preset.version}_$THUMB_SIZE.jpg")
        if (file.isFile && file.length() > 0) return@withContext file
        if (!presetThumbDir.exists() && !presetThumbDir.mkdirs()) throw ExportException("Could not create the preview cache.")
        val request = OffscreenRequest(
            preset.vertexSource, preset.fragmentSource, preset.params, ParamLogic.defaults(preset.params),
            THUMB_SIZE, THUMB_SIZE, preset.previewTime,
        )
        val bitmap = renderer.render(request)
        try {
            val tmp = File(presetThumbDir, file.name + ".tmp")
            FileOutputStream(tmp).use { if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it)) throw ExportException("Preview encoding failed.") }
            if (!tmp.renameTo(file)) throw ExportException("Could not store the preview.")
            file
        } finally {
            bitmap.recycle()
        }
    }

    private fun requestFor(p: ShaderProject, w: Int, h: Int, time: Float) = OffscreenRequest(
        p.vertexSource, p.fragmentSource, p.params, ParamLogic.normalize(p.params, p.values),
        w, h, time, zoom = p.render.zoom, speed = p.animation.speed,
    )

    private companion object {
        const val THUMB_SIZE = 256
    }
}
