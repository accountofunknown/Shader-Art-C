package com.shaderart.studio.core.presets

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.json.asList
import com.shaderart.studio.core.json.asObject
import com.shaderart.studio.core.json.optBool
import com.shaderart.studio.core.json.optFloat
import com.shaderart.studio.core.json.reqLong
import com.shaderart.studio.core.json.reqString
import com.shaderart.studio.core.model.ParamJson
import com.shaderart.studio.core.model.ParamValidator
import com.shaderart.studio.core.model.Performance
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.PresetCategory
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.shader.ShaderMetadataParser

class PresetException(message: String) : Exception(message)

/** Parses assets/presets/catalog.json. [readAsset] loads a shader file by its asset path. */
object PresetCatalogParser {
    fun parse(catalogJson: String, readAsset: (String) -> String): List<Preset> {
        try {
            val root = MiniJson.parseObject(catalogJson)
            val version = root.reqLong("catalogVersion")
            if (version != 1L) throw PresetException("Unsupported preset catalog version $version")
            val ids = HashSet<String>()
            return root["presets"].asList("presets").mapIndexed { i, entry ->
                val m = entry.asObject("presets[$i]")
                val id = m.reqString("id")
                if (!ids.add(id)) throw PresetException("Duplicate preset id '$id'")
                val catName = m.reqString("category")
                val category = PresetCategory.parse(catName) ?: throw PresetException("Preset '$id': unknown category '$catName'")
                val perfName = m.reqString("performance")
                val performance = Performance.entries.firstOrNull { it.name.equals(perfName, true) }
                    ?: throw PresetException("Preset '$id': unknown performance class '$perfName'")
                val params = m["params"].asList("params").mapIndexed { j, p -> ParamJson.fromMap(p.asObject("params[$j]")) }
                val problems = ParamValidator.validate(params)
                if (problems.isNotEmpty()) throw PresetException("Preset '$id': ${problems.first()}")
                val vertex = readAsset(m.reqString("vertexAsset"))
                val fragment = readAsset(m.reqString("fragmentAsset"))
                val srcProblems = GlslSourceCheck.check(vertex, "Vertex") + GlslSourceCheck.check(fragment, "Fragment")
                if (srcProblems.isNotEmpty()) throw PresetException("Preset '$id': ${srcProblems.first()}")
                // Every control must drive a uniform that the shader really declares.
                val declared = ShaderMetadataParser.declaredNames(fragment)
                val missing = params.firstOrNull { it.uniform !in declared }
                if (missing != null) throw PresetException("Preset '$id': control '${missing.id}' has no matching uniform in the shader")
                Preset(
                    id = id,
                    name = m.reqString("name"),
                    category = category,
                    description = m.reqString("description"),
                    performance = performance,
                    performanceNote = m.reqString("performanceNote"),
                    version = m.reqLong("version").toInt(),
                    seed = m.optFloat("seed", 0f),
                    previewTime = m.optFloat("previewTime", 3f),
                    animated = m.optBool("animated", true),
                    vertexSource = vertex,
                    fragmentSource = fragment,
                    params = params,
                )
            }
        } catch (e: JsonException) {
            throw PresetException(e.message ?: "Invalid preset catalog")
        }
    }
}
