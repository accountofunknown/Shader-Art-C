package com.shaderart.studio.core.export

import com.shaderart.studio.core.security.ImportLimits
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ImageFormat(val extension: String, val mime: String, val label: String) {
    PNG("png", "image/png", "PNG"),
    JPEG("jpg", "image/jpeg", "JPEG"),
}

data class ExportConfig(
    val width: Int,
    val height: Int,
    val format: ImageFormat = ImageFormat.PNG,
    /** JPEG quality 1..100 (ignored for PNG). */
    val quality: Int = 92,
    /** Shader time (seconds) to render. */
    val timeSeconds: Float = 0f,
)

data class SizePreset(val id: String, val label: String, val width: Int, val height: Int, val wallpaper: Boolean = false)

object ExportLimits {
    const val MIN_SIDE = 16
    const val MAX_SIDE = ImportLimits.MAX_RENDER_DIMENSION
    /** About 100 MB of RGBA pixels. Keeps the final bitmap within reach of typical app heaps. */
    const val MAX_PIXELS = 25_000_000L

    val PRESETS = listOf(
        SizePreset("square_1080", "Square 1080", 1080, 1080),
        SizePreset("square_2048", "Square 2048", 2048, 2048),
        SizePreset("landscape_hd", "Landscape 1920×1080", 1920, 1080),
        SizePreset("portrait_hd", "Portrait 1080×1920", 1080, 1920),
        SizePreset("uhd", "4K 3840×2160", 3840, 2160),
        SizePreset("wp_916", "Phone 9:16 · 1080×1920", 1080, 1920, wallpaper = true),
        SizePreset("wp_1950", "Phone 9:19.5 · 1080×2340", 1080, 2340, wallpaper = true),
        SizePreset("wp_920", "Phone 9:20 · 1080×2400", 1080, 2400, wallpaper = true),
        SizePreset("wp_921", "Phone 9:21 · 1080×2520", 1080, 2520, wallpaper = true),
        SizePreset("wp_qhd", "Phone QHD+ · 1440×3120", 1440, 3120, wallpaper = true),
    )

    /**
     * Returns a user-facing problem with [config], or null if it is acceptable.
     * @param gpuMaxSide the real maximum texture/renderbuffer size reported by the GPU, if known.
     */
    fun problem(config: ExportConfig, gpuMaxSide: Int? = null): String? {
        val w = config.width
        val h = config.height
        if (w < MIN_SIDE || h < MIN_SIDE) return "Width and height must be at least $MIN_SIDE px."
        if (w > MAX_SIDE || h > MAX_SIDE) return "Width and height can be at most $MAX_SIDE px."
        if (w.toLong() * h.toLong() > MAX_PIXELS) return "That is more than ${MAX_PIXELS / 1_000_000} megapixels. Choose a smaller size."
        if (gpuMaxSide != null && (w > gpuMaxSide || h > gpuMaxSide)) return "This GPU supports images up to $gpuMaxSide px per side."
        if (config.quality !in 1..100) return "JPEG quality must be between 1 and 100."
        if (!config.timeSeconds.isFinite() || config.timeSeconds < 0f) return "Time must be zero or greater."
        return null
    }

    /** Largest size with the same aspect ratio that fits the limits. */
    fun fit(width: Int, height: Int, gpuMaxSide: Int? = null): Pair<Int, Int> {
        if (width <= 0 || height <= 0) return MIN_SIDE to MIN_SIDE
        val side = minOf(MAX_SIDE, gpuMaxSide ?: MAX_SIDE)
        var scale = minOf(1.0, side.toDouble() / width, side.toDouble() / height)
        val pixels = width.toDouble() * height * scale * scale
        if (pixels > MAX_PIXELS) scale *= Math.sqrt(MAX_PIXELS / pixels)
        return maxOf(MIN_SIDE, (width * scale).toInt()) to maxOf(MIN_SIDE, (height * scale).toInt())
    }
}

object FileNaming {
    /** Safe file-name stem: letters, digits, dot, dash and underscore only, at most 48 characters. */
    fun sanitize(name: String): String {
        val s = name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_', '.', '-')
        return s.take(48).trim('_', '.', '-').ifEmpty { "shader" }
    }

    fun imageName(projectName: String, config: ExportConfig, nowMillis: Long): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(nowMillis))
        return "${sanitize(projectName)}_${config.width}x${config.height}_$stamp.${config.format.extension}"
    }

    fun sourceName(projectName: String, extension: String): String = "${sanitize(projectName)}.$extension"
}
