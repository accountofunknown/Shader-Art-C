package com.shaderart.studio.ui.screens

import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.EmptyState
import com.shaderart.studio.ui.components.ParamActions
import com.shaderart.studio.ui.components.ParamPanel
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.SecondaryButton

@Composable
fun VisualStudioScreen(
    vm: StudioViewModel,
    showPerformance: Boolean,
    onBrowsePresets: () -> Unit,
    onOpenGallery: () -> Unit,
    onOpenInCode: () -> Unit,
    onExport: () -> Unit,
) {
    val ui = vm.ui
    if (!ui.hasProject) {
        EmptyState(
            icon = R.drawable.ic_tune,
            title = "Visual Studio",
            body = "Pick a preset and shape it with sliders, colours and palettes. No code needed.",
            modifier = Modifier.fillMaxSize(),
        ) {
            PrimaryButton("Browse presets", onBrowsePresets, icon = R.drawable.ic_explore)
            SecondaryButton("Open from Gallery", onOpenGallery, icon = R.drawable.ic_gallery)
        }
        return
    }

    val actions = ParamActions(
        onValue = vm::setParam,
        onRandomize = vm::randomize,
        onVariation = vm::variation,
        onReset = vm::resetParams,
        onPalette = vm::applyPalette,
    )

    Column(Modifier.fillMaxSize()) {
        StudioHeader(vm) {
            SIconButton(R.drawable.ic_export, "Export image", onExport, enabled = !ui.needsRun)
        }
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val landscape = maxWidth > maxHeight
            if (landscape) {
                Row(Modifier.fillMaxSize()) {
                    StudioPreview(vm, showPerformance, Modifier.weight(1f).fillMaxSize())
                    PanelColumn(vm, actions, onOpenInCode, Modifier.weight(1f).fillMaxSize())
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    StudioPreview(vm, showPerformance, Modifier.fillMaxWidth().height(maxHeight * 0.42f))
                    PanelColumn(vm, actions, onOpenInCode, Modifier.weight(1f).fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun PanelColumn(vm: StudioViewModel, actions: ParamActions, onOpenInCode: () -> Unit, modifier: Modifier) {
    val ui = vm.ui
    Column(modifier.verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
        if (ui.type == ProjectType.VISUAL) {
            Text(
                "Presets are read-only code. Use the sliders below, or make an editable copy.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        ParamPanel(ui.params, ui.values, actions)
        ViewControls(vm)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
            SecondaryButton("Edit as code", onOpenInCode, Modifier.weight(1f), icon = R.drawable.ic_code)
        }
        Spacer(Modifier.height(24.dp))
    }
}
