package com.shaderart.studio.core.storage

import com.shaderart.studio.core.importing.ShaderArchive
import com.shaderart.studio.core.model.ProjectSummary
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.security.ImportLimits
import java.io.File
import java.io.IOException
import java.io.OutputStream
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

/** Metadata row kept in Room. Large content (shader sources) stays in app-private files. */
data class ProjectRow(
    val id: String,
    val name: String,
    val type: ProjectType,
    val createdAt: Long,
    val modifiedAt: Long,
    val lastOpenedAt: Long,
    val favorite: Boolean,
    val presetOrigin: String?,
    val hasThumbnail: Boolean,
)

/** Storage-agnostic index of projects. Room implements it on Android; tests use an in-memory version. */
interface ProjectIndex {
    fun observeAll(): Flow<List<ProjectRow>>
    suspend fun get(id: String): ProjectRow?
    suspend fun upsert(row: ProjectRow)
    suspend fun delete(id: String)
}

interface ProjectRepository {
    fun observeProjects(): Flow<List<ProjectSummary>>
    suspend fun load(id: String): ShaderProject
    suspend fun exists(id: String): Boolean
    suspend fun save(project: ShaderProject): ShaderProject
    suspend fun rename(id: String, name: String)
    suspend fun duplicate(id: String): String
    suspend fun delete(id: String)
    suspend fun setFavorite(id: String, favorite: Boolean)
    suspend fun markOpened(id: String)
    suspend fun saveThumbnail(id: String, jpegBytes: ByteArray)
    fun thumbnailFile(id: String): File
    suspend fun writeArchive(id: String, out: OutputStream)
    suspend fun importProject(project: ShaderProject, preview: ByteArray?): ShaderProject
}

class FileProjectRepository(
    private val root: File,
    private val index: ProjectIndex,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val idGenerator: () -> String = { ProjectIds.newId() },
    private val io: CoroutineDispatcher = Dispatchers.IO,
) : ProjectRepository {

    private val projectsDir get() = File(root, "projects")
    private val thumbsDir get() = File(root, "thumbnails")

    private fun dirOf(id: String): File {
        require(ImportLimits.isSafeProjectId(id)) { "Unsafe project id" }
        return File(projectsDir, id)
    }

    override fun observeProjects(): Flow<List<ProjectSummary>> = index.observeAll().map { rows ->
        rows.map {
            ProjectSummary(it.id, it.name, it.type, it.createdAt, it.modifiedAt, it.lastOpenedAt, it.favorite, it.presetOrigin, it.hasThumbnail)
        }
    }

    override suspend fun exists(id: String): Boolean = withContext(io) {
        ImportLimits.isSafeProjectId(id) && File(dirOf(id), MANIFEST).isFile
    }

    override suspend fun load(id: String): ShaderProject = withContext(io) {
        val dir = dirOf(id)
        val manifest = File(dir, MANIFEST)
        if (!manifest.isFile) throw ProjectFormatException("Project files are missing")
        val project = try {
            ProjectSerializer.fromManifestJson(
                manifest.readText(Charsets.UTF_8),
                File(dir, VERTEX).readText(Charsets.UTF_8),
                File(dir, FRAGMENT).readText(Charsets.UTF_8),
            )
        } catch (e: IOException) {
            throw ProjectFormatException("Project files could not be read: ${e.message}")
        }
        if (project.id != id) throw ProjectFormatException("Project id does not match its folder")
        project
    }

    override suspend fun save(project: ShaderProject): ShaderProject = withContext(io) {
        val dir = dirOf(project.id)
        val now = clock()
        val saved = project.copy(modifiedAt = now, formatVersion = ProjectSerializer.CURRENT_FORMAT)
        AtomicFiles.writeText(File(dir, VERTEX), saved.vertexSource)
        AtomicFiles.writeText(File(dir, FRAGMENT), saved.fragmentSource)
        AtomicFiles.writeText(File(dir, MANIFEST), ProjectSerializer.toManifestJson(saved))
        val old = index.get(saved.id)
        index.upsert(
            ProjectRow(
                id = saved.id,
                name = saved.name,
                type = saved.type,
                createdAt = old?.createdAt ?: saved.createdAt,
                modifiedAt = now,
                lastOpenedAt = old?.lastOpenedAt ?: now,
                favorite = old?.favorite ?: false,
                presetOrigin = saved.presetOrigin,
                hasThumbnail = old?.hasThumbnail ?: false,
            ),
        )
        saved
    }

    override suspend fun rename(id: String, name: String) {
        val clean = name.trim()
        require(clean.isNotEmpty() && clean.length <= ImportLimits.MAX_NAME_LENGTH) { "Name must be 1-${ImportLimits.MAX_NAME_LENGTH} characters" }
        save(load(id).copy(name = clean))
    }

    override suspend fun duplicate(id: String): String {
        val src = load(id)
        val newId = idGenerator()
        val now = clock()
        val copy = src.copy(id = newId, name = "${src.name} copy".take(ImportLimits.MAX_NAME_LENGTH), createdAt = now, modifiedAt = now)
        save(copy)
        withContext(io) {
            val thumb = thumbnailFile(id)
            if (thumb.isFile) {
                AtomicFiles.write(thumbnailFile(newId), thumb.readBytes())
                index.get(newId)?.let { index.upsert(it.copy(hasThumbnail = true)) }
            }
        }
        return newId
    }

    override suspend fun delete(id: String) = withContext(io) {
        AtomicFiles.deleteRecursively(dirOf(id))
        thumbnailFile(id).delete()
        index.delete(id)
    }

    override suspend fun setFavorite(id: String, favorite: Boolean) {
        index.get(id)?.let { index.upsert(it.copy(favorite = favorite)) }
    }

    override suspend fun markOpened(id: String) {
        index.get(id)?.let { index.upsert(it.copy(lastOpenedAt = clock())) }
    }

    override suspend fun saveThumbnail(id: String, jpegBytes: ByteArray) = withContext(io) {
        AtomicFiles.write(thumbnailFile(id), jpegBytes)
        index.get(id)?.let { index.upsert(it.copy(hasThumbnail = true)) }
        Unit
    }

    override fun thumbnailFile(id: String): File {
        require(ImportLimits.isSafeProjectId(id)) { "Unsafe project id" }
        return File(thumbsDir, "$id.jpg")
    }

    override suspend fun writeArchive(id: String, out: OutputStream) {
        val project = load(id)
        val thumb = withContext(io) { thumbnailFile(id).takeIf { it.isFile }?.readBytes() }
        withContext(io) { ShaderArchive.write(project, thumb, previewIsJpeg = true, out = out) }
    }

    /** Imported projects always get a fresh id, so an import can never overwrite an existing project. */
    override suspend fun importProject(project: ShaderProject, preview: ByteArray?): ShaderProject {
        val now = clock()
        val fresh = project.copy(id = idGenerator(), createdAt = now, modifiedAt = now)
        val saved = save(fresh)
        if (preview != null) {
            // Archive previews may be PNG or JPEG; the gallery only needs something decodable, so store as-is.
            withContext(io) { AtomicFiles.write(thumbnailFile(saved.id), preview) }
            index.get(saved.id)?.let { index.upsert(it.copy(hasThumbnail = true)) }
        }
        return saved
    }

    private companion object {
        const val MANIFEST = "manifest.json"
        const val VERTEX = "vertex.vert"
        const val FRAGMENT = "fragment.frag"
    }
}
