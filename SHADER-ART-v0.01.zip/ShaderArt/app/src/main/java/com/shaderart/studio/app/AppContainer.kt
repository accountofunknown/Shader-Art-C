package com.shaderart.studio.app

import android.content.Context
import androidx.room.Room
import com.shaderart.studio.core.export.ExportEngine
import com.shaderart.studio.core.gpu.DeviceGles
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.importing.ImportService
import com.shaderart.studio.core.importing.UriIO
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.core.storage.AppDatabase
import com.shaderart.studio.core.storage.FileProjectRepository
import com.shaderart.studio.core.storage.ProjectRepository
import com.shaderart.studio.core.storage.RoomProjectIndex
import com.shaderart.studio.feature.settings.SettingsRepository
import com.shaderart.studio.feature.settings.settingsDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Hand-wired dependencies (no DI framework). Created once by [ShaderArtApp]. */
class AppContainer(context: Context) {
    private val app = context.applicationContext

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val presets = PresetRepository(app.assets)
    private val database = Room.databaseBuilder(app, AppDatabase::class.java, "shaderart.db").build()
    val projects: ProjectRepository = FileProjectRepository(app.filesDir, RoomProjectIndex(database.projectDao()))
    val settings = SettingsRepository(app.settingsDataStore)
    val export = ExportEngine(app.cacheDir)
    val uriIO = UriIO(app.contentResolver)
    val importer = ImportService(uriIO, projects, presets)

    /** False on devices that cannot run OpenGL ES 3.0: the app then shows a compatibility message. */
    val gles3Supported: Boolean = DeviceGles.supportsEs3(app)
    val reportedGlesVersion: Int = DeviceGles.reportedVersion(app)

    private val _lastCapabilities = MutableStateFlow<ShaderCapabilities?>(null)
    /** GPU information from the most recent real GL context (null until a studio or export has run). */
    val lastCapabilities: StateFlow<ShaderCapabilities?> = _lastCapabilities

    fun reportCapabilities(c: ShaderCapabilities) { _lastCapabilities.value = c }
}
