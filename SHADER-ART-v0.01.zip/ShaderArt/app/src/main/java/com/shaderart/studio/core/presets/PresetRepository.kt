package com.shaderart.studio.core.presets

import android.content.res.AssetManager
import com.shaderart.studio.core.model.Preset

data class ShaderTemplate(val id: String, val name: String, val description: String, val asset: String)

/** Loads the bundled preset catalog and code templates. Everything works offline from app assets. */
class PresetRepository(private val assets: AssetManager) {
    val templates = listOf(
        ShaderTemplate("default", "Default", "Gradient wave with touch glow. Shows every standard uniform.", "templates/default.frag"),
        ShaderTemplate("plasma", "Plasma", "Classic animated sine plasma with colour controls.", "templates/plasma.frag"),
        ShaderTemplate("sphere", "Raymarched sphere", "A lit sphere found by sphere tracing (64 step cap).", "templates/sphere.frag"),
        ShaderTemplate("clouds", "Noise clouds", "Fractal value noise with drifting motion.", "templates/clouds.frag"),
    )

    private val loaded: Result<List<Preset>> by lazy {
        runCatching { PresetCatalogParser.parse(read("presets/catalog.json")) { read(it) } }
    }

    /** All presets, or the reason the catalog could not be loaded. */
    val catalog: Result<List<Preset>> get() = loaded

    val presets: List<Preset> get() = loaded.getOrDefault(emptyList())

    fun get(id: String): Preset? = presets.firstOrNull { it.id == id }

    val vertexSource: String by lazy { read("shaders/fullscreen.vert") }

    fun templateSource(id: String): String {
        val t = templates.firstOrNull { it.id == id } ?: templates.first()
        return read(t.asset)
    }

    private fun read(path: String): String = assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
}
