package com.shaderart.studio.feature.studio

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shaderart.studio.app.AppContainer
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.compiler.ShaderStage
import com.shaderart.studio.core.importing.ORIGIN_IMPORTED
import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.renderer.CompileReport
import com.shaderart.studio.core.renderer.RenderNotice
import com.shaderart.studio.core.renderer.RenderSession
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.shader.ShaderMetadataParser
import com.shaderart.studio.core.storage.ProjectFactory
import com.shaderart.studio.core.storage.ProjectIds
import com.shaderart.studio.feature.codeeditor.AutoIndent
import com.shaderart.studio.feature.codeeditor.CodeFormatter
import com.shaderart.studio.feature.codeeditor.Completion
import com.shaderart.studio.feature.codeeditor.EditorHistory
import com.shaderart.studio.feature.codeeditor.FindEngine
import com.shaderart.studio.feature.codeeditor.LineUtil
import com.shaderart.studio.feature.export.ExportController
import com.shaderart.studio.feature.params.Palette
import com.shaderart.studio.feature.params.Palettes
import com.shaderart.studio.feature.settings.AppSettings
import kotlin.random.Random
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

enum class EditorTab { FRAGMENT, VERTEX }
enum class BottomTab { OUTPUT, UNIFORMS, INFO }

data class FindState(
    val visible: Boolean = false,
    val query: String = "",
    val caseSensitive: Boolean = false,
    val matches: List<Int> = emptyList(),
    /** Index into [matches], -1 when there is none. */
    val current: Int = -1,
)

/** Asks the editor to scroll a line into view. A new [id] means a new request. */
data class ScrollRequest(val line: Int, val id: Int)

data class StudioUi(
    val hasProject: Boolean = false,
    val projectId: String? = null,
    val name: String = "",
    val type: ProjectType = ProjectType.VISUAL,
    val createdAt: Long = 0L,
    val presetOrigin: String? = null,
    /** True once the project exists in the library. Presets and templates start as unsaved drafts. */
    val saved: Boolean = false,
    val dirty: Boolean = false,
    /** Imported shaders do not run until the user presses Run. */
    val needsRun: Boolean = false,

    val params: List<ParamDef> = emptyList(),
    val values: Map<String, List<Float>> = emptyMap(),
    val playing: Boolean = true,
    val speed: Float = 1f,
    val zoom: Float = 1f,
    val quality: Float = 1f,

    val fragment: TextFieldValue = TextFieldValue(""),
    val vertex: TextFieldValue = TextFieldValue(""),
    val tab: EditorTab = EditorTab.FRAGMENT,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val suggestions: List<String> = emptyList(),
    val find: FindState = FindState(),
    val scroll: ScrollRequest? = null,

    val autoCompile: Boolean = true,
    val compiling: Boolean = false,
    /** null = not compiled yet. */
    val compileOk: Boolean? = null,
    val lastCompileMs: Long = 0L,
    val diagnostics: List<ShaderDiagnostic> = emptyList(),
    /** True when the text has changed since the last successful submit to the GPU. */
    val sourceChanged: Boolean = false,
    val bottom: BottomTab = BottomTab.OUTPUT,
)

/**
 * State and logic shared by Visual Studio and Code Studio. The editor text lives in Compose snapshot
 * state (not a Flow) because text fields must see their own writes synchronously. Everything here runs on
 * the main thread; GPU work happens on the renderer's thread behind [session].
 */
class StudioViewModel(private val container: AppContainer) : ViewModel() {

    val session = RenderSession()

    var ui by mutableStateOf(StudioUi())
        private set

    /** Settings mirror, used for defaults of new projects. */
    var appSettings by mutableStateOf(AppSettings())
        private set

    /** Set while a "discard unsaved changes?" question is open; holds what to do on confirmation. */
    var discardPrompt: (() -> Unit)? by mutableStateOf(null)
        private set

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val export = ExportController(container, viewModelScope) { exportableProject() }

    private val fragHistory = EditorHistory()
    private val vertHistory = EditorHistory()
    private var autoJob: Job? = null
    private var pendingGeneration = -1
    private var reportedGeneration = -2
    private var trusted = true
    private var scrollCounter = 0
    private val random = Random(System.nanoTime())

    /** What a "Save as" destination will receive; kept here so it survives a configuration change. */
    var pendingFileSave: PendingFileSave? = null

    init {
        viewModelScope.launch { session.compile.collect { onCompile(it) } }
        viewModelScope.launch { session.notices.collect { onNotice(it) } }
        viewModelScope.launch { session.capabilities.filterNotNull().collect { container.reportCapabilities(it) } }
        viewModelScope.launch {
            container.settings.settings.collect { s ->
                appSettings = s
                session.setMaxFps(if (s.limitTo30Fps) 30 else 0)
            }
        }
    }

    private fun say(text: String) { _messages.tryEmit(text) }

    // ------------------------------------------------------------------ opening projects

    /** Runs [action] now, or after the user agrees to drop unsaved changes. */
    fun requestOpen(action: () -> Unit) {
        if (ui.hasProject && ui.dirty) discardPrompt = action else action()
    }

    fun confirmDiscard() {
        val a = discardPrompt
        discardPrompt = null
        a?.invoke()
    }

    fun cancelDiscard() { discardPrompt = null }

    fun openPreset(presetId: String) {
        val preset = container.presets.get(presetId)
        if (preset == null) { say("That preset could not be found."); return }
        val base = ProjectFactory.fromPreset(preset, ProjectIds.newId(), System.currentTimeMillis())
        load(base.copy(render = base.render.copy(qualityScale = appSettings.qualityScale)), saved = false, trusted = true)
    }

    fun newCode(templateId: String) {
        val t = container.presets.templates.firstOrNull { it.id == templateId } ?: container.presets.templates.first()
        val source = try { container.presets.templateSource(t.id) } catch (e: Exception) { say("Could not load the template: ${e.message}"); return }
        val base = ProjectFactory.newCode("New ${t.name}", ProjectIds.newId(), System.currentTimeMillis(), container.presets.vertexSource, source)
        load(base.copy(render = base.render.copy(qualityScale = appSettings.qualityScale)), saved = false, trusted = true)
    }

    /** Loads a saved project; [onLoaded] runs only after it has really been loaded (used to navigate). */
    fun openProject(id: String, onLoaded: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                val p = container.projects.load(id)
                container.projects.markOpened(id)
                load(p, saved = true, trusted = p.presetOrigin != ORIGIN_IMPORTED)
                onLoaded()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Could not open the project: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Turns the current visual project into an editable code project (a new unsaved draft). */
    fun openInCode() {
        val p = currentProject() ?: return
        val copy = p.copy(
            id = ProjectIds.newId(),
            name = (p.name + " (code)").take(ImportLimits.MAX_NAME_LENGTH),
            type = ProjectType.CODE,
            createdAt = System.currentTimeMillis(),
        )
        load(copy, saved = false, trusted = trusted)
        // Keep it unsaved but flag it as changed so the user is asked before losing it.
        ui = ui.copy(dirty = true)
    }

    private fun load(p: ShaderProject, saved: Boolean, trusted: Boolean) {
        autoJob?.cancel()
        fragHistory.clear()
        vertHistory.clear()
        this.trusted = trusted
        val values = ParamLogic.normalize(p.params, p.values)
        val playing = p.animation.playing && trusted
        ui = StudioUi(
            hasProject = true,
            projectId = p.id,
            name = p.name,
            type = p.type,
            createdAt = p.createdAt,
            presetOrigin = p.presetOrigin,
            saved = saved,
            dirty = false,
            needsRun = !trusted,
            params = p.params,
            values = values,
            playing = playing,
            speed = p.animation.speed,
            zoom = p.render.zoom,
            quality = p.render.qualityScale.coerceIn(0.25f, 1f),
            fragment = TextFieldValue(p.fragmentSource),
            vertex = TextFieldValue(p.vertexSource),
            autoCompile = ui.autoCompile,
            diagnostics = if (trusted) emptyList() else listOf(
                ShaderDiagnostic(ShaderStage.CONTEXT, Severity.INFO, null, "This shader was imported. Read it first, then press Run to compile and start it."),
            ),
        )
        session.setSpeed(p.animation.speed)
        session.setZoom(p.render.zoom)
        session.setPlaying(playing)
        session.updateParams(p.params, values)
        session.seek(p.animation.time)
        if (trusted) submit() else session.requestFrame()
    }

    // ------------------------------------------------------------------ compiling

    fun run() {
        if (!ui.hasProject) return
        autoJob?.cancel()
        trusted = true
        if (ui.needsRun) {
            ui = ui.copy(needsRun = false, playing = true)
            session.setPlaying(true)
        }
        submit()
    }

    fun stop() {
        ui = ui.copy(playing = false)
        session.setPlaying(false)
    }

    fun setAutoCompile(on: Boolean) {
        ui = ui.copy(autoCompile = on)
        if (on) scheduleAutoCompile() else autoJob?.cancel()
    }

    private fun scheduleAutoCompile() {
        autoJob?.cancel()
        if (!ui.autoCompile || !trusted || ui.type != ProjectType.CODE) return
        autoJob = viewModelScope.launch {
            delay(AUTO_COMPILE_DELAY_MS)
            submit()
        }
    }

    private fun submit() {
        val frag = ui.fragment.text
        val vert = ui.vertex.text
        val problems = GlslSourceCheck.check(vert, "Vertex").map { ShaderDiagnostic(ShaderStage.VERTEX, Severity.ERROR, null, it) } +
            GlslSourceCheck.check(frag, "Fragment").map { ShaderDiagnostic(ShaderStage.FRAGMENT, Severity.ERROR, null, it) }
        if (problems.isNotEmpty()) {
            ui = ui.copy(compiling = false, compileOk = false, diagnostics = problems)
            return
        }
        if (ui.type == ProjectType.CODE) {
            val parsed = ShaderMetadataParser.toParamDefs(ShaderMetadataParser.declaredUniforms(frag))
            val merged = mergeParams(ui.params, parsed)
            if (merged != ui.params) {
                ui = ui.copy(params = merged, values = ParamLogic.normalize(merged, ui.values))
            }
        }
        session.updateParams(ui.params, ui.values)
        pendingGeneration = session.submitSources(vert, frag)
        ui = ui.copy(compiling = true, sourceChanged = false)
    }

    /**
     * Custom (annotation-derived) controls follow the source: their range and label update when the
     * annotation changes. Everything else keeps its definition, and so keeps the user's value.
     */
    private fun mergeParams(existing: List<ParamDef>, parsed: List<ParamDef>): List<ParamDef> {
        val byUniform = parsed.associateBy { it.uniform }
        val refreshed = existing.map { e -> if (e.group == "Custom") byUniform[e.uniform] ?: e else e }
        return ShaderMetadataParser.merge(refreshed, parsed)
    }

    private fun onCompile(r: CompileReport) {
        if (r.millis < 0) {
            // Uniform warnings for the program that is currently running.
            if (r.generation != reportedGeneration) return
            ui = ui.copy(diagnostics = ui.diagnostics.filter { it.stage != ShaderStage.UNIFORM } + r.diagnostics)
            return
        }
        if (r.generation < pendingGeneration) return // a newer compile is already on its way
        reportedGeneration = r.generation
        ui = ui.copy(compiling = false, compileOk = r.success, lastCompileMs = r.millis, diagnostics = r.diagnostics)
    }

    private fun onNotice(n: RenderNotice) {
        when (n) {
            is RenderNotice.AutoPaused -> {
                ui = ui.copy(playing = false)
                session.setPlaying(false)
                say("This shader is very slow on this device, so animation was paused. Lower the quality or simplify the shader.")
            }
            is RenderNotice.GlError -> say(n.message)
        }
    }

    // ------------------------------------------------------------------ parameters and playback

    private fun pushParams() = session.updateParams(ui.params, ui.values)

    fun setParam(def: ParamDef, index: Int, raw: Float) {
        ui = ui.copy(values = ParamLogic.withValue(ui.values, def, index, raw), dirty = true)
        pushParams()
    }

    fun randomize() { ui = ui.copy(values = ParamLogic.randomize(ui.params, ui.values, random), dirty = true); pushParams() }
    fun variation() { ui = ui.copy(values = ParamLogic.variation(ui.params, ui.values, random), dirty = true); pushParams() }
    fun resetParams() { ui = ui.copy(values = ParamLogic.defaults(ui.params), dirty = true); pushParams() }
    fun applyPalette(p: Palette) { ui = ui.copy(values = Palettes.apply(p, ui.params, ui.values), dirty = true); pushParams() }

    fun togglePlay() {
        val next = !ui.playing
        ui = ui.copy(playing = next)
        session.setPlaying(next)
    }

    fun restart() { session.seek(0f); session.requestFrame() }

    fun setSpeed(s: Float) {
        val v = s.coerceIn(0f, 4f)
        ui = ui.copy(speed = v, dirty = true)
        session.setSpeed(v)
    }

    fun setZoom(z: Float) {
        val v = z.coerceIn(0.25f, 8f)
        ui = ui.copy(zoom = v, dirty = true)
        session.setZoom(v)
    }

    fun onPinch(factor: Float) { if (factor.isFinite() && factor > 0f) setZoom(ui.zoom * factor) }

    fun setQuality(q: Float) { ui = ui.copy(quality = q.coerceIn(0.25f, 1f), dirty = true) }

    fun setBottom(tab: BottomTab) { ui = ui.copy(bottom = tab) }

    // ------------------------------------------------------------------ editor

    private fun buffer(tab: EditorTab) = if (tab == EditorTab.FRAGMENT) ui.fragment else ui.vertex
    private fun history(tab: EditorTab) = if (tab == EditorTab.FRAGMENT) fragHistory else vertHistory

    private fun setBuffer(tab: EditorTab, v: TextFieldValue) {
        ui = if (tab == EditorTab.FRAGMENT) ui.copy(fragment = v) else ui.copy(vertex = v)
    }

    fun selectTab(tab: EditorTab) {
        ui = ui.copy(tab = tab)
        refreshAfterEdit()
    }

    fun onEditorChange(new: TextFieldValue) {
        val tab = ui.tab
        val old = buffer(tab)
        if (new.text == old.text) {
            setBuffer(tab, new)
            ui = ui.copy(suggestions = suggestionsFor(new))
            return
        }
        if (new.text.length > ImportLimits.MAX_SOURCE_BYTES) {
            say("The shader is too large (limit ${ImportLimits.MAX_SOURCE_BYTES / 1024} KB).")
            return
        }
        var applied = new
        AutoIndent.onTyped(old.text, new.text, new.selection.start)?.let { applied = TextFieldValue(it.text, TextRange(it.cursor)) }
        history(tab).beforeChange(EditorHistory.Snapshot(old.text, old.selection.start), SystemClock.elapsedRealtime())
        setBuffer(tab, applied)
        afterTextChange()
    }

    private fun afterTextChange() {
        ui = ui.copy(dirty = true, sourceChanged = true)
        refreshAfterEdit()
        scheduleAutoCompile()
    }

    private fun refreshAfterEdit() {
        val tab = ui.tab
        val b = buffer(tab)
        val h = history(tab)
        var find = ui.find
        if (find.visible) {
            val matches = FindEngine.findAll(b.text, find.query, find.caseSensitive)
            find = find.copy(matches = matches, current = if (matches.isEmpty()) -1 else find.current.coerceIn(0, matches.lastIndex))
        }
        ui = ui.copy(canUndo = h.canUndo, canRedo = h.canRedo, suggestions = suggestionsFor(b), find = find)
    }

    private fun suggestionsFor(v: TextFieldValue): List<String> =
        if (v.selection.collapsed) Completion.suggest(v.text, v.selection.start) else emptyList()

    fun undo() {
        val tab = ui.tab
        val cur = buffer(tab)
        val snap = history(tab).undo(EditorHistory.Snapshot(cur.text, cur.selection.start)) ?: return
        setBuffer(tab, TextFieldValue(snap.text, TextRange(snap.cursor.coerceIn(0, snap.text.length))))
        afterTextChange()
    }

    fun redo() {
        val tab = ui.tab
        val cur = buffer(tab)
        val snap = history(tab).redo(EditorHistory.Snapshot(cur.text, cur.selection.start)) ?: return
        setBuffer(tab, TextFieldValue(snap.text, TextRange(snap.cursor.coerceIn(0, snap.text.length))))
        afterTextChange()
    }

    fun format() {
        val tab = ui.tab
        val cur = buffer(tab)
        val formatted = CodeFormatter.format(cur.text)
        if (formatted == cur.text) return
        history(tab).beforeChange(EditorHistory.Snapshot(cur.text, cur.selection.start), SystemClock.elapsedRealtime(), forceBreak = true)
        setBuffer(tab, TextFieldValue(formatted, TextRange(cur.selection.start.coerceIn(0, formatted.length))))
        afterTextChange()
    }

    fun insertText(text: String) {
        val tab = ui.tab
        val cur = buffer(tab)
        val s = cur.selection.min
        val e = cur.selection.max
        val next = cur.text.substring(0, s) + text + cur.text.substring(e)
        onEditorChange(TextFieldValue(next, TextRange(s + text.length)))
    }

    fun applySuggestion(s: String) {
        val tab = ui.tab
        val cur = buffer(tab)
        val r = Completion.apply(cur.text, cur.selection.start, s)
        history(tab).beforeChange(EditorHistory.Snapshot(cur.text, cur.selection.start), SystemClock.elapsedRealtime(), forceBreak = true)
        setBuffer(tab, TextFieldValue(r.text, TextRange(r.cursor)))
        afterTextChange()
    }

    /** Moves the cursor to the start of 1-based [line] in the tab that [stage] belongs to, and scrolls there. */
    fun goToLine(stage: ShaderStage, line: Int) {
        val tab = if (stage == ShaderStage.VERTEX) EditorTab.VERTEX else EditorTab.FRAGMENT
        val text = buffer(tab).text
        val offset = LineUtil.offsetOfLine(text, line.coerceAtLeast(1))
        ui = ui.copy(tab = tab)
        setBuffer(tab, TextFieldValue(text, TextRange(offset)))
        ui = ui.copy(scroll = ScrollRequest(line.coerceAtLeast(1), ++scrollCounter))
        refreshAfterEdit()
    }

    // ------------------------------------------------------------------ find

    fun toggleFind() {
        val visible = !ui.find.visible
        ui = ui.copy(find = ui.find.copy(visible = visible))
        if (visible) updateFind(ui.find.query, ui.find.caseSensitive)
    }

    fun updateFind(query: String, caseSensitive: Boolean = ui.find.caseSensitive) {
        val text = buffer(ui.tab).text
        val matches = FindEngine.findAll(text, query, caseSensitive)
        val cursor = buffer(ui.tab).selection.start
        val cur = FindEngine.nextIndex(matches, cursor)
        ui = ui.copy(find = ui.find.copy(query = query, caseSensitive = caseSensitive, matches = matches, current = cur))
        if (cur >= 0) selectMatch(cur)
    }

    fun findNext() {
        val f = ui.find
        if (f.matches.isEmpty()) return
        selectMatch((f.current + 1) % f.matches.size)
    }

    fun findPrevious() {
        val f = ui.find
        if (f.matches.isEmpty()) return
        selectMatch(if (f.current <= 0) f.matches.lastIndex else f.current - 1)
    }

    private fun selectMatch(index: Int) {
        val f = ui.find
        val start = f.matches.getOrNull(index) ?: return
        val tab = ui.tab
        val text = buffer(tab).text
        setBuffer(tab, TextFieldValue(text, TextRange(start, (start + f.query.length).coerceAtMost(text.length))))
        ui = ui.copy(
            find = f.copy(current = index),
            scroll = ScrollRequest(LineUtil.lineOfOffset(text, start), ++scrollCounter),
        )
    }

    // ------------------------------------------------------------------ project data

    fun rename(name: String) {
        val n = name.trim().take(ImportLimits.MAX_NAME_LENGTH)
        if (n.isEmpty()) return
        ui = ui.copy(name = n, dirty = true)
    }

    /** The project as currently edited (not necessarily saved). Null when nothing is open. */
    fun currentProject(): ShaderProject? {
        val u = ui
        val id = u.projectId ?: return null
        if (!u.hasProject) return null
        val stats = session.stats.value
        return ShaderProject(
            id = id,
            name = u.name,
            type = u.type,
            createdAt = u.createdAt,
            modifiedAt = System.currentTimeMillis(),
            vertexSource = u.vertex.text,
            fragmentSource = u.fragment.text,
            params = u.params,
            values = ParamLogic.normalize(u.params, u.values),
            animation = AnimationConfig(playing = u.playing, speed = u.speed, time = stats.timeSeconds),
            render = RenderSettings(qualityScale = u.quality, previewWidth = stats.width, previewHeight = stats.height, zoom = u.zoom),
            presetOrigin = u.presetOrigin,
        )
    }

    /** Like [currentProject], but null while an imported shader has not been run (it must not execute unasked). */
    private fun exportableProject(): ShaderProject? = if (ui.needsRun) null else currentProject()

    fun save() {
        val p = currentProject() ?: return
        viewModelScope.launch {
            try {
                val saved = container.projects.save(p)
                ui = ui.copy(saved = true, dirty = false, projectId = saved.id)
                say("Saved “${saved.name}”.")
                if (!ui.needsRun) {
                    try {
                        container.projects.saveThumbnail(saved.id, container.export.renderThumbnail(saved))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        say("Saved, but the thumbnail could not be created: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Could not save: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Saves the project (if needed) and returns its id, for actions that need it in the library. */
    suspend fun ensureSaved(): String? {
        val p = currentProject() ?: return null
        if (ui.saved && !ui.dirty) return p.id
        return try {
            val saved = container.projects.save(p)
            ui = ui.copy(saved = true, dirty = false, projectId = saved.id)
            saved.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            say("Could not save: ${e.message ?: "unknown error"}")
            null
        }
    }

    fun message(text: String) = say(text)

    override fun onCleared() {
        autoJob?.cancel()
        export.cancel()
        super.onCleared()
    }

    private companion object {
        const val AUTO_COMPILE_DELAY_MS = 700L
    }
}

/** What the next system "create document" result should write. */
sealed class PendingFileSave {
    data class Source(val text: String) : PendingFileSave()
    data object Archive : PendingFileSave()
}
