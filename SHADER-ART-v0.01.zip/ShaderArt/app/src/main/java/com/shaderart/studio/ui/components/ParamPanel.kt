package com.shaderart.studio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.feature.params.Palette
import com.shaderart.studio.feature.params.Palettes
import com.shaderart.studio.ui.theme.ShaderArtColors
import java.util.Locale

/** Everything the panel can ask the host to do. Keeps the panel free of any ViewModel dependency. */
class ParamActions(
    val onValue: (ParamDef, Int, Float) -> Unit,
    val onRandomize: () -> Unit,
    val onVariation: () -> Unit,
    val onReset: () -> Unit,
    val onPalette: (Palette) -> Unit,
)

/**
 * The parameter UI. It is generated entirely from [params]: there is no per-preset control code.
 * Parameters are grouped by their `group` metadata.
 */
@Composable
fun ParamPanel(
    params: List<ParamDef>,
    values: Map<String, List<Float>>,
    actions: ParamActions,
    modifier: Modifier = Modifier,
) {
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            SecondaryButton("Randomize", actions.onRandomize, Modifier.weight(1f), icon = R.drawable.ic_shuffle)
            SecondaryButton("Variation", actions.onVariation, Modifier.weight(1f), icon = R.drawable.ic_sparkle)
            SecondaryButton("Reset", actions.onReset, Modifier.weight(1f), icon = R.drawable.ic_refresh)
        }

        if (Palettes.targets(params).isNotEmpty()) {
            SectionLabel("Palettes")
            LazyRow(
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                items(Palettes.ALL, key = { it.name }) { palette -> PaletteChip(palette) { actions.onPalette(palette) } }
            }
        }

        if (params.isEmpty()) {
            Text(
                "This shader has no adjustable parameters. In Code Studio, declare a uniform with an annotation such as // @slider 0 1 0.5 \"Amount\".",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp),
            )
        }

        val groups = params.groupBy { it.group ?: "General" }
        for ((group, defs) in groups) {
            SectionLabel(group)
            for (def in defs) {
                val current = values[def.id] ?: def.defaults
                androidx.compose.runtime.key(def.id) {
                    when (def.type) {
                        ParamType.FLOAT, ParamType.INT -> NumberParam(def, current.firstOrNull() ?: def.defaults[0], actions.onValue)
                        ParamType.BOOL -> ToggleParam(def, (current.firstOrNull() ?: 0f) >= 0.5f, actions.onValue)
                        ParamType.COLOR -> ColorParam(def, current, actions.onValue)
                    }
                }
            }
        }
    }
}

private fun format(def: ParamDef, v: Float): String =
    if (def.type == ParamType.INT) v.toInt().toString()
    else String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

@Composable
private fun NumberParam(def: ParamDef, value: Float, onValue: (ParamDef, Int, Float) -> Unit) {
    val range = if (def.max > def.min) def.min..def.max else def.min..(def.min + 1f)
    var text by remember(def.id) { mutableStateOf("") }
    var editing by remember(def.id) { mutableStateOf(false) }
    // While the user types, show their text; otherwise always show the real value (slider, randomize, reset).
    val shown = if (editing) text else format(def, value)

    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(def.name, style = MaterialTheme.typography.bodyMedium)
                if (def.description.isNotBlank()) {
                    Text(def.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                }
            }
            OutlinedTextField(
                value = shown,
                onValueChange = { s ->
                    editing = true
                    text = s
                    s.toFloatOrNull()?.let { if (it.isFinite()) onValue(def, 0, it) }
                },
                modifier = Modifier
                    .width(96.dp)
                    .onFocusChanged { if (!it.isFocused) editing = false }
                    .semantics { contentDescription = "${def.name} value" },
                singleLine = true,
                textStyle = MaterialTheme.typography.bodyMedium,
                keyboardOptions = KeyboardOptions(keyboardType = if (def.type == ParamType.INT) KeyboardType.Number else KeyboardType.Decimal),
            )
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive),
            onValueChange = { editing = false; onValue(def, 0, it) },
            valueRange = range,
            steps = if (def.type == ParamType.INT && (def.max - def.min) in 2f..64f) (def.max - def.min).toInt() - 1 else 0,
            colors = SliderDefaults.colors(
                thumbColor = Color.White, activeTrackColor = Color.White,
                inactiveTrackColor = ShaderArtColors.Border, activeTickColor = Color.Black, inactiveTickColor = ShaderArtColors.Disabled,
            ),
            modifier = Modifier.semantics { contentDescription = def.name },
        )
    }
}

@Composable
private fun ToggleParam(def: ParamDef, on: Boolean, onValue: (ParamDef, Int, Float) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(def.name, style = MaterialTheme.typography.bodyMedium)
            if (def.description.isNotBlank()) {
                Text(def.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
        }
        Switch(
            checked = on,
            onCheckedChange = { onValue(def, 0, if (it) 1f else 0f) },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = Color.White,
                uncheckedThumbColor = ShaderArtColors.TextSecondary, uncheckedTrackColor = ShaderArtColors.Graphite,
            ),
            modifier = Modifier.semantics { contentDescription = def.name },
        )
    }
}

private fun toColor(v: List<Float>): Color =
    Color(v.getOrElse(0) { 1f }.coerceIn(0f, 1f), v.getOrElse(1) { 1f }.coerceIn(0f, 1f), v.getOrElse(2) { 1f }.coerceIn(0f, 1f))

private fun toHex(v: List<Float>): String {
    fun c(i: Int) = (v.getOrElse(i) { 1f }.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
    return String.format(Locale.US, "#%02X%02X%02X", c(0), c(1), c(2))
}

private fun parseHex(s: String): List<Float>? {
    val t = s.trim().removePrefix("#")
    if (t.length != 6 || !t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
    val n = t.toInt(16)
    return listOf(((n shr 16) and 0xFF) / 255f, ((n shr 8) and 0xFF) / 255f, (n and 0xFF) / 255f)
}

@Composable
private fun ColorParam(def: ParamDef, value: List<Float>, onValue: (ParamDef, Int, Float) -> Unit) {
    var open by remember(def.id) { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clickableWithRole { open = true }.padding(horizontal = 16.dp, vertical = 8.dp)
            .semantics { contentDescription = "${def.name}, colour ${toHex(value)}. Opens colour picker" },
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(def.name, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Text(toHex(value), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.size(32.dp).clip(CircleShape).background(toColor(value)).border(1.dp, Color.White, CircleShape))
    }
    if (open) {
        ColorPickerDialog(
            title = def.name,
            initial = value,
            onPick = { rgb -> rgb.forEachIndexed { i, x -> onValue(def, i, x) } },
            onDismiss = { open = false },
        )
    }
}

@Composable
private fun PaletteChip(palette: Palette, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .border(1.dp, ShaderArtColors.Border, RoundedCornerShape(10.dp))
            .clickableWithRole(onClick)
            .padding(8.dp)
            .semantics { contentDescription = "Apply ${palette.name} palette" },
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row {
            palette.colors.forEach { c -> Box(Modifier.size(width = 18.dp, height = 28.dp).background(toColor(c))) }
        }
        Text(palette.name, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 4.dp))
    }
}

/** HSV colour picker with a hex field. Applies the colour when OK is pressed. */
@Composable
fun ColorPickerDialog(title: String, initial: List<Float>, onPick: (List<Float>) -> Unit, onDismiss: () -> Unit) {
    val start = remember(initial) { ParamLogic.rgbToHsv(initial.getOrElse(0) { 1f }, initial.getOrElse(1) { 1f }, initial.getOrElse(2) { 1f }) }
    var h by remember { mutableStateOf(start[0]) }
    var s by remember { mutableStateOf(start[1]) }
    var v by remember { mutableStateOf(start[2]) }
    val rgb = ParamLogic.hsvToRgb(h, s, v)
    var hexText by remember { mutableStateOf("") }
    var hexTouched by remember { mutableStateOf(false) }
    val hexShown = if (hexTouched) hexText else toHex(rgb)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        containerColor = ShaderArtColors.Charcoal,
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(12.dp))
                        .background(toColor(rgb)).border(1.dp, Color.White, RoundedCornerShape(12.dp)),
                )
                LabeledSlider("Hue", h, 0f, 1f) { h = it; hexTouched = false }
                LabeledSlider("Saturation", s, 0f, 1f) { s = it; hexTouched = false }
                LabeledSlider("Brightness", v, 0f, 1f) { v = it; hexTouched = false }
                OutlinedTextField(
                    value = hexShown,
                    onValueChange = { t ->
                        hexText = t
                        hexTouched = true
                        parseHex(t)?.let { c ->
                            val hsv = ParamLogic.rgbToHsv(c[0], c[1], c[2])
                            h = hsv[0]; s = hsv[1]; v = hsv[2]
                        }
                    },
                    label = { Text("Hex") },
                    singleLine = true,
                    isError = hexTouched && parseHex(hexText) == null,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(rgb); onDismiss() }) { Text("Apply") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun LabeledSlider(label: String, value: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(
            value = value, onValueChange = onChange, valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = ShaderArtColors.Border),
            modifier = Modifier.semantics { contentDescription = label },
        )
    }
}
