package com.shaderart.studio.core.storage

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.json.asFloat
import com.shaderart.studio.core.json.asList
import com.shaderart.studio.core.json.asObject
import com.shaderart.studio.core.json.optBool
import com.shaderart.studio.core.json.optFloat
import com.shaderart.studio.core.json.optObject
import com.shaderart.studio.core.json.optString
import com.shaderart.studio.core.json.reqLong
import com.shaderart.studio.core.json.reqString
import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ParamJson
import com.shaderart.studio.core.model.ParamValidator
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck

/** Reads and writes the project manifest. Shader sources are stored beside it as separate files. */
object ProjectSerializer {
    const val CURRENT_FORMAT = ProjectMigrations.CURRENT_FORMAT

    fun toManifestMap(p: ShaderProject): Map<String, Any?> = linkedMapOf(
        "formatVersion" to CURRENT_FORMAT,
        "id" to p.id,
        "name" to p.name,
        "type" to p.type.name,
        "createdAt" to p.createdAt,
        "modifiedAt" to p.modifiedAt,
        "shaderVersion" to p.shaderVersion,
        "presetOrigin" to p.presetOrigin,
        "params" to p.params.map { ParamJson.toMap(it) },
        "values" to p.values,
        "animation" to linkedMapOf(
            "playing" to p.animation.playing,
            "speed" to p.animation.speed,
            "time" to p.animation.time,
        ),
        "render" to linkedMapOf(
            "qualityScale" to p.render.qualityScale,
            "previewWidth" to p.render.previewWidth,
            "previewHeight" to p.render.previewHeight,
            "zoom" to p.render.zoom,
        ),
    )

    fun toManifestJson(p: ShaderProject, pretty: Boolean = true): String = MiniJson.write(toManifestMap(p), pretty)

    /**
     * Parses and fully validates a manifest. Throws [ProjectFormatException] (or the
     * [UnsupportedProjectVersionException] subclass) for anything malformed or out of range.
     */
    fun fromManifestJson(text: String, vertexSource: String, fragmentSource: String): ShaderProject {
        try {
            val raw = MiniJson.parseObject(text)
            val m = ProjectMigrations.migrate(raw)

            val id = m.reqString("id")
            if (!ImportLimits.isSafeProjectId(id)) throw ProjectFormatException("Project id contains unsafe characters")
            val name = m.reqString("name").trim()
            if (name.isEmpty() || name.length > ImportLimits.MAX_NAME_LENGTH) {
                throw ProjectFormatException("Project name must be 1-${ImportLimits.MAX_NAME_LENGTH} characters")
            }
            val typeName = m.reqString("type")
            val type = ProjectType.parse(typeName) ?: throw ProjectFormatException("Unknown project type '$typeName'")
            val created = m.reqLong("createdAt")
            val modified = m.reqLong("modifiedAt")
            val shaderVersion = m.optString("shaderVersion") ?: "300 es"
            if (shaderVersion != "300 es") throw ProjectFormatException("Unsupported shader version '$shaderVersion'")
            val origin = m.optString("presetOrigin")
            if ((origin?.length ?: 0) > 64) throw ProjectFormatException("Preset origin is too long")

            val paramList = m["params"].asList("params")
            if (paramList.size > ParamValidator.MAX_PARAMS) throw ProjectFormatException("Too many parameters")
            val params = paramList.mapIndexed { i, e -> ParamJson.fromMap(e.asObject("params[$i]")) }
            val paramErrors = ParamValidator.validate(params)
            if (paramErrors.isNotEmpty()) throw ProjectFormatException(paramErrors.first())

            val valuesObj = m["values"]?.asObject("values") ?: emptyMap()
            val values = LinkedHashMap<String, List<Float>>()
            for ((k, v) in valuesObj) values[k] = v.asList("values.$k").map { it.asFloat("values.$k") }
            val valueErrors = ParamValidator.validateValues(params, values)
            if (valueErrors.isNotEmpty()) throw ProjectFormatException(valueErrors.first())
            for (p in params) values.putIfAbsent(p.id, p.defaults)

            val anim = m.optObject("animation")
            val speed = anim?.optFloat("speed", 1f) ?: 1f
            val time = anim?.optFloat("time", 0f) ?: 0f
            if (speed < 0f || speed > 10f) throw ProjectFormatException("Animation speed must be between 0 and 10")
            if (time < 0f || time > 1.0e7f) throw ProjectFormatException("Animation time is out of range")
            val animation = AnimationConfig(anim?.optBool("playing", true) ?: true, speed, time)

            val r = m.optObject("render")
            val quality = r?.optFloat("qualityScale", 1f) ?: 1f
            val pw = r?.optFloat("previewWidth", 0f) ?: 0f
            val ph = r?.optFloat("previewHeight", 0f) ?: 0f
            val zoom = r?.optFloat("zoom", 1f) ?: 1f
            if (quality < 0.25f || quality > 1f) throw ProjectFormatException("Quality scale must be between 0.25 and 1")
            if (pw < 0f || ph < 0f || pw > ImportLimits.MAX_RENDER_DIMENSION || ph > ImportLimits.MAX_RENDER_DIMENSION) {
                throw ProjectFormatException("Preview dimensions are out of range")
            }
            if (zoom < 0.01f || zoom > 1000f) throw ProjectFormatException("Zoom is out of range")
            val render = RenderSettings(quality, pw.toInt(), ph.toInt(), zoom)

            val sourceProblems = GlslSourceCheck.check(vertexSource, "Vertex") + GlslSourceCheck.check(fragmentSource, "Fragment")
            if (sourceProblems.isNotEmpty()) throw ProjectFormatException(sourceProblems.first())

            return ShaderProject(
                id = id,
                name = name,
                type = type,
                createdAt = created,
                modifiedAt = modified,
                vertexSource = vertexSource,
                fragmentSource = fragmentSource,
                shaderVersion = shaderVersion,
                params = params,
                values = values,
                animation = animation,
                render = render,
                presetOrigin = origin,
                formatVersion = CURRENT_FORMAT,
            )
        } catch (e: JsonException) {
            throw ProjectFormatException(e.message ?: "Invalid project data")
        }
    }
}
