package com.shaderart.studio.core.renderer

import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.model.ParamDef
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * UI-independent handle on one live renderer. ViewModels own a session; a [ShaderSurfaceView] is attached
 * to it by the screen. The session survives configuration changes, so the shader keeps its state and the
 * view can be recreated freely.
 */
class RenderSession : RendererListener {
    val renderer = ShaderRenderer(this)

    /** Every compile report, in order. A SharedFlow (not a StateFlow) so two quick reports are never merged into one. */
    private val _compile = MutableSharedFlow<CompileReport>(replay = 1, extraBufferCapacity = 16, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val compile: SharedFlow<CompileReport> = _compile.asSharedFlow()

    private val _stats = MutableStateFlow(RenderStats())
    val stats: StateFlow<RenderStats> = _stats.asStateFlow()

    private val _capabilities = MutableStateFlow<ShaderCapabilities?>(null)
    val capabilities: StateFlow<ShaderCapabilities?> = _capabilities.asStateFlow()

    private val _notices = MutableSharedFlow<RenderNotice>(extraBufferCapacity = 8)
    val notices: SharedFlow<RenderNotice> = _notices.asSharedFlow()

    private var request = RenderRequest()
    private var generation = 0
    private var timeCommand = 0

    @Synchronized
    private fun publish(next: RenderRequest) {
        request = next
        renderer.request = next
        renderer.surface?.requestRender()
    }

    /** Publishes new shader sources. The result arrives on [compile]; the previous program keeps running if it fails. */
    @Synchronized
    fun submitSources(vertex: String, fragment: String): Int {
        generation++
        publish(request.copy(generation = generation, vertexSource = vertex, fragmentSource = fragment))
        return generation
    }

    @Synchronized
    fun updateParams(params: List<ParamDef>, values: Map<String, List<Float>>) =
        publish(request.copy(params = params, values = values))

    @Synchronized fun setPlaying(playing: Boolean) = publish(request.copy(playing = playing))
    @Synchronized fun setSpeed(speed: Float) = publish(request.copy(speed = speed))
    @Synchronized fun setZoom(zoom: Float) = publish(request.copy(zoom = zoom))
    @Synchronized fun setMaxFps(fps: Int) = publish(request.copy(maxFps = fps))

    /** Jumps the shader clock to [seconds]. */
    @Synchronized
    fun seek(seconds: Float) {
        timeCommand++
        publish(request.copy(timeCommandId = timeCommand, timeSeconds = seconds.coerceAtLeast(0f)))
    }

    @Synchronized fun requestFrame() { renderer.surface?.requestRender() }

    val currentGeneration: Int @Synchronized get() = generation

    // ---- RendererListener (called on the GL thread) ----
    override fun onCapabilities(capabilities: ShaderCapabilities) { _capabilities.value = capabilities }
    override fun onCompile(report: CompileReport) { _compile.tryEmit(report) }
    override fun onStats(stats: RenderStats) { _stats.value = stats }
    override fun onNotice(notice: RenderNotice) { _notices.tryEmit(notice) }
}
