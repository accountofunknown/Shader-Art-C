package com.shaderart.studio.core.export

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES30
import com.shaderart.studio.core.compiler.ShaderCompiler
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.gpu.FullscreenTriangle
import com.shaderart.studio.core.gpu.GpuException
import com.shaderart.studio.core.gpu.GpuInfo
import com.shaderart.studio.core.gpu.RenderTarget
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.uniforms.FrameUniforms
import com.shaderart.studio.core.uniforms.ShaderUniformManager
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CancellationException

/** An export failed. The message is safe to show to the user; [diagnostics] holds compiler output if relevant. */
class ExportException(message: String, val diagnostics: List<ShaderDiagnostic> = emptyList()) : Exception(message)

class OffscreenRequest(
    val vertexSource: String,
    val fragmentSource: String,
    val params: List<ParamDef>,
    val values: Map<String, List<Float>>,
    val width: Int,
    val height: Int,
    val timeSeconds: Float,
    val zoom: Float = 1f,
    val speed: Float = 1f,
)

/**
 * Renders a shader at an exact pixel size into a Bitmap using its own EGL context and a pbuffer, so it
 * never touches the on-screen renderer. Must always be called from the same single thread.
 *
 * The image is rendered in tiles using the scissor test while the viewport stays full-size. gl_FragCoord
 * and u_resolution therefore refer to the whole image, so every tile is pixel-identical to a single
 * full render. Tiling keeps each GPU job short, which avoids driver watchdog resets on heavy shaders.
 */
class OffscreenRenderer {

    fun render(
        request: OffscreenRequest,
        onProgress: (Float) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): Bitmap {
        val w = request.width
        val h = request.height
        val env = EglEnv.create()
        try {
            val caps = GpuInfo.query()
            if (w > caps.maxImageSide || h > caps.maxImageSide) {
                throw ExportException("This GPU supports images up to ${caps.maxImageSide} px per side (requested ${w}×$h).")
            }
            return renderInContext(request, caps, onProgress, isCancelled)
        } finally {
            env.release()
        }
    }

    /** Largest image side this GPU can render, determined with a real context. Null if no context could be created. */
    fun queryMaxSide(): Int? {
        val env = try { EglEnv.create() } catch (e: ExportException) { return null }
        return try { GpuInfo.query().maxImageSide } finally { env.release() }
    }

    private fun renderInContext(
        r: OffscreenRequest,
        caps: ShaderCapabilities,
        onProgress: (Float) -> Unit,
        isCancelled: () -> Boolean,
    ): Bitmap {
        val w = r.width
        val h = r.height
        val compiled = ShaderCompiler().compile(r.vertexSource, r.fragmentSource)
        val program = compiled.program
            ?: throw ExportException(
                "The shader does not compile: " + (compiled.diagnostics.firstOrNull { it.severity == Severity.ERROR }?.message ?: "unknown error"),
                compiled.diagnostics,
            )
        val triangle = FullscreenTriangle()
        val target = RenderTarget(w, h)
        try {
            triangle.create()
            try {
                target.create()
            } catch (e: GpuException) {
                throw ExportException(e.message ?: "Could not create the render target.")
            }
            target.bind()
            GLES30.glViewport(0, 0, w, h)
            GLES30.glDisable(GLES30.GL_DEPTH_TEST)
            GLES30.glDisable(GLES30.GL_BLEND)
            program.use()
            val uniforms = ShaderUniformManager()
            uniforms.bindFrame(program, FrameUniforms(r.timeSeconds, w, h, 0.5f, 0.5f, false, 1f / 60f, 0, r.speed, r.zoom))
            uniforms.bindParams(program, r.params, r.values)

            val tilesX = (w + TILE - 1) / TILE
            val tilesY = (h + TILE - 1) / TILE
            val totalSteps = tilesX * tilesY + bandCount(w, h)
            var done = 0

            GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
            for (ty in 0 until tilesY) {
                for (tx in 0 until tilesX) {
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    val x = tx * TILE
                    val y = ty * TILE
                    GLES30.glScissor(x, y, minOf(TILE, w - x), minOf(TILE, h - y))
                    triangle.draw()
                    GLES30.glFinish()
                    onProgress(++done / totalSteps.toFloat())
                }
            }
            GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            checkErrors()

            val bitmap = try {
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            } catch (e: OutOfMemoryError) {
                throw ExportException("Not enough memory for a ${w}×$h image. Choose a smaller size.")
            }
            try {
                readBack(w, h, bitmap) {
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    onProgress(++done / totalSteps.toFloat())
                }
            } catch (t: Throwable) {
                bitmap.recycle()
                throw t
            }
            return bitmap
        } finally {
            target.release()
            triangle.release()
            program.delete()
        }
    }

    private fun bandRows(w: Int): Int = (BAND_BYTES / (w * 4)).coerceIn(1, 256)

    private fun bandCount(w: Int, h: Int): Int = (h + bandRows(w) - 1) / bandRows(w)

    /** Reads the framebuffer in horizontal bands (bounded memory) and writes rows top-down into the bitmap. */
    private fun readBack(w: Int, h: Int, bitmap: Bitmap, onBand: () -> Unit) {
        val rows = bandRows(w)
        val buffer = ByteBuffer.allocateDirect(w * rows * 4).order(ByteOrder.nativeOrder())
        val ints = buffer.asIntBuffer()
        val line = IntArray(w)
        val out = IntArray(w * rows)
        val littleEndian = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN
        var y0 = 0
        while (y0 < h) {
            val bh = minOf(rows, h - y0)
            buffer.clear()
            GLES30.glReadPixels(0, y0, w, bh, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buffer)
            val err = GLES30.glGetError()
            if (err != GLES30.GL_NO_ERROR) throw ExportException("Reading pixels from the GPU failed (GL error 0x${Integer.toHexString(err)}).")
            // OpenGL rows run bottom-to-top; bitmap rows run top-to-bottom.
            for (r in 0 until bh) {
                ints.position((bh - 1 - r) * w)
                ints.get(line, 0, w)
                val base = r * w
                if (littleEndian) {
                    for (x in 0 until w) {
                        val v = line[x] // bytes R,G,B,A in memory -> 0xAABBGGRR
                        out[base + x] = (0xFF shl 24) or (v and 0x0000FF00) or ((v and 0xFF) shl 16) or ((v ushr 16) and 0xFF)
                    }
                } else {
                    for (x in 0 until w) {
                        val v = line[x] // 0xRRGGBBAA
                        out[base + x] = (0xFF shl 24) or (v ushr 8)
                    }
                }
            }
            bitmap.setPixels(out, 0, w, 0, h - y0 - bh, w, bh)
            y0 += bh
            onBand()
        }
    }

    private fun checkErrors() {
        val err = GLES30.glGetError()
        if (err == GLES30.GL_NO_ERROR) return
        val egl = EGL14.eglGetError()
        if (err == GLES30.GL_OUT_OF_MEMORY) throw ExportException("The GPU ran out of memory while rendering.")
        if (egl == EGL14.EGL_CONTEXT_LOST) throw ExportException("The GPU context was lost while rendering. Try again.")
        throw ExportException("The GPU reported an error while rendering (GL error 0x${Integer.toHexString(err)}).")
    }

    /** Owns the EGL display connection pieces for one render. */
    private class EglEnv(
        private val display: EGLDisplay,
        private val context: EGLContext,
        private val surface: EGLSurface,
    ) {
        fun release() {
            EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(display, surface)
            EGL14.eglDestroyContext(display, context)
            // eglTerminate is intentionally not called: the display connection is shared with the on-screen renderer.
        }

        companion object {
            fun create(): EglEnv {
                val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
                if (display == EGL14.EGL_NO_DISPLAY) throw ExportException("No EGL display is available on this device.")
                val version = IntArray(2)
                if (!EGL14.eglInitialize(display, version, 0, version, 1)) throw ExportException("EGL could not be initialised.")
                val attribs = intArrayOf(
                    EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR,
                    EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
                    EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
                    EGL14.EGL_NONE,
                )
                val configs = arrayOfNulls<EGLConfig>(1)
                val count = IntArray(1)
                if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, count, 0) || count[0] == 0 || configs[0] == null) {
                    throw ExportException("This device has no OpenGL ES 3.0 configuration usable for offscreen rendering.")
                }
                val ctx = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
                if (ctx == EGL14.EGL_NO_CONTEXT) throw ExportException("An OpenGL ES 3.0 context could not be created (EGL error 0x${Integer.toHexString(EGL14.eglGetError())}).")
                val surf = EGL14.eglCreatePbufferSurface(display, configs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
                if (surf == EGL14.EGL_NO_SURFACE) {
                    EGL14.eglDestroyContext(display, ctx)
                    throw ExportException("An offscreen surface could not be created (EGL error 0x${Integer.toHexString(EGL14.eglGetError())}).")
                }
                if (!EGL14.eglMakeCurrent(display, surf, surf, ctx)) {
                    EGL14.eglDestroySurface(display, surf)
                    EGL14.eglDestroyContext(display, ctx)
                    throw ExportException("The offscreen context could not be activated (EGL error 0x${Integer.toHexString(EGL14.eglGetError())}).")
                }
                return EglEnv(display, ctx, surf)
            }
        }
    }

    private companion object {
        const val TILE = 512
        const val BAND_BYTES = 4_000_000
    }
}
