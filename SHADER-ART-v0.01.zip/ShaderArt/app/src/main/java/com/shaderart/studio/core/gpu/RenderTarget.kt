package com.shaderart.studio.core.gpu

import android.opengl.GLES30

class GpuException(message: String) : Exception(message)

/**
 * A texture-backed framebuffer (RGBA8). Used by offscreen export; it is also the building block for
 * the multi-pass features planned after v0.01 (see [RenderPass] and [PingPong]).
 */
class RenderTarget(val width: Int, val height: Int) {
    var textureId = 0
        private set
    var framebufferId = 0
        private set

    fun create() {
        while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* clear stale errors */ }
        val tex = IntArray(1)
        GLES30.glGenTextures(1, tex, 0)
        textureId = tex[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureId)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, width, height, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        val allocError = GLES30.glGetError()
        if (allocError != GLES30.GL_NO_ERROR) {
            release()
            throw GpuException(
                if (allocError == GLES30.GL_OUT_OF_MEMORY) "The GPU ran out of memory allocating a ${width}×$height texture."
                else "Texture allocation failed (GL error 0x${Integer.toHexString(allocError)}).",
            )
        }
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_NEAREST)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

        val fbo = IntArray(1)
        GLES30.glGenFramebuffers(1, fbo, 0)
        framebufferId = fbo[0]
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, framebufferId)
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, textureId, 0)
        val status = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        if (status != GLES30.GL_FRAMEBUFFER_COMPLETE) {
            release()
            throw GpuException("The framebuffer is incomplete (status 0x${Integer.toHexString(status)}).")
        }
    }

    fun bind() {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, framebufferId)
    }

    fun release() {
        if (framebufferId != 0) {
            GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
            GLES30.glDeleteFramebuffers(1, intArrayOf(framebufferId), 0)
            framebufferId = 0
        }
        if (textureId != 0) {
            GLES30.glDeleteTextures(1, intArrayOf(textureId), 0)
            textureId = 0
        }
    }
}

/**
 * Multi-pass scaffolding. In v0.01 only the single-pass pipeline runs; these types exist so feedback
 * effects and post-processing can be added without reshaping the renderer. Nothing uses them yet.
 */
interface RenderPass {
    val name: String

    /** Renders into [target] (or the screen when null), reading [inputs] as textures. */
    fun execute(target: RenderTarget?, inputs: List<RenderTarget>)
}

/** Two render targets that swap roles each frame (for feedback effects). Not wired up in v0.01. */
class PingPong(width: Int, height: Int) {
    private val a = RenderTarget(width, height)
    private val b = RenderTarget(width, height)
    private var flip = false

    val read: RenderTarget get() = if (flip) b else a
    val write: RenderTarget get() = if (flip) a else b

    fun create() {
        a.create()
        b.create()
    }

    fun swap() {
        flip = !flip
    }

    fun release() {
        a.release()
        b.release()
    }
}
