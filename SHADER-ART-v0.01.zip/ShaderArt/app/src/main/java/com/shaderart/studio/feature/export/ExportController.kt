package com.shaderart.studio.feature.export

import android.net.Uri
import com.shaderart.studio.app.AppContainer
import com.shaderart.studio.core.export.ExportConfig
import com.shaderart.studio.core.export.ExportException
import com.shaderart.studio.core.export.ExportLimits
import com.shaderart.studio.core.export.FileNaming
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.core.model.ShaderProject
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ExportUi(
    val width: Int = 1080,
    val height: Int = 1920,
    val presetId: String? = "wp_916",
    val format: ImageFormat = ImageFormat.PNG,
    val quality: Int = 92,
    val timeSeconds: Float = 0f,
    val running: Boolean = false,
    val progress: Float = 0f,
    /** A finished export waiting in the share cache. Saving or sharing never re-renders. */
    val resultFile: File? = null,
    val resultName: String? = null,
    val resultWidth: Int = 0,
    val resultHeight: Int = 0,
    val error: String? = null,
    val info: String? = null,
    /** Real GPU limit, null until it has been queried. */
    val gpuMaxSide: Int? = null,
)

/**
 * Drives one image export at a time. The render itself runs in [com.shaderart.studio.core.export.ExportEngine];
 * this class holds the settings and the result between screens.
 */
class ExportController(
    private val container: AppContainer,
    private val scope: CoroutineScope,
    private val projectProvider: () -> ShaderProject?,
) {
    private val _ui = MutableStateFlow(ExportUi())
    val ui: StateFlow<ExportUi> = _ui.asStateFlow()
    private var job: Job? = null

    /** Looks up the GPU limits once. Safe to call repeatedly. */
    fun loadLimits() {
        if (_ui.value.gpuMaxSide != null) return
        scope.launch {
            val side = try { container.export.maxImageSide() } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
            if (side != null) _ui.update { it.copy(gpuMaxSide = side) }
        }
    }

    fun selectPreset(id: String) {
        val p = ExportLimits.PRESETS.firstOrNull { it.id == id } ?: return
        _ui.update { it.copy(width = p.width, height = p.height, presetId = id, error = null) }
    }

    fun setSize(width: Int, height: Int) {
        _ui.update { it.copy(width = width, height = height, presetId = null, error = null) }
    }

    fun setFormat(format: ImageFormat) = _ui.update { it.copy(format = format, error = null) }
    fun setQuality(q: Int) = _ui.update { it.copy(quality = q.coerceIn(1, 100)) }
    fun setTime(seconds: Float) = _ui.update { it.copy(timeSeconds = if (seconds.isFinite()) seconds.coerceAtLeast(0f) else 0f) }
    fun clearResult() {
        _ui.value.resultFile?.delete()
        _ui.update { it.copy(resultFile = null, resultName = null, info = null) }
    }
    fun dismissMessages() = _ui.update { it.copy(error = null, info = null) }

    /** Reduces the requested size to the largest one this device can really render. */
    fun fitToDevice() {
        val s = _ui.value
        val (w, h) = ExportLimits.fit(s.width, s.height, s.gpuMaxSide)
        _ui.update { it.copy(width = w, height = h, presetId = null, error = null) }
    }

    fun start() {
        if (_ui.value.running) return
        val project = projectProvider()
        if (project == null) {
            _ui.update { it.copy(error = "There is nothing to export yet. Open a preset or project first. An imported shader must be run once in Code Studio before it can be exported.") }
            return
        }
        val s = _ui.value
        val config = ExportConfig(s.width, s.height, s.format, s.quality, s.timeSeconds)
        ExportLimits.problem(config, s.gpuMaxSide)?.let { problem ->
            _ui.update { it.copy(error = problem) }
            return
        }
        s.resultFile?.delete()
        val name = FileNaming.imageName(project.name, config, System.currentTimeMillis())
        _ui.update { it.copy(running = true, progress = 0f, error = null, info = null, resultFile = null, resultName = null) }
        job = scope.launch {
            try {
                val file = container.export.exportImage(project, config, name) { p -> _ui.update { it.copy(progress = p) } }
                _ui.update {
                    it.copy(
                        running = false, progress = 1f, resultFile = file, resultName = name,
                        resultWidth = config.width, resultHeight = config.height,
                        info = "Rendered ${config.width}×${config.height} ${config.format.label}.",
                    )
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(running = false, progress = 0f, info = "Export cancelled.") }
                throw e
            } catch (e: ExportException) {
                _ui.update { it.copy(running = false, progress = 0f, error = e.message ?: "Export failed.") }
            } catch (e: OutOfMemoryError) {
                _ui.update { it.copy(running = false, progress = 0f, error = "The device ran out of memory at this size. Choose a smaller size.") }
            } catch (e: Exception) {
                _ui.update { it.copy(running = false, progress = 0f, error = "Export failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    fun cancel() { job?.cancel() }

    /** Copies the rendered file to a location chosen with the system file picker. */
    fun saveTo(uri: Uri) {
        val file = _ui.value.resultFile
        if (file == null || !file.isFile) {
            _ui.update { it.copy(error = "The exported image is no longer available. Export it again.") }
            return
        }
        scope.launch {
            try {
                withContext(Dispatchers.IO) { container.uriIO.copyFrom(file, uri) }
                _ui.update { it.copy(info = "Saved.", error = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(error = "Could not save the image: ${e.message ?: "unknown error"}") }
            }
        }
    }
}
