package com.shaderart.studio.core

import com.shaderart.studio.assetsDir
import com.shaderart.studio.core.compiler.GlslLogParser
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderStage
import com.shaderart.studio.core.export.ExportConfig
import com.shaderart.studio.core.export.ExportLimits
import com.shaderart.studio.core.export.FileNaming
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.core.model.ParamValidator
import com.shaderart.studio.core.model.PresetCategory
import com.shaderart.studio.core.presets.PresetCatalogParser
import com.shaderart.studio.core.presets.PresetException
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.shader.ShaderMetadataParser
import com.shaderart.studio.expectThrows
import com.shaderart.studio.sampleParams
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class GlslLogParserTest {
    @Test fun parsesQualcommArmAndAngleStyle() {
        val d = GlslLogParser.parse(ShaderStage.FRAGMENT, "ERROR: 0:12: 'foo' : undeclared identifier\nWARNING: 0:3: 'x' : unused\n")
        assertEquals(2, d.size)
        assertEquals(12, d[0].line); assertEquals(Severity.ERROR, d[0].severity)
        assertTrue(d[0].message.contains("undeclared identifier"))
        assertEquals(3, d[1].line); assertEquals(Severity.WARNING, d[1].severity)
        assertEquals(ShaderStage.FRAGMENT, d[0].stage)
    }

    @Test fun parsesMesaStyle() {
        val d = GlslLogParser.parse(ShaderStage.VERTEX, "0:7(14): error: syntax error, unexpected '}'")
        assertEquals(7, d.single().line)
        assertEquals(Severity.ERROR, d.single().severity)
        assertTrue(d.single().message.startsWith("syntax error"))
    }

    @Test fun parsesNvidiaStyle() {
        val d = GlslLogParser.parse(ShaderStage.FRAGMENT, "0(21) : error C1008: undefined variable \"q\"")
        assertEquals(21, d.single().line)
        assertTrue(d.single().message.contains("undefined variable"))
    }

    @Test fun parsesColumnVariant() {
        assertEquals(5, GlslLogParser.parse(ShaderStage.FRAGMENT, "ERROR: 0:5:9: bad").single().line)
    }

    @Test fun neverDropsUnrecognisedLines() {
        val d = GlslLogParser.parse(ShaderStage.LINK, "Link failed: varying mismatch\n\n   \nsome info")
        assertEquals(2, d.size)
        assertNull(d[0].line)
        assertEquals(Severity.ERROR, d[0].severity)
        assertEquals(Severity.INFO, d[1].severity)
    }

    @Test fun emptyLogGivesNoDiagnostics() { assertTrue(GlslLogParser.parse(ShaderStage.FRAGMENT, "\u0000 \n").isEmpty()) }
}

class ShaderMetadataParserTest {
    private val src = """
        #version 300 es
        precision highp float;
        uniform float u_time;
        uniform float u_scale;  // @slider 0.5 8 2 "Zoom level"
        uniform int u_steps;    // @slider 1 64 16 "Steps"
        uniform vec3 u_tint;    // @color 1 0.5 0.25 "Tint"
        uniform vec3 u_glowColor;
        uniform bool u_invert;  // @toggle 1
        uniform float u_plain;
        uniform vec2 u_offset;
        uniform highp float u_hp;
        uniform float u_arr[4];
        // uniform float u_commented;
        /* uniform float u_blocked; */
        out vec4 c;
        void main() { c = vec4(1.0); }
    """.trimIndent()

    private val defs get() = ShaderMetadataParser.toParamDefs(ShaderMetadataParser.declaredUniforms(src)).associateBy { it.uniform }

    @Test fun findsDeclarationsWithLineNumbers() {
        val d = ShaderMetadataParser.declaredUniforms(src)
        assertEquals(4, d.first { it.name == "u_scale" }.line)
        assertTrue(d.any { it.name == "u_arr" && it.type == "float[]" })
        assertFalse(d.any { it.name == "u_commented" || it.name == "u_blocked" })
    }

    @Test fun systemUniformsGetNoControl() { assertFalse(defs.containsKey("u_time")) }

    @Test fun readsSliderAnnotations() {
        val s = defs.getValue("u_scale")
        assertEquals(ParamType.FLOAT, s.type)
        assertEquals(0.5f, s.min, 0f); assertEquals(8f, s.max, 0f); assertEquals(listOf(2f), s.defaults)
        assertEquals("Zoom level", s.name)
        val n = defs.getValue("u_steps")
        assertEquals(ParamType.INT, n.type); assertEquals(listOf(16f), n.defaults); assertEquals(1f, n.step, 0f)
    }

    @Test fun readsColorAndToggleAnnotations() {
        val c = defs.getValue("u_tint")
        assertEquals(ParamType.COLOR, c.type); assertEquals(listOf(1f, 0.5f, 0.25f), c.defaults)
        assertEquals(ParamType.COLOR, defs.getValue("u_glowColor").type)
        assertEquals(listOf(1f), defs.getValue("u_invert").defaults)
    }

    @Test fun unannotatedUniformsGetSafeDefaults() {
        val p = defs.getValue("u_plain")
        assertEquals(0f, p.min, 0f); assertEquals(4f, p.max, 0f); assertEquals(listOf(1f), p.defaults)
        assertEquals("Plain", p.name)
        assertTrue(defs.containsKey("u_hp"))
    }

    @Test fun unsupportedTypesAreSkipped() {
        assertFalse(defs.containsKey("u_offset"))
        assertFalse(defs.containsKey("u_arr"))
    }

    @Test fun everyGeneratedDefinitionIsValid() { assertTrue(ParamValidator.validate(defs.values.toList()).isEmpty()) }

    @Test fun badAnnotationFallsBackToDefaults() {
        val d = ShaderMetadataParser.toParamDefs(ShaderMetadataParser.declaredUniforms("uniform float u_a; // @slider 9 1 5\n")).single()
        assertEquals(0f, d.min, 0f); assertEquals(4f, d.max, 0f)
    }

    @Test fun mergeKeepsExistingDefinitionsAndAddsNewOnes() {
        val existing = sampleParams()
        val parsed = ShaderMetadataParser.toParamDefs(ShaderMetadataParser.declaredUniforms("uniform float u_scale;\nuniform float u_new;\n"))
        val merged = ShaderMetadataParser.merge(existing, parsed)
        assertEquals(existing.size + 1, merged.size)
        assertEquals(existing[0], merged[0])
        assertTrue(merged.any { it.uniform == "u_new" })
    }

    @Test fun prettify() {
        assertEquals("Glow Color", ShaderMetadataParser.prettify("u_glowColor"))
        assertEquals("Edge Width", ShaderMetadataParser.prettify("u_edge_width"))
    }
}

class GlslSourceCheckTest {
    @Test fun acceptsVersionAfterComments() {
        assertTrue(GlslSourceCheck.hasVersion300es("// hi\n/* x */\n#version 300 es\nvoid main(){}"))
        assertTrue(GlslSourceCheck.check("#version 300 es\nvoid main(){}", "Fragment").isEmpty())
    }

    @Test fun rejectsOtherVersionsAndMissingDirective() {
        assertFalse(GlslSourceCheck.check("#version 100\nvoid main(){}", "Fragment").isEmpty())
        assertFalse(GlslSourceCheck.check("#version 330 core\n", "Fragment").isEmpty())
        assertFalse(GlslSourceCheck.check("void main(){}", "Fragment").isEmpty())
        assertFalse(GlslSourceCheck.check("#version 3000 es\n", "Fragment").isEmpty())
        assertFalse(GlslSourceCheck.check("   ", "Fragment").isEmpty())
    }

    @Test fun rejectsNulBytes() { assertFalse(GlslSourceCheck.check("#version 300 es\n\u0000", "Fragment").isEmpty()) }
}

class PresetCatalogTest {
    private val assets = assetsDir()
    private val presets by lazy {
        PresetCatalogParser.parse(File(assets, "presets/catalog.json").readText()) { File(assets, it).readText() }
    }

    @Test fun allSpecifiedStarterPresetsExist() {
        val names = presets.map { it.name }.toSet()
        listOf(
            "Liquid Flow", "Plasma Dreams", "Monochrome Waves", "Infinite Tunnel", "Voronoi Universe", "Fractal Bloom",
            "Neon Geometry", "Organic Noise", "Digital Glitch", "Quantum Grid", "Fluid Distortion", "Cellular Patterns",
            "Black Hole", "Abstract Topography", "Interference Field", "Retro Scanlines", "Mandelbrot Explorer", "Julia Dream",
        ).forEach { assertTrue("missing preset $it", it in names) }
    }

    @Test fun everyCategoryIsRepresented() {
        assertEquals(PresetCategory.entries.toSet(), presets.map { it.category }.toSet())
    }

    @Test fun idsAreUniqueAndSourcesPresent() {
        assertEquals(presets.size, presets.map { it.id }.toSet().size)
        for (p in presets) {
            assertTrue(p.id, p.fragmentSource.contains("void main()"))
            assertTrue(p.id, p.vertexSource.contains("gl_VertexID"))
            assertTrue(p.id, p.description.isNotBlank() && p.performanceNote.isNotBlank())
        }
    }

    @Test fun parametersAreValidAndDefaultsInRange() {
        for (p in presets) {
            assertTrue(p.id, ParamValidator.validate(p.params).isEmpty())
            assertTrue(p.id, ParamValidator.validateValues(p.params, ParamLogic.defaults(p.params)).isEmpty())
        }
    }

    @Test fun everyPresetHasColorControlsAndPostEffects() {
        for (p in presets) {
            assertTrue(p.id, p.params.count { it.type == ParamType.COLOR } >= 3)
            assertTrue(p.id, p.params.count { it.group == ParamLogic.GROUP_POST } == 7)
        }
    }

    @Test fun presetShadersOnlyUseDeclaredUniforms() {
        for (p in presets) {
            val declared = ShaderMetadataParser.declaredNames(p.fragmentSource)
            val used = Regex("\\bu_[A-Za-z0-9_]+\\b").findAll(p.fragmentSource).map { it.value }.toSet()
            assertTrue("${p.id}: undeclared ${used - declared}", declared.containsAll(used))
        }
    }

    @Test fun loopHeavyPresetsExposeIterationLimits() {
        val heavy = presets.filter { it.performance.name == "HEAVY" }
        assertTrue(heavy.isNotEmpty())
        for (p in heavy) {
            val it = p.params.firstOrNull { x -> x.uniform == "u_iterations" }
            if (it != null) assertTrue(p.id, it.max <= 256f)
        }
    }

    @Test fun malformedCatalogsAreRejected() {
        val read = { _: String -> "#version 300 es\nuniform float a;\nvoid main(){}" }
        expectThrows<PresetException> { PresetCatalogParser.parse("""{"catalogVersion":9,"presets":[]}""", read) }
        expectThrows<PresetException> { PresetCatalogParser.parse("""{"presets":[]}""", read) }
        expectThrows<PresetException> { PresetCatalogParser.parse("nonsense", read) }
    }

    @Test fun vertexAssetIsAFullscreenTriangle() {
        val v = File(assets, "shaders/fullscreen.vert").readText()
        assertTrue(v.startsWith("#version 300 es"))
        assertTrue(v.contains("gl_VertexID") && v.contains("gl_Position"))
    }
}

class ExportConfigTest {
    private fun cfg(w: Int, h: Int) = ExportConfig(w, h)

    @Test fun acceptsReasonableSizes() {
        assertNull(ExportLimits.problem(cfg(1080, 1920)))
        assertNull(ExportLimits.problem(cfg(4096, 4096)))
    }

    @Test fun rejectsTooSmallTooLargeAndTooManyPixels() {
        assertTrue(ExportLimits.problem(cfg(8, 100)) != null)
        assertTrue(ExportLimits.problem(cfg(9000, 100)) != null)
        assertTrue(ExportLimits.problem(cfg(8000, 8000)) != null)
    }

    @Test fun respectsGpuLimit() {
        assertTrue(ExportLimits.problem(cfg(4096, 100), gpuMaxSide = 2048) != null)
        assertNull(ExportLimits.problem(cfg(2048, 100), gpuMaxSide = 2048))
    }

    @Test fun validatesQualityAndTime() {
        assertTrue(ExportLimits.problem(ExportConfig(100, 100, ImageFormat.JPEG, quality = 0)) != null)
        assertTrue(ExportLimits.problem(ExportConfig(100, 100, timeSeconds = -1f)) != null)
        assertTrue(ExportLimits.problem(ExportConfig(100, 100, timeSeconds = Float.NaN)) != null)
    }

    @Test fun fitKeepsAspectAndLimits() {
        val (w, h) = ExportLimits.fit(20_000, 10_000)
        assertNull(ExportLimits.problem(cfg(w, h)))
        assertEquals(2.0, w.toDouble() / h, 0.01)
        assertEquals(1080 to 1920, ExportLimits.fit(1080, 1920))
        val (gw, _) = ExportLimits.fit(4000, 3000, gpuMaxSide = 1024)
        assertTrue(gw <= 1024)
    }

    @Test fun presetsAreAllValid() {
        for (p in ExportLimits.PRESETS) assertNull(p.id, ExportLimits.problem(cfg(p.width, p.height)))
        assertTrue(ExportLimits.PRESETS.any { it.wallpaper })
    }

    @Test fun fileNamesAreSafe() {
        assertEquals("My_cool_shader", FileNaming.sanitize("My cool shader!!"))
        assertEquals("shader", FileNaming.sanitize("///"))
        assertEquals("shader", FileNaming.sanitize(""))
        assertFalse(FileNaming.sanitize("../../etc/passwd").contains('/'))
        assertFalse(FileNaming.sanitize("../../etc/passwd").startsWith("."))
        assertTrue(FileNaming.sanitize("x".repeat(200)).length <= 48)
        val n = FileNaming.imageName("A B", ExportConfig(640, 480, ImageFormat.JPEG), 0L)
        assertTrue(n, Regex("A_B_640x480_\\d{8}-\\d{6}\\.jpg").matches(n))
        assertEquals("A_B.glsl", FileNaming.sourceName("A B", "glsl"))
    }
}
