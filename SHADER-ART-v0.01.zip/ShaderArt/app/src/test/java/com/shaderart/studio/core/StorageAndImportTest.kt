package com.shaderart.studio.core

import com.shaderart.studio.MIN_FRAGMENT
import com.shaderart.studio.MIN_VERTEX
import com.shaderart.studio.core.importing.ImportException
import com.shaderart.studio.core.importing.ShaderArchive
import com.shaderart.studio.core.importing.SourceImport
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.storage.FileProjectRepository
import com.shaderart.studio.core.storage.ProjectFormatException
import com.shaderart.studio.core.storage.ProjectIndex
import com.shaderart.studio.core.storage.ProjectMigrations
import com.shaderart.studio.core.storage.ProjectRow
import com.shaderart.studio.core.storage.ProjectSerializer
import com.shaderart.studio.core.storage.UnsupportedProjectVersionException
import com.shaderart.studio.expectThrows
import com.shaderart.studio.sampleProject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProjectSerializerTest {
    private fun roundTrip(p: com.shaderart.studio.core.model.ShaderProject) =
        ProjectSerializer.fromManifestJson(ProjectSerializer.toManifestJson(p), p.vertexSource, p.fragmentSource)

    @Test fun roundTripPreservesEverything() {
        val p = sampleProject()
        assertEquals(p, roundTrip(p))
    }

    @Test fun roundTripPreservesCodeProjectWithoutOrigin() {
        val p = sampleProject().copy(type = ProjectType.CODE, presetOrigin = null)
        assertEquals(p, roundTrip(p))
    }

    @Test fun legacyV0ManifestIsMigrated() {
        val v0 = """{"id":"old-1","name":"Old","createdAt":1,"modifiedAt":2}"""
        val p = ProjectSerializer.fromManifestJson(v0, MIN_VERTEX, MIN_FRAGMENT)
        assertEquals(ProjectType.CODE, p.type)
        assertEquals("300 es", p.shaderVersion)
        assertEquals(1f, p.animation.speed, 0f)
        assertEquals(1f, p.render.qualityScale, 0f)
        assertEquals(ProjectSerializer.CURRENT_FORMAT, p.formatVersion)
    }

    @Test fun migrationSetsCurrentVersion() {
        val m = ProjectMigrations.migrate(mapOf("id" to "x"))
        assertEquals(1L, m["formatVersion"])
    }

    @Test fun newerFormatVersionIsRejected() {
        val json = ProjectSerializer.toManifestJson(sampleProject()).replace("\"formatVersion\": 1", "\"formatVersion\": 2")
        val e = expectThrows<UnsupportedProjectVersionException> { ProjectSerializer.fromManifestJson(json, MIN_VERTEX, MIN_FRAGMENT) }
        assertEquals(2, e.version)
    }

    @Test fun fractionalAndNegativeVersionsAreRejected() {
        expectThrows<ProjectFormatException> { ProjectMigrations.migrate(mapOf("formatVersion" to 1.5)) }
        expectThrows<UnsupportedProjectVersionException> { ProjectMigrations.migrate(mapOf("formatVersion" to -1L)) }
        expectThrows<ProjectFormatException> { ProjectMigrations.migrate(mapOf("formatVersion" to "1")) }
    }

    private fun mutate(edit: (MutableMap<String, Any?>) -> Unit): String {
        val m = LinkedHashMap(ProjectSerializer.toManifestMap(sampleProject()))
        edit(m)
        return MiniJson.write(m)
    }

    @Test fun unsafeProjectIdIsRejected() {
        for (bad in listOf("../evil", "a/b", "a\\b", "", "x".repeat(65), "has space")) {
            expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { it["id"] = bad }, MIN_VERTEX, MIN_FRAGMENT) }
        }
    }

    @Test fun invalidNamesAreRejected() {
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { it["name"] = "  " }, MIN_VERTEX, MIN_FRAGMENT) }
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { it["name"] = "n".repeat(81) }, MIN_VERTEX, MIN_FRAGMENT) }
    }

    @Test fun invalidParameterDataIsRejected() {
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["values"] = mapOf("u_scale" to listOf(99)) }, MIN_VERTEX, MIN_FRAGMENT)
        }
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["values"] = mapOf("ghost" to listOf(1)) }, MIN_VERTEX, MIN_FRAGMENT)
        }
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["values"] = mapOf("u_colorA" to listOf(1)) }, MIN_VERTEX, MIN_FRAGMENT)
        }
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["params"] = listOf(mapOf("id" to "x")) }, MIN_VERTEX, MIN_FRAGMENT)
        }
    }

    @Test fun outOfRangeSettingsAreRejected() {
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["render"] = mapOf("qualityScale" to 5.0) }, MIN_VERTEX, MIN_FRAGMENT)
        }
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["render"] = mapOf("previewWidth" to 99999) }, MIN_VERTEX, MIN_FRAGMENT)
        }
        expectThrows<ProjectFormatException> {
            ProjectSerializer.fromManifestJson(mutate { it["animation"] = mapOf("speed" to 500.0) }, MIN_VERTEX, MIN_FRAGMENT)
        }
    }

    @Test fun unsupportedShaderVersionAndBadSourcesAreRejected() {
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { it["shaderVersion"] = "100" }, MIN_VERTEX, MIN_FRAGMENT) }
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { }, MIN_VERTEX, "void main() {}") }
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(mutate { }, MIN_VERTEX, "#version 330 core\nvoid main() {}") }
    }

    @Test fun garbageManifestIsAFormatError() {
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson("not json", MIN_VERTEX, MIN_FRAGMENT) }
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson("[]", MIN_VERTEX, MIN_FRAGMENT) }
    }
}

class ShaderArchiveTest {
    private val png = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 1, 2, 3)

    private fun zip(entries: List<Pair<String, ByteArray>>): ByteArray {
        val bos = ByteArrayOutputStream()
        ZipOutputStream(bos).use { z -> for ((n, b) in entries) { z.putNextEntry(ZipEntry(n)); z.write(b); z.closeEntry() } }
        return bos.toByteArray()
    }

    private fun validEntries(p: com.shaderart.studio.core.model.ShaderProject = sampleProject()) = listOf(
        "manifest.json" to ProjectSerializer.toManifestJson(p).toByteArray(),
        "vertex.vert" to p.vertexSource.toByteArray(),
        "fragment.frag" to p.fragmentSource.toByteArray(),
    )

    private fun read(bytes: ByteArray) = ShaderArchive.read(ByteArrayInputStream(bytes))

    @Test fun writeThenReadRoundTrips() {
        val p = sampleProject()
        val out = ByteArrayOutputStream()
        ShaderArchive.write(p, png, previewIsJpeg = false, out = out)
        val back = read(out.toByteArray())
        assertEquals(p, back.project)
        assertTrue(png.contentEquals(back.preview))
        assertFalse(back.previewIsJpeg)
    }

    @Test fun archiveWithoutPreviewIsFine() {
        val out = ByteArrayOutputStream()
        ShaderArchive.write(sampleProject(), null, false, out)
        assertNull(read(out.toByteArray()).preview)
    }

    @Test fun pathTraversalEntryIsRejected() {
        for (name in listOf("../fragment.frag", "../../etc/passwd", "a/../fragment.frag", "/fragment.frag", "dir/fragment.frag", "..\\fragment.frag", "C:evil.frag")) {
            val e = expectThrows<ImportException> { read(zip(validEntries() + (name to ByteArray(4)))) }
            assertTrue(name + " -> " + e.message, e.message!!.contains("unsafe") || e.message!!.contains("unexpected"))
        }
    }

    @Test fun unexpectedEntryIsRejected() {
        expectThrows<ImportException> { read(zip(validEntries() + ("payload.so" to ByteArray(16)))) }
        expectThrows<ImportException> { read(zip(validEntries() + ("script.sh" to "rm -rf /".toByteArray()))) }
    }

    @Test fun directoryEntriesAreRejected() {
        expectThrows<ImportException> { read(zip(validEntries() + ("folder/" to ByteArray(0)))) }
    }

    @Test fun missingPartsAreRejected() {
        expectThrows<ImportException> { read(zip(validEntries().filter { it.first != "manifest.json" })) }
        expectThrows<ImportException> { read(zip(validEntries().filter { it.first != "vertex.vert" })) }
        expectThrows<ImportException> { read(zip(validEntries().filter { it.first != "fragment.frag" })) }
        expectThrows<ImportException> { read(ByteArray(0)) }
    }

    @Test fun nonZipBytesAreRejected() {
        expectThrows<ImportException> { read("this is definitely not a zip".toByteArray()) }
    }

    @Test fun oversizedSourceIsRejected() {
        val big = ("#version 300 es\n" + "// x\n".repeat(80_000)).toByteArray()
        expectThrows<ImportException> { read(zip(validEntries().map { if (it.first == "fragment.frag") it.first to big else it })) }
    }

    @Test fun decompressionBombIsRejected() {
        // 10 MB of zeros compresses to a few KB: the declared archive size is tiny, the expanded size is not.
        val bomb = ByteArray(10_000_000)
        val bytes = zip(validEntries().map { if (it.first == "manifest.json") it.first to bomb else it })
        assertTrue(bytes.size < 100_000)
        expectThrows<ImportException> { read(bytes) }
    }

    @Test fun oversizedArchiveIsRejected() {
        val noise = java.util.Random(1).let { r -> ByteArray(ImportLimits.MAX_PREVIEW_BYTES).also { r.nextBytes(it) } }
        val entries = validEntries() + ("preview.png" to (png + noise).copyOf(ImportLimits.MAX_PREVIEW_BYTES)) + ("preview.jpg" to noise)
        expectThrows<ImportException> { read(zip(entries)) }
    }

    @Test fun malformedManifestIsRejected() {
        expectThrows<ImportException> { read(zip(validEntries().map { if (it.first == "manifest.json") it.first to "{oops".toByteArray() else it })) }
    }

    @Test fun newerFormatInArchiveIsRejectedWithMessage() {
        val json = ProjectSerializer.toManifestJson(sampleProject()).replace("\"formatVersion\": 1", "\"formatVersion\": 9")
        val e = expectThrows<ImportException> { read(zip(validEntries().map { if (it.first == "manifest.json") it.first to json.toByteArray() else it })) }
        assertTrue(e.message!!.contains("Unsupported"))
    }

    @Test fun invalidUtf8SourceIsRejected() {
        expectThrows<ImportException> { read(zip(validEntries().map { if (it.first == "fragment.frag") it.first to byteArrayOf(0x23, 0xC3.toByte(), 0x28) else it })) }
    }

    @Test fun badPreviewMagicIsRejected() {
        expectThrows<ImportException> { read(zip(validEntries() + ("preview.png" to "GIF89a".toByteArray()))) }
    }

    @Test fun safeNameRules() {
        assertTrue(ImportLimits.isSafeEntryName("manifest.json"))
        assertFalse(ImportLimits.isSafeEntryName("manifest.json/"))
        assertFalse(ImportLimits.isSafeEntryName(".hidden"))
        assertFalse(ImportLimits.isSafeEntryName("a\u0000b"))
        assertFalse(ImportLimits.isSafeEntryName(""))
    }
}

class SourceImportTest {
    private val frag = MIN_FRAGMENT.toByteArray()

    @Test fun fragmentFileBecomesCodeProject() {
        val p = SourceImport.fromBytes("My Shader.frag", frag, MIN_VERTEX, "unused", 5L, "id-1")
        assertEquals("My Shader", p.name)
        assertEquals(ProjectType.CODE, p.type)
        assertEquals(MIN_FRAGMENT, p.fragmentSource)
        assertEquals(MIN_VERTEX, p.vertexSource)
        assertTrue(p.params.any { it.uniform == "u_scale" })
    }

    @Test fun vertexFileKeepsDefaultFragment() {
        val p = SourceImport.fromBytes("v.vert", MIN_VERTEX.toByteArray(), "x", MIN_FRAGMENT, 5L, "id-2")
        assertEquals(MIN_VERTEX, p.vertexSource)
        assertEquals(MIN_FRAGMENT, p.fragmentSource)
    }

    @Test fun crlfIsNormalised() {
        val p = SourceImport.fromBytes("a.glsl", MIN_FRAGMENT.replace("\n", "\r\n").toByteArray(), MIN_VERTEX, "", 1L, "id-3")
        assertFalse(p.fragmentSource.contains('\r'))
    }

    @Test fun rejectsWrongExtensionOversizeBadUtf8AndWrongVersion() {
        expectThrows<ImportException> { SourceImport.fromBytes("a.txt", frag, MIN_VERTEX, "", 1L, "i") }
        expectThrows<ImportException> { SourceImport.fromBytes("a.frag", ByteArray(ImportLimits.MAX_SOURCE_BYTES + 1), MIN_VERTEX, "", 1L, "i") }
        expectThrows<ImportException> { SourceImport.fromBytes("a.frag", byteArrayOf(0x23, 0xFF.toByte(), 0xFE.toByte()), MIN_VERTEX, "", 1L, "i") }
        val e = expectThrows<ImportException> { SourceImport.fromBytes("a.frag", "#version 100\nvoid main(){}".toByteArray(), MIN_VERTEX, "", 1L, "i") }
        assertTrue(e.message!!.contains("300 es"))
        expectThrows<ImportException> { SourceImport.fromBytes("a.frag", "void main(){}".toByteArray(), MIN_VERTEX, "", 1L, "i") }
    }
}

private class MemoryIndex : ProjectIndex {
    val rows = MutableStateFlow<Map<String, ProjectRow>>(emptyMap())
    override fun observeAll() = kotlinx.coroutines.flow.flow { rows.collect { emit(it.values.toList()) } }
    override suspend fun get(id: String) = rows.value[id]
    override suspend fun upsert(row: ProjectRow) { rows.value = rows.value + (row.id to row) }
    override suspend fun delete(id: String) { rows.value = rows.value - id }
}

class FileProjectRepositoryTest {
    private fun newRepo(): Triple<FileProjectRepository, MemoryIndex, File> {
        val dir = Files.createTempDirectory("shaderart-test").toFile()
        val index = MemoryIndex()
        var tick = 10_000L
        var n = 0
        val repo = FileProjectRepository(dir, index, clock = { tick += 100; tick }, idGenerator = { "gen-${++n}" }, io = Dispatchers.Unconfined)
        return Triple(repo, index, dir)
    }

    @Test fun saveThenLoadRoundTrips(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            val saved = repo.save(sampleProject())
            assertTrue(saved.modifiedAt > sampleProject().modifiedAt)
            assertEquals(saved, repo.load("proj-1"))
            assertTrue(repo.exists("proj-1"))
        } finally { dir.deleteRecursively() }
    }

    @Test fun saveLeavesNoTemporaryFiles(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            repo.save(sampleProject()); repo.save(sampleProject().copy(name = "Again"))
            val leftovers = dir.walkTopDown().filter { it.name.endsWith(".tmp") }.toList()
            assertTrue(leftovers.toString(), leftovers.isEmpty())
        } finally { dir.deleteRecursively() }
    }

    @Test fun resavingKeepsFavoriteAndCreationDate(): Unit = runBlocking {
        val (repo, index, dir) = newRepo()
        try {
            repo.save(sampleProject())
            repo.setFavorite("proj-1", true)
            repo.save(sampleProject().copy(name = "Renamed"))
            val row = index.get("proj-1")!!
            assertTrue(row.favorite)
            assertEquals("Renamed", row.name)
            assertEquals(1_000L, row.createdAt)
        } finally { dir.deleteRecursively() }
    }

    @Test fun listingReflectsChanges(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            repo.save(sampleProject("a", "A")); repo.save(sampleProject("b", "B"))
            assertEquals(setOf("a", "b"), repo.observeProjects().first().map { it.id }.toSet())
            repo.delete("a")
            assertEquals(listOf("b"), repo.observeProjects().first().map { it.id })
            assertFalse(File(dir, "projects/a").exists())
        } finally { dir.deleteRecursively() }
    }

    @Test fun renameAndDuplicate(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            repo.save(sampleProject())
            repo.saveThumbnail("proj-1", byteArrayOf(1, 2, 3))
            repo.rename("proj-1", "  New name ")
            assertEquals("New name", repo.load("proj-1").name)
            val copyId = repo.duplicate("proj-1")
            assertNotEquals("proj-1", copyId)
            assertEquals("New name copy", repo.load(copyId).name)
            assertEquals(repo.load("proj-1").values, repo.load(copyId).values)
            assertTrue(repo.thumbnailFile(copyId).isFile)
            expectThrows<IllegalArgumentException> { runBlocking { repo.rename("proj-1", "  ") } }
        } finally { dir.deleteRecursively() }
    }

    @Test fun loadingMissingOrDamagedProjectIsAFormatError(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            expectThrows<ProjectFormatException> { runBlocking { repo.load("nope") } }
            repo.save(sampleProject())
            File(dir, "projects/proj-1/manifest.json").writeText("{ broken")
            expectThrows<ProjectFormatException> { runBlocking { repo.load("proj-1") } }
        } finally { dir.deleteRecursively() }
    }

    @Test fun unsafeIdsNeverTouchTheFileSystem(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            expectThrows<IllegalArgumentException> { runBlocking { repo.load("../outside") } }
            expectThrows<IllegalArgumentException> { runBlocking { repo.save(sampleProject(id = "../outside")) } }
            expectThrows<IllegalArgumentException> { repo.thumbnailFile("a/b") }
            assertFalse(repo.exists("../x"))
        } finally { dir.deleteRecursively() }
    }

    @Test fun importAlwaysAssignsAFreshId(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            repo.save(sampleProject())
            val imported = repo.importProject(sampleProject(), byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47))
            assertNotEquals("proj-1", imported.id)
            assertEquals("Sample", repo.load("proj-1").name)
            assertTrue(repo.thumbnailFile(imported.id).isFile)
        } finally { dir.deleteRecursively() }
    }

    @Test fun archiveExportThenImportRoundTrips(): Unit = runBlocking {
        val (repo, _, dir) = newRepo()
        try {
            repo.save(sampleProject())
            repo.saveThumbnail("proj-1", byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte(), 9))
            val bos = ByteArrayOutputStream()
            repo.writeArchive("proj-1", bos)
            val parsed = ShaderArchive.read(ByteArrayInputStream(bos.toByteArray()))
            assertNotNull(parsed.preview)
            val imported = repo.importProject(parsed.project, parsed.preview)
            val a = repo.load("proj-1"); val b = repo.load(imported.id)
            assertEquals(a.fragmentSource, b.fragmentSource)
            assertEquals(a.values, b.values)
            assertEquals(a.params, b.params)
        } finally { dir.deleteRecursively() }
    }
}
