# SHADER ART — Real-Time GPU Visual Laboratory (v0.02)

SHADER ART is a native Android app for making, tuning and exporting real-time GPU shader art. It runs fully offline: **no internet permission, no accounts, no analytics, no ads.** The only sensitive permission is the **microphone**, used only if you choose a sound source that needs it.

- Package: `com.shaderart.studio` · Version: `0.02` (versionCode 2)
- Kotlin, Jetpack Compose, OpenGL ES 3.0 (GLSL ES 3.00), minSdk 26, Gradle Kotlin DSL
- Build output: a **debug APK**

> **Honesty note.** This project was written in a sandbox that could not reach the Android SDK or Maven. v0.01 was built successfully by GitHub Actions on your side; **v0.02 has not been built or run on a device by its author**. What *was* verified, and what was not, is listed in [Verification status](#verification-status). The v0.02 UI code in particular (Jetpack Compose) has never been compiled; if the Actions build fails, send the error text and it can be fixed quickly.

## What is new in v0.02

| Feature | Where |
|---|---|
| **Video export** (H.264 MP4, up to 4K / 60 s, picture only) and **GIF export** (up to 720 px, 300 frames) | Export screen → *What to export* |
| **Transparent PNG** (shader alpha, or "Black → transparent" keying for glowing artwork) | Export screen → Transparency |
| **Live wallpaper** (draws only while visible, 15–60 fps cap, touch reacts) | Studio → Tools → Wallpaper |
| **Multi-pass shaders**: Image + Buffers A–D, 4 inputs per pass, ping-pong feedback (float buffers when the GPU allows) | Code Studio tabs + Tools → Passes |
| **Texture inputs**: import pictures (shrunk to ≤2048 px, stored in the project), built-in noise, audio texture | Tools → Passes |
| **Audio-reactive input**: demo beat, microphone, or an audio file; `u_audio`, `u_beat`, spectrum/waveform texture | Tools → Inputs |
| **Sensor uniforms**: `u_tilt`, `u_gyro`, `u_accel` | Tools → Inputs |
| **Touch reaction**: multi-touch (`u_touches[10]`), pressure, velocity, recent taps (`u_taps[8]`) | always on |
| **Post-effect stack**: 14 effects (vignette, blur, bloom, colour grade, chromatic aberration, lens, sharpen, film grain, pixelate, posterize, invert, duotone, mirror/kaleidoscope, edge detect) with reorder/enable | Tools → Post effects |
| **Keyframe timeline**: animate any slider or colour channel with easing; applied live and in exports | Tools → Timeline |
| **Shadertoy import**: paste `mainImage` code (with Common and Buffers A–D) or exported JSON | Code Studio → ⋮ → Import from Shadertoy |
| **10 new presets** (33 total, 10 categories): Reflective Chrome, Abstract Environment, Recursive Geometry (Menger sponge), Kaleidoscope, Truchet Weave, Audio Spectrum Rings, Audio Pulse Tunnel, Touch Ripples, Feedback Trails (multi-pass), Reaction-Diffusion (4 chained buffers) | Explore |
| **5 new code templates**: audio, touch, sensors, picture input, multi-pass feedback | Code Studio |

---

## What is in the app

| Destination | What it does |
|---|---|
| **Home** | Continue recent projects, featured presets, quick actions, compatibility warning if the GPU is too old. |
| **Explore** | 33 presets in 10 categories (Fluid, Math, Geometric, Raymarch, Digital, Reflective, Environments, Recursive, Audio-reactive, Interactive). Search (name, category, tag), filter, favourites. Previews are rendered by your own GPU. |
| **Visual Studio** | Live preview with sliders, numeric fields, switches, colour picker, palettes, Randomize, Variation, Reset, speed, zoom (pinch), quality. Save, rename, export. |
| **Code Studio** | GLSL editor: syntax colours, line numbers, completion, auto-indent, undo/redo, find, format, Image / Buffer A–D / Vertex tabs, templates, channel + picture panel, Run / Stop / auto-compile, GPU-driver error messages you can tap to jump to the line, Output / Uniforms / Info panel. |
| **Gallery** | Saved projects with thumbnails, search, filter, sort, favourites, rename, duplicate, delete, import and export (`.shaderart`). |
| **Settings** | Default quality, performance panel, 30 FPS limit, device and GPU info, about. |

Also: PNG/JPEG/GIF/MP4 export (progress, cancel, save with the system file picker, share; images up to the real limit of your GPU), phone wallpaper sizes, lifecycle-aware rendering (the GPU is idle when the app is not on screen), GPU context-loss recovery, edge-to-edge dark AMOLED UI, accessibility labels.

### Shader parameters from comments

In Code Studio, controls are created from annotations next to a `uniform`:

```glsl
uniform float u_amount;   // @slider 0 1 0.5 "Amount"
uniform vec3  u_tint;     // @color 1.0 0.5 0.2 "Tint"
uniform bool  u_invert;   // @toggle 0 "Invert"
```

### Built-in uniforms

Declare only the ones you use (a uniform your shader does not declare is simply skipped).

| Uniform | Meaning |
|---|---|
| `float u_time`, `vec2 u_resolution`, `float u_deltaTime`, `int u_frame`, `float u_speed`, `float u_zoom` | clock, size, frame data, UI speed, pinch zoom |
| `vec4 u_mouse` | xy = first finger 0..1 (origin bottom-left), z = 1 while down |
| `vec4 u_mousePx` | Shadertoy-style `iMouse` in pixels |
| `vec4 u_date` | year, month (0–11), day, seconds since midnight |
| `vec4 u_touches[10]`, `int u_touchCount`, `float u_pressure`, `vec2 u_touchVel` | multi-touch: xy 0..1, z pressure, w = down |
| `vec4 u_taps[8]`, `int u_tapCount` | recent taps: xy 0..1, z = `u_time` of the tap, w = strength |
| `vec4 u_audio` (level, bass, mid, treble), `float u_beat` | sound analysis (0..1); silent if no source is on |
| `vec2 u_tilt`, `vec3 u_gyro`, `vec3 u_accel` | motion sensors (when switched on) |
| `sampler2D u_channel0..3`, `vec3 u_channelResolution[4]` | the pass inputs: buffer, picture, noise or audio |

The **audio texture** (`Audio` channel) is 512×2: row 0.25 = log-frequency spectrum, row 0.75 = waveform. Passes run in the order Buffer A, B, C, D, then Image, then the post stack. A pass that reads a buffer drawn earlier in the same frame sees the new image; reading itself or a later buffer gives the previous frame (feedback).

Shaders are GLSL ES 3.00: start with `#version 300 es`, declare `out vec4`, and write your colour in `main`. Buffer passes are complete shaders with their own `main()`.

Coordinates: `gl_FragCoord` has its origin at the **bottom-left**. Exported images are flipped to normal orientation.

---

## Getting the APK from your phone (no computer needed)

You need a free GitHub account. GitHub's servers build the app for you.

### 1. Upload the two files
1. In the GitHub app or in a mobile browser (use "Desktop site" if offered), create a **new repository** (private is fine). Do not add any files yet.
2. Open the repository → **Add file → Upload files**.
3. Upload **`SHADER-ART-v0.02.zip`** (the ZIP itself — do **not** unzip it). If the older `SHADER-ART-v0.02.zip` is still there you can leave it or delete it: the workflow uses the highest version.
4. Create the workflow file. Easiest: **Add file → Create new file**, type the name exactly `.github/workflows/build-apk.yml` (typing the slashes creates the folders), paste the contents of the provided `build-apk.yml`, and commit.

The repository root must look like this:

```
your-repo/
├── SHADER-ART-v0.02.zip
└── .github/
    └── workflows/
        └── build-apk.yml
```

(The ZIP also contains a copy of the workflow and the full project, so you may alternatively upload the extracted project; the workflow handles both.)

### 2. Start the build
- Committing to `main`/`master` starts it automatically, **or**
- Open the **Actions** tab → **Build SHADER ART debug APK** → **Run workflow**.
- If the Actions tab asks you to enable workflows, press the green button.

A build takes roughly 8–15 minutes the first time. Green tick = success.

### 3. Download and install
1. Open the finished run → scroll to **Artifacts** → tap **`SHADER-ART-v0.02-debug-APK`**. GitHub downloads a ZIP.
2. Open your Files app, unzip it, and tap `SHADER-ART-v0.02-debug.apk`.
3. Android will ask to allow installs from this source (your browser or Files app). Allow it for this install, then press **Install**.
4. Google Play Protect may warn that the app is unrecognised. That is normal for any app not from the Play Store: this is a debug build signed with a debug key.

If the build fails, open the run, tap the red step, and copy the error. The `SHADER-ART-v0.02-reports` artifact also holds test and lint reports.

---

## Building in Android Studio (optional)

1. Install Android Studio (Ladybug or newer) with JDK 17.
2. Unzip the ZIP, **File → Open** the `ShaderArt` folder, let Gradle sync.
3. Run on a device or emulator with OpenGL ES 3.0, or from a terminal:
   ```
   ./gradlew testDebugUnitTest      # unit tests (JVM)
   ./gradlew lintDebug              # lint
   ./gradlew assembleDebug          # APK in app/build/outputs/apk/debug/
   ./gradlew connectedDebugAndroidTest   # GPU + storage tests, needs a device/emulator
   ```

Toolchain: AGP 8.7.3 · Gradle 8.9 (wrapper) · Kotlin 2.1.0 · KSP 2.1.0-1.0.29 · Compose BOM 2024.12.01 · Room 2.6.1 · compileSdk/targetSdk 35 · Java 17.

---

## Project layout

```
app/src/main/java/com/shaderart/studio/
  app/            Application, AppContainer (hand-wired dependencies), MainActivity, navigation
  core/
    gpu/          ShaderCapabilities, ShaderProgram, fullscreen triangle, render targets, ping-pong buffers
    pipeline/     PassPipeline (buffers → image → post stack), post shaders, texture decoding
    audio/ input/ FFT + beat analysis, touch state, live-input hub
    compiler/     ShaderCompiler (real driver logs), ShaderDiagnostic + log parser
    uniforms/     ShaderUniformManager (type-checked uniform binding)
    renderer/     ShaderRenderer, ShaderSurfaceView, RenderSession, RenderRequest/Stats
    export/       OffscreenRenderer (EGL pbuffer), GIF encoder, MP4 exporter (MediaCodec), ExportEngine, limits
    model/        Project, preset and parameter models and logic
    storage/      Room index + atomic file storage, migrations, serializer
    importing/    Validated import (.shaderart, .glsl, .frag, .vert), Shadertoy converter, Storage Access helpers
    presets/      Preset catalog + code templates
    security/     Import limits and safe-name rules
    shader/       Annotation parser, source checks
    json/         Strict JSON parser
  feature/        library, studio (shared ViewModel), params, codeeditor, export, settings, live (audio + sensors)
  service/        ShaderWallpaperService (live wallpaper)
  ui/             theme, components (editor, parameter panel, canvas), screens
app/src/main/assets/   shaders/*.frag, post/*.frag, presets/catalog.json, templates/*.frag
app/src/test/          JVM unit tests (192)
app/src/androidTest/   GPU (incl. GIF, MP4, transparency, multi-pass) and storage tests (run on a device)
tools/                 GLSL sources, preset generator, glslang validation script
```

Presets are generated from `tools/shader-src` by `python3 tools/build_presets.py`; `node tools/validate-glsl/validate.cjs app/src/main/assets/shaders` checks every shader with glslang.

---

## Verification status

**Actually run by the author (in a sandbox without the Android SDK or Maven):**
- All 33 presets (and the 5 buffer passes of the two multi-pass presets), all 11 template files and all 17 post-effect shaders validated with glslang (as GLSL ES 3.10 equivalents: confirms syntax and types, **not** what your GPU driver accepts). Deliberately broken shaders were confirmed to be rejected.
- The pure-Kotlin logic (JSON, models, parameters, storage and migrations, import limits and the `.shaderart` reader/writer, annotation parser, log parser, editor logic, **GIF encoder, FFT/beat analysis, touch state, timeline evaluation, post-stack model, multi-pass checks, Shadertoy converter, preset catalog loading**) was compiled with the real Kotlin 2.1.0 compiler and **192 unit tests passed** — run with a small stand-in for JUnit, not through Gradle.
- All non-UI Android code (renderer, pass pipeline, exporters, MediaCodec/EGL code, audio and sensor controllers, wallpaper service, the studio ViewModel and export controller) was **type-checked against the real Android 34 SDK stubs** (with small stand-ins for Compose state and Room). That proves it compiles, not that it works.
- Workflow YAML parsed, and each script in it syntax-checked.

**Not run by the author — first verified by your GitHub build or your phone:**
- The Gradle build, KSP/Room, **Compose compilation of all screens** (never compiled for v0.02), lint, `assembleDebug`.
- Everything that needs Android or a GPU: GL behaviour of the pass pipeline (float ping-pong buffers, feedback), post effects, GIF/MP4 output, MediaCodec support on your device, the live wallpaper, microphone/file audio analysis, sensors, touch on a real screen, the file pickers and permission prompts, performance on real hardware, thumbnails.
- The instrumentation tests (written, never executed; GitHub Actions does not run them).
- Installing and launching the APK.

Expect that a first build of this much new UI code written without a compiler may contain compile errors. Send the Actions error text and they can be fixed quickly.

---

## Limits and known gaps (v0.02)

- **Sound**: sources are the demo beat, the microphone, and a picked audio file (played by the app and analysed with Android's `Visualizer`, which needs the microphone permission). **Capturing other apps' playback system-wide is not implemented.** Microphone and demo sources stop when you leave the studio.
- **Video** has no audio track. Exports of audio-reactive shaders use the built-in demo beat, so they are reproducible. MP4 support depends on your device's H.264 encoder; the app checks first and reports why if it cannot.
- **GIF** is limited to 720 px and 300 frames (256 colours per frame, dithered).
- **Reaction-Diffusion** needs float render targets; on GPUs without them it falls back to 8-bit buffers and the chemistry will look coarse or die out.
- Large exports of feedback / multi-pass shaders are rendered in one piece (not tiled) after a warm-up of up to 900 frames; very large sizes may hit memory limits. Single-pass images are still tiled.
- **Shadertoy**: Image, Buffer A–D, Common, `iTime/iResolution/iMouse/iFrame/iTimeDelta/iDate/iChannelN` and buffer/noise/sound inputs are converted. Picture textures become noise (with a warning); cubemaps, volumes, video, webcam, keyboard and *sound* shaders are not supported. Shadertoy shaders carry their authors' licences (by default CC BY-NC-SA 3.0): check before reusing or sharing results. Imported code never runs until you press Run.
- Channel sampler filtering is fixed (buffers linear/clamp, pictures and noise linear/repeat).
- Adding, removing or reordering post effects rebuilds the pipeline, which restarts feedback buffers.
- A picture added to a draft that you never save leaves a small orphan file in app storage.
- The live wallpaper shows the *saved* version of the project; sound and sensors are off there.

---

## Security and privacy

- No `INTERNET` permission (the workflow fails the build if one appears). No analytics, ads or accounts. `RECORD_AUDIO` is declared for the microphone / audio-file sources only; it is requested at the moment you pick one, audio is analysed in memory and never stored or sent, and the microphone closes when the studio leaves the screen. Pictures and audio files are read through the system file picker (no storage permission).
- Imports are validated: size limits, a fixed list of allowed archive entries, zip-bomb limits, safe file names, strict JSON, and **imported shaders never run until you press Run**.
- Files are written atomically; shared images, GIFs and videos go through a restricted `FileProvider` (export cache only). Imported pictures are re-encoded to PNG (metadata stripped) and size-capped; archive entry names are allow-listed.
- A slow shader is automatically paused after three frames longer than one second.

## Known limitations

- Debug build only (debug signature). Not published to any store.
- Dark theme only. The UI is monochrome; the artwork, syntax colours and error/success messages are the only coloured elements.
- Large single-pass image exports use tiled rendering, which is exact only for shaders that depend on `gl_FragCoord`; multi-pass and post-stack exports render in one piece. Very large sizes can still run out of memory on low-RAM phones; the app reports the failure.
- Saving through the system file picker may append `.txt` or `.bin` on some storage providers.
- Preset previews are rendered on first view and then cached, so Explore fills in progressively.
- Editor: lines do not wrap (the editor scrolls sideways); no replace, multi-cursor or bracket matching.
- Accessibility labels are provided, but v0.02 was not tested with TalkBack.

## Deferred (not in v0.02)

System-wide playback capture as an audio source · a sound track in exported videos · cubemap / volume / video inputs · per-channel sampler filter and wrap options · cloud features.

## Troubleshooting

| Problem | What to do |
|---|---|
| Actions says "Could not find settings.gradle.kts" | The ZIP is not in the repository root, or was unzipped incorrectly. Upload `SHADER-ART-v0.02.zip` itself, next to `.github`. |
| Build fails in "Unit tests" or "Assemble" | Open the red step and copy the first `error:` line. |
| "App not installed" | Uninstall any older copy first; make sure you downloaded the unzipped `.apk`. |
| Black preview, message about OpenGL ES | The device does not support OpenGL ES 3.0. |
| A shader is slow | Lower the quality (25–50%) or enable the 30 FPS limit. |
| Compile error in Code Studio | The Output tab shows the driver's own message; tap a line to jump to it. |
