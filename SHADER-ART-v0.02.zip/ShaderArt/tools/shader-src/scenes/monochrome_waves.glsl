// Monochrome Waves: layered flowing sine lines.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float acc = 0.0;
  for (int i = 0; i < 14; i++) {
    if (i >= int(u_complexity) * 2) break;
    float fi = float(i);
    float w = sin(p.x * u_frequency * (1.0 + 0.15 * fi) + u_time * (0.4 + 0.07 * fi) + fi * 1.7);
    w *= 0.3 / (1.0 + fi * 0.25) * u_distortion;
    float d = abs(p.y - w + (fi - 6.0) * 0.14);
    acc += smoothstep(0.018 * u_intensity + 0.004, 0.0, d) * (1.0 - fi / 20.0);
  }
  return mix(u_bgColor, u_colorA, clamp(acc, 0.0, 1.0));
}
