// Truchet Weave: quarter-circle tiles drift past; light pulses run along the arcs.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * 2.5 * u_density + vec2(u_time * 0.25, u_time * 0.1);
  vec2 id = floor(p);
  vec2 f = fract(p) - 0.5;
  float rnd = hash21(id + u_seed);
  if (rnd > 0.5) f.x = -f.x;
  vec2 c1 = f - vec2(0.5, 0.5);
  vec2 c2 = f + vec2(0.5, 0.5);
  float d1 = abs(length(c1) - 0.5);
  float d2 = abs(length(c2) - 0.5);
  bool first = d1 < d2;
  float d = min(d1, d2);
  vec2 cc = first ? c1 : c2;
  float ang = atan(cc.y, cc.x);
  float w = 0.03 + 0.05 * u_distortion;
  float over = mod(id.x + id.y, 2.0);
  float line = smoothstep(w, w - 0.02, d);
  float edge = smoothstep(w + 0.025, w, d) - line;
  float pulse = 0.5 + 0.5 * sin(ang * 4.0 - u_time * 3.0 * u_flow + rnd * 6.2831);
  vec3 col = u_bgColor;
  col += edge * 0.25 * u_colorB;
  col = mix(col, ramp(rnd + 0.3 * pulse), line * (0.55 + 0.45 * pulse));
  col *= 0.85 + 0.15 * over;
  col += pow(pulse, 8.0) * line * 0.5 * u_colorB;
  return col * u_intensity;
}
