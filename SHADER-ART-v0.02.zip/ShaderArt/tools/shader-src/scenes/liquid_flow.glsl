// Liquid Flow: domain-warped fractal noise (Inigo Quilez-style warping) tinted with the palette.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale + u_seed;
  float t = u_time * 0.25;
  int oct = int(u_complexity);
  vec2 q = vec2(fbm(p + vec2(0.0, t), oct), fbm(p + vec2(5.2, 1.3 - t), oct));
  vec2 w = p + u_distortion * 2.0 * q;
  vec2 r = vec2(fbm(w + vec2(1.7, 9.2) + 0.5 * t, oct), fbm(w + vec2(8.3, 2.8) - 0.4 * t, oct));
  float f = fbm(p + u_distortion * 2.0 * r, oct);
  vec3 col = mix(u_bgColor, ramp(f * 1.6), smoothstep(0.1, 0.9, f + 0.3));
  col = mix(col, u_colorB, clamp(length(q) * 0.7, 0.0, 1.0) * 0.5);
  col += u_intensity * 0.15 * smoothstep(0.55, 0.9, f);
  return col;
}
