// Plasma Dreams: classic sine-sum plasma with a moving centre.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float t = u_time;
  float f = u_frequency;
  float v = sin(p.x * f + t);
  v += sin((p.y * f + t) * 0.5);
  v += sin((p.x + p.y) * f * 0.5 + t * 0.7);
  vec2 c = p + 0.5 * vec2(sin(t * 0.33), cos(t * 0.5));
  v += sin(sqrt(dot(c, c) * f * f + 1.0) + t);
  v = v * 0.125 + 0.5;
  float bands = 0.5 + 0.5 * sin(TAU * v * u_complexity * 0.5);
  vec3 col = mix(u_colorA, u_colorB, bands);
  return mix(u_bgColor, col, clamp(smoothstep(0.0, 0.5, v) * u_intensity, 0.0, 1.0));
}
