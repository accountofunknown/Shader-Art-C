// Recursive Geometry: a Menger sponge. Each step of Complexity cuts the same pattern into every remaining block.
float sdBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float map(vec3 p, out float orbit) {
  float d = sdBox(p, vec3(1.0));
  float s = 1.0;
  orbit = 0.0;
  for (int m = 0; m < 4; m++) {
    if (m >= int(u_complexity)) break;
    vec3 a = mod(p * s, 2.0) - 1.0;
    s *= 3.0;
    vec3 r = abs(1.0 - 3.0 * abs(a));
    float da = max(r.x, r.y);
    float db = max(r.y, r.z);
    float dc = max(r.z, r.x);
    float c = (min(da, min(db, dc)) - 1.0) / s;
    if (c > d) { d = c; orbit = float(m + 1); }
  }
  return d;
}

vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc);
  float yaw = u_time * 0.3 + (u_mouse.z > 0.5 ? (u_mouse.x - 0.5) * 6.0 : 0.0);
  float pitch = 0.5 + 0.25 * sin(u_time * 0.2) + (u_mouse.z > 0.5 ? (u_mouse.y - 0.5) * 2.0 : 0.0);
  vec3 ro = vec3(0.0, 0.0, 3.4 / u_scale);
  ro.yz = rot(pitch) * ro.yz;
  ro.xz = rot(yaw) * ro.xz;
  vec3 fwd = normalize(-ro);
  vec3 right = normalize(cross(fwd, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, fwd);
  vec3 rd = normalize(fwd * 1.8 + right * uv.x + up * uv.y);
  vec3 col = u_bgColor + 0.06 * (1.0 - length(uv) * 0.5);
  float t = 0.0;
  float orb = 0.0;
  bool hit = false;
  for (int i = 0; i < 96; i++) {
    float o;
    float d = map(ro + rd * t, o);
    if (d < 0.0008 * t) { hit = true; orb = o; break; }
    t += d;
    if (t > 8.0) break;
  }
  if (hit) {
    vec3 p = ro + rd * t;
    float dummy;
    vec2 e = vec2(0.001 * t, 0.0);
    vec3 n = normalize(vec3(map(p + e.xyy, dummy) - map(p - e.xyy, dummy), map(p + e.yxy, dummy) - map(p - e.yxy, dummy), map(p + e.yyx, dummy) - map(p - e.yyx, dummy)));
    vec3 l = normalize(vec3(0.6, 0.8, 0.4));
    float diff = max(dot(n, l), 0.0);
    float ao = clamp(map(p + n * 0.05, dummy) / 0.05, 0.0, 1.0);
    vec3 base = mix(u_colorA, u_colorB, clamp(orb / 4.0, 0.0, 1.0));
    col = base * (0.25 + 0.9 * diff) * (0.4 + 0.6 * ao) * u_intensity;
    col += pow(max(dot(reflect(rd, n), l), 0.0), 24.0) * 0.4;
  }
  return col;
}
