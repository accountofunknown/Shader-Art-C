// Infinite Tunnel: sphere-traced tube. The step count is capped by u_iterations (max 96)
// and the ray is cut off at a fixed far distance.
float mapTunnel(vec3 p) {
  p.xy += vec2(sin(p.z * 0.35), cos(p.z * 0.27)) * 0.35 * u_distortion;
  float ang = atan(p.y, p.x);
  float rib = 0.07 * sin(p.z * u_frequency) * sin(ang * 6.0);
  return 1.5 * u_scale - length(p.xy) + rib;
}

vec3 scene(vec2 fc) {
  vec2 uv = rot(u_time * 0.12) * uvOf(fc);
  vec3 ro = vec3(0.0, 0.0, u_time * 1.5);
  vec3 rd = normalize(vec3(uv, 1.1));
  float t = 0.0;
  float steps = 0.0;
  for (int i = 0; i < 96; i++) {
    if (i >= u_iterations) break;
    float d = mapTunnel(ro + rd * t);
    if (d < 0.002 || t > 40.0) break;
    t += d * 0.85;
    steps += 1.0;
  }
  vec3 p = ro + rd * t;
  float stripe = 0.5 + 0.5 * sin(p.z * u_frequency * 1.5 + atan(p.y, p.x) * 3.0);
  float fog = exp(-t * 0.08);
  float ao = 1.0 - steps / float(max(u_iterations, 1));
  vec3 col = mix(u_colorA, u_colorB, stripe) * ao * u_intensity * 1.2;
  return mix(u_bgColor, col, fog);
}
