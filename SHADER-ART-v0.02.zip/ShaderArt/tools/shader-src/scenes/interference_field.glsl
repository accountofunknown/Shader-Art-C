// Interference Field: overlapping circular waves from orbiting sources.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float v = 0.0;
  float n = float(max(int(u_complexity), 1));
  for (int i = 0; i < 8; i++) {
    if (float(i) >= n) break;
    float a = float(i) * 0.9 + u_time * 0.1;
    vec2 c = vec2(cos(a), sin(a)) * (0.5 + 0.3 * sin(u_time * 0.2 + float(i)));
    v += sin(length(p - c) * u_frequency * 5.0 - u_time * 2.0);
  }
  v = 0.5 + 0.5 * v / n;
  float band = smoothstep(0.45, 0.55, v);
  vec3 col = mix(u_bgColor, ramp(v), band * clamp(u_intensity, 0.0, 1.0));
  col += (1.0 - band) * 0.12 * u_colorB;
  return col;
}
