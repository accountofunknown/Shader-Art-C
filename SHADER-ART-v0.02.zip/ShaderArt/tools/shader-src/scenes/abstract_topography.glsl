// Abstract Topography: contour lines of a slowly evolving fractal height field.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * 1.5 + u_seed;
  float h = fbm(p + u_time * 0.03, int(u_complexity));
  float f = fract(h * u_frequency * 3.0);
  float line = 1.0 - smoothstep(0.0, 0.06, f) * smoothstep(1.0, 0.94, f);
  vec3 fill = mix(u_bgColor, ramp(h * 1.4), 0.5);
  return mix(fill, u_colorA * u_intensity + 0.1, line * 0.85);
}
