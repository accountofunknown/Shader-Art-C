// Radial Rings: polar-coordinate rings crossed with spokes (circular waves, radial structure).
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float r = length(p);
  float a = atan(p.y, p.x);
  float rings = 0.5 + 0.5 * sin(r * u_frequency * 6.0 - u_time * 2.0);
  float spokes = 0.5 + 0.5 * cos(a * float(u_sides) + r * u_distortion * 3.0 - u_time);
  float v = rings * spokes;
  vec3 col = mix(u_bgColor, ramp(v + 0.2 * r), smoothstep(0.05, 0.6, v) * clamp(u_intensity, 0.0, 1.0));
  col += smoothstep(0.03, 0.0, r) * u_colorB;
  return col;
}
