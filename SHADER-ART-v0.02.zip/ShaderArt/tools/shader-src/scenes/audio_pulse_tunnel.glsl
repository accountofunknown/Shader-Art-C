// Audio Pulse Tunnel: rings rush toward you and flash with the beat; bass widens the tunnel, treble adds sparkle.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc);
  float r = length(p) + 1e-4;
  float a = atan(p.y, p.x);
  float depth = 0.5 / r * u_scale;
  float z = depth + u_time * 1.5 + u_audio.y * 0.6;
  float rings = smoothstep(0.08, 0.0, abs(fract(z) - 0.5) - 0.38 + u_audio.x * 0.1);
  float spokes = smoothstep(0.06, 0.0, abs(fract(a / TAU * float(u_sides) * 2.0 + z * 0.1) - 0.5) - 0.42);
  float fogv = exp(-depth * 0.15);
  vec3 col = u_bgColor;
  col += rings * mix(u_colorA, u_colorB, fract(z * 0.2)) * (0.5 + u_beat * 1.5) * fogv;
  col += spokes * u_colorB * (0.15 + u_audio.z * 0.6) * fogv;
  col += u_beat * 0.25 * u_colorA * exp(-r * 3.0);
  float spark = step(0.985 - u_audio.w * 0.1, hash21(floor(vec2(a * 40.0, z * 6.0))));
  col += spark * u_audio.w * fogv * 1.5;
  col *= smoothstep(0.0, 0.25, r) * u_intensity;
  return col;
}
