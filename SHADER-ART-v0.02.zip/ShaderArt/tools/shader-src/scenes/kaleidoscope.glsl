// Kaleidoscope: space is folded into mirrored wedges, then folded again and again (Complexity) before colouring.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float seg = TAU / float(u_sides);
  float a = atan(p.y, p.x) + u_time * 0.1;
  float r = length(p);
  a = abs(mod(a, seg) - 0.5 * seg);
  p = vec2(cos(a), sin(a)) * r;
  float acc = 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= int(u_complexity)) break;
    p = abs(p) - vec2(0.25 + 0.1 * sin(u_time * 0.3 + float(i)), 0.1) * u_distortion;
    p *= rot(0.5 + 0.2 * sin(u_time * 0.2));
    p *= 1.18;
    acc += exp(-4.0 * length(p));
  }
  float n = fbm(p * 2.0 + u_time * 0.1, 4);
  float v = clamp(acc * 0.8 + n * 0.6, 0.0, 1.5);
  vec3 col = mix(u_bgColor, ramp(v), smoothstep(0.0, 0.5, v)) * u_intensity;
  col += u_colorB * 0.12 * smoothstep(0.02, 0.0, abs(r - 0.5));
  return col;
}
