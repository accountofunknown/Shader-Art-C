// Reaction-Diffusion: one Gray-Scott step per buffer. Buffers A, B, C and D are chained (A reads D from the previous
// frame, B reads A, C reads B, D reads C), so each frame advances the chemistry four steps.
// This file is used for all four buffers: channel 0 is the previous step.
void main() {
  vec2 px = 1.0 / u_resolution;
  vec2 uv = gl_FragCoord.xy * px;
  vec2 c = texture(u_channel0, uv).xy;
  if (c.x < 0.001 && c.y < 0.001) {
    // First frame (or after a resize): fill with u = 1 and seed v in a few random patches.
    float seed = hash21(floor(uv * 14.0) + u_seed);
    float blob = step(0.9, seed) * step(length(fract(uv * 14.0) - 0.5), 0.35);
    fragColor = vec4(1.0, blob, 0.0, 1.0);
    return;
  }
  vec2 n = texture(u_channel0, uv + vec2(0.0, px.y)).xy;
  vec2 s = texture(u_channel0, uv - vec2(0.0, px.y)).xy;
  vec2 e = texture(u_channel0, uv + vec2(px.x, 0.0)).xy;
  vec2 w = texture(u_channel0, uv - vec2(px.x, 0.0)).xy;
  vec2 ne = texture(u_channel0, uv + px).xy;
  vec2 nw = texture(u_channel0, uv + vec2(-px.x, px.y)).xy;
  vec2 se = texture(u_channel0, uv + vec2(px.x, -px.y)).xy;
  vec2 sw = texture(u_channel0, uv - px).xy;
  vec2 lap = 0.2 * (n + s + e + w) + 0.05 * (ne + nw + se + sw) - c;
  float uvv = c.x * c.y * c.y;
  vec2 next = c + vec2(1.0 * lap.x - uvv + u_feed * (1.0 - c.x), 0.5 * lap.y + uvv - (u_feed + u_kill) * c.y);
  // Touching adds the second chemical, so you can draw new growth.
  if (u_mouse.z > 0.5) {
    float d = length((uv - u_mouse.xy) * vec2(u_resolution.x / u_resolution.y, 1.0));
    next.y += smoothstep(0.04, 0.0, d) * 0.5;
  }
  fragColor = vec4(clamp(next, 0.0, 1.0), 0.0, 1.0);
}
