// Domain Repeat: repeated, folded and rotated space gives recursive-looking structure.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  vec3 col = u_bgColor;
  for (int i = 0; i < 8; i++) {
    if (i >= int(u_complexity)) break;
    float fi = float(i);
    p = rot(u_time * 0.15 + fi * 0.4) * p;
    p = abs(fract(p * u_density * 0.8 + 0.5) - 0.5) * 2.0;
    float d = abs(max(p.x, p.y) - 0.5);
    col += (0.012 * u_intensity) / (d + 0.012) / (1.0 + fi * 0.3) * ramp(fi / 8.0);
  }
  return col;
}
