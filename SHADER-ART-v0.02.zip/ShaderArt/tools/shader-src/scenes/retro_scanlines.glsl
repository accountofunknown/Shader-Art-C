// Retro Scanlines: synthwave sun and perspective floor grid. CRT scanlines, grain and RGB split
// are enabled by default in the post-effects group.
vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc);
  vec3 col = mix(u_bgColor, u_colorB * 0.6, smoothstep(-0.2, 1.0, uv.y));
  float horizon = -0.05;
  float sd = length(uv - vec2(0.0, 0.25)) - 0.45 * u_scale;
  float slice = uv.y > horizon ? 1.0 : step(0.0, sin(uv.y * 80.0));
  col = mix(col, mix(u_colorA, u_colorB, clamp(uv.y + 0.4, 0.0, 1.0)), smoothstep(0.01, 0.0, sd) * slice * step(horizon, uv.y));
  if (uv.y < horizon) {
    float h = horizon - uv.y;
    float z = 0.5 / h;
    vec2 g = vec2(uv.x * z * u_density, z * u_density + u_time * 2.0);
    vec2 gl = abs(fract(g) - 0.5);
    float line = smoothstep(0.42, 0.5, max(gl.x, gl.y)) * clamp(h * 3.0, 0.0, 1.0);
    col = mix(u_bgColor, u_colorA * u_intensity, line);
  }
  return col;
}
