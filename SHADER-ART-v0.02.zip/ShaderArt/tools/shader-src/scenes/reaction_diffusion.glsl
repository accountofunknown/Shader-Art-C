// Reaction-Diffusion: colours the chemical concentration (channel 0 = Buffer D) and adds relief lighting.
vec3 scene(vec2 fc) {
  vec2 uv = fc / u_resolution;
  vec2 px = 1.0 / u_resolution;
  float v = texture(u_channel0, uv).y;
  float vx = texture(u_channel0, uv + vec2(px.x, 0.0)).y - texture(u_channel0, uv - vec2(px.x, 0.0)).y;
  float vy = texture(u_channel0, uv + vec2(0.0, px.y)).y - texture(u_channel0, uv - vec2(0.0, px.y)).y;
  vec3 n = normalize(vec3(-vx * 6.0 * u_scale, -vy * 6.0 * u_scale, 1.0));
  float diff = max(dot(n, normalize(vec3(-0.4, 0.5, 0.8))), 0.0);
  vec3 col = mix(u_bgColor, ramp(v * 3.0), smoothstep(0.02, 0.35, v));
  col *= 0.55 + 0.7 * diff;
  col += pow(diff, 20.0) * 0.25 * smoothstep(0.05, 0.3, v);
  return col * u_intensity;
}
