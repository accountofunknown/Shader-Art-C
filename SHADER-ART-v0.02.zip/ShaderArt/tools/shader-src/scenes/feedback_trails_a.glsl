// Feedback Trails, Buffer A: remembers last frame (channel 0 = Buffer A itself), fades and swirls it,
// then draws new light at three orbiting emitters and at every finger.
void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  vec2 p = uv - 0.5;
  p *= rot(0.006 * u_flow);
  p *= 0.997;
  p += vec2(sin(uv.y * 9.0 + u_time), cos(uv.x * 9.0 - u_time)) * 0.0006 * u_flow;
  vec3 prev = texture(u_channel0, p + 0.5).rgb;
  prev = max(prev * u_decay - 0.0015, 0.0);
  vec2 q = uvOf(gl_FragCoord.xy);
  float t = u_time;
  vec3 add = vec3(0.0);
  for (int i = 0; i < 3; i++) {
    float fi = float(i);
    vec2 pos = vec2(sin(t * (0.6 + 0.17 * fi) + fi * 2.1), cos(t * (0.5 + 0.23 * fi) + fi * 1.3)) * (0.55 + 0.15 * fi) * u_scale;
    float d = length(q - pos);
    add += mix(u_colorA, u_colorB, fi / 2.0) * 0.006 / (d * d + 0.0012) * 0.05;
  }
  for (int i = 0; i < 10; i++) {
    if (i >= u_touchCount) break;
    vec4 tp = u_touches[i];
    vec2 pos = (tp.xy * u_resolution * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y) / u_zoom;
    float d = length(q - pos);
    add += mix(u_colorB, vec3(1.0), 0.4) * 0.01 / (d * d + 0.0015) * 0.08 * (0.5 + tp.z);
  }
  fragColor = vec4(min(prev + add * u_intensity, vec3(6.0)), 1.0);
}
