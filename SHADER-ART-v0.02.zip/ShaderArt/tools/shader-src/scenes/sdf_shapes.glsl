// SDF Shapes: raymarched smooth-blended sphere and box on a checker floor with a cheap
// environment reflection. Touch and drag horizontally to orbit the camera.
// Step count is capped by u_iterations (max 128) and the ray is cut at distance 20.
float sdBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float smin(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

float mapScene(vec3 p) {
  float t = u_time * 0.6;
  float floorD = p.y + 1.0;
  vec3 s = p - vec3(sin(t) * 1.2, 0.0, cos(t * 0.7) * 0.6);
  float ball = length(s) - 0.7;
  vec3 b = p - vec3(-sin(t * 0.8) * 1.2, 0.1, 0.0);
  b.xz = rot(t) * b.xz;
  float box = sdBox(b, vec3(0.5)) - 0.1;
  float shapes = smin(ball, box, 0.2 + 0.4 * u_distortion);
  return min(floorD, shapes);
}

float march(vec3 ro, vec3 rd) {
  float t = 0.0;
  for (int i = 0; i < 128; i++) {
    if (i >= u_iterations) break;
    float d = mapScene(ro + rd * t);
    if (d < 0.001) break;
    t += d;
    if (t > 20.0) break;
  }
  return t;
}

vec3 normalAt(vec3 p) {
  vec2 e = vec2(0.001, 0.0);
  return normalize(vec3(
    mapScene(p + e.xyy) - mapScene(p - e.xyy),
    mapScene(p + e.yxy) - mapScene(p - e.yxy),
    mapScene(p + e.yyx) - mapScene(p - e.yyx)));
}

vec3 envColor(vec3 d) {
  return mix(u_bgColor, u_colorB, clamp(d.y * 0.5 + 0.5, 0.0, 1.0));
}

vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc);
  float orbit = (u_mouse.z > 0.5) ? (u_mouse.x - 0.5) * 4.0 : u_time * 0.1;
  vec3 ro = vec3(0.0, 0.8, -4.0 * u_scale);
  vec3 rd = normalize(vec3(uv, 1.8));
  ro.xz = rot(orbit) * ro.xz;
  rd.xz = rot(orbit) * rd.xz;
  float t = march(ro, rd);
  if (t >= 20.0) {
    return envColor(rd) * 0.6;
  }
  vec3 p = ro + rd * t;
  vec3 n = normalAt(p);
  vec3 l = normalize(vec3(0.6, 0.8, -0.5));
  float diff = clamp(dot(n, l), 0.0, 1.0);
  float fres = pow(1.0 - clamp(dot(n, -rd), 0.0, 1.0), 3.0);
  float chk = mod(floor(p.x) + floor(p.z), 2.0);
  vec3 base = (p.y < -0.98) ? mix(u_bgColor * 1.5 + 0.05, u_colorA * 0.35, chk) : u_colorA;
  vec3 lit = base * (0.15 + 0.85 * diff);
  vec3 refl = envColor(reflect(rd, n));
  vec3 col = mix(lit, refl, 0.12 + 0.55 * fres);
  return col * (0.6 + 0.4 * u_intensity);
}
