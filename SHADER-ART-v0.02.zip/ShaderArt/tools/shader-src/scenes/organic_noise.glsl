// Organic Noise: two-stage fractal noise with ridge highlights, like living tissue.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * 2.0 + u_seed;
  float t = u_time * 0.15;
  int oct = int(u_complexity);
  float n = fbm(p + vec2(t, -t), oct);
  float m = fbm(p * 1.7 - vec2(t * 0.7) + n * u_distortion * 2.0, oct);
  float v = smoothstep(0.25, 0.75, m);
  vec3 col = mix(u_bgColor, ramp(n), v);
  float ridge = 1.0 - abs(2.0 * m - 1.0);
  col += pow(ridge, 6.0) * u_intensity * 0.5 * u_colorB;
  return col;
}
