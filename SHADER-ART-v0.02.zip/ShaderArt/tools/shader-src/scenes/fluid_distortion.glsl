// Fluid Distortion: repeatedly warped coordinates produce silky stripes.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float t = u_time * 0.3;
  for (int i = 1; i < 9; i++) {
    if (i >= int(u_complexity) + 1) break;
    float fi = float(i);
    p += u_distortion * 0.4 / fi * vec2(sin(fi * p.y * 1.5 + t), cos(fi * p.x * 1.5 + t * 1.3));
  }
  float v = 0.5 + 0.5 * sin(p.x * u_frequency + p.y * u_frequency * 0.7);
  vec3 col = ramp(v) * (0.35 + 0.65 * v);
  return mix(u_bgColor, col, 0.35 + 0.65 * clamp(u_intensity, 0.0, 1.0));
}
