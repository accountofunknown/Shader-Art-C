// Digital Glitch: blocky data bars. The glitch/RGB-split/scanline post effects are on by default.
vec3 scene(vec2 fc) {
  vec2 uv = fc / u_resolution;
  float t = floor(u_time * 4.0);
  vec2 cell = floor(uv * vec2(u_density * 12.0, u_density * 8.0));
  float r = hash21(cell + t + u_seed);
  float bars = step(0.5, fract(uv.x * u_frequency * 4.0 + hash21(vec2(cell.y, t)) * 8.0));
  vec3 col = u_bgColor;
  col = mix(col, u_colorA, step(0.82, r) * bars);
  col = mix(col, u_colorB, step(0.95, hash21(cell * 1.7 + t)));
  float lum = 0.5 + 0.5 * sin(uv.y * TAU * 2.0 + u_time);
  col += 0.15 * u_intensity * lum * u_colorA;
  return col;
}
