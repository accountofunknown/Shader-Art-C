// Black Hole: a 2D lensing approximation (not a physical simulation): bent star field,
// a flattened accretion disc and an event-horizon shadow.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float r = length(p);
  float rs = 0.28;
  vec2 q = p * (1.0 - rs * rs * u_distortion / (dot(p, p) + 0.02));
  float star = pow(hash21(floor(q * 80.0)), 30.0) * 1.5;
  vec3 col = u_bgColor + star;
  vec2 d = vec2(p.x, p.y * 3.0);
  float dl = length(d);
  float disk = smoothstep(0.5, 0.0, abs(dl - 0.6));
  float swirl = 0.5 + 0.5 * sin(atan(d.y, d.x) * 3.0 - u_time * 2.0 + dl * 8.0);
  col += disk * (0.4 + 0.6 * swirl) * mix(u_colorA, u_colorB, swirl) * u_intensity * 1.5;
  float halo = smoothstep(0.35, rs, r) * 0.5;
  col += halo * u_colorB * u_intensity;
  col *= smoothstep(rs * 0.85, rs, r);
  return col;
}
