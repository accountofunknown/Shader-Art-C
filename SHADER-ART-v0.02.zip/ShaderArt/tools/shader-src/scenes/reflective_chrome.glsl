// Reflective Chrome: raymarched liquid-metal blobs that mirror a procedural studio environment.
// Drag to orbit the camera.
float smin(float a, float b, float k) {
  float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
  return mix(b, a, h) - k * h * (1.0 - h);
}

float map(vec3 p) {
  float t = u_time * 0.7;
  float d = length(p) - 0.7;
  for (int i = 0; i < 4; i++) {
    float fi = float(i);
    vec3 c = vec3(sin(t * (0.7 + 0.2 * fi) + fi * 1.7), cos(t * (0.9 + 0.15 * fi) + fi * 2.3), sin(t * 0.5 + fi * 0.9));
    d = smin(d, length(p - c * (0.35 + 0.35 * u_distortion)) - 0.36, 0.55);
  }
  return d;
}

vec3 envMap(vec3 d) {
  float h = d.y * 0.5 + 0.5;
  vec3 col = mix(u_bgColor + 0.04, vec3(0.55, 0.65, 0.85), pow(h, 1.6));
  col += smoothstep(0.86, 0.95, dot(d, normalize(vec3(0.6, 0.7, 0.4)))) * vec3(1.6);
  col += smoothstep(0.88, 0.97, dot(d, normalize(vec3(-0.7, 0.3, -0.5)))) * u_colorB * 1.8;
  float floorMask = step(0.0, -d.y);
  col += floorMask * (0.12 + 0.12 * sin(d.x * 24.0 + d.z * 24.0)) * u_colorA;
  col += smoothstep(0.06, 0.0, abs(d.y)) * 0.6;
  return col;
}

vec3 calcNormal(vec3 p) {
  vec2 e = vec2(0.002, 0.0);
  return normalize(vec3(map(p + e.xyy) - map(p - e.xyy), map(p + e.yxy) - map(p - e.yxy), map(p + e.yyx) - map(p - e.yyx)));
}

vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc);
  float yaw = u_time * 0.25 + (u_mouse.z > 0.5 ? (u_mouse.x - 0.5) * 6.0 : 0.0);
  float pitch = 0.25 + (u_mouse.z > 0.5 ? (u_mouse.y - 0.5) * 2.0 : 0.0);
  vec3 ro = vec3(0.0, 0.0, 3.6 / u_scale);
  ro.yz = rot(pitch) * ro.yz;
  ro.xz = rot(yaw) * ro.xz;
  vec3 fwd = normalize(-ro);
  vec3 right = normalize(cross(fwd, vec3(0.0, 1.0, 0.0)));
  vec3 up = cross(right, fwd);
  vec3 rd = normalize(fwd * 1.7 + right * uv.x + up * uv.y);

  float t = 0.0;
  bool hit = false;
  for (int i = 0; i < 128; i++) {
    if (i >= u_iterations) break;
    float d = map(ro + rd * t);
    if (d < 0.002) { hit = true; break; }
    t += d;
    if (t > 12.0) break;
  }
  if (!hit) return envMap(rd) * 0.55;
  vec3 p = ro + rd * t;
  vec3 n = calcNormal(p);
  vec3 r = reflect(rd, n);
  float fres = pow(1.0 - max(dot(-rd, n), 0.0), 3.0);
  vec3 refl = envMap(r);
  vec3 metal = refl * mix(vec3(0.85), u_colorA + 0.35, 0.6);
  vec3 col = mix(envMap(rd) * 0.2, metal, clamp(u_reflect * (0.55 + 0.45 * fres) + 0.2, 0.0, 1.0));
  col += fres * 0.35 * u_intensity;
  return col * u_intensity;
}
