// Mandelbrot Explorer: pinch to zoom, use Center X/Y to move. Iterations are capped at 256.
vec3 scene(vec2 fc) {
  vec2 c = uvOf(fc) * 1.6 / u_scale + vec2(u_centerX, u_centerY);
  vec2 z = vec2(0.0);
  float it = 0.0;
  int maxIt = min(u_iterations, 256);
  for (int i = 0; i < 256; i++) {
    if (i >= maxIt) break;
    z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
    if (dot(z, z) > 256.0) break;
    it += 1.0;
  }
  if (it >= float(maxIt)) {
    return u_bgColor;
  }
  float sm = it + 2.0 - log2(log2(dot(z, z)));
  float t = 0.5 + 0.5 * sin(sm * 0.12 * u_frequency + u_time * 0.3);
  return ramp(t) * (0.35 + 0.65 * clamp(u_intensity, 0.0, 1.0));
}
