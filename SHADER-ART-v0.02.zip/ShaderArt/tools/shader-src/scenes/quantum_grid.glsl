// Quantum Grid: a warped grid with node dots. Touch and drag to push the grid.
vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc);
  vec2 mu = uvOf(u_mouse.xy * u_resolution);
  vec2 p = uv * u_scale * 3.0;
  vec2 w = vec2(sin(p.y * 1.3 + u_time), cos(p.x * 1.1 + u_time * 0.8)) * 0.3 * u_distortion;
  float md = length(uv - mu);
  p += w + (uv - mu) * exp(-md * 3.0) * u_mouse.z * 2.0;
  vec2 f = fract(p) - 0.5;
  float line = smoothstep(0.42, 0.5, max(abs(f.x), abs(f.y)));
  float node = smoothstep(0.14, 0.0, length(f));
  vec3 col = mix(u_bgColor, u_colorA, line * clamp(u_intensity, 0.0, 1.0));
  col += node * u_colorB * u_intensity;
  return col;
}
