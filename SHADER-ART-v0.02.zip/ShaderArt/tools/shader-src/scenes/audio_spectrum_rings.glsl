// Audio Spectrum Rings: the sound spectrum drawn as a ring of bars, with the waveform wrapped around it.
// Needs an audio source (Settings in the studio: Demo beat, Microphone or an audio file).
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  float r = length(p);
  float a = atan(p.y, p.x);
  float x = abs(a) / PI;
  float bars = max(float(u_sides) * 8.0, 16.0);
  float seg = floor(x * bars) / bars;
  float spec = texture(u_channel0, vec2(seg * 0.9 + 0.02, 0.25)).r;
  float base = 0.38 + 0.06 * u_audio.y;
  float len = spec * 0.55 * u_intensity;
  float barMask = smoothstep(base - 0.004, base, r) * smoothstep(base + len + 0.004, base + len, r);
  float gap = smoothstep(0.0, 0.18, fract(x * bars)) * smoothstep(1.0, 0.82, fract(x * bars));
  float w = texture(u_channel0, vec2(fract(abs(a) / TAU * 2.0), 0.75)).r - 0.5;
  float waveR = 0.22 + w * 0.3 * u_distortion;
  float wave = smoothstep(0.012, 0.0, abs(r - waveR));
  vec3 col = u_bgColor + u_beat * 0.12 * u_colorB * (1.0 - r);
  col += barMask * gap * mix(u_colorA, u_colorB, spec * 1.4 + seg);
  col += wave * u_colorB * (0.6 + u_audio.x);
  col += u_colorA * 0.06 / (0.05 + abs(r - base)) * (0.3 + u_audio.y);
  return col;
}
