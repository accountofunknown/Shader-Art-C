// Julia Dream: the constant c orbits slowly; touch the canvas to set c yourself.
vec3 scene(vec2 fc) {
  vec2 z = uvOf(fc) * 1.4 / u_scale;
  vec2 c = 0.7885 * vec2(cos(u_time * 0.3), sin(u_time * 0.3));
  if (u_mouse.z > 0.5) {
    c = (u_mouse.xy * 2.0 - 1.0);
  }
  float it = 0.0;
  float trap = 1000.0;
  int maxIt = min(u_iterations, 256);
  for (int i = 0; i < 256; i++) {
    if (i >= maxIt) break;
    z = vec2(z.x * z.x - z.y * z.y, 2.0 * z.x * z.y) + c;
    trap = min(trap, dot(z, z));
    if (dot(z, z) > 256.0) break;
    it += 1.0;
  }
  float t = it / float(max(maxIt, 1));
  vec3 col = ramp(0.5 + 0.5 * sin(it * 0.25 * u_frequency + u_time * 0.4));
  col *= (0.3 + 0.7 * sqrt(t)) * u_intensity;
  col += exp(-trap * 4.0) * 0.5 * u_colorB;
  return mix(u_bgColor, col, step(0.001, t));
}
