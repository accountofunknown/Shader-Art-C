// Touch Ripples: tap anywhere to send water ripples; every finger on the glass also pushes a light.
// Ripples are computed from the recent taps (u_taps), so no buffers are needed.
vec3 scene(vec2 fc) {
  vec2 uv = fc / u_resolution;
  float aspect = u_resolution.x / u_resolution.y;
  float h = 0.0;
  for (int i = 0; i < 8; i++) {
    if (i >= u_tapCount) break;
    vec4 t = u_taps[i];
    float age = u_time - t.z;
    if (age < 0.0 || age > 5.0) continue;
    float r = length((uv - t.xy) * vec2(aspect, 1.0));
    float front = age * 0.22 * u_frequency;
    float wave = sin((r - front) * u_frequency * 9.0) * exp(-abs(r - front) * 7.0) * exp(-age * 0.8) * t.w * u_distortion;
    h += wave * smoothstep(0.0, 0.03, front - r + 0.04);
  }
  // A gentle idle swell so the surface is never flat.
  vec2 q = (uv - 0.5) * vec2(aspect, 1.0) * 3.0;
  h += 0.04 * sin(q.x * 3.0 + u_time * 0.6) * sin(q.y * 2.5 - u_time * 0.5);
  float lights = 0.0;
  for (int i = 0; i < 10; i++) {
    if (i >= u_touchCount) break;
    vec4 tp = u_touches[i];
    float d = length((uv - tp.xy) * vec2(aspect, 1.0));
    lights += 0.01 / (d * d + 0.004) * (0.4 + tp.z);
    h += 0.25 * exp(-d * 12.0);
  }
  vec3 n = normalize(vec3(-dFdx(h) * 40.0 * u_scale, -dFdy(h) * 40.0 * u_scale, 1.0));
  vec3 l = normalize(vec3(-0.4, 0.6, 0.7));
  float diff = max(dot(n, l), 0.0);
  float spec = pow(max(dot(reflect(-l, n), vec3(0.0, 0.0, 1.0)), 0.0), 40.0);
  vec3 water = mix(u_bgColor, ramp(0.5 + h * 2.0 + uv.y * 0.4), 0.55 + 0.45 * diff);
  vec3 col = water * (0.6 + 0.6 * diff) + spec * u_colorB * 0.8 * u_intensity;
  col += lights * u_colorB * 0.35;
  return col;
}
