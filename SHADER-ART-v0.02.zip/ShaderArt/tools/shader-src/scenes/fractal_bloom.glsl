// Fractal Bloom: kaleidoscopic inversion fold ("kali" set) with an orbit-trap glow.
vec3 scene(vec2 fc) {
  vec2 p = rot(u_time * 0.1) * (uvOf(fc) * u_scale);
  vec2 c = (vec2(0.85, 0.55) + 0.1 * vec2(sin(u_time * 0.2), cos(u_time * 0.17))) * u_distortion;
  float trap = 1000.0;
  float acc = 0.0;
  for (int i = 0; i < 12; i++) {
    if (i >= int(u_complexity) + 2) break;
    p = abs(p) / (dot(p, p) + 0.0001) - c;
    float l = length(p);
    trap = min(trap, l);
    acc += exp(-3.0 * abs(l - 1.0));
  }
  float glow = 1.0 - exp(-acc * 0.25 * u_intensity);
  return mix(u_bgColor, ramp(trap * 0.6), glow);
}
