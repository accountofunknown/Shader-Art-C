// Feedback Trails: reads Buffer A (channel 0) and tone-maps the glow.
vec3 scene(vec2 fc) {
  vec3 c = texture(u_channel0, fc / u_resolution).rgb;
  vec3 mapped = c / (1.0 + c);
  float l = dot(mapped, vec3(0.333));
  return mix(u_bgColor, mapped, 1.0) + l * 0.1 * u_colorB;
}
