// Cellular Patterns: Worley cells with pulsing contour rings.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * u_density * 3.0 + u_seed;
  vec3 v = voro(p);
  float rings = 0.5 + 0.5 * sin(v.x * u_frequency * 6.0 - u_time * 1.5);
  vec3 base = ramp(v.z);
  vec3 col = mix(u_bgColor, base, 0.35 + 0.65 * rings * clamp(u_intensity, 0.0, 1.0));
  col *= smoothstep(0.0, 0.06, v.y - v.x) * 0.6 + 0.4;
  return col;
}
