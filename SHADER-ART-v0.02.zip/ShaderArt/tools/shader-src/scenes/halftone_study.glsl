// Halftone Study: soft moving gradient blobs rendered with the Halftone post effect (on by default).
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale;
  vec2 c = vec2(sin(u_time * 0.5), cos(u_time * 0.4)) * 0.5;
  float v = 0.5 + 0.5 * sin(length(p - c) * u_frequency - u_time);
  v *= 0.5 + 0.5 * cos(p.x * 1.5 + u_time * 0.3);
  return mix(u_bgColor, ramp(v), 0.9 * clamp(u_intensity, 0.0, 1.0) + 0.1);
}
