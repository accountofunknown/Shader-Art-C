// Pixel Dither: drifting clouds with the Pixelate and Dither post effects (on by default).
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * 1.5;
  float n = fbm(p + vec2(u_time * 0.1, 0.0), int(u_complexity));
  float m = fbm(p * 2.0 - u_time * 0.05, int(u_complexity));
  float v = clamp(n * 1.2 + m * 0.4 - 0.15, 0.0, 1.0);
  return mix(u_bgColor, ramp(v), smoothstep(0.1, 0.8, v) * clamp(u_intensity, 0.0, 1.5));
}
