// Abstract Environment: a never-ending hall of pillars and beams lit by coloured light strips.
float sdBox(vec3 p, vec3 b) {
  vec3 q = abs(p) - b;
  return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0);
}

float gGlow;

float map(vec3 p) {
  float sp = 3.0 / u_density;
  p.z += u_time * 1.4 * u_frequency * 0.33;
  float cell = floor(p.z / sp);
  vec3 q = p;
  q.z = mod(p.z, sp) - 0.5 * sp;
  vec3 pq = q;
  pq.x = abs(pq.x) - 1.7;
  float pillar = sdBox(pq, vec3(0.16, 3.0, 0.16));
  float beam = sdBox(q - vec3(0.0, 1.35, 0.0), vec3(2.2, 0.07, 0.12));
  float floorD = p.y + 1.1;
  float strip = sdBox(q - vec3(0.0, -1.05, 0.0), vec3(0.04, 0.03, sp));
  float ceilingStrip = sdBox(q - vec3(0.0, 1.25, 0.0), vec3(1.6, 0.02, 0.02));
  gGlow += 0.004 / (0.01 + abs(ceilingStrip)) * (0.5 + 0.5 * sin(cell * 1.3 + u_time));
  return min(min(pillar, beam), min(floorD, strip));
}

vec3 scene(vec2 fc) {
  vec2 uv = uvOf(fc) * u_scale;
  vec3 ro = vec3(0.35 * sin(u_time * 0.4), 0.1 * sin(u_time * 0.6), 0.0);
  if (u_mouse.z > 0.5) ro.x += (u_mouse.x - 0.5) * 1.6;
  vec3 rd = normalize(vec3(uv, -1.5));
  rd.xz = rot(0.2 * sin(u_time * 0.3)) * rd.xz;
  gGlow = 0.0;
  float t = 0.0;
  float steps = 0.0;
  for (int i = 0; i < 128; i++) {
    if (i >= u_iterations) break;
    float d = map(ro + rd * t);
    steps += 1.0;
    if (d < 0.003 || t > 40.0) break;
    t += d;
  }
  float fog = exp(-t * 0.07);
  vec3 col = u_bgColor;
  col += mix(u_colorA, u_colorB, 0.5 + 0.5 * sin(t * 0.15 - u_time * 0.3)) * fog * (1.0 - steps / float(max(u_iterations, 1))) * 0.9;
  col += gGlow * u_colorB * 0.35;
  col += u_colorA * 0.25 * smoothstep(1.0, 0.0, abs(uv.y)) * fog;
  return col * u_intensity;
}
