// Neon Geometry: nested rotating polygons drawn as glowing outlines.
float sdPoly(vec2 p, float r, float n) {
  float a = atan(p.x, p.y) + PI;
  float seg = TAU / n;
  return cos(floor(0.5 + a / seg) * seg - a) * length(p) - r;
}

vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc);
  vec3 col = u_bgColor;
  for (int i = 0; i < 10; i++) {
    if (i >= int(u_complexity) + 2) break;
    float fi = float(i);
    vec2 q = rot(u_time * 0.2 * (1.0 + fi * 0.15) + fi * 0.3) * p;
    float d = abs(sdPoly(q, (0.12 + fi * 0.09) * u_scale, float(u_sides)));
    col += (0.006 * u_intensity) / (d + 0.004) * mix(u_colorA, u_colorB, fi / 10.0);
  }
  return col;
}
