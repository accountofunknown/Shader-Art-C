// Voronoi Universe: animated cells with glowing borders and star points at the cell centres.
vec3 scene(vec2 fc) {
  vec2 p = uvOf(fc) * u_scale * 3.0 * u_density;
  vec3 v = voro(p);
  float edge = smoothstep(0.0, 0.08, v.y - v.x);
  vec3 cell = mix(u_colorA, u_colorB, v.z) * (1.0 - 0.7 * v.x);
  vec3 col = mix(u_bgColor, cell, 0.85);
  col += (1.0 - edge) * u_intensity * 0.6 * u_colorB;
  col += smoothstep(0.07, 0.0, v.x) * u_intensity;
  return col;
}
