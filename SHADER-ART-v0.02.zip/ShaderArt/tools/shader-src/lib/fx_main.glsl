// ---- Post effects + main(): every preset runs through this single-pass wrapper ----
// Effects scale with the render height so they look the same at any export resolution.
// An effect set to 0 is skipped entirely.
float fxScale() {
  return max(min(u_resolution.x, u_resolution.y) / 540.0, 0.25);
}

float bayer2(vec2 a) {
  a = floor(a);
  return fract(dot(a, vec2(0.5, a.y * 0.75)));
}

float bayer4(vec2 a) {
  return bayer2(0.5 * a) * 0.25 + bayer2(a);
}

void main() {
  float k = fxScale();
  vec2 fc = gl_FragCoord.xy;

  if (u_fxGlitch > 0.0) {
    float band = floor(fc.y / (24.0 * k));
    float tick = floor(u_time * 6.0);
    float r = hash21(vec2(band, tick));
    if (r > 1.0 - 0.35 * u_fxGlitch) {
      fc.x += (hash21(vec2(band + 7.0, tick)) - 0.5) * 140.0 * k * u_fxGlitch;
    }
  }

  if (u_fxPixel >= 1.0) {
    float s = u_fxPixel * k;
    fc = (floor(fc / s) + 0.5) * s;
  }

  vec3 col;
  if (u_fxChroma > 0.0) {
    vec2 off = (fc / u_resolution - 0.5) * u_fxChroma * 60.0 * k;
    col = vec3(scene(fc + off).r, scene(fc).g, scene(fc - off).b);
  } else {
    col = scene(fc);
  }

  if (u_fxHalftone > 0.0) {
    float cell = 9.0 * k;
    vec2 g = fract(gl_FragCoord.xy / cell) - 0.5;
    float lum = dot(col, vec3(0.299, 0.587, 0.114));
    float rad = 0.1 + sqrt(clamp(lum, 0.0, 1.0)) * 0.6;
    float m = 1.0 - smoothstep(rad - 0.05, rad + 0.05, length(g));
    col = mix(col, mix(u_bgColor, col, m), u_fxHalftone);
  }

  if (u_fxScan > 0.0) {
    float s = 0.5 + 0.5 * sin(gl_FragCoord.y * (TAU / (4.0 * k)));
    col *= 1.0 - u_fxScan * 0.5 * s;
  }

  if (u_fxGrain > 0.0) {
    float g = hash21(gl_FragCoord.xy + fract(u_time) * 100.0) - 0.5;
    col += g * u_fxGrain * 0.35;
  }

  if (u_fxDither > 0.0) {
    float lv = mix(256.0, 4.0, u_fxDither);
    col = floor(clamp(col, 0.0, 1.0) * lv + bayer4(gl_FragCoord.xy / k)) / lv;
  }

  fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
