// ---- Shared helpers: coordinates, hashing, noise, colour ramp ----
const float PI = 3.14159265359;
const float TAU = 6.28318530718;

// Centre = (0,0); the shorter screen side spans -1..1. Pinch-zoom (u_zoom) is applied here,
// so every preset that uses uvOf() supports pinch-to-zoom.
vec2 uvOf(vec2 fc) {
  return (fc * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y) / u_zoom;
}

float hash21(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

vec2 hash22(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * vec3(0.1031, 0.1030, 0.0973));
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.xx + p3.yz) * p3.zy);
}

mat2 rot(float a) {
  float c = cos(a);
  float s = sin(a);
  return mat2(c, -s, s, c);
}

float vnoise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  float a = hash21(i);
  float b = hash21(i + vec2(1.0, 0.0));
  float c = hash21(i + vec2(0.0, 1.0));
  float d = hash21(i + vec2(1.0, 1.0));
  return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Fractal Brownian motion, at most 8 octaves (bounded loop).
float fbm(vec2 p, int oct) {
  float v = 0.0;
  float a = 0.5;
  mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
  for (int i = 0; i < 8; i++) {
    if (i >= oct) break;
    v += a * vnoise(p);
    p = m * p;
    a *= 0.5;
  }
  return v;
}

vec3 ramp(float t) {
  return mix(u_colorA, u_colorB, clamp(t, 0.0, 1.0));
}
