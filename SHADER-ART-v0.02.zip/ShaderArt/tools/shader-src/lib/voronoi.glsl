// ---- Voronoi / Worley cells: returns (F1, F2, cell id 0..1) ----
vec3 voro(vec2 p) {
  vec2 ip = floor(p);
  vec2 fp = fract(p);
  float d1 = 8.0;
  float d2 = 8.0;
  float id = 0.0;
  for (int j = -1; j <= 1; j++) {
    for (int i = -1; i <= 1; i++) {
      vec2 g = vec2(float(i), float(j));
      vec2 o = hash22(ip + g + u_seed);
      o = 0.5 + 0.5 * sin(u_time * 0.5 + TAU * o);
      float d = length(g + o - fp);
      if (d < d1) {
        d2 = d1;
        d1 = d;
        id = hash21(ip + g + 3.7);
      } else if (d < d2) {
        d2 = d;
      }
    }
  }
  return vec3(d1, d2, id);
}
