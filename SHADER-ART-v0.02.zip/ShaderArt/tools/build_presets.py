#!/usr/bin/env python3
"""Compose SHADER ART preset shaders and the preset catalog.

Inputs  : tools/shader-src/lib/*.glsl, tools/shader-src/scenes/<id>.glsl, the PRESETS table below.
Outputs : app/src/main/assets/shaders/<id>.frag   (complete GLSL ES 3.00 fragment shaders)
          app/src/main/assets/presets/catalog.json (resolved metadata read by the app)

Every output shader is self-contained, so the Code Studio shows exactly what the GPU compiles.
Run:  python3 tools/build_presets.py
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / "tools" / "shader-src"
ASSETS = ROOT / "app" / "src" / "main" / "assets"

# Uniforms the engine sets on every program (never shown as controls).
SYSTEM_UNIFORMS = [
    ("float", "u_time", "seconds of animation time (already multiplied by the speed setting)"),
    ("vec2", "u_resolution", "render target size in pixels"),
    ("vec4", "u_mouse", "xy = touch position 0..1 (origin bottom-left), z = 1 while touching"),
    ("float", "u_deltaTime", "seconds since the previous frame"),
    ("int", "u_frame", "frame counter"),
    ("float", "u_speed", "animation speed multiplier chosen in the UI"),
    ("float", "u_zoom", "pinch-zoom factor, 1.0 = none"),
]
# v0.02 uniforms: declared in a shader only when its source actually uses them.
EXTRA_UNIFORMS = [
    ("vec4", "u_mousePx", "", "Shadertoy-style mouse in pixels: xy = position, zw = press position (negative when released)"),
    ("vec4", "u_date", "", "year, month (0-11), day, seconds since midnight"),
    ("vec4", "u_audio", "", "x = level, y = bass, z = mid, w = treble, all 0..1 (needs an audio source; silent otherwise)"),
    ("float", "u_beat", "", "1.0 on a detected beat, fading to 0"),
    ("vec3", "u_gyro", "", "rotation rate in rad/s (device sensor)"),
    ("vec3", "u_accel", "", "acceleration without gravity in m/s^2 (device sensor)"),
    ("vec2", "u_tilt", "", "tilt from gravity, -1..1 on each axis (device sensor)"),
    ("vec4", "u_touches", "[10]", "per finger: xy = position 0..1, z = pressure, w = 1 if down"),
    ("int", "u_touchCount", "", "number of fingers down"),
    ("float", "u_pressure", "", "pressure of the first finger, 0..1"),
    ("vec2", "u_touchVel", "", "velocity of the first finger (screen widths per second)"),
    ("vec4", "u_taps", "[8]", "recent taps: xy = position 0..1, z = u_time of the tap, w = strength"),
    ("int", "u_tapCount", "", "number of valid entries in u_taps"),
    ("sampler2D", "u_channel0", "", "input 0 (buffer, texture, noise or audio)"),
    ("sampler2D", "u_channel1", "", "input 1"),
    ("sampler2D", "u_channel2", "", "input 2"),
    ("sampler2D", "u_channel3", "", "input 3"),
    ("vec3", "u_channelResolution", "[4]", "size in pixels of each input"),
]
SYSTEM_NAMES = {n for _, n, _ in SYSTEM_UNIFORMS} | {n for _, n, _, _ in EXTRA_UNIFORMS}


def P(name, typ, default, lo, hi, step, group, desc):
    d = default if isinstance(default, list) else [default]
    return dict(name=name, type=typ, default=d, min=lo, max=hi, step=step, group=group, description=desc)


STANDARD = {
    "u_scale": P("Scale", "float", 1.0, 0.2, 6.0, 0.05, "Shape", "Zoom of the pattern."),
    "u_complexity": P("Complexity", "float", 4.0, 1.0, 8.0, 1.0, "Shape", "Layers, octaves or folds of detail."),
    "u_intensity": P("Intensity", "float", 1.0, 0.0, 2.0, 0.01, "Look", "Brightness and strength of the effect."),
    "u_distortion": P("Distortion", "float", 1.0, 0.0, 3.0, 0.01, "Shape", "How strongly the pattern is warped."),
    "u_frequency": P("Frequency", "float", 3.0, 0.5, 12.0, 0.1, "Shape", "Repetition rate of waves or bands."),
    "u_density": P("Density", "float", 1.0, 0.2, 4.0, 0.05, "Shape", "Number of cells, bars or repeats."),
    "u_iterations": P("Iterations", "int", 48.0, 8.0, 128.0, 1.0, "Quality", "Maximum loop steps. Lower is faster."),
    "u_sides": P("Sides", "int", 6.0, 3.0, 12.0, 1.0, "Shape", "Number of sides or spokes."),
    "u_seed": P("Seed", "float", 0.0, 0.0, 100.0, 0.01, "Variation", "Offsets the random pattern."),
    "u_feed": P("Feed rate", "float", 0.037, 0.01, 0.09, 0.0005, "Chemistry", "How fast the reaction is fed. Small changes give very different patterns."),
    "u_kill": P("Kill rate", "float", 0.06, 0.04, 0.07, 0.0005, "Chemistry", "How fast the reaction is removed."),
    "u_flow": P("Flow", "float", 1.0, 0.0, 3.0, 0.01, "Motion", "How strongly trails swirl and drift."),
    "u_decay": P("Persistence", "float", 0.96, 0.8, 0.995, 0.001, "Motion", "How long trails stay visible. Higher = longer."),
    "u_reflect": P("Reflectivity", "float", 1.0, 0.0, 1.5, 0.01, "Look", "Mirror strength of the surface."),
    "u_centerX": P("Center X", "float", -0.75, -2.0, 2.0, 0.001, "View", "Horizontal centre of the view."),
    "u_centerY": P("Center Y", "float", 0.0, -2.0, 2.0, 0.001, "View", "Vertical centre of the view."),
    "u_colorA": P("Primary color", "color", [0.1, 0.6, 1.0], 0.0, 1.0, 0.01, "Colors", "Foreground colour."),
    "u_colorB": P("Secondary color", "color", [1.0, 0.3, 0.7], 0.0, 1.0, 0.01, "Colors", "Accent colour."),
    "u_bgColor": P("Background color", "color", [0.0, 0.0, 0.0], 0.0, 1.0, 0.01, "Colors", "Background colour."),
}
MANDATORY = ["u_colorA", "u_colorB", "u_bgColor"]

FX = {
    "u_fxPixel": P("Pixelate", "float", 0.0, 0.0, 24.0, 1.0, "Post effects", "Pixel block size. 0 = off."),
    "u_fxGlitch": P("Digital glitch", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "Horizontal slice displacement."),
    "u_fxChroma": P("RGB split", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "Chromatic aberration / RGB distortion."),
    "u_fxScan": P("Scanlines", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "CRT scanline darkening."),
    "u_fxGrain": P("Film grain", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "Animated noise grain."),
    "u_fxDither": P("Dither", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "Ordered dithering with reduced colour levels."),
    "u_fxHalftone": P("Halftone", "float", 0.0, 0.0, 1.0, 0.01, "Post effects", "Halftone dot screen."),
}

LIB_DEPENDS = {"voronoi": ["u_seed"]}

# id, name, category, description, performance, perfNote, libs, previewTime, params(list of ref or (ref, overrides)), fx overrides
PRESETS = [
    dict(id="liquid_flow", name="Liquid Flow", cat="FLUID", perf="MEDIUM",
         desc="Domain-warped fractal noise that flows like paint in water.",
         params=[("u_scale", dict(default=2.0)), ("u_complexity", dict(default=5.0, max=8.0)), "u_distortion", "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.0, 0.55, 1.0])), ("u_colorB", dict(default=[1.0, 0.2, 0.6])), ("u_bgColor", dict(default=[0.0, 0.0, 0.05]))]),
    dict(id="plasma_dreams", name="Plasma Dreams", cat="FLUID", perf="LIGHT",
         desc="Classic sine-sum plasma with a roaming centre.",
         params=[("u_scale", dict(default=1.5)), ("u_frequency", dict(default=3.0)), ("u_complexity", dict(default=4.0)), "u_intensity",
                 ("u_colorA", dict(default=[1.0, 0.1, 0.5])), ("u_colorB", dict(default=[0.1, 0.4, 1.0]))]),
    dict(id="monochrome_waves", name="Monochrome Waves", cat="FLUID", perf="LIGHT",
         desc="Layered flowing sine lines in black and white.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=2.0)), ("u_complexity", dict(default=5.0)), "u_distortion", ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[1.0, 1.0, 1.0])), ("u_colorB", dict(default=[0.5, 0.5, 0.5]))]),
    dict(id="infinite_tunnel", name="Infinite Tunnel", cat="RAYMARCH", perf="HEAVY",
         desc="Sphere-traced tunnel with ribs and fog. Lower Iterations on slower GPUs.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=4.0)), "u_distortion", "u_intensity", ("u_iterations", dict(default=40.0, max=96.0)),
                 ("u_colorA", dict(default=[0.0, 0.8, 1.0])), ("u_colorB", dict(default=[0.9, 0.2, 1.0]))]),
    dict(id="voronoi_universe", name="Voronoi Universe", cat="MATH", perf="MEDIUM", libs=["voronoi"],
         desc="Animated Voronoi cells with glowing borders and star points.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.1, 0.2, 0.9])), ("u_colorB", dict(default=[0.9, 0.5, 1.0])), ("u_bgColor", dict(default=[0.0, 0.0, 0.04]))]),
    dict(id="fractal_bloom", name="Fractal Bloom", cat="MATH", perf="MEDIUM",
         desc="Kaleidoscopic inversion fractal that opens like a flower.",
         params=[("u_scale", dict(default=1.2)), ("u_complexity", dict(default=6.0, max=10.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[1.0, 0.5, 0.1])), ("u_colorB", dict(default=[0.8, 0.1, 0.6]))]),
    dict(id="neon_geometry", name="Neon Geometry", cat="GEOMETRIC", perf="LIGHT",
         desc="Nested rotating polygons drawn as glowing neon outlines.",
         params=[("u_scale", dict(default=1.0)), ("u_complexity", dict(default=6.0, max=8.0)), "u_sides", ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[0.0, 1.0, 0.8])), ("u_colorB", dict(default=[1.0, 0.1, 0.8]))]),
    dict(id="organic_noise", name="Organic Noise", cat="FLUID", perf="MEDIUM",
         desc="Two-stage fractal noise with ridge highlights, like living tissue.",
         params=[("u_scale", dict(default=1.0)), ("u_complexity", dict(default=5.0)), "u_distortion", "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.2, 0.8, 0.4])), ("u_colorB", dict(default=[1.0, 0.9, 0.3])), ("u_bgColor", dict(default=[0.02, 0.04, 0.02]))]),
    dict(id="digital_glitch", name="Digital Glitch", cat="DIGITAL", perf="LIGHT",
         desc="Blocky data bars with horizontal glitch slices and RGB split.",
         params=[("u_density", dict(default=1.0)), ("u_frequency", dict(default=3.0)), "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.0, 1.0, 0.5])), ("u_colorB", dict(default=[1.0, 0.1, 0.3])), ("u_bgColor", dict(default=[0.0, 0.02, 0.05]))],
         fx=dict(u_fxGlitch=0.7, u_fxChroma=0.35, u_fxScan=0.4, u_fxGrain=0.15)),
    dict(id="quantum_grid", name="Quantum Grid", cat="GEOMETRIC", perf="LIGHT",
         desc="A warped grid with node dots. Touch and drag to push it around.",
         params=[("u_scale", dict(default=1.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[0.3, 0.7, 1.0])), ("u_colorB", dict(default=[1.0, 1.0, 1.0])), ("u_bgColor", dict(default=[0.0, 0.0, 0.03]))]),
    dict(id="fluid_distortion", name="Fluid Distortion", cat="FLUID", perf="LIGHT",
         desc="Repeatedly warped coordinates produce silky flowing stripes.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=4.0)), ("u_complexity", dict(default=5.0, max=8.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[0.9, 0.3, 0.1])), ("u_colorB", dict(default=[1.0, 0.9, 0.4]))]),
    dict(id="cellular_patterns", name="Cellular Patterns", cat="FLUID", perf="MEDIUM", libs=["voronoi"],
         desc="Worley cells with pulsing contour rings.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), ("u_frequency", dict(default=2.0)), "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.1, 0.8, 0.6])), ("u_colorB", dict(default=[0.1, 0.3, 0.9])), ("u_bgColor", dict(default=[0.0, 0.03, 0.03]))]),
    dict(id="black_hole", name="Black Hole", cat="RAYMARCH", perf="LIGHT",
         desc="2D lensing approximation: bent stars, accretion disc and event horizon shadow.",
         params=[("u_scale", dict(default=1.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[1.0, 0.55, 0.1])), ("u_colorB", dict(default=[1.0, 0.9, 0.7]))]),
    dict(id="abstract_topography", name="Abstract Topography", cat="MATH", perf="MEDIUM",
         desc="Contour lines of a slowly evolving fractal height field.",
         params=[("u_scale", dict(default=1.0)), ("u_complexity", dict(default=5.0)), ("u_frequency", dict(default=3.0)), "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.95, 0.95, 0.9])), ("u_colorB", dict(default=[0.2, 0.5, 0.4])), ("u_bgColor", dict(default=[0.02, 0.05, 0.05]))]),
    dict(id="interference_field", name="Interference Field", cat="MATH", perf="LIGHT",
         desc="Circular waves from orbiting sources interfere like ripples on water.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=3.0)), ("u_complexity", dict(default=5.0, max=8.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.9, 0.9, 1.0])), ("u_colorB", dict(default=[0.2, 0.3, 0.9]))]),
    dict(id="retro_scanlines", name="Retro Scanlines", cat="DIGITAL", perf="LIGHT",
         desc="Synthwave sun and perspective grid seen through a CRT.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), "u_intensity",
                 ("u_colorA", dict(default=[1.0, 0.2, 0.7])), ("u_colorB", dict(default=[1.0, 0.8, 0.2])), ("u_bgColor", dict(default=[0.05, 0.0, 0.15]))],
         fx=dict(u_fxScan=0.8, u_fxGrain=0.2, u_fxChroma=0.15)),
    dict(id="mandelbrot_explorer", name="Mandelbrot Explorer", cat="MATH", perf="HEAVY",
         desc="Pinch to zoom into the Mandelbrot set. Float precision limits very deep zooms.",
         params=[("u_scale", dict(default=1.0)), "u_centerX", "u_centerY", ("u_iterations", dict(default=80.0, max=256.0)), ("u_frequency", dict(default=3.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.1, 0.3, 1.0])), ("u_colorB", dict(default=[1.0, 0.8, 0.3]))]),
    dict(id="julia_dream", name="Julia Dream", cat="MATH", perf="HEAVY",
         desc="Animated Julia set. Touch the canvas to choose the constant yourself.",
         params=[("u_scale", dict(default=1.0)), ("u_iterations", dict(default=64.0, max=256.0)), ("u_frequency", dict(default=3.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.9, 0.2, 0.8])), ("u_colorB", dict(default=[0.2, 0.9, 1.0]))]),
    dict(id="sdf_shapes", name="SDF Shapes", cat="RAYMARCH", perf="HEAVY",
         desc="Raymarched blended sphere and box on a checker floor. Drag to orbit.",
         params=[("u_scale", dict(default=1.0)), ("u_distortion", dict(default=1.0)), ("u_iterations", dict(default=48.0, max=128.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.9, 0.35, 0.25])), ("u_colorB", dict(default=[0.5, 0.7, 1.0])), ("u_bgColor", dict(default=[0.03, 0.04, 0.08]))]),
    dict(id="radial_rings", name="Radial Rings", cat="GEOMETRIC", perf="LIGHT",
         desc="Polar rings crossed with spokes: circular waves and radial structure.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=3.0)), ("u_sides", dict(default=8.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[1.0, 0.8, 0.2])), ("u_colorB", dict(default=[0.8, 0.1, 0.4]))]),
    dict(id="halftone_study", name="Halftone Study", cat="DIGITAL", perf="LIGHT",
         desc="Soft gradient blobs rendered through the halftone dot screen.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=3.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.95, 0.3, 0.2])), ("u_colorB", dict(default=[1.0, 0.9, 0.6])), ("u_bgColor", dict(default=[0.08, 0.02, 0.05]))],
         fx=dict(u_fxHalftone=1.0)),
    dict(id="pixel_dither", name="Pixel Dither", cat="DIGITAL", perf="LIGHT",
         desc="Drifting clouds in chunky pixels with ordered dithering.",
         params=[("u_scale", dict(default=1.0)), ("u_complexity", dict(default=4.0)), ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[0.9, 0.95, 0.6])), ("u_colorB", dict(default=[0.2, 0.5, 0.4])), ("u_bgColor", dict(default=[0.02, 0.05, 0.08]))],
         fx=dict(u_fxPixel=6.0, u_fxDither=0.8)),
    dict(id="domain_repeat", name="Domain Repeat", cat="GEOMETRIC", perf="LIGHT",
         desc="Repeated, folded and rotated space gives recursive-looking structure.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), ("u_complexity", dict(default=6.0, max=8.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.2, 1.0, 0.8])), ("u_colorB", dict(default=[1.0, 0.3, 0.9]))]),
    # ---- v0.02 presets ----
    dict(id="reflective_chrome", name="Reflective Chrome", cat="REFLECTIVE", perf="HEAVY", tags=["raymarch", "reflection"],
         desc="Liquid-metal blobs raymarched with a mirror finish that reflects a studio environment. Drag to orbit.",
         params=[("u_scale", dict(default=1.0)), ("u_distortion", dict(default=1.0)), ("u_iterations", dict(default=64.0, max=128.0)), "u_reflect", "u_intensity",
                 ("u_colorA", dict(default=[0.75, 0.8, 0.9])), ("u_colorB", dict(default=[1.0, 0.45, 0.2])), ("u_bgColor", dict(default=[0.02, 0.025, 0.04]))]),
    dict(id="abstract_environment", name="Abstract Environment", cat="ENVIRONMENT", perf="HEAVY", tags=["raymarch", "3d"],
         desc="Fly down an endless hall of pillars, beams and light strips. Drag sideways to steer.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), ("u_frequency", dict(default=3.0)), ("u_iterations", dict(default=64.0, max=128.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.1, 0.5, 1.0])), ("u_colorB", dict(default=[1.0, 0.3, 0.6])), ("u_bgColor", dict(default=[0.01, 0.0, 0.03]))]),
    dict(id="recursive_geometry", name="Recursive Geometry", cat="RECURSIVE", perf="HEAVY", tags=["fractal", "raymarch"],
         desc="A Menger sponge: the same cut repeated inside every block. Complexity sets the depth. Drag to orbit.",
         params=[("u_scale", dict(default=1.0)), ("u_complexity", dict(default=3.0, max=4.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.95, 0.6, 0.25])), ("u_colorB", dict(default=[0.2, 0.55, 1.0])), ("u_bgColor", dict(default=[0.03, 0.03, 0.05]))]),
    dict(id="kaleidoscope", name="Kaleidoscope", cat="GEOMETRIC", perf="MEDIUM", tags=["symmetry"],
         desc="Space folded into mirrored wedges, then folded again. Sides and Complexity change the symmetry.",
         params=[("u_scale", dict(default=1.0)), ("u_sides", dict(default=6.0)), ("u_complexity", dict(default=5.0, max=8.0)), "u_distortion", "u_intensity",
                 ("u_colorA", dict(default=[0.9, 0.3, 0.6])), ("u_colorB", dict(default=[0.2, 0.8, 1.0])), ("u_bgColor", dict(default=[0.0, 0.0, 0.03]))]),
    dict(id="truchet_weave", name="Truchet Weave", cat="GEOMETRIC", perf="LIGHT", tags=["pattern"],
         desc="Quarter-circle tiles that connect into endless woven paths with light pulses running along them.",
         params=[("u_scale", dict(default=1.0)), ("u_density", dict(default=1.0)), "u_distortion", ("u_flow", dict(default=1.0)), "u_intensity", "u_seed",
                 ("u_colorA", dict(default=[0.1, 0.8, 0.7])), ("u_colorB", dict(default=[1.0, 0.7, 0.2])), ("u_bgColor", dict(default=[0.02, 0.03, 0.05]))]),
    dict(id="audio_spectrum_rings", name="Audio Spectrum Rings", cat="AUDIO", perf="LIGHT", tags=["audio", "needs-audio"],
         desc="The sound spectrum as a ring of bars with the waveform wrapped inside. Pick Demo beat, Microphone or a file in the studio.",
         channels=["audio", "none", "none", "none"],
         params=[("u_scale", dict(default=1.0)), ("u_sides", dict(default=8.0, max=12.0)), ("u_distortion", dict(default=1.0)), ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[0.1, 0.7, 1.0])), ("u_colorB", dict(default=[1.0, 0.3, 0.7])), ("u_bgColor", dict(default=[0.0, 0.0, 0.03]))]),
    dict(id="audio_pulse_tunnel", name="Audio Pulse Tunnel", cat="AUDIO", perf="LIGHT", tags=["audio", "needs-audio"],
         desc="A tunnel of rings that flash on every beat; bass pushes the rings, treble adds sparkle.",
         channels=["none", "none", "none", "none"],
         params=[("u_scale", dict(default=1.0)), ("u_sides", dict(default=6.0)), ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[1.0, 0.2, 0.5])), ("u_colorB", dict(default=[0.2, 0.7, 1.0])), ("u_bgColor", dict(default=[0.0, 0.0, 0.02]))]),
    dict(id="touch_ripples", name="Touch Ripples", cat="INTERACTIVE", perf="LIGHT", tags=["touch"], preview=2.0,
         desc="Tap the canvas to send ripples across a water surface; every finger also glows. Calm waves play when idle.",
         params=[("u_scale", dict(default=1.0)), ("u_frequency", dict(default=3.0)), ("u_distortion", dict(default=1.0)), "u_intensity",
                 ("u_colorA", dict(default=[0.05, 0.35, 0.7])), ("u_colorB", dict(default=[0.7, 0.95, 1.0])), ("u_bgColor", dict(default=[0.0, 0.03, 0.08]))]),
    dict(id="feedback_trails", name="Feedback Trails", cat="INTERACTIVE", perf="MEDIUM", tags=["multipass", "feedback", "touch"], preview=6.0,
         desc="Multi-pass: three light orbs leave swirling trails because Buffer A remembers the last frame. Touch adds more light.",
         buffers={"a": dict(channels=["buffer:a", "none", "none", "none"])},
         channels=["buffer:a", "none", "none", "none"],
         params=[("u_scale", dict(default=1.0)), ("u_flow", dict(default=1.0)), ("u_decay", dict(default=0.96)), ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[0.1, 0.6, 1.0])), ("u_colorB", dict(default=[1.0, 0.3, 0.6])), ("u_bgColor", dict(default=[0.0, 0.0, 0.02]))]),
    dict(id="reaction_diffusion", name="Reaction-Diffusion", cat="FLUID", perf="HEAVY", tags=["multipass", "simulation", "touch"], preview=8.0,
         desc="Multi-pass Gray-Scott chemistry in four chained buffers (four steps per frame). Touch to seed growth; try other Feed and Kill rates.",
         buffers={"a": dict(channels=["buffer:d", "none", "none", "none"]),
                  "b": dict(channels=["buffer:a", "none", "none", "none"], src="a"),
                  "c": dict(channels=["buffer:b", "none", "none", "none"], src="a"),
                  "d": dict(channels=["buffer:c", "none", "none", "none"], src="a")},
         channels=["buffer:d", "none", "none", "none"],
         params=[("u_scale", dict(default=1.0)), ("u_feed", dict(default=0.037)), ("u_kill", dict(default=0.06)), "u_seed", ("u_intensity", dict(default=1.0)),
                 ("u_colorA", dict(default=[0.1, 0.8, 0.7])), ("u_colorB", dict(default=[1.0, 0.8, 0.3])), ("u_bgColor", dict(default=[0.02, 0.02, 0.06]))]),
]

TYPE_GLSL = {"float": "float", "int": "int", "bool": "bool", "color": "vec3"}


def resolve_params(preset):
    out = []
    seen = set()
    entries = list(preset["params"])
    for dep in preset.get("libs", []):
        for u in LIB_DEPENDS.get(dep, []):
            if u not in {(e if isinstance(e, str) else e[0]) for e in entries}:
                entries.append(u)
    for m in MANDATORY:
        if m not in {(e if isinstance(e, str) else e[0]) for e in entries}:
            entries.append(m)
    for e in entries:
        ref, over = (e, {}) if isinstance(e, str) else e
        if ref in seen:
            raise SystemExit(f"{preset['id']}: duplicate param {ref}")
        seen.add(ref)
        base = dict(STANDARD[ref])
        base.update(over)
        if not isinstance(base["default"], list):
            base["default"] = [base["default"]]
        out.append(dict(id=ref, uniform=ref, **base))
    fx_over = preset.get("fx", {})
    for ref, base in FX.items():
        b = dict(base)
        if ref in fx_over:
            b["default"] = [fx_over[ref]]
        out.append(dict(id=ref, uniform=ref, **b))
    # Sanity: defaults within range.
    for p in out:
        if p["type"] != "color":
            v = p["default"][0]
            assert p["min"] <= v <= p["max"], f"{preset['id']}.{p['id']} default {v} outside {p['min']}..{p['max']}"
    return out


def header(preset, params, body=""):
    lines = [
        "#version 300 es",
        f"// SHADER ART preset: {preset['name']}  (id: {preset['id']}, version 1)",
        "// Generated by tools/build_presets.py. Edit freely in Code Studio: the app keeps your controls.",
        "precision highp float;",
        "precision highp int;",
        "",
        "// ---- Standard uniforms (set by the engine every frame) ----",
    ]
    for t, n, c in SYSTEM_UNIFORMS:
        lines.append(f"uniform {t} {n};  // {c}")
    used_extra = [e for e in EXTRA_UNIFORMS if re.search(r"\b%s\b" % e[1], body)]
    if used_extra:
        lines += ["", "// ---- Inputs (touch, sound, sensors, textures) ----"]
        for t, n, arr, c in used_extra:
            lines.append(f"uniform {t} {n}{arr};  // {c}")
    lines += ["", "// ---- Controls (one slider / colour / switch each in Visual Studio) ----"]
    group = None
    for p in params:
        if p["group"] != group:
            group = p["group"]
            lines.append(f"// {group}")
        lines.append(f"uniform {TYPE_GLSL[p['type']]} {p['uniform']};")
    lines += ["", "out vec4 fragColor;", ""]
    return "\n".join(lines)


def compose(preset, params, buffer_key=None, src_key=None):
    common = (SRC / "lib" / "common.glsl").read_text()
    libs = [(SRC / "lib" / f"{lib}.glsl").read_text() for lib in preset.get("libs", [])]
    if buffer_key is None:
        body = (SRC / "scenes" / f"{preset['id']}.glsl").read_text()
        tail = [(SRC / "lib" / "fx_main.glsl").read_text()]
    else:
        # A buffer pass is a complete main() of its own: no post-effect wrapper.
        body = (SRC / "scenes" / f"{preset['id']}_{src_key or buffer_key}.glsl").read_text()
        tail = []
    everything = common + "".join(libs) + body + "".join(tail)
    parts = [header(preset, params, everything), common] + libs + [body] + tail
    text = "\n".join(p.rstrip("\n") + "\n" for p in parts)

    declared = {p["uniform"] for p in params} | SYSTEM_NAMES
    used = set(re.findall(r"\bu_[A-Za-z0-9_]+\b", text))
    missing = used - declared
    if missing:
        raise SystemExit(f"{preset['id']}: shader uses undeclared uniforms {sorted(missing)}")
    return text


def main():
    ASSETS.joinpath("shaders").mkdir(parents=True, exist_ok=True)
    ASSETS.joinpath("presets").mkdir(parents=True, exist_ok=True)
    catalog = []
    ids = set()
    for pr in PRESETS:
        assert pr["id"] not in ids, pr["id"]
        ids.add(pr["id"])
        params = resolve_params(pr)
        text = compose(pr, params)
        (ASSETS / "shaders" / f"{pr['id']}.frag").write_text(text)
        buffers = []
        for key, bdef in sorted(pr.get("buffers", {}).items()):
            btext = compose(pr, params, key, bdef.get('src'))
            (ASSETS / "shaders" / f"{pr['id']}_{key}.frag").write_text(btext)
            buffers.append(dict(id=key, asset=f"shaders/{pr['id']}_{key}.frag", channels=bdef["channels"]))
        entry_extra = {}
        if buffers:
            entry_extra["buffers"] = buffers
        if pr.get("channels"):
            entry_extra["imageChannels"] = pr["channels"]
        if pr.get("tags"):
            entry_extra["tags"] = pr["tags"]
        catalog.append(dict(
            id=pr["id"], name=pr["name"], category=pr["cat"], description=pr["desc"],
            performance=pr["perf"],
            performanceNote={"LIGHT": "Light: runs smoothly on most devices.",
                             "MEDIUM": "Medium: several noise layers; reduce Quality on older devices.",
                             "HEAVY": "Heavy: long loops or raymarching; lower Iterations or Quality if it stutters."}[pr["perf"]],
            version=1, seed=0.0, previewTime=pr.get("preview", 3.0), animated=True,
            vertexAsset="shaders/fullscreen.vert", fragmentAsset=f"shaders/{pr['id']}.frag",
            params=params, **entry_extra))
    (ASSETS / "presets" / "catalog.json").write_text(json.dumps(dict(catalogVersion=1, presets=catalog), indent=1) + "\n")
    print(f"wrote {len(catalog)} presets")


if __name__ == "__main__":
    sys.exit(main())
