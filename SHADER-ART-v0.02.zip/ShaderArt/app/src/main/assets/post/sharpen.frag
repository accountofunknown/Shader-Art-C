#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 px = 1.0 / u_resolution;
    vec4 c = texture(u_input, uv);
    vec3 n = texture(u_input, uv + vec2(px.x, 0.0)).rgb + texture(u_input, uv - vec2(px.x, 0.0)).rgb
           + texture(u_input, uv + vec2(0.0, px.y)).rgb + texture(u_input, uv - vec2(0.0, px.y)).rgb;
    vec3 rgb = c.rgb + (c.rgb * 4.0 - n) * u_p0;
    fragColor = vec4(max(rgb, 0.0), c.a);
}
