#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 q = (uv - 0.5) * vec2(u_resolution.x / u_resolution.y, 1.0);
    float r = length(q);
    float a = atan(q.y, q.x) + u_p1;
    float seg = 6.2831853 / max(floor(u_p0 + 0.5), 1.0);
    a = abs(mod(a, seg) - 0.5 * seg);
    vec2 k = vec2(cos(a), sin(a)) * r;
    k.x /= u_resolution.x / u_resolution.y;
    vec2 st = clamp(k + 0.5, 0.0, 1.0);
    fragColor = mix(texture(u_input, uv), texture(u_input, st), u_p2);
}
