#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 dir = (uv - 0.5);
    vec2 off = dir * (u_p0 / max(u_resolution.x, u_resolution.y)) * 2.0;
    vec4 c = texture(u_input, uv);
    float r = texture(u_input, uv + off).r;
    float b = texture(u_input, uv - off).b;
    fragColor = vec4(r, c.g, b, c.a);
}
