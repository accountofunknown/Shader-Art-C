#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
vec3 hueShift(vec3 c, float h) {
    const mat3 toYiq = mat3(0.299, 0.596, 0.211, 0.587, -0.274, -0.523, 0.114, -0.322, 0.312);
    const mat3 toRgb = mat3(1.0, 1.0, 1.0, 0.956, -0.272, -1.106, 0.621, -0.647, 1.703);
    vec3 yiq = toYiq * c;
    float a = h * 6.2831853;
    float cs = cos(a);
    float sn = sin(a);
    yiq.yz = vec2(yiq.y * cs - yiq.z * sn, yiq.y * sn + yiq.z * cs);
    return toRgb * yiq;
}
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec4 c = texture(u_input, uv);
    vec3 rgb = c.rgb * exp2(u_p0);
    rgb = (rgb - 0.5) * u_p1 + 0.5;
    float l = dot(rgb, vec3(0.2126, 0.7152, 0.0722));
    rgb = mix(vec3(l), rgb, u_p2);
    rgb = hueShift(rgb, u_p3);
    fragColor = vec4(max(rgb, 0.0), c.a);
}
