#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec4 c = texture(u_input, uv);
    vec2 q = (uv - 0.5) * vec2(u_resolution.x / u_resolution.y, 1.0);
    float d = length(q) * 1.4142;
    float v = smoothstep(1.0, 1.0 - max(u_p1, 0.05), d);
    fragColor = vec4(c.rgb * mix(1.0 - clamp(u_p0, 0.0, 1.5), 1.0, v), c.a);
}
