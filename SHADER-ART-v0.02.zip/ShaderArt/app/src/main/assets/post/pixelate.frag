#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    float b = max(u_p0, 1.0);
    vec2 cell = floor(gl_FragCoord.xy / b);
    vec2 uv = (cell + 0.5) * b / u_resolution;
    fragColor = texture(u_input, uv);
}
