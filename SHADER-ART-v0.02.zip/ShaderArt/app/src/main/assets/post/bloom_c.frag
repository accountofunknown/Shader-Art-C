#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform sampler2D u_orig;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec4 base = texture(u_orig, uv);
    vec3 glow = texture(u_input, uv).rgb;
    fragColor = vec4(base.rgb + glow * u_p1 * 2.0, base.a);
}
