#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec4 c = texture(u_input, uv);
    float n = max(u_p0, 2.0) - 1.0;
    fragColor = vec4(floor(clamp(c.rgb, 0.0, 1.0) * n + 0.5) / n, c.a);
}
