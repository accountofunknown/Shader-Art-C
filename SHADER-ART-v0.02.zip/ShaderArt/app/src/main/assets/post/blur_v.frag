#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 step = vec2(0.0, 1.0) / u_resolution;
    float r = max(u_p0, 0.0);
    if (r < 0.5) { fragColor = texture(u_input, uv); return; }
    // 9 taps whose spacing grows with the radius; Gaussian weights.
    float s = r / 4.0;
    vec4 sum = texture(u_input, uv) * 0.2270270270;
    sum += (texture(u_input, uv + step * s * 1.3846153846) + texture(u_input, uv - step * s * 1.3846153846)) * 0.3162162162;
    sum += (texture(u_input, uv + step * s * 3.2307692308) + texture(u_input, uv - step * s * 3.2307692308)) * 0.0702702703;
    sum += (texture(u_input, uv + step * s * 5.0) + texture(u_input, uv - step * s * 5.0)) * 0.02;
    fragColor = sum / 1.0;
}
