#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 step = vec2(0.0, 1.0) / u_resolution;
    float s = max(u_p2, 1.0) / 4.0;
    vec3 sum = vec3(0.0);
    float wsum = 0.0;
    for (int i = -4; i <= 4; i++) {
        float w = exp(-float(i * i) * 0.18);
        sum += texture(u_input, uv + step * s * float(i)).rgb * w;
        wsum += w;
    }
    fragColor = vec4(sum / wsum, 1.0);
}
