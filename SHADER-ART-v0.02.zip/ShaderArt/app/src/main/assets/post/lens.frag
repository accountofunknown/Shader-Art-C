#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 q = uv * 2.0 - 1.0;
    q.x *= u_resolution.x / u_resolution.y;
    float r2 = dot(q, q);
    q *= 1.0 + u_p0 * r2;
    q.x /= u_resolution.x / u_resolution.y;
    vec2 st = q * 0.5 + 0.5;
    if (st.x < 0.0 || st.x > 1.0 || st.y < 0.0 || st.y > 1.0) { fragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
    fragColor = texture(u_input, st);
}
