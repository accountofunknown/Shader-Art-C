#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
float lum(vec2 st) { return dot(texture(u_input, st).rgb, vec3(0.299, 0.587, 0.114)); }
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec2 px = 1.0 / u_resolution;
    float tl = lum(uv + px * vec2(-1.0, 1.0));
    float t = lum(uv + px * vec2(0.0, 1.0));
    float tr = lum(uv + px * vec2(1.0, 1.0));
    float l = lum(uv + px * vec2(-1.0, 0.0));
    float r = lum(uv + px * vec2(1.0, 0.0));
    float bl = lum(uv + px * vec2(-1.0, -1.0));
    float b = lum(uv + px * vec2(0.0, -1.0));
    float br = lum(uv + px * vec2(1.0, -1.0));
    float gx = -tl - 2.0 * l - bl + tr + 2.0 * r + br;
    float gy = -tl - 2.0 * t - tr + bl + 2.0 * b + br;
    float e = clamp(length(vec2(gx, gy)) * u_p0, 0.0, 1.0);
    vec4 c = texture(u_input, uv);
    fragColor = vec4(mix(c.rgb, vec3(e), u_p1), c.a);
}
