#version 300 es
precision highp float;
precision highp int;
uniform sampler2D u_input;
uniform vec2 u_resolution;
uniform float u_time;
uniform float u_p0;
uniform float u_p1;
uniform float u_p2;
uniform float u_p3;
out vec4 fragColor;
float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
void main() {
    vec2 uv = gl_FragCoord.xy / u_resolution;
    vec4 c = texture(u_input, uv);
    vec2 cell = floor(gl_FragCoord.xy / max(u_p1, 1.0));
    float n = hash12(cell + floor(u_time * 24.0) * 17.0) - 0.5;
    float l = dot(c.rgb, vec3(0.299, 0.587, 0.114));
    float amt = u_p0 * (1.0 - 0.5 * l);
    fragColor = vec4(c.rgb + n * amt, c.a);
}
