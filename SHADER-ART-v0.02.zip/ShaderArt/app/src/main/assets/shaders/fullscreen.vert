#version 300 es
// SHADER ART full-screen triangle vertex shader (no vertex buffers needed).
// Draw with glDrawArrays(GL_TRIANGLES, 0, 3). Covers the whole viewport with one triangle.
void main() {
  vec2 pos = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
  gl_Position = vec4(pos * 2.0 - 1.0, 0.0, 1.0);
}
