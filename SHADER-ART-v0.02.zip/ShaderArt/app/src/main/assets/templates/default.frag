#version 300 es
// SHADER ART default template (GLSL ES 3.00)
//
// Standard uniforms: the app sets these every frame. Declare only the ones you use.
//   u_time        float  seconds of animation time
//   u_resolution  vec2   render size in pixels
//   u_mouse       vec4   xy = touch position 0..1 (origin bottom-left), z = 1 while touching
//   u_deltaTime   float  seconds since the previous frame
//   u_frame       int    frame counter
//   u_speed       float  animation speed chosen in the UI
//   u_zoom        float  pinch zoom (1.0 = none)
//
// Your own uniforms get a control automatically. Describe it in a comment on the same line:
//   uniform float u_scale; // @slider min max default "Label"
//   uniform vec3  u_tint;  // @color r g b "Label"
//   uniform bool  u_flip;  // @toggle 0 "Label"
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec4 u_mouse;
uniform float u_zoom;

uniform float u_scale;  // @slider 0.2 6 1.5 "Scale"
uniform vec3 u_colorA;  // @color 0.1 0.6 1 "Primary color"
uniform vec3 u_colorB;  // @color 1 0.3 0.7 "Secondary color"

out vec4 fragColor;

// Screen centre is (0,0); the shorter side spans -1..1. Pinch zoom is applied here.
vec2 normalizedCoord(vec2 fragCoord) {
  return (fragCoord * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y) / u_zoom;
}

vec3 render(vec2 uv) {
  vec2 p = uv * u_scale;
  float wave = 0.5 + 0.5 * sin(p.x * 3.0 + u_time) * cos(p.y * 3.0 - u_time * 0.7);
  vec3 col = mix(u_colorA, u_colorB, wave);
  if (u_mouse.z > 0.5) {
    vec2 m = normalizedCoord(u_mouse.xy * u_resolution);
    col += 0.4 * exp(-4.0 * length(uv - m));
  }
  return col;
}

void main() {
  vec2 uv = normalizedCoord(gl_FragCoord.xy);
  fragColor = vec4(render(uv), 1.0);
}
