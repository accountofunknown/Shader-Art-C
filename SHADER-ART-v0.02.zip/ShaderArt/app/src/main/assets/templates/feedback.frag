#version 300 es
// SHADER ART template: multi-pass feedback (GLSL ES 3.00)
//
// This is the Image pass. It shows Buffer A (channel 0). Buffer A reads itself (its own channel 0 = Buffer A),
// which gives it a memory of the previous frame. Open the "Buffer A" tab to see how.
precision highp float;
precision highp int;

uniform vec2 u_resolution;
uniform sampler2D u_channel0;

out vec4 fragColor;

void main() {
  vec3 c = texture(u_channel0, gl_FragCoord.xy / u_resolution).rgb;
  fragColor = vec4(c / (1.0 + c), 1.0);
}
