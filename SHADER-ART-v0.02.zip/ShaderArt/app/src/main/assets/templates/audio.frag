#version 300 es
// SHADER ART template: audio-reactive (GLSL ES 3.00)
//
// Turn on a sound source with the Inputs button (Demo beat needs no permission).
//   u_audio    vec4   x = overall level, y = bass, z = mid, w = treble  (all 0..1)
//   u_beat     float  jumps to 1.0 on a beat and fades out
//   u_channel0 sampler2D  set channel 0 to "Audio": row 0.25 = spectrum (left = low pitch), row 0.75 = waveform
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform float u_zoom;
uniform vec4 u_audio;
uniform float u_beat;
uniform sampler2D u_channel0;

uniform vec3 u_colorA;  // @color 0.1 0.7 1 "Primary color"
uniform vec3 u_colorB;  // @color 1 0.3 0.7 "Secondary color"
uniform float u_gain;   // @slider 0 3 1.2 "Reaction strength"

out vec4 fragColor;

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y) / u_zoom;
  float r = length(uv);
  float spec = texture(u_channel0, vec2(clamp(abs(uv.x) * 0.5, 0.0, 1.0), 0.25)).r;
  float bar = smoothstep(0.02, 0.0, uv.y + 0.6 - spec * u_gain);
  float ring = smoothstep(0.02, 0.0, abs(r - (0.3 + u_audio.y * 0.3 * u_gain)));
  vec3 col = vec3(0.0);
  col += bar * mix(u_colorA, u_colorB, abs(uv.x));
  col += ring * u_colorB;
  col += u_beat * 0.15 * u_colorA * (1.0 - r);
  fragColor = vec4(col, 1.0);
}
