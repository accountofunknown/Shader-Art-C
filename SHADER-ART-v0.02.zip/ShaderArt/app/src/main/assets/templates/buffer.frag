#version 300 es
// New buffer pass. A buffer draws into its own image that other passes can read as a channel.
// Bind inputs in the channel panel; channel 0 here starts out as "none" (black).
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform sampler2D u_channel0;

out vec4 fragColor;

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  fragColor = vec4(texture(u_channel0, uv).rgb + vec3(0.0), 1.0);
}
