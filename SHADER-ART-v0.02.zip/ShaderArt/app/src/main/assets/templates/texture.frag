#version 300 es
// SHADER ART template: picture input (GLSL ES 3.00)
//
// In the channel panel, import a picture and bind it to channel 0 (or pick "Noise").
//   u_channel0           sampler2D  the picture (origin bottom-left, so it appears upright)
//   u_channelResolution  vec3[4]    size in pixels of each channel
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform sampler2D u_channel0;

uniform float u_wobble;  // @slider 0 0.1 0.02 "Wobble"

out vec4 fragColor;

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  uv += u_wobble * vec2(sin(uv.y * 20.0 + u_time * 2.0), cos(uv.x * 20.0 + u_time * 2.0));
  fragColor = vec4(texture(u_channel0, uv).rgb, 1.0);
}
