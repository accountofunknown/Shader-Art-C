#version 300 es
// SHADER ART template: touch reaction (GLSL ES 3.00)
//
//   u_touches[10]  vec4   per finger: xy = position 0..1, z = pressure, w = 1 if down
//   u_touchCount   int    how many fingers are down
//   u_taps[8]      vec4   recent taps: xy = position 0..1, z = u_time of the tap, w = strength
//   u_tapCount     int    valid entries in u_taps
//   u_touchVel     vec2   speed of the first finger (screen widths per second)
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec4 u_touches[10];
uniform int u_touchCount;
uniform vec4 u_taps[8];
uniform int u_tapCount;

uniform vec3 u_colorA;  // @color 0.1 0.7 1 "Primary color"
uniform vec3 u_colorB;  // @color 1 0.4 0.8 "Secondary color"

out vec4 fragColor;

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  float aspect = u_resolution.x / u_resolution.y;
  vec3 col = mix(vec3(0.0), u_colorA * 0.2, uv.y);
  for (int i = 0; i < 8; i++) {
    if (i >= u_tapCount) break;
    vec4 t = u_taps[i];
    float age = u_time - t.z;
    float d = length((uv - t.xy) * vec2(aspect, 1.0));
    col += u_colorB * smoothstep(0.02, 0.0, abs(d - age * 0.3)) * exp(-age * 1.5) * t.w;
  }
  for (int i = 0; i < 10; i++) {
    if (i >= u_touchCount) break;
    float d = length((uv - u_touches[i].xy) * vec2(aspect, 1.0));
    col += u_colorA * 0.02 / (d * d + 0.01);
  }
  fragColor = vec4(col, 1.0);
}
