#version 300 es
// Raymarched sphere: a minimal sphere-tracing starter. The loop is capped (MAX_STEPS) and the ray is
// cut off at MAX_DIST so the shader can never run away. Keep both limits when you extend it.
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec4 u_mouse;

uniform float u_radius;    // @slider 0.2 1.5 0.8 "Radius"
uniform int u_steps;       // @slider 8 64 48 "Max steps"
uniform vec3 u_colorA;     // @color 0.9 0.35 0.25 "Surface color"
uniform vec3 u_bgColor;    // @color 0.03 0.04 0.08 "Background color"

out vec4 fragColor;

const float MAX_DIST = 20.0;
const int MAX_STEPS = 64;

float sdSphere(vec3 p, float r) {
  return length(p) - r;
}

float map(vec3 p) {
  vec3 c = vec3(sin(u_time) * 0.4, 0.0, 0.0);
  return sdSphere(p - c, u_radius);
}

vec3 normalAt(vec3 p) {
  vec2 e = vec2(0.001, 0.0);
  return normalize(vec3(
    map(p + e.xyy) - map(p - e.xyy),
    map(p + e.yxy) - map(p - e.yxy),
    map(p + e.yyx) - map(p - e.yyx)));
}

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y);
  vec3 ro = vec3(0.0, 0.0, -3.0);
  vec3 rd = normalize(vec3(uv, 1.6));
  float t = 0.0;
  bool hit = false;
  for (int i = 0; i < MAX_STEPS; i++) {
    if (i >= u_steps) break;
    float d = map(ro + rd * t);
    if (d < 0.001) { hit = true; break; }
    t += d;
    if (t > MAX_DIST) break;
  }
  vec3 col = u_bgColor;
  if (hit) {
    vec3 p = ro + rd * t;
    vec3 n = normalAt(p);
    vec3 l = normalize(vec3(0.6, 0.8, -0.5));
    float diff = clamp(dot(n, l), 0.0, 1.0);
    col = u_colorA * (0.15 + 0.85 * diff);
  }
  fragColor = vec4(col, 1.0);
}
