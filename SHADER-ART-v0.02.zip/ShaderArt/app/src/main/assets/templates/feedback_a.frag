#version 300 es
// Buffer A: fades and swirls its previous frame, then adds a new light.
// Channel 0 of this pass is Buffer A itself, so texture(u_channel0, ...) returns what this pass drew last frame.
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec4 u_mouse;
uniform sampler2D u_channel0;

uniform float u_decay;   // @slider 0.8 0.995 0.96 "Persistence"
uniform vec3 u_colorA;   // @color 0.1 0.6 1 "Light color"

out vec4 fragColor;

void main() {
  vec2 uv = gl_FragCoord.xy / u_resolution;
  vec2 p = uv - 0.5;
  float a = 0.01;
  p = mat2(cos(a), sin(a), -sin(a), cos(a)) * p * 0.997;
  vec3 prev = texture(u_channel0, p + 0.5).rgb * u_decay;
  vec2 q = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y);
  vec2 pos = u_mouse.z > 0.5 ? (u_mouse.xy * 2.0 - 1.0) * vec2(u_resolution.x / u_resolution.y, 1.0)
                             : vec2(sin(u_time * 0.9), cos(u_time * 0.7)) * 0.6;
  float d = length(q - pos);
  vec3 add = u_colorA * 0.004 / (d * d + 0.002);
  fragColor = vec4(min(prev + add, vec3(6.0)), 1.0);
}
