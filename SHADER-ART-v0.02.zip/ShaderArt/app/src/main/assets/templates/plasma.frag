#version 300 es
// Plasma: classic sine-sum plasma. Edit the formula in plasma() and press Run.
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;

uniform float u_frequency;  // @slider 0.5 12 3 "Frequency"
uniform float u_speedMul;   // @slider 0 4 1 "Speed"
uniform vec3 u_colorA;      // @color 1 0.1 0.5 "Primary color"
uniform vec3 u_colorB;      // @color 0.1 0.4 1 "Secondary color"

out vec4 fragColor;

float plasma(vec2 p, float t) {
  float v = sin(p.x * u_frequency + t);
  v += sin((p.y * u_frequency + t) * 0.5);
  v += sin((p.x + p.y) * u_frequency * 0.5 + t * 0.7);
  vec2 c = p + 0.5 * vec2(sin(t * 0.33), cos(t * 0.5));
  v += sin(sqrt(dot(c, c) * u_frequency * u_frequency + 1.0) + t);
  return v * 0.125 + 0.5;
}

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y);
  float v = plasma(uv * 1.5, u_time * u_speedMul);
  vec3 col = mix(u_colorA, u_colorB, 0.5 + 0.5 * sin(6.28318 * v));
  fragColor = vec4(col, 1.0);
}
