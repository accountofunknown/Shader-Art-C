#version 300 es
// Noise clouds: fractal value noise with drifting motion.
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;

uniform float u_scale;     // @slider 0.5 8 3 "Scale"
uniform int u_octaves;     // @slider 1 8 5 "Octaves"
uniform vec3 u_colorA;     // @color 0.05 0.1 0.25 "Shadow color"
uniform vec3 u_colorB;     // @color 0.9 0.95 1 "Cloud color"

out vec4 fragColor;

float hash(vec2 p) {
  vec3 p3 = fract(vec3(p.xyx) * 0.1031);
  p3 += dot(p3, p3.yzx + 33.33);
  return fract((p3.x + p3.y) * p3.z);
}

float noise(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
             mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
}

float fbm(vec2 p) {
  float v = 0.0;
  float a = 0.5;
  for (int i = 0; i < 8; i++) {
    if (i >= u_octaves) break;
    v += a * noise(p);
    p = p * 2.0 + vec2(17.0, 9.0);
    a *= 0.5;
  }
  return v;
}

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y);
  float n = fbm(uv * u_scale + vec2(u_time * 0.1, 0.0));
  fragColor = vec4(mix(u_colorA, u_colorB, smoothstep(0.25, 0.8, n)), 1.0);
}
