#version 300 es
// SHADER ART template: device sensors (GLSL ES 3.00)
//
// Turn on "Motion sensors" with the Inputs button, then tilt and shake the phone.
//   u_tilt   vec2   tilt from gravity, -1..1 on each axis
//   u_gyro   vec3   rotation rate in rad/s
//   u_accel  vec3   acceleration without gravity in m/s^2
precision highp float;
precision highp int;

uniform float u_time;
uniform vec2 u_resolution;
uniform vec2 u_tilt;
uniform vec3 u_gyro;
uniform vec3 u_accel;

uniform vec3 u_colorA;  // @color 0.1 0.6 1 "Primary color"
uniform vec3 u_colorB;  // @color 1 0.3 0.6 "Secondary color"

out vec4 fragColor;

void main() {
  vec2 uv = (gl_FragCoord.xy * 2.0 - u_resolution) / min(u_resolution.x, u_resolution.y);
  vec2 centre = u_tilt * 0.6;
  float d = length(uv - centre);
  float shake = clamp(length(u_accel) * 0.1, 0.0, 1.0);
  float glow = 0.05 / (d * d + 0.02);
  vec3 col = mix(u_colorA, u_colorB, shake) * glow;
  col += u_colorB * 0.1 * sin(uv.x * 10.0 + u_gyro.z * 2.0 + u_time);
  fragColor = vec4(col, 1.0);
}
