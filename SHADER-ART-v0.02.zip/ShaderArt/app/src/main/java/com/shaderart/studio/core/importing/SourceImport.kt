package com.shaderart.studio.core.importing

import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.shader.ShaderMetadataParser
import com.shaderart.studio.core.storage.ProjectIds

/** Builds a code project from a raw `.glsl`, `.frag` or `.vert` file. */
object SourceImport {
    val EXTENSIONS = setOf("glsl", "frag", "vert")

    fun extensionOf(fileName: String): String = fileName.substringAfterLast('.', "").lowercase()

    /**
     * @param defaultVertex used when the imported file is a fragment shader.
     * @param defaultFragment used when the imported file is a vertex shader.
     */
    fun fromBytes(
        fileName: String,
        bytes: ByteArray,
        defaultVertex: String,
        defaultFragment: String,
        now: Long,
        id: String = ProjectIds.newId(),
    ): ShaderProject {
        val ext = extensionOf(fileName)
        if (ext !in EXTENSIONS) throw ImportException("Unsupported file type '.$ext'. Use .glsl, .frag, .vert or .shaderart.")
        if (bytes.size > ImportLimits.MAX_SOURCE_BYTES) {
            throw ImportException("The file is larger than ${ImportLimits.MAX_SOURCE_BYTES / 1024} KB.")
        }
        val text = try {
            GlslSourceCheck.decodeUtf8Strict(bytes)
        } catch (e: IllegalArgumentException) {
            throw ImportException(e.message ?: "The file is not valid text.")
        }.replace("\r\n", "\n")

        val isVertex = ext == "vert"
        val problems = GlslSourceCheck.check(text, if (isVertex) "Vertex" else "Fragment")
        if (problems.isNotEmpty()) throw ImportException(problems.first())

        val vertex = if (isVertex) text else defaultVertex
        val fragment = if (isVertex) defaultFragment else text
        val params = ShaderMetadataParser.toParamDefs(ShaderMetadataParser.declaredUniforms(fragment))
        val base = fileName.substringBeforeLast('.', fileName).trim().ifEmpty { "Imported shader" }
        return ShaderProject(
            id = id,
            name = base.take(ImportLimits.MAX_NAME_LENGTH),
            type = ProjectType.CODE,
            createdAt = now,
            modifiedAt = now,
            vertexSource = vertex,
            fragmentSource = fragment,
            params = params,
            values = ParamLogic.defaults(params),
        )
    }
}
