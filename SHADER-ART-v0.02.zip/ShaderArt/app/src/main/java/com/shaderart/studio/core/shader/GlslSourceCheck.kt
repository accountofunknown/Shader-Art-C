package com.shaderart.studio.core.shader

import com.shaderart.studio.core.security.ImportLimits
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.CodingErrorAction

/** Cheap structural checks that run before anything reaches the GPU compiler. */
object GlslSourceCheck {
    private val VERSION_300_ES = Regex("""^\s*(?://[^\n]*\n\s*|/\*.*?\*/\s*)*#version\s+300\s+es(?:\s|$)""", RegexOption.DOT_MATCHES_ALL)
    private val VERSION_ANY = Regex("""#version\s+(\d+)(?:\s+(\w+))?""")

    fun hasVersion300es(source: String): Boolean = VERSION_300_ES.containsMatchIn(source)

    /** Returns problems found, empty if the source looks acceptable. */
    fun check(source: String, stageName: String): List<String> {
        val problems = ArrayList<String>()
        if (source.isBlank()) { problems += "$stageName shader is empty"; return problems }
        if (source.toByteArray(Charsets.UTF_8).size > ImportLimits.MAX_SOURCE_BYTES) {
            problems += "$stageName shader is larger than ${ImportLimits.MAX_SOURCE_BYTES / 1024} KB"
        }
        if (source.contains('\u0000')) problems += "$stageName shader contains NUL characters"
        if (source.count { it == '\n' } + 1 > ImportLimits.MAX_SOURCE_LINES) {
            problems += "$stageName shader has more than ${ImportLimits.MAX_SOURCE_LINES} lines"
        }
        if (!hasVersion300es(source)) {
            val found = VERSION_ANY.find(source)
            problems += if (found != null) "$stageName shader uses '#version ${found.groupValues[1]} ${found.groupValues[2]}'. SHADER ART needs '#version 300 es' as the first line."
            else "$stageName shader must start with '#version 300 es'"
        }
        return problems
    }

    /** Strict UTF-8 decoding: malformed bytes are an error, never silently replaced. */
    fun decodeUtf8Strict(bytes: ByteArray): String {
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            throw IllegalArgumentException("The file is not valid UTF-8 text")
        }
    }
}
