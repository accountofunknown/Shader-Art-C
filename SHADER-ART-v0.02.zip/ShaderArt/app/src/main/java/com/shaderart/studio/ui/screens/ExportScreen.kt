package com.shaderart.studio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.export.AlphaMode
import com.shaderart.studio.core.export.AnimationLimits
import com.shaderart.studio.core.export.ExportLimits
import com.shaderart.studio.feature.export.ExportKind
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.ScreenTitle
import com.shaderart.studio.ui.components.SecondaryButton
import com.shaderart.studio.ui.components.SectionLabel
import com.shaderart.studio.ui.components.StatusBanner
import com.shaderart.studio.ui.theme.ShaderArtColors
import java.util.Locale

class ExportHost(
    val onBack: () -> Unit,
    /** Opens the system "save as" picker for the finished image. */
    val onSaveAs: (fileName: String, mime: String) -> Unit,
    val onShare: (file: java.io.File, mime: String) -> Unit,
)

@Composable
fun ExportScreen(vm: StudioViewModel, host: ExportHost) {
    val controller = vm.export
    val s by controller.ui.collectAsStateWithLifecycle()
    val ui = vm.ui
    val metrics = LocalContext.current.resources.displayMetrics

    LaunchedEffect(Unit) { controller.loadLimits() }

    var widthText by remember { mutableStateOf("") }
    var heightText by remember { mutableStateOf("") }
    var editingSize by remember { mutableStateOf(false) }
    var timeText by remember { mutableStateOf("") }
    var editingTime by remember { mutableStateOf(false) }

    // Typing starts from the current size, so a stale half-typed value can never leak in.
    fun typeSize(isWidth: Boolean, raw: String) {
        if (!editingSize) {
            widthText = s.width.toString()
            heightText = s.height.toString()
            editingSize = true
        }
        val digits = raw.filter { it.isDigit() }.take(5)
        if (isWidth) widthText = digits else heightText = digits
        val w = widthText.toIntOrNull()
        val h = heightText.toIntOrNull()
        if (w != null && h != null) controller.setSize(w, h)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Export", subtitle = ui.name.ifEmpty { "No project open" }) {
            SIconButton(R.drawable.ic_close, "Close export", host.onBack)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            if (!ui.hasProject) {
                StatusBanner("Open a preset or project first.", ShaderArtColors.Warning, R.drawable.ic_warning, Modifier.padding(16.dp))
                return@Column
            }

            SectionLabel("What to export")
            Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExportKind.entries.forEach { k -> Pill(k.label, s.kind == k, { controller.setKind(k) }) }
            }

            SectionLabel(if (s.kind == ExportKind.IMAGE) "Size" else "Size (the animation is scaled to fit its limits)")
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ExportLimits.PRESETS.filter { !it.wallpaper }.forEach { p ->
                    Pill(p.label, s.presetId == p.id, { editingSize = false; controller.selectPreset(p.id) })
                }
            }
            SectionLabel("Phone wallpaper")
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("This screen ${metrics.widthPixels}×${metrics.heightPixels}", s.presetId == null && s.width == metrics.widthPixels && s.height == metrics.heightPixels, {
                    editingSize = false
                    controller.setSize(metrics.widthPixels, metrics.heightPixels)
                })
                ExportLimits.PRESETS.filter { it.wallpaper }.forEach { p ->
                    Pill(p.label, s.presetId == p.id, { editingSize = false; controller.selectPreset(p.id) })
                }
            }

            SectionLabel("Custom size (px)")
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = if (editingSize) widthText else s.width.toString(),
                    onValueChange = { t -> typeSize(true, t) },
                    label = { Text("Width") }, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Text("×")
                OutlinedTextField(
                    value = if (editingSize) heightText else s.height.toString(),
                    onValueChange = { t -> typeSize(false, t) },
                    label = { Text("Height") }, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
            }
            val mp = s.width.toLong() * s.height.toLong() / 1_000_000.0
            Text(
                "%.1f megapixels".format(Locale.US, mp) + (s.gpuMaxSide?.let { " · this GPU supports up to $it px per side" } ?: ""),
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
            if (s.kind == ExportKind.GIF) {
                val (gw, gh) = controller.gifSize()
                Text("The GIF will be $gw×$gh (GIFs are limited to ${AnimationLimits.GIF_MAX_SIDE} px per side).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
            }
            if (s.kind == ExportKind.VIDEO) {
                val (vw, vh) = controller.videoSize()
                Text("The video will be $vw×$vh (even sizes, at most ${AnimationLimits.VIDEO_MAX_SIDE} px).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp))
            }
            if (s.kind == ExportKind.IMAGE && ExportLimits.problem(com.shaderart.studio.core.export.ExportConfig(s.width, s.height, s.format, s.quality, s.timeSeconds), s.gpuMaxSide) != null) {
                SecondaryButton("Fit to this device", { editingSize = false; controller.fitToDevice() }, Modifier.padding(horizontal = 16.dp))
            }

            if (s.kind == ExportKind.IMAGE) {
                SectionLabel("Format")
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ImageFormat.entries.forEach { f -> Pill(f.label, s.format == f, { controller.setFormat(f) }) }
                }
                if (s.format == ImageFormat.JPEG) {
                    LabeledValueSlider("JPEG quality", s.quality.toFloat(), 1f, 100f, "${s.quality}") { controller.setQuality(it.toInt()) }
                    Text(
                        "JPEG cannot be transparent.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                    )
                } else {
                    SectionLabel("Transparency (PNG)")
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AlphaMode.entries.forEach { a -> Pill(a.label, s.alpha == a, { controller.setAlpha(a) }) }
                    }
                    Text(
                        when (s.alpha) {
                            AlphaMode.OPAQUE -> "The picture is fully opaque."
                            AlphaMode.SHADER -> "Uses the alpha value the shader writes. Most presets write 1.0, so they stay opaque; your own shaders can write less."
                            AlphaMode.KEY_BLACK -> "Black becomes transparent and glows fade out smoothly. Best for light-on-dark artwork you want to place over other pictures."
                        },
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                    )
                }
            }
            if (s.kind == ExportKind.GIF) {
                SectionLabel("GIF settings")
                Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnimationLimits.GIF_FPS.forEach { f -> Pill("$f fps", s.gifFps == f, { controller.setGifFps(f) }) }
                }
                LabeledValueSlider("Length", s.gifSeconds, AnimationLimits.MIN_SECONDS, 30f, "%.1f s".format(Locale.US, s.gifSeconds)) { controller.setGifSeconds(it) }
                val frames = Math.round(s.gifFps * s.gifSeconds)
                Text(
                    "$frames frames" + if (frames > AnimationLimits.GIF_MAX_FRAMES) " — too many: a GIF can have at most ${AnimationLimits.GIF_MAX_FRAMES}." else ". GIFs use 256 colours per frame and can get large.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                )
            }
            if (s.kind == ExportKind.VIDEO) {
                SectionLabel("Video settings")
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AnimationLimits.VIDEO_FPS.forEach { f -> Pill("$f fps", s.videoFps == f, { controller.setVideoFps(f) }) }
                }
                LabeledValueSlider("Length", s.videoSeconds, AnimationLimits.MIN_SECONDS, AnimationLimits.VIDEO_MAX_SECONDS, "%.1f s".format(Locale.US, s.videoSeconds)) { controller.setVideoSeconds(it) }
                Text(
                    "H.264 MP4 made with your device's video encoder. The file has no sound track: audio reaction is shown with a built-in demo beat in exports.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp),
                )
            }

            SectionLabel(if (s.kind == ExportKind.IMAGE) "Moment in the animation" else "Start time in the animation")
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = if (editingTime) timeText else "%.2f".format(Locale.US, s.timeSeconds),
                    onValueChange = { t ->
                        editingTime = true
                        timeText = t.filter { it.isDigit() || it == '.' }.take(8)
                        timeText.toFloatOrNull()?.let { controller.setTime(it) }
                    },
                    label = { Text("Time (seconds)") }, singleLine = true, modifier = Modifier.weight(1f),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                )
                SecondaryButton("Use preview time", {
                    editingTime = false
                    controller.setTime(vm.session.stats.value.timeSeconds)
                })
            }

            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (s.running) {
                    LinearProgressIndicator(
                        progress = { s.progress },
                        modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Export progress ${(s.progress * 100).toInt()} percent" },
                        color = Color.White, trackColor = ShaderArtColors.Border,
                    )
                    Text("Rendering… ${(s.progress * 100).toInt()}%" + if (s.kind != ExportKind.IMAGE) " (stay on this screen; the animation is rendered frame by frame)" else "", style = MaterialTheme.typography.bodySmall)
                    SecondaryButton("Cancel", { controller.cancel() }, Modifier.fillMaxWidth(), icon = R.drawable.ic_close)
                } else {
                    PrimaryButton(when (s.kind) { ExportKind.IMAGE -> "Render image"; ExportKind.GIF -> "Render GIF"; ExportKind.VIDEO -> "Render video" }, { controller.start() }, Modifier.fillMaxWidth(), enabled = !ui.needsRun, icon = R.drawable.ic_export)
                }

                s.error?.let { StatusBanner(it, ShaderArtColors.Error, R.drawable.ic_error) }
                s.info?.let { StatusBanner(it, ShaderArtColors.TextSecondary, R.drawable.ic_info) }

                val file = s.resultFile
                val name = s.resultName
                if (file != null && name != null && !s.running) {
                    Column(
                        Modifier.fillMaxWidth().background(ShaderArtColors.Charcoal).padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Text(name, style = MaterialTheme.typography.titleSmall)
                        Text("${s.resultWidth}×${s.resultHeight} · ${file.length() / 1024} KB", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Save to device", { host.onSaveAs(name, s.resultMime) }, Modifier.weight(1f), icon = R.drawable.ic_save)
                            SecondaryButton("Share", { host.onShare(file, s.resultMime) }, Modifier.weight(1f), icon = R.drawable.ic_share)
                        }
                    }
                }
            }
        }
    }
}
