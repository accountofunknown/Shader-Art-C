package com.shaderart.studio.core.input

import com.shaderart.studio.core.audio.AudioFeatures

/**
 * Collects the latest audio, sensor and touch data from independent producers (threads) into one immutable [LiveInputs]
 * that the render thread reads each frame.
 */
class LiveInputHub {
    @Volatile
    var current: LiveInputs = LiveInputs.NONE
        private set

    @Synchronized fun setAudio(a: AudioFeatures) {
        val c = current
        current = LiveInputs(a, c.gyro, c.accel, c.tilt, c.touch)
    }

    @Synchronized fun setSensors(gyro: FloatArray, accel: FloatArray, tilt: FloatArray) {
        val c = current
        current = LiveInputs(c.audio, gyro.copyOf(3), accel.copyOf(3), tilt.copyOf(2), c.touch)
    }

    @Synchronized fun setTouch(t: TouchSnapshot) {
        val c = current
        current = LiveInputs(c.audio, c.gyro, c.accel, c.tilt, t)
    }

    /** Silence and stillness: used when a source is switched off. */
    @Synchronized fun clearAudio() = setAudio(AudioFeatures.SILENCE)

    @Synchronized fun clearSensors() = setSensors(FloatArray(3), FloatArray(3), FloatArray(2))
}
