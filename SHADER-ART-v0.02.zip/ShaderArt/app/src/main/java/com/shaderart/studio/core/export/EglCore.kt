package com.shaderart.studio.core.export

import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.view.Surface

/**
 * One EGL display + OpenGL ES 3 context + one drawing surface, created outside any view. The surface is either a small
 * pbuffer (offscreen renders, GIF frames) or a window surface wrapping a MediaCodec input surface (video).
 * Create and use it on one thread only.
 */
class EglCore private constructor(
    private val display: EGLDisplay,
    private val context: EGLContext,
    private val surface: EGLSurface,
) {
    fun swapBuffers(): Boolean = EGL14.eglSwapBuffers(display, surface)

    fun setPresentationTime(nanos: Long) {
        EGLExt.eglPresentationTimeANDROID(display, surface, nanos)
    }

    fun release() {
        EGL14.eglMakeCurrent(display, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
        EGL14.eglDestroySurface(display, surface)
        EGL14.eglDestroyContext(display, context)
        // eglTerminate is intentionally not called: the display connection is shared with the on-screen renderer.
    }

    companion object {
        private const val EGL_RECORDABLE_ANDROID = 0x3142

        /** An offscreen context with a 1x1 pbuffer: rendering goes to framebuffer objects. */
        fun createPbuffer(): EglCore = create(null)

        /** A context whose default framebuffer is [window] (a MediaCodec input surface). */
        fun createWindow(window: Surface): EglCore = create(window)

        private fun hex(v: Int) = Integer.toHexString(v)

        private fun create(window: Surface?): EglCore {
            val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
            if (display == EGL14.EGL_NO_DISPLAY) throw ExportException("No EGL display is available on this device.")
            val version = IntArray(2)
            if (!EGL14.eglInitialize(display, version, 0, version, 1)) throw ExportException("EGL could not be initialised.")
            val attribs = ArrayList<Int>().apply {
                add(EGL14.EGL_RENDERABLE_TYPE); add(EGLExt.EGL_OPENGL_ES3_BIT_KHR)
                add(EGL14.EGL_SURFACE_TYPE); add(if (window != null) EGL14.EGL_WINDOW_BIT else EGL14.EGL_PBUFFER_BIT)
                add(EGL14.EGL_RED_SIZE); add(8); add(EGL14.EGL_GREEN_SIZE); add(8); add(EGL14.EGL_BLUE_SIZE); add(8); add(EGL14.EGL_ALPHA_SIZE); add(8)
                if (window != null) { add(EGL_RECORDABLE_ANDROID); add(1) }
                add(EGL14.EGL_NONE)
            }.toIntArray()
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            if (!EGL14.eglChooseConfig(display, attribs, 0, configs, 0, 1, count, 0) || count[0] == 0 || configs[0] == null) {
                throw ExportException("This device has no OpenGL ES 3.0 configuration usable for ${if (window != null) "video recording" else "offscreen rendering"}.")
            }
            val ctx = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
            if (ctx == EGL14.EGL_NO_CONTEXT) throw ExportException("An OpenGL ES 3.0 context could not be created (EGL error 0x${hex(EGL14.eglGetError())}).")
            val surf = if (window != null) {
                EGL14.eglCreateWindowSurface(display, configs[0], window, intArrayOf(EGL14.EGL_NONE), 0)
            } else {
                EGL14.eglCreatePbufferSurface(display, configs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
            }
            if (surf == EGL14.EGL_NO_SURFACE) {
                EGL14.eglDestroyContext(display, ctx)
                throw ExportException("A drawing surface could not be created (EGL error 0x${hex(EGL14.eglGetError())}).")
            }
            if (!EGL14.eglMakeCurrent(display, surf, surf, ctx)) {
                EGL14.eglDestroySurface(display, surf)
                EGL14.eglDestroyContext(display, ctx)
                throw ExportException("The offscreen context could not be activated (EGL error 0x${hex(EGL14.eglGetError())}).")
            }
            return EglCore(display, ctx, surf)
        }
    }
}
