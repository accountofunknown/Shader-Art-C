package com.shaderart.studio.core.export

import android.graphics.Bitmap
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.pipeline.PassSource
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ShaderProject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.Executors
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

/**
 * Runs every offscreen GPU job (image export, thumbnails, preset previews) one at a time on a single
 * dedicated thread. That keeps EGL contexts on one thread and stops several heavy renders from
 * competing for the GPU.
 */
class ExportEngine(
    private val cacheDir: File,
    /** Decodes a project's texture for the GPU (flipped, owned by the caller), or null. */
    private val textureLoader: (projectId: String, name: String) -> Bitmap? = { _, _ -> null },
    private val postSourceLoader: (String) -> String? = { null },
) {
    private val gpuThread = Executors.newSingleThreadExecutor { r -> Thread(r, "shaderart-offscreen") }.asCoroutineDispatcher()
    private val renderer = OffscreenRenderer()

    private val exportDir get() = File(cacheDir, "exports")
    private val presetThumbDir get() = File(cacheDir, "preset_thumbs")

    /** Removes previously exported files from the share cache. */
    fun clearExportCache() {
        exportDir.listFiles()?.forEach { it.delete() }
    }

    suspend fun maxImageSide(): Int? = withContext(gpuThread) { renderer.queryMaxSide() }

    /**
     * Renders [project] at the requested size and writes an image file into the share cache.
     * Cancelling the calling coroutine stops the render between tiles.
     * Throws [ExportException] on failure; a file is returned only if the image really was written.
     */
    suspend fun exportImage(
        project: ShaderProject,
        config: ExportConfig,
        fileName: String,
        onProgress: (Float) -> Unit,
    ): File = withContext(gpuThread) {
        ExportLimits.problem(config)?.let { throw ExportException(it) }
        val dir = exportDir
        if (!dir.exists() && !dir.mkdirs()) throw ExportException("Could not create the export folder.")
        val alpha = if (config.format == ImageFormat.PNG) config.alpha else AlphaMode.OPAQUE
        val bitmap = renderer.render(
            requestFor(project, config.width, config.height, config.timeSeconds, alpha),
            onProgress = { onProgress(it * 0.95f) },
            isCancelled = { !isActive },
        )
        try {
            val out = File(dir, fileName)
            try {
                FileOutputStream(out).use { stream ->
                    val format = if (config.format == ImageFormat.PNG) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
                    val ok = bitmap.compress(format, if (config.format == ImageFormat.PNG) 100 else config.quality, stream)
                    if (!ok) throw ExportException("The image could not be encoded.")
                    stream.flush()
                }
            } catch (e: IOException) {
                out.delete()
                throw ExportException("The image could not be written: ${e.message}")
            } catch (e: ExportException) {
                out.delete()
                throw e
            }
            if (!isActive) {
                out.delete()
                throw kotlinx.coroutines.CancellationException("Export cancelled")
            }
            onProgress(1f)
            out
        } finally {
            bitmap.recycle()
        }
    }

    /** Small JPEG used as a project thumbnail. */
    suspend fun renderThumbnail(project: ShaderProject, size: Int = THUMB_SIZE): ByteArray = withContext(gpuThread) {
        val bitmap = renderer.render(requestFor(project, size, size, project.animation.time))
        try {
            val out = ByteArrayOutputStream()
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, out)) throw ExportException("Thumbnail encoding failed.")
            out.toByteArray()
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * Returns a cached preview image of a built-in preset, rendering it with the real shader on first use.
     * The cache key contains the preset version, so updated presets get fresh previews.
     */
    suspend fun presetThumbnail(preset: Preset): File = withContext(gpuThread) {
        val file = File(presetThumbDir, "${preset.id}_v${preset.version}_$THUMB_SIZE.jpg")
        if (file.isFile && file.length() > 0) return@withContext file
        if (!presetThumbDir.exists() && !presetThumbDir.mkdirs()) throw ExportException("Could not create the preview cache.")
        val request = OffscreenRequest(sceneOf(preset), THUMB_SIZE, THUMB_SIZE, preset.previewTime)
        val bitmap = renderer.render(request)
        try {
            val tmp = File(presetThumbDir, file.name + ".tmp")
            FileOutputStream(tmp).use { if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it)) throw ExportException("Preview encoding failed.") }
            if (!tmp.renameTo(file)) throw ExportException("Could not store the preview.")
            file
        } finally {
            bitmap.recycle()
        }
    }

    /**
     * Records [project] as an animated GIF. Frames are rendered with fixed time steps, quantized and streamed to disk, so memory
     * use stays at one frame. Cancelling the calling coroutine stops between frames and removes the partial file.
     */
    suspend fun exportGif(project: ShaderProject, config: GifConfig, fileName: String, onProgress: (Float) -> Unit): File = withContext(gpuThread) {
        AnimationLimits.gifProblem(config)?.let { throw ExportException(it) }
        val out = prepareOutput(fileName)
        var ok = false
        try {
            FileOutputStream(out).buffered(64 * 1024).use { stream ->
                val gif = GifEncoder(stream, config.width, config.height, config.delayCentis, loop = true, dither = true)
                renderer.renderSequence(
                    sceneOf(project), config.width, config.height, config.frames, config.fps.toFloat(), config.startTime,
                    onFrame = { _, pixels -> gif.addFrame(pixels) },
                    onProgress = { onProgress(it * 0.98f) },
                    isCancelled = { !isActive },
                )
                gif.finish()
            }
            ok = true
            onProgress(1f)
            out
        } catch (e: IOException) {
            throw ExportException("The GIF could not be written: ${e.message}")
        } finally {
            if (!ok) out.delete()
        }
    }

    /** Records [project] as an H.264 MP4 (video only). Throws [ExportException] with a plain explanation if the device cannot encode it. */
    suspend fun exportVideo(project: ShaderProject, config: VideoConfig, fileName: String, onProgress: (Float) -> Unit): File = withContext(gpuThread) {
        AnimationLimits.videoProblem(config)?.let { throw ExportException(it) }
        val out = prepareOutput(fileName)
        video.export(sceneOf(project), config, out, onProgress) { !isActive }
        out
    }

    /** Null if this device can probably encode [config]; otherwise a user-facing reason. */
    suspend fun videoSupport(config: VideoConfig): String? = withContext(gpuThread) { video.checkSupport(config) }

    private val video = VideoExporter()

    private fun prepareOutput(fileName: String): File {
        val dir = exportDir
        if (!dir.exists() && !dir.mkdirs()) throw ExportException("Could not create the export folder.")
        return File(dir, fileName)
    }

    private fun sceneOf(p: ShaderProject) = SceneData(
        vertex = p.vertexSource,
        image = PassSource(PassId.IMAGE, p.fragmentSource, p.imageChannels),
        buffers = p.buffers.map { PassSource(it.id, it.fragmentSource, it.channels) },
        post = p.postStack,
        params = p.params,
        values = ParamLogic.normalize(p.params, p.values),
        timeline = p.timeline,
        zoom = p.render.zoom,
        speed = p.animation.speed,
        textureLoader = { name -> textureLoader(p.id, name) },
        postSourceLoader = postSourceLoader,
    )

    private fun sceneOf(preset: Preset) = SceneData(
        vertex = preset.vertexSource,
        image = PassSource(PassId.IMAGE, preset.fragmentSource, preset.imageChannels),
        buffers = preset.buffers.map { PassSource(it.id, it.fragmentSource, it.channels) },
        post = emptyList(),
        params = preset.params,
        values = ParamLogic.defaults(preset.params),
        timeline = Timeline(),
        zoom = 1f,
        speed = 1f,
        textureLoader = { null },
        postSourceLoader = postSourceLoader,
    )

    private fun requestFor(p: ShaderProject, w: Int, h: Int, time: Float, alpha: AlphaMode = AlphaMode.OPAQUE) =
        OffscreenRequest(sceneOf(p), w, h, time, alpha)

    private companion object {
        const val THUMB_SIZE = 256
    }
}
