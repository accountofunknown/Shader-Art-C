package com.shaderart.studio.core.export

import com.shaderart.studio.core.security.ImportLimits
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ImageFormat(val extension: String, val mime: String, val label: String) {
    PNG("png", "image/png", "PNG"),
    JPEG("jpg", "image/jpeg", "JPEG"),
}

/** How the alpha channel of an exported image is produced. */
enum class AlphaMode(val label: String) {
    /** Fully opaque. */
    OPAQUE("Opaque"),

    /** The shader's own alpha output. */
    SHADER("Shader alpha"),

    /** Black becomes transparent: alpha = brightest colour channel, colour is un-multiplied. Good for glowing artwork. */
    KEY_BLACK("Black → transparent"),
}

data class ExportConfig(
    val width: Int,
    val height: Int,
    val format: ImageFormat = ImageFormat.PNG,
    /** JPEG quality 1..100 (ignored for PNG). */
    val quality: Int = 92,
    /** Shader time (seconds) to render. */
    val timeSeconds: Float = 0f,
    /** Transparency (PNG only; JPEG has no alpha and is always opaque). */
    val alpha: AlphaMode = AlphaMode.OPAQUE,
)

data class GifConfig(
    val width: Int,
    val height: Int,
    /** 5..30 frames per second; GIF stores delays in hundredths of a second, so the real rate is rounded to 100/n. */
    val fps: Int = 20,
    val durationSeconds: Float = 4f,
    val startTime: Float = 0f,
) {
    val frames: Int get() = Math.round(fps * durationSeconds).coerceAtLeast(1)
    /** Delay between frames in hundredths of a second (at least 2: browsers treat 0 and 1 as 10). */
    val delayCentis: Int get() = Math.round(100f / fps).coerceAtLeast(2)
}

data class VideoConfig(
    val width: Int,
    val height: Int,
    val fps: Int = 30,
    val durationSeconds: Float = 8f,
    val startTime: Float = 0f,
    /** 0 = choose automatically from size and frame rate. */
    val bitrateKbps: Int = 0,
) {
    val frames: Int get() = Math.round(fps * durationSeconds).coerceAtLeast(1)

    /** Bits per second used for the encoder: about 0.1 bit per pixel per frame, clamped to a sane range. */
    val bitrate: Int
        get() = if (bitrateKbps > 0) bitrateKbps * 1000
        else (width.toLong() * height * fps / 10L).coerceIn(2_000_000L, 40_000_000L).toInt()
}

object AnimationLimits {
    val GIF_FPS = listOf(10, 15, 20, 25, 30)
    val VIDEO_FPS = listOf(24, 30, 60)
    const val GIF_MAX_SIDE = 720
    const val GIF_MAX_FRAMES = 300
    const val GIF_MIN_SIDE = 32
    const val VIDEO_MIN_SIDE = 64
    const val VIDEO_MAX_SIDE = 3840
    const val VIDEO_MAX_SECONDS = 60f
    const val MIN_SECONDS = 0.5f

    fun gifProblem(c: GifConfig): String? {
        if (c.width < GIF_MIN_SIDE || c.height < GIF_MIN_SIDE) return "A GIF must be at least $GIF_MIN_SIDE px on each side."
        if (c.width > GIF_MAX_SIDE || c.height > GIF_MAX_SIDE) return "GIFs are limited to $GIF_MAX_SIDE px per side to keep the file a usable size."
        if (c.fps !in 5..30) return "GIF frame rate must be between 5 and 30."
        if (!c.durationSeconds.isFinite() || c.durationSeconds < MIN_SECONDS) return "Duration must be at least $MIN_SECONDS seconds."
        if (c.frames > GIF_MAX_FRAMES) return "That is ${c.frames} frames; a GIF is limited to $GIF_MAX_FRAMES (lower the frame rate or duration)."
        if (!c.startTime.isFinite() || c.startTime < 0f) return "Start time must be zero or greater."
        return null
    }

    fun videoProblem(c: VideoConfig): String? {
        if (c.width < VIDEO_MIN_SIDE || c.height < VIDEO_MIN_SIDE) return "A video must be at least $VIDEO_MIN_SIDE px on each side."
        if (c.width > VIDEO_MAX_SIDE || c.height > VIDEO_MAX_SIDE) return "Videos are limited to $VIDEO_MAX_SIDE px per side."
        if (c.fps !in 1..60) return "Frame rate must be between 1 and 60."
        if (!c.durationSeconds.isFinite() || c.durationSeconds < MIN_SECONDS) return "Duration must be at least $MIN_SECONDS seconds."
        if (c.durationSeconds > VIDEO_MAX_SECONDS) return "Videos are limited to ${VIDEO_MAX_SECONDS.toInt()} seconds."
        if (!c.startTime.isFinite() || c.startTime < 0f) return "Start time must be zero or greater."
        return null
    }

    /** H.264 needs even dimensions. */
    fun even(v: Int): Int = (v + 1) and 1.inv()

    /** Largest GIF size with the same aspect ratio as [width] x [height]. */
    fun fitGif(width: Int, height: Int): Pair<Int, Int> {
        if (width <= 0 || height <= 0) return GIF_MIN_SIDE to GIF_MIN_SIDE
        val scale = minOf(1.0, GIF_MAX_SIDE.toDouble() / width, GIF_MAX_SIDE.toDouble() / height)
        return maxOf(GIF_MIN_SIDE, (width * scale).toInt()) to maxOf(GIF_MIN_SIDE, (height * scale).toInt())
    }
}

data class SizePreset(val id: String, val label: String, val width: Int, val height: Int, val wallpaper: Boolean = false)

object ExportLimits {
    const val MIN_SIDE = 16
    const val MAX_SIDE = ImportLimits.MAX_RENDER_DIMENSION
    /** About 100 MB of RGBA pixels. Keeps the final bitmap within reach of typical app heaps. */
    const val MAX_PIXELS = 25_000_000L

    val PRESETS = listOf(
        SizePreset("square_1080", "Square 1080", 1080, 1080),
        SizePreset("square_2048", "Square 2048", 2048, 2048),
        SizePreset("landscape_hd", "Landscape 1920×1080", 1920, 1080),
        SizePreset("portrait_hd", "Portrait 1080×1920", 1080, 1920),
        SizePreset("uhd", "4K 3840×2160", 3840, 2160),
        SizePreset("wp_916", "Phone 9:16 · 1080×1920", 1080, 1920, wallpaper = true),
        SizePreset("wp_1950", "Phone 9:19.5 · 1080×2340", 1080, 2340, wallpaper = true),
        SizePreset("wp_920", "Phone 9:20 · 1080×2400", 1080, 2400, wallpaper = true),
        SizePreset("wp_921", "Phone 9:21 · 1080×2520", 1080, 2520, wallpaper = true),
        SizePreset("wp_qhd", "Phone QHD+ · 1440×3120", 1440, 3120, wallpaper = true),
    )

    /**
     * Returns a user-facing problem with [config], or null if it is acceptable.
     * @param gpuMaxSide the real maximum texture/renderbuffer size reported by the GPU, if known.
     */
    fun problem(config: ExportConfig, gpuMaxSide: Int? = null): String? {
        val w = config.width
        val h = config.height
        if (w < MIN_SIDE || h < MIN_SIDE) return "Width and height must be at least $MIN_SIDE px."
        if (w > MAX_SIDE || h > MAX_SIDE) return "Width and height can be at most $MAX_SIDE px."
        if (w.toLong() * h.toLong() > MAX_PIXELS) return "That is more than ${MAX_PIXELS / 1_000_000} megapixels. Choose a smaller size."
        if (gpuMaxSide != null && (w > gpuMaxSide || h > gpuMaxSide)) return "This GPU supports images up to $gpuMaxSide px per side."
        if (config.quality !in 1..100) return "JPEG quality must be between 1 and 100."
        if (!config.timeSeconds.isFinite() || config.timeSeconds < 0f) return "Time must be zero or greater."
        return null
    }

    /** Largest size with the same aspect ratio that fits the limits. */
    fun fit(width: Int, height: Int, gpuMaxSide: Int? = null): Pair<Int, Int> {
        if (width <= 0 || height <= 0) return MIN_SIDE to MIN_SIDE
        val side = minOf(MAX_SIDE, gpuMaxSide ?: MAX_SIDE)
        var scale = minOf(1.0, side.toDouble() / width, side.toDouble() / height)
        val pixels = width.toDouble() * height * scale * scale
        if (pixels > MAX_PIXELS) scale *= Math.sqrt(MAX_PIXELS / pixels)
        return maxOf(MIN_SIDE, (width * scale).toInt()) to maxOf(MIN_SIDE, (height * scale).toInt())
    }
}

object FileNaming {
    /** Safe file-name stem: letters, digits, dot, dash and underscore only, at most 48 characters. */
    fun sanitize(name: String): String {
        val s = name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_', '.', '-')
        return s.take(48).trim('_', '.', '-').ifEmpty { "shader" }
    }

    fun imageName(projectName: String, config: ExportConfig, nowMillis: Long): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(nowMillis))
        return "${sanitize(projectName)}_${config.width}x${config.height}_$stamp.${config.format.extension}"
    }

    fun animationName(projectName: String, width: Int, height: Int, extension: String, nowMillis: Long): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date(nowMillis))
        return "${sanitize(projectName)}_${width}x${height}_$stamp.$extension"
    }

    fun sourceName(projectName: String, extension: String): String = "${sanitize(projectName)}.$extension"
}
