package com.shaderart.studio.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.renderer.RenderSession
import com.shaderart.studio.core.renderer.RenderStats
import com.shaderart.studio.ui.theme.CodeFont

/**
 * Hosts the live GL view. The [RenderSession] owns the renderer and survives configuration changes;
 * this composable only owns the view, and pauses/resumes it with the lifecycle so the GPU is idle
 * whenever the app is not visible.
 */
@Composable
fun ShaderCanvas(
    session: RenderSession,
    quality: Float,
    onPinch: (Float) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val pinch = rememberUpdatedState(onPinch)
    val view = remember(session) {
        com.shaderart.studio.core.renderer.ShaderSurfaceView(context).also { it.attach(session.renderer) }
    }

    DisposableEffect(view, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> view.onResume()
                Lifecycle.Event.ON_PAUSE -> view.onPause()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        // The composition may start while the activity is already resumed: resume now.
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) view.onResume()
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            view.onPause()
            if (session.renderer.surface === view) session.renderer.surface = null
        }
    }

    AndroidView(
        factory = { view },
        modifier = modifier,
        update = {
            it.setQuality(quality)
            it.onPinch = { f -> pinch.value(f) }
        },
    )
}

/** Compact performance read-out drawn over the preview. Every number comes from the real renderer. */
@Composable
fun PerformanceOverlay(stats: RenderStats, capabilities: ShaderCapabilities?, quality: Float, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .background(Color(0xCC000000), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalArrangement = Arrangement.spacedBy(1.dp),
    ) {
        val style = MaterialTheme.typography.labelSmall.copy(fontFamily = CodeFont)
        Text("%.0f fps · %.1f ms".format(stats.fps, stats.frameMs), style = style)
        Text("${stats.width}×${stats.height} px · ${(quality * 100).toInt()}%", style = style)
        Text("t = %.2f s · frame ${stats.frame}".format(stats.timeSeconds), style = style)
        if (stats.contextCount > 1) Text("GL context recreated ×${stats.contextCount - 1}", style = style)
        if (capabilities != null) Text(capabilities.renderer.take(34), style = style, maxLines = 1)
    }
}
