package com.shaderart.studio.core.shader

import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamType
import kotlin.math.abs

data class DeclaredUniform(val type: String, val name: String, val line: Int, val annotation: String?)

/**
 * Finds `uniform` declarations in GLSL and turns them into control metadata.
 *
 * Optional annotations, written in a trailing comment on the same line:
 *
 *     uniform float u_scale;   // @slider 0.2 6 1 "Scale"
 *     uniform int   u_steps;   // @slider 1 64 16 "Steps"
 *     uniform vec3  u_tint;    // @color 1 0.5 0.2 "Tint"
 *     uniform bool  u_invert;  // @toggle 0 "Invert"
 *
 * Without an annotation: float -> slider 0..4 (default 1), int -> slider 0..16 (default 4),
 * bool -> off, vec3 whose name contains "color"/"colour" -> colour picker. Other types
 * (vec2, vec4, matrices, samplers, arrays) get no control.
 */
object ShaderMetadataParser {
    val SYSTEM_UNIFORMS = setOf(
        "u_time", "u_resolution", "u_mouse", "u_deltaTime", "u_frame", "u_speed", "u_zoom",
        // v0.02
        "u_mousePx", "u_date", "u_audio", "u_beat", "u_gyro", "u_accel", "u_tilt",
        "u_touches", "u_touchCount", "u_pressure", "u_touchVel", "u_taps", "u_tapCount",
        "u_channel0", "u_channel1", "u_channel2", "u_channel3", "u_channelResolution",
    )

    private val DECL = Regex("""^\s*uniform\s+(?:(?:highp|mediump|lowp)\s+)?([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*(\[[^\]]*\])?\s*;(.*)$""")
    private val QUOTED = Regex("\"([^\"]{1,60})\"")

    fun declaredUniforms(source: String): List<DeclaredUniform> {
        val clean = blankBlockComments(source)
        val out = ArrayList<DeclaredUniform>()
        clean.split('\n').forEachIndexed { i, line ->
            val m = DECL.find(line) ?: return@forEachIndexed
            val rest = m.groupValues[4].trim()
            val annotation = if (rest.startsWith("//")) rest.removePrefix("//").trim() else null
            val isArray = m.groupValues[3].isNotEmpty()
            val type = if (isArray) m.groupValues[1] + "[]" else m.groupValues[1]
            out += DeclaredUniform(type, m.groupValues[2], i + 1, annotation)
        }
        return out
    }

    fun declaredNames(source: String): Set<String> = declaredUniforms(source).map { it.name }.toSet()

    fun toParamDefs(declared: List<DeclaredUniform>): List<ParamDef> {
        val out = ArrayList<ParamDef>()
        for (d in declared) {
            if (d.name in SYSTEM_UNIFORMS) continue
            parseOne(d)?.let { out += it }
        }
        return out
    }

    fun parseOne(d: DeclaredUniform): ParamDef? {
        val ann = d.annotation
        val label = ann?.let { QUOTED.find(it)?.groupValues?.get(1) } ?: prettify(d.name)
        val nums = ann?.let { a ->
            a.substringAfter("@", "").split(Regex("\\s+")).drop(1)
                .map { it.trim('"') }.mapNotNull { it.toFloatOrNull() }.filter { it.isFinite() }
        } ?: emptyList()
        val tag = ann?.let { Regex("@(slider|color|toggle)").find(it)?.groupValues?.get(1) }
        return when (d.type) {
            "float" -> {
                var min = 0f; var max = 4f; var def = 1f
                if (tag == "slider" && nums.size >= 3 && nums[0] < nums[1]) { min = nums[0]; max = nums[1]; def = nums[2].coerceIn(min, max) }
                ParamDef(d.name, label, d.name, ParamType.FLOAT, listOf(def), min, max, niceStep(min, max), "", "Custom")
            }
            "int" -> {
                var min = 0f; var max = 16f; var def = 4f
                if (tag == "slider" && nums.size >= 3 && nums[0] < nums[1]) {
                    min = Math.floor(nums[0].toDouble()).toFloat(); max = Math.ceil(nums[1].toDouble()).toFloat()
                    def = Math.round(nums[2]).toFloat().coerceIn(min, max)
                }
                ParamDef(d.name, label, d.name, ParamType.INT, listOf(def), min, max, 1f, "", "Custom")
            }
            "bool" -> {
                val def = if (tag == "toggle" && nums.isNotEmpty() && nums[0] >= 0.5f) 1f else 0f
                ParamDef(d.name, label, d.name, ParamType.BOOL, listOf(def), 0f, 1f, 1f, "", "Custom")
            }
            "vec3" -> {
                val lower = d.name.lowercase()
                if (tag == "color" || lower.contains("color") || lower.contains("colour")) {
                    val rgb = if (tag == "color" && nums.size >= 3) nums.take(3).map { it.coerceIn(0f, 1f) } else listOf(1f, 1f, 1f)
                    ParamDef(d.name, label, d.name, ParamType.COLOR, rgb, 0f, 1f, 0.01f, "", "Custom")
                } else null
            }
            else -> null
        }
    }

    /** Keeps existing definitions (and thus their stored values) and appends newly discovered ones. */
    fun merge(existing: List<ParamDef>, parsed: List<ParamDef>): List<ParamDef> {
        val have = existing.map { it.uniform }.toSet()
        return existing + parsed.filter { it.uniform !in have }
    }

    private fun niceStep(min: Float, max: Float): Float {
        val span = abs(max - min)
        return when {
            span <= 1f -> 0.005f
            span <= 10f -> 0.01f
            span <= 100f -> 0.1f
            else -> 1f
        }
    }

    fun prettify(name: String): String {
        val base = name.removePrefix("u_").removePrefix("u")
        val spaced = base.replace('_', ' ').replace(Regex("([a-z0-9])([A-Z])"), "$1 $2").trim()
        return if (spaced.isEmpty()) name else spaced.split(' ').joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
    }

    /** Replaces block comments by spaces (keeping newlines) so commented-out uniforms are ignored. */
    internal fun blankBlockComments(source: String): String {
        val sb = StringBuilder(source.length)
        var i = 0
        var inBlock = false
        while (i < source.length) {
            val c = source[i]
            if (inBlock) {
                if (c == '*' && i + 1 < source.length && source[i + 1] == '/') { inBlock = false; sb.append("  "); i += 2; continue }
                sb.append(if (c == '\n') '\n' else ' ')
                i++
            } else if (c == '/' && i + 1 < source.length && source[i + 1] == '*') {
                inBlock = true; sb.append("  "); i += 2
            } else {
                sb.append(c); i++
            }
        }
        return sb.toString()
    }
}
