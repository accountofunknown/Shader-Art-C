package com.shaderart.studio.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/** The app UI is monochrome on pure black (AMOLED). Status colours are the only exception. */
object ShaderArtColors {
    val Black = Color(0xFF000000)
    val NearBlack = Color(0xFF080808)
    val Charcoal = Color(0xFF121212)
    val Graphite = Color(0xFF1C1C1C)
    val Border = Color(0xFF333333)
    val TextSecondary = Color(0xFF9E9E9E)
    val Disabled = Color(0xFF5A5A5A)

    // Functional status colours (errors, success): never decorative.
    val Error = Color(0xFFFF6B6B)
    val Warning = Color(0xFFFFC857)
    val Success = Color(0xFF6FCF97)
}

private val AmoledScheme = darkColorScheme(
    primary = Color.White,
    onPrimary = Color.Black,
    primaryContainer = ShaderArtColors.Graphite,
    onPrimaryContainer = Color.White,
    secondary = Color(0xFFD0D0D0),
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF2A2A2A),
    onSecondaryContainer = Color.White,
    tertiary = Color(0xFFB0B0B0),
    onTertiary = Color.Black,
    background = ShaderArtColors.Black,
    onBackground = Color.White,
    surface = ShaderArtColors.Black,
    onSurface = Color.White,
    surfaceVariant = ShaderArtColors.Graphite,
    onSurfaceVariant = ShaderArtColors.TextSecondary,
    surfaceTint = Color.Transparent,
    surfaceContainerLowest = ShaderArtColors.Black,
    surfaceContainerLow = ShaderArtColors.NearBlack,
    surfaceContainer = ShaderArtColors.Charcoal,
    surfaceContainerHigh = ShaderArtColors.Graphite,
    surfaceContainerHighest = Color(0xFF242424),
    outline = ShaderArtColors.Border,
    outlineVariant = Color(0xFF242424),
    error = ShaderArtColors.Error,
    onError = Color.Black,
    inverseSurface = Color.White,
    inverseOnSurface = Color.Black,
)

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium),
    titleSmall = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    bodyLarge = TextStyle(fontSize = 15.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    bodySmall = TextStyle(fontSize = 12.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Medium),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium),
    labelSmall = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Medium),
)

val CodeFont = FontFamily.Monospace

@Composable
fun ShaderArtTheme(content: @Composable () -> Unit) {
    // The AMOLED dark theme is the only theme in this version, regardless of the system setting.
    @Suppress("UNUSED_VARIABLE")
    val systemDark = isSystemInDarkTheme()
    MaterialTheme(colorScheme = AmoledScheme, typography = AppTypography, content = content)
}
