package com.shaderart.studio.ui.components

import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.feature.codeeditor.GlslTokenizer
import com.shaderart.studio.feature.codeeditor.LineUtil
import com.shaderart.studio.feature.codeeditor.TokenKind
import com.shaderart.studio.feature.studio.ScrollRequest
import com.shaderart.studio.ui.theme.CodeFont
import com.shaderart.studio.ui.theme.ShaderArtColors

/**
 * Syntax colours are a documented exception to the monochrome UI: they carry meaning (token kinds),
 * and code is unreadable without them. Everything else in the editor is black, white and grey.
 */
private object SyntaxColors {
    val Keyword = Color(0xFFFF7B72)
    val Type = Color(0xFF79C0FF)
    val Builtin = Color(0xFFD2A8FF)
    val Number = Color(0xFFFFA657)
    val Preprocessor = Color(0xFF7EE787)
    val Comment = Color(0xFF6E7681)
    val MatchBg = Color(0x55FFFFFF)
    val CurrentMatchBg = Color(0xAAFFFFFF)
    val ErrorBg = Color(0x33FF6B6B)
    val WarningBg = Color(0x22FFC857)
}

private val EditorTextStyle = TextStyle(fontFamily = CodeFont, fontSize = 13.sp, lineHeight = 18.sp, color = Color.White)

private class GlslHighlighter(
    private val matches: List<Int>,
    private val matchLength: Int,
    private val currentMatch: Int,
    private val lineSeverity: Map<Int, Severity>,
) : VisualTransformation {
    private var lastText: String? = null
    private var lastResult: AnnotatedString? = null

    override fun filter(text: AnnotatedString): TransformedText {
        val src = text.text
        if (src == lastText) return TransformedText(lastResult!!, OffsetMapping.Identity)
        val result = highlight(src)
        lastText = src
        lastResult = result
        return TransformedText(result, OffsetMapping.Identity)
    }

    private fun highlight(src: String): AnnotatedString = buildAnnotatedString {
        append(src)
        for (t in GlslTokenizer.tokenize(src)) {
            val style = when (t.kind) {
                TokenKind.COMMENT -> SpanStyle(color = SyntaxColors.Comment)
                TokenKind.KEYWORD -> SpanStyle(color = SyntaxColors.Keyword, fontWeight = FontWeight.Medium)
                TokenKind.TYPE -> SpanStyle(color = SyntaxColors.Type)
                TokenKind.BUILTIN -> SpanStyle(color = SyntaxColors.Builtin)
                TokenKind.NUMBER -> SpanStyle(color = SyntaxColors.Number)
                TokenKind.PREPROCESSOR -> SpanStyle(color = SyntaxColors.Preprocessor)
            }
            addStyle(style, t.start.coerceIn(0, src.length), t.end.coerceIn(0, src.length))
        }
        if (lineSeverity.isNotEmpty()) {
            var line = 1
            var start = 0
            while (start <= src.length) {
                val nl = src.indexOf('\n', start)
                val end = if (nl < 0) src.length else nl
                lineSeverity[line]?.let { sev ->
                    if (end > start) addStyle(SpanStyle(background = if (sev == Severity.ERROR) SyntaxColors.ErrorBg else SyntaxColors.WarningBg), start, end)
                }
                if (nl < 0) break
                start = nl + 1
                line++
            }
        }
        matches.forEachIndexed { i, s ->
            val e = (s + matchLength).coerceAtMost(src.length)
            if (s in 0 until e) addStyle(SpanStyle(background = if (i == currentMatch) SyntaxColors.CurrentMatchBg else SyntaxColors.MatchBg, color = if (i == currentMatch) Color.Black else Color.Unspecified), s, e)
        }
    }
}

/**
 * Code editor: monospace text with syntax highlighting, a line-number gutter and error-line marking.
 * Lines never wrap (the field scrolls sideways), so gutter numbers always line up with the text.
 */
@Composable
fun CodeEditor(
    value: TextFieldValue,
    onValueChange: (TextFieldValue) -> Unit,
    lineSeverity: Map<Int, Severity>,
    matches: List<Int>,
    matchLength: Int,
    currentMatch: Int,
    scrollRequest: ScrollRequest?,
    modifier: Modifier = Modifier,
    readOnly: Boolean = false,
) {
    val density = LocalDensity.current
    val lineHeightPx = with(density) { 18.sp.toPx() }
    val vScroll = rememberScrollState()
    val hScroll = rememberScrollState()
    var viewportW by remember { mutableIntStateOf(0) }
    var viewportH by remember { mutableIntStateOf(0) }

    val lineCount = remember(value.text) { LineUtil.lineCount(value.text) }
    val digits = lineCount.toString().length.coerceAtLeast(2)
    val gutterWidth = (digits * 9 + 20).dp

    val highlighter = remember(matches, matchLength, currentMatch, lineSeverity) {
        GlslHighlighter(matches, matchLength, currentMatch, lineSeverity)
    }

    val gutterText = remember(lineCount, lineSeverity) {
        buildAnnotatedString {
            for (i in 1..lineCount) {
                val sev = lineSeverity[i]
                if (sev == null) append(i.toString())
                else withStyle(SpanStyle(color = if (sev == Severity.ERROR) ShaderArtColors.Error else ShaderArtColors.Warning, fontWeight = FontWeight.Bold)) { append(i.toString()) }
                if (i < lineCount) append('\n')
            }
        }
    }

    LaunchedEffect(scrollRequest?.id) {
        val req = scrollRequest ?: return@LaunchedEffect
        val target = ((req.line - 1) * lineHeightPx - viewportH / 3f).toInt().coerceAtLeast(0)
        vScroll.animateScrollTo(target, tween(220))
    }

    Box(
        modifier = modifier
            .background(Color.Black)
            .clipToBounds()
            .onSizeChanged { viewportW = it.width; viewportH = it.height },
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .verticalScroll(vScroll),
        ) {
            Text(
                text = gutterText,
                style = EditorTextStyle.copy(color = ShaderArtColors.TextSecondary, textAlign = TextAlign.End),
                softWrap = false,
                modifier = Modifier
                    .width(gutterWidth)
                    .background(ShaderArtColors.NearBlack)
                    .padding(end = 8.dp),
            )
            // Inside horizontalScroll the text gets unbounded width, so lines never wrap and the gutter stays aligned.
            Box(Modifier.weight(1f).horizontalScroll(hScroll)) {
                val minW = with(density) { (viewportW).toDp() } - gutterWidth
                val minH = with(density) { viewportH.toDp() }
                BasicTextField(
                    value = value,
                    onValueChange = onValueChange,
                    readOnly = readOnly,
                    textStyle = EditorTextStyle,
                    cursorBrush = SolidColor(Color.White),
                    visualTransformation = highlighter,
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.None,
                        autoCorrectEnabled = false,
                        keyboardType = KeyboardType.Ascii,
                        imeAction = ImeAction.None,
                    ),
                    modifier = Modifier
                        .defaultMinSize(minWidth = minW.coerceAtLeast(0.dp), minHeight = minH.coerceAtLeast(0.dp))
                        .padding(start = 8.dp, end = 24.dp),
                )
            }
        }
    }
}
