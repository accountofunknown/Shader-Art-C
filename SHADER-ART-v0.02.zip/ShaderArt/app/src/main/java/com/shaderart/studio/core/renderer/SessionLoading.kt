package com.shaderart.studio.core.renderer

import android.graphics.Bitmap
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.pipeline.PassSource

/** Sends a whole saved project (all passes, post stack, timeline, parameters) to a render session. */
fun RenderSession.loadProject(project: ShaderProject, textureLoader: (String) -> Bitmap?, postSourceLoader: (String) -> String?) {
    setTimeline(project.timeline)
    updateParams(project.params, ParamLogic.normalize(project.params, project.values))
    setZoom(project.render.zoom)
    setSpeed(project.animation.speed)
    submitProject(
        project.vertexSource, project.fragmentSource, project.imageChannels,
        project.buffers.map { PassSource(it.id, it.fragmentSource, it.channels) },
        project.postStack, textureLoader, postSourceLoader,
    )
}

/** Sends a built-in preset (with its default parameter values) to a render session. */
fun RenderSession.loadPreset(preset: Preset, postSourceLoader: (String) -> String?) {
    setTimeline(com.shaderart.studio.core.model.Timeline())
    updateParams(preset.params, ParamLogic.defaults(preset.params))
    submitProject(
        preset.vertexSource, preset.fragmentSource, preset.imageChannels,
        preset.buffers.map { PassSource(it.id, it.fragmentSource, it.channels) },
        emptyList(), { null }, postSourceLoader,
    )
}
