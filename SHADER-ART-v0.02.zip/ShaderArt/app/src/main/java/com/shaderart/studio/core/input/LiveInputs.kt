package com.shaderart.studio.core.input

import com.shaderart.studio.core.audio.AudioFeatures

/**
 * Everything that changes from outside the shader while it runs: sound, motion sensors and touches.
 * Immutable; hosts publish a new instance whenever something changes.
 */
class LiveInputs(
    val audio: AudioFeatures = AudioFeatures.SILENCE,
    /** Rotation rate in rad/s around x, y, z (device axes). */
    val gyro: FloatArray = FloatArray(3),
    /** Gravity-removed acceleration in m/s^2 (device axes). */
    val accel: FloatArray = FloatArray(3),
    /** Tilt from gravity: x = left/right, y = forward/back, each -1..1 (0 = flat). */
    val tilt: FloatArray = FloatArray(2),
    val touch: TouchSnapshot = TouchSnapshot.EMPTY,
) {
    companion object {
        val NONE = LiveInputs()
    }
}
