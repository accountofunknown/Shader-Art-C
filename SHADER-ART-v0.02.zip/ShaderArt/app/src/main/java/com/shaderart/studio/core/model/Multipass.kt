package com.shaderart.studio.core.model

/** One render pass of a multipass project. [IMAGE] is the final on-screen pass; A-D are offscreen buffers. */
enum class PassId(val label: String, val key: String) {
    IMAGE("Image", "image"),
    A("Buffer A", "a"),
    B("Buffer B", "b"),
    C("Buffer C", "c"),
    D("Buffer D", "d");

    val isBuffer: Boolean get() = this != IMAGE

    companion object {
        val BUFFERS: List<PassId> = listOf(A, B, C, D)
        fun parseKey(s: String): PassId? = entries.firstOrNull { it.key == s.trim().lowercase() }
    }
}

enum class ChannelKind { NONE, BUFFER, TEXTURE, NOISE, AUDIO }

/**
 * What a `u_channelN` sampler is bound to. Serialized as a short string:
 * "none", "buffer:a", "texture:<name>", "noise", "audio".
 */
data class ChannelBinding(val kind: ChannelKind = ChannelKind.NONE, val ref: String = "") {
    fun toText(): String = when (kind) {
        ChannelKind.NONE -> "none"
        ChannelKind.BUFFER -> "buffer:$ref"
        ChannelKind.TEXTURE -> "texture:$ref"
        ChannelKind.NOISE -> "noise"
        ChannelKind.AUDIO -> "audio"
    }

    val bufferPass: PassId? get() = if (kind == ChannelKind.BUFFER) PassId.parseKey(ref) else null

    companion object {
        val NONE = ChannelBinding()
        val NOISE = ChannelBinding(ChannelKind.NOISE)
        val AUDIO = ChannelBinding(ChannelKind.AUDIO)
        fun buffer(p: PassId) = ChannelBinding(ChannelKind.BUFFER, p.key)
        fun texture(name: String) = ChannelBinding(ChannelKind.TEXTURE, name)

        /** Returns null when [s] is not a valid binding text. */
        fun parse(s: String): ChannelBinding? {
            val t = s.trim()
            return when {
                t == "none" -> NONE
                t == "noise" -> NOISE
                t == "audio" -> AUDIO
                t.startsWith("buffer:") -> PassId.parseKey(t.removePrefix("buffer:"))?.takeIf { it.isBuffer }?.let { buffer(it) }
                t.startsWith("texture:") -> t.removePrefix("texture:").takeIf { TextureNames.isValid(it) }?.let { texture(it) }
                else -> null
            }
        }

        fun noneChannels(): List<ChannelBinding> = List(CHANNEL_COUNT) { NONE }
        const val CHANNEL_COUNT = 4
    }
}

/** A buffer pass (A-D): its own fragment shader and four channel inputs. */
data class PassSpec(
    val id: PassId,
    val fragmentSource: String,
    val channels: List<ChannelBinding> = ChannelBinding.noneChannels(),
) {
    init {
        require(id.isBuffer) { "PassSpec is for buffers only" }
        require(channels.size == ChannelBinding.CHANNEL_COUNT) { "Exactly ${ChannelBinding.CHANNEL_COUNT} channels" }
    }
}

/** Metadata of an imported texture. Pixels live in a PNG file next to the project. */
data class TextureAsset(val name: String, val width: Int, val height: Int)

object TextureNames {
    private val RE = Regex("^[a-z0-9_]{1,24}$")
    fun isValid(name: String): Boolean = RE.matches(name)

    /** Turns a file name such as "My Photo.JPG" into a valid, unused texture name. */
    fun fromFileName(fileName: String, taken: Set<String>): String {
        val base = fileName.substringBeforeLast('.').lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(20).ifEmpty { "texture" }
        if (base !in taken) return base
        var i = 2
        while ("${base}_$i" in taken) i++
        return "${base}_$i"
    }
}

object MultipassLimits {
    const val MAX_TEXTURES = 8
    const val MAX_TEXTURE_SIDE = 2048
    const val MAX_TEXTURE_BYTES = 1_500_000
    const val MAX_TRACKS = 32
    const val MAX_KEYS = 64
    const val MAX_POST = 12
}

/** Rules that make a multipass configuration safe to compile and render. */
object MultipassCheck {
    /** Problems with channel bindings: unknown textures, buffers that do not exist. Empty = fine. */
    fun check(buffers: List<PassSpec>, imageChannels: List<ChannelBinding>, textures: List<TextureAsset>): List<String> {
        val problems = ArrayList<String>()
        if (imageChannels.size != ChannelBinding.CHANNEL_COUNT) problems += "Image channels must have exactly 4 entries"
        val ids = buffers.map { it.id }
        if (ids.size != ids.toSet().size) problems += "A buffer appears twice"
        val texNames = textures.map { it.name }.toSet()
        if (textures.size != texNames.size) problems += "Two textures share a name"
        if (textures.size > MultipassLimits.MAX_TEXTURES) problems += "Too many textures (max ${MultipassLimits.MAX_TEXTURES})"
        fun checkChannels(owner: String, ch: List<ChannelBinding>) {
            for ((i, c) in ch.withIndex()) {
                when (c.kind) {
                    ChannelKind.BUFFER -> {
                        val p = c.bufferPass
                        if (p == null || p !in ids) problems += "$owner channel $i uses ${c.ref.uppercase()}, which does not exist"
                    }
                    ChannelKind.TEXTURE -> if (c.ref !in texNames) problems += "$owner channel $i uses missing texture '${c.ref}'"
                    else -> Unit
                }
            }
        }
        checkChannels("Image", imageChannels)
        for (b in buffers) checkChannels(b.id.label, b.channels)
        return problems
    }
}
