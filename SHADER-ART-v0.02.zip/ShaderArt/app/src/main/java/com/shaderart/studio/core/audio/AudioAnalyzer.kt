package com.shaderart.studio.core.audio

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** What shaders receive: smoothed band levels (0..1), a beat pulse, a 512-bin spectrum and a 512-sample waveform. */
class AudioFeatures(
    val level: Float,
    val bass: Float,
    val mid: Float,
    val treble: Float,
    val beat: Float,
    /** 512 values 0..1, low to high frequency (logarithmic-ish compression is applied by the analyzer). */
    val spectrum: FloatArray,
    /** 512 values 0..1, 0.5 = silence. */
    val waveform: FloatArray,
) {
    /** The 512x2 single-channel texture: row 0 spectrum, row 1 waveform, as unsigned bytes. */
    fun toTextureBytes(): ByteArray {
        val out = ByteArray(TEXTURE_WIDTH * 2)
        for (i in 0 until TEXTURE_WIDTH) {
            out[i] = (spectrum[i].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
            out[TEXTURE_WIDTH + i] = (waveform[i].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
        }
        return out
    }

    companion object {
        const val TEXTURE_WIDTH = 512
        val SILENCE = AudioFeatures(0f, 0f, 0f, 0f, 0f, FloatArray(TEXTURE_WIDTH), FloatArray(TEXTURE_WIDTH) { 0.5f })
    }
}

/**
 * Turns PCM samples into [AudioFeatures]. Call [push] with whatever chunks arrive (any size, mono, -1..1);
 * [features] returns the latest analysis. Not thread-safe: use from one thread, hand results over via an immutable
 * [AudioFeatures] object.
 */
class AudioAnalyzer(private val sampleRate: Int, private val fftSize: Int = 1024) {
    private val fft = Fft(fftSize)
    private val window = fft.hann()
    private val ring = FloatArray(fftSize)
    private var ringPos = 0
    private var filled = 0
    private val re = FloatArray(fftSize)
    private val im = FloatArray(fftSize)

    private val spectrum = FloatArray(AudioFeatures.TEXTURE_WIDTH)
    private var bass = 0f
    private var mid = 0f
    private var treble = 0f
    private var level = 0f
    private var beat = 0f
    private var bassAvg = 0f
    private var sinceBeat = 1f
    private var latest: AudioFeatures = AudioFeatures.SILENCE

    fun reset() {
        ring.fill(0f); ringPos = 0; filled = 0
        spectrum.fill(0f); bass = 0f; mid = 0f; treble = 0f; level = 0f; beat = 0f; bassAvg = 0f; sinceBeat = 1f
        latest = AudioFeatures.SILENCE
    }

    fun features(): AudioFeatures = latest

    /** Feeds [count] samples and re-analyzes if a full window is available. Returns the latest features. */
    fun push(samples: FloatArray, count: Int = samples.size): AudioFeatures {
        val n = min(count, samples.size)
        for (i in 0 until n) {
            ring[ringPos] = samples[i].coerceIn(-1f, 1f)
            ringPos = (ringPos + 1) % fftSize
        }
        filled = min(fftSize, filled + n)
        if (filled >= fftSize && n > 0) analyze(n.toFloat() / sampleRate)
        return latest
    }

    /** 8-bit unsigned PCM as delivered by android.media.audiofx.Visualizer (128 = silence). */
    fun pushUnsignedBytes(bytes: ByteArray, count: Int = bytes.size): AudioFeatures {
        val n = min(count, bytes.size)
        val f = FloatArray(n) { ((bytes[it].toInt() and 0xFF) - 128) / 128f }
        return push(f, n)
    }

    /** Stereo/mono 16-bit PCM from AudioRecord. */
    fun pushShorts(pcm: ShortArray, count: Int = pcm.size): AudioFeatures {
        val n = min(count, pcm.size)
        val f = FloatArray(n) { pcm[it] / 32768f }
        return push(f, n)
    }

    private fun analyze(dt: Float) {
        // Latest fftSize samples in time order, windowed.
        var peak = 0f
        var sumSq = 0f
        for (i in 0 until fftSize) {
            val s = ring[(ringPos + i) % fftSize]
            re[i] = s * window[i]
            im[i] = 0f
            peak = max(peak, abs(s))
            sumSq += s * s
        }
        val rms = kotlin.math.sqrt(sumSq / fftSize)
        fft.transform(re, im)

        val bins = fftSize / 2
        val hzPerBin = sampleRate.toFloat() / fftSize
        // Spectrum: 512 outputs spaced on a gentle log curve between ~30 Hz and Nyquist.
        val fMin = 30f
        val fMax = sampleRate / 2f
        val norm = 4f / fftSize // amplitude of a full-scale sine ~ 1 after the Hann window
        for (o in 0 until AudioFeatures.TEXTURE_WIDTH) {
            val f0 = fMin * Math.pow((fMax / fMin).toDouble(), o.toDouble() / AudioFeatures.TEXTURE_WIDTH).toFloat()
            val f1 = fMin * Math.pow((fMax / fMin).toDouble(), (o + 1).toDouble() / AudioFeatures.TEXTURE_WIDTH).toFloat()
            val b0 = (f0 / hzPerBin).toInt().coerceIn(1, bins - 1)
            val b1 = max(b0 + 1, (f1 / hzPerBin).toInt()).coerceAtMost(bins)
            var m = 0f
            for (b in b0 until b1) m = max(m, Fft.magnitude(re[b], im[b]))
            val db = 20f * log10(m * norm + 1e-6f) // 0 dB = full scale
            val target = ((db + 70f) / 70f).coerceIn(0f, 1f)
            // fast attack, slow release
            val k = if (target > spectrum[o]) 0.6f else 0.18f
            spectrum[o] += (target - spectrum[o]) * k
        }

        val bt = bandEnergy(20f, 250f, hzPerBin, bins, norm)
        val mt = bandEnergy(250f, 2000f, hzPerBin, bins, norm)
        val tt = bandEnergy(2000f, min(10000f, fMax), hzPerBin, bins, norm)
        val a = 1f - exp(-dt * 40f) // attack
        val r = 1f - exp(-dt * 8f) // release
        bass += (bt - bass) * (if (bt > bass) a.coerceAtLeast(0.3f) else r.coerceAtLeast(0.1f))
        mid += (mt - mid) * (if (mt > mid) a.coerceAtLeast(0.3f) else r.coerceAtLeast(0.1f))
        treble += (tt - treble) * (if (tt > treble) a.coerceAtLeast(0.3f) else r.coerceAtLeast(0.1f))
        val lt = (rms * 3f).coerceIn(0f, 1f)
        level += (lt - level) * (if (lt > level) 0.5f else 0.12f)

        // Beat: bass jumps clearly above its running average.
        sinceBeat += dt
        bassAvg += (bt - bassAvg) * (1f - exp(-dt * 2.5f)).coerceIn(0.02f, 0.5f)
        if (bt > bassAvg * 1.35f + 0.08f && sinceBeat > 0.18f && bt > 0.25f) {
            beat = 1f
            sinceBeat = 0f
        } else {
            beat *= exp(-dt * 6f)
        }

        val wave = FloatArray(AudioFeatures.TEXTURE_WIDTH)
        for (i in wave.indices) {
            val src = i * fftSize / AudioFeatures.TEXTURE_WIDTH
            wave[i] = (0.5f + 0.5f * ring[(ringPos + src) % fftSize]).coerceIn(0f, 1f)
        }
        latest = AudioFeatures(level, bass.coerceIn(0f, 1f), mid.coerceIn(0f, 1f), treble.coerceIn(0f, 1f), beat.coerceIn(0f, 1f), spectrum.copyOf(), wave)
    }

    private fun bandEnergy(f0: Float, f1: Float, hzPerBin: Float, bins: Int, norm: Float): Float {
        val b0 = (f0 / hzPerBin).toInt().coerceIn(1, bins - 1)
        val b1 = max(b0 + 1, (f1 / hzPerBin).toInt()).coerceAtMost(bins)
        var m = 0f
        for (b in b0 until b1) m = max(m, Fft.magnitude(re[b], im[b]))
        val db = 20f * log10(m * norm + 1e-6f)
        return ((db + 60f) / 60f).coerceIn(0f, 1f)
    }
}

/**
 * A deterministic stand-in for music: a 120 BPM beat with a kick, hats and a slow melody sweep. Needs no permission,
 * and is what exports use, so exported audio-reactive files are reproducible.
 */
object DemoAudio {
    const val BPM = 120f

    fun featuresAt(t: Float): AudioFeatures {
        val beatPhase = ((t * BPM / 60f) % 1f + 1f) % 1f
        val kick = exp(-beatPhase * 7f)
        val offPhase = (((t * BPM / 60f) + 0.5f) % 1f + 1f) % 1f
        val hat = exp(-offPhase * 22f)
        val sweep = 0.5f + 0.5f * kotlin.math.sin(t * 0.9f)
        val bass = (0.15f + 0.85f * kick).coerceIn(0f, 1f)
        val mid = (0.25f + 0.35f * sweep + 0.15f * kick).coerceIn(0f, 1f)
        val treble = (0.1f + 0.7f * hat + 0.1f * sweep).coerceIn(0f, 1f)
        val beat = if (beatPhase < 0.25f) exp(-beatPhase * 12f) else 0f
        val spec = FloatArray(AudioFeatures.TEXTURE_WIDTH)
        val melodyCentre = 0.25f + 0.5f * sweep
        for (i in spec.indices) {
            val x = i / (AudioFeatures.TEXTURE_WIDTH - 1f)
            val low = bass * exp(-x * 9f)
            val melody = 0.55f * mid * exp(-((x - melodyCentre) * (x - melodyCentre)) * 220f)
            val high = treble * 0.5f * x * x
            spec[i] = (low + melody + high).coerceIn(0f, 1f)
        }
        val wave = FloatArray(AudioFeatures.TEXTURE_WIDTH) { i ->
            val x = i / 512f
            (0.5f + 0.4f * (bass * kotlin.math.sin((x * 6f + t * 4f) * 6.2832f) * 0.6f + mid * kotlin.math.sin(x * 40f + t) * 0.4f)).coerceIn(0f, 1f)
        }
        return AudioFeatures((bass * 0.5f + mid * 0.3f + treble * 0.2f).coerceIn(0f, 1f), bass, mid, treble, beat, spec, wave)
    }
}
