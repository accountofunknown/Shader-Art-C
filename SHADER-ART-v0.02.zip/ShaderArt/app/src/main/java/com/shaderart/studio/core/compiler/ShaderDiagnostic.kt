package com.shaderart.studio.core.compiler

enum class ShaderStage(val label: String) {
    VERTEX("Vertex"), FRAGMENT("Fragment"), LINK("Link"), CONTEXT("Context"), UNIFORM("Uniforms")
}

enum class Severity { ERROR, WARNING, INFO }

/** One message from the real GL compiler/linker (or from the app's own checks, stage CONTEXT/UNIFORM). */
data class ShaderDiagnostic(
    val stage: ShaderStage,
    val severity: Severity,
    /** 1-based line in the source of [stage], if the driver reported one. */
    val line: Int?,
    val message: String,
    val raw: String = message,
    /** Which pass the message belongs to: null = the Image pass, otherwise "Buffer A", "Post: Bloom", ... */
    val pass: String? = null,
)

/**
 * Parses driver info logs into diagnostics. Drivers disagree about the format, so several styles are
 * recognised. Whatever cannot be parsed is kept verbatim as a line-less message: logs are never dropped.
 */
object GlslLogParser {
    // ERROR: 0:12: 'foo' : undeclared identifier        (Qualcomm, ARM Mali, ANGLE, glslang)
    private val STYLE_COLON = Regex("""^\s*(ERROR|WARNING)\s*:\s*(\d+):(\d+)(?::(\d+))?\s*:?\s*(.*)$""", RegexOption.IGNORE_CASE)

    // 0:12(5): error: syntax error                       (Mesa)
    private val STYLE_MESA = Regex("""^\s*\d+:(\d+)\(\d+\)\s*:\s*(error|warning)\s*:\s*(.*)$""", RegexOption.IGNORE_CASE)

    // 0(12) : error C1008: undefined variable "x"        (NVIDIA)
    private val STYLE_NVIDIA = Regex("""^\s*\d+\((\d+)\)\s*:\s*(error|warning)\s*[A-Za-z0-9]*\s*:\s*(.*)$""", RegexOption.IGNORE_CASE)

    fun parse(stage: ShaderStage, log: String): List<ShaderDiagnostic> {
        val out = ArrayList<ShaderDiagnostic>()
        for (rawLine in log.split('\n')) {
            val line = rawLine.trim { it <= ' ' || it == '\u0000' }
            if (line.isEmpty()) continue
            val colon = STYLE_COLON.find(line)
            if (colon != null) {
                val g = colon.groupValues
                out += ShaderDiagnostic(stage, sev(g[1]), g[3].toIntOrNull(), g[5].ifBlank { line }, line)
                continue
            }
            val mesa = STYLE_MESA.find(line)
            if (mesa != null) {
                val g = mesa.groupValues
                out += ShaderDiagnostic(stage, sev(g[2]), g[1].toIntOrNull(), g[3].ifBlank { line }, line)
                continue
            }
            val nvidia = STYLE_NVIDIA.find(line)
            if (nvidia != null) {
                val g = nvidia.groupValues
                out += ShaderDiagnostic(stage, sev(g[2]), g[1].toIntOrNull(), g[3].ifBlank { line }, line)
                continue
            }
            val lower = line.lowercase()
            val severity = when {
                lower.contains("error") || lower.contains("fail") -> Severity.ERROR
                lower.contains("warning") -> Severity.WARNING
                else -> Severity.INFO
            }
            out += ShaderDiagnostic(stage, severity, null, line, line)
        }
        return out
    }

    private fun sev(s: String) = if (s.equals("warning", ignoreCase = true)) Severity.WARNING else Severity.ERROR
}
