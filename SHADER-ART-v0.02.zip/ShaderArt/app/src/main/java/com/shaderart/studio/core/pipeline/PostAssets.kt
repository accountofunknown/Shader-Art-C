package com.shaderart.studio.core.pipeline

import android.content.res.AssetManager
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap

/** Loads post-effect pass shaders from assets/post/. Results are cached; a missing file gives null. */
class PostAssets(private val assets: AssetManager) {
    private val cache = ConcurrentHashMap<String, String>()

    fun load(pass: String): String? {
        cache[pass]?.let { return it }
        if (!pass.matches(Regex("[a-z0-9_]{1,32}"))) return null
        return try {
            assets.open("post/$pass.frag").bufferedReader(Charsets.UTF_8).use { it.readText() }.also { cache[pass] = it }
        } catch (e: IOException) {
            null
        }
    }
}
