package com.shaderart.studio.core.json

/** Thrown for malformed JSON or a value of the wrong shape. */
class JsonException(message: String) : Exception(message)

/**
 * A small, strict JSON reader/writer used for project manifests and the preset catalog.
 *
 * Strictness matters because imported `.shaderart` archives are untrusted: nesting depth is capped,
 * duplicate keys are rejected, NaN/Infinity are rejected and trailing garbage is rejected.
 * Parsed values are: Map<String, Any?>, List<Any?>, String, Long, Double, Boolean or null.
 */
object MiniJson {
    const val MAX_DEPTH = 32

    fun parse(text: String): Any? {
        val p = Parser(text)
        p.skipWs()
        val v = p.value(0)
        p.skipWs()
        if (p.pos != text.length) p.fail("Unexpected content after JSON value")
        return v
    }

    fun parseObject(text: String): Map<String, Any?> = parse(text).asObject("document")

    fun write(value: Any?, pretty: Boolean = false): String {
        val sb = StringBuilder()
        writeValue(sb, value, pretty, 0)
        return sb.toString()
    }

    private fun writeValue(sb: StringBuilder, v: Any?, pretty: Boolean, level: Int) {
        when (v) {
            null -> sb.append("null")
            is String -> writeString(sb, v)
            is Boolean -> sb.append(if (v) "true" else "false")
            is Int, is Long, is Short, is Byte -> sb.append(v.toString())
            is Float -> {
                if (!v.isFinite()) throw JsonException("Cannot write non-finite number")
                sb.append(v.toString())
            }
            is Double -> {
                if (!v.isFinite()) throw JsonException("Cannot write non-finite number")
                sb.append(v.toString())
            }
            is Map<*, *> -> {
                if (v.isEmpty()) { sb.append("{}"); return }
                sb.append('{')
                var first = true
                for ((k, value) in v) {
                    if (!first) sb.append(',')
                    first = false
                    newline(sb, pretty, level + 1)
                    writeString(sb, k.toString())
                    sb.append(if (pretty) ": " else ":")
                    writeValue(sb, value, pretty, level + 1)
                }
                newline(sb, pretty, level)
                sb.append('}')
            }
            is Iterable<*> -> {
                val items = v.toList()
                if (items.isEmpty()) { sb.append("[]"); return }
                sb.append('[')
                var first = true
                for (item in items) {
                    if (!first) sb.append(',')
                    first = false
                    newline(sb, pretty, level + 1)
                    writeValue(sb, item, pretty, level + 1)
                }
                newline(sb, pretty, level)
                sb.append(']')
            }
            else -> throw JsonException("Unsupported value type ${v::class.java.simpleName}")
        }
    }

    private fun newline(sb: StringBuilder, pretty: Boolean, level: Int) {
        if (!pretty) return
        sb.append('\n')
        repeat(level) { sb.append("  ") }
    }

    private fun writeString(sb: StringBuilder, s: String) {
        sb.append('"')
        for (c in s) {
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c < ' ' -> sb.append("\\u").append(String.format("%04x", c.code))
                else -> sb.append(c)
            }
        }
        sb.append('"')
    }

    private class Parser(val s: String) {
        var pos = 0

        fun fail(msg: String): Nothing = throw JsonException("$msg at offset $pos")

        fun skipWs() {
            while (pos < s.length) {
                val c = s[pos]
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t') pos++ else break
            }
        }

        fun value(depth: Int): Any? {
            if (depth > MAX_DEPTH) fail("Nesting too deep")
            if (pos >= s.length) fail("Unexpected end of input")
            val c = s[pos]
            return when {
                c == '{' -> obj(depth)
                c == '[' -> arr(depth)
                c == '"' -> str()
                c == 't' -> literal("true", true)
                c == 'f' -> literal("false", false)
                c == 'n' -> literal("null", null)
                c == '-' || c in '0'..'9' -> num()
                else -> fail("Unexpected character '$c'")
            }
        }

        private fun literal(word: String, v: Any?): Any? {
            if (!s.startsWith(word, pos)) fail("Invalid literal")
            pos += word.length
            return v
        }

        private fun obj(depth: Int): Map<String, Any?> {
            pos++ // {
            val m = LinkedHashMap<String, Any?>()
            skipWs()
            if (pos < s.length && s[pos] == '}') { pos++; return m }
            while (true) {
                skipWs()
                if (pos >= s.length || s[pos] != '"') fail("Expected string key")
                val k = str()
                skipWs()
                if (pos >= s.length || s[pos] != ':') fail("Expected ':'")
                pos++
                skipWs()
                val v = value(depth + 1)
                if (m.containsKey(k)) fail("Duplicate key '$k'")
                m[k] = v
                skipWs()
                if (pos >= s.length) fail("Unterminated object")
                val c = s[pos++]
                if (c == ',') continue
                if (c == '}') return m
                pos--
                fail("Expected ',' or '}'")
            }
        }

        private fun arr(depth: Int): List<Any?> {
            pos++ // [
            val l = ArrayList<Any?>()
            skipWs()
            if (pos < s.length && s[pos] == ']') { pos++; return l }
            while (true) {
                skipWs()
                l.add(value(depth + 1))
                skipWs()
                if (pos >= s.length) fail("Unterminated array")
                val c = s[pos++]
                if (c == ',') continue
                if (c == ']') return l
                pos--
                fail("Expected ',' or ']'")
            }
        }

        private fun str(): String {
            pos++ // opening quote
            val sb = StringBuilder()
            while (true) {
                if (pos >= s.length) fail("Unterminated string")
                val c = s[pos++]
                when {
                    c == '"' -> return sb.toString()
                    c == '\\' -> {
                        if (pos >= s.length) fail("Unterminated escape")
                        when (val e = s[pos++]) {
                            '"' -> sb.append('"')
                            '\\' -> sb.append('\\')
                            '/' -> sb.append('/')
                            'b' -> sb.append('\b')
                            'f' -> sb.append('\u000C')
                            'n' -> sb.append('\n')
                            'r' -> sb.append('\r')
                            't' -> sb.append('\t')
                            'u' -> {
                                if (pos + 4 > s.length) fail("Truncated unicode escape")
                                val hex = s.substring(pos, pos + 4)
                                val code = hex.toIntOrNull(16) ?: fail("Invalid unicode escape")
                                sb.append(code.toChar())
                                pos += 4
                            }
                            else -> fail("Invalid escape '\\$e'")
                        }
                    }
                    c < ' ' -> fail("Control character in string")
                    else -> sb.append(c)
                }
            }
        }

        private fun num(): Any {
            val start = pos
            if (s[pos] == '-') pos++
            if (pos >= s.length) fail("Invalid number")
            if (s[pos] == '0') {
                pos++
            } else if (s[pos] in '1'..'9') {
                while (pos < s.length && s[pos] in '0'..'9') pos++
            } else fail("Invalid number")
            var isInt = true
            if (pos < s.length && s[pos] == '.') {
                isInt = false
                pos++
                val d = pos
                while (pos < s.length && s[pos] in '0'..'9') pos++
                if (pos == d) fail("Invalid number")
            }
            if (pos < s.length && (s[pos] == 'e' || s[pos] == 'E')) {
                isInt = false
                pos++
                if (pos < s.length && (s[pos] == '+' || s[pos] == '-')) pos++
                val d = pos
                while (pos < s.length && s[pos] in '0'..'9') pos++
                if (pos == d) fail("Invalid number")
            }
            val token = s.substring(start, pos)
            if (isInt) {
                token.toLongOrNull()?.let { return it }
            }
            val d = token.toDouble()
            if (!d.isFinite()) fail("Number out of range")
            return d
        }
    }
}

// ---- Typed accessors (throw JsonException with a readable message) ----

@Suppress("UNCHECKED_CAST")
fun Any?.asObject(what: String): Map<String, Any?> {
    if (this !is Map<*, *>) throw JsonException("'$what' must be an object")
    for (k in this.keys) if (k !is String) throw JsonException("'$what' has a non-string key")
    return this as Map<String, Any?>
}

fun Any?.asList(what: String): List<Any?> {
    if (this !is List<*>) throw JsonException("'$what' must be an array")
    return this
}

fun Any?.asFloat(what: String): Float {
    if (this !is Number) throw JsonException("'$what' must be a number")
    val f = this.toFloat()
    if (!f.isFinite()) throw JsonException("'$what' must be a finite number")
    return f
}

fun Map<String, Any?>.reqString(key: String): String =
    this[key] as? String ?: throw JsonException("Field '$key' must be a string")

fun Map<String, Any?>.optString(key: String): String? {
    val v = this[key] ?: return null
    return v as? String ?: throw JsonException("Field '$key' must be a string")
}

fun Map<String, Any?>.reqFloat(key: String): Float {
    if (!containsKey(key)) throw JsonException("Missing field '$key'")
    return this[key].asFloat(key)
}

fun Map<String, Any?>.optFloat(key: String, default: Float): Float =
    if (this[key] == null) default else this[key].asFloat(key)

fun Map<String, Any?>.reqLong(key: String): Long {
    val v = this[key] as? Number ?: throw JsonException("Field '$key' must be an integer")
    val d = v.toDouble()
    if (d != Math.floor(d) || Math.abs(d) > 9.0e15) throw JsonException("Field '$key' must be an integer")
    return v.toLong()
}

fun Map<String, Any?>.optBool(key: String, default: Boolean): Boolean {
    val v = this[key] ?: return default
    return v as? Boolean ?: throw JsonException("Field '$key' must be true or false")
}

fun Map<String, Any?>.optObject(key: String): Map<String, Any?>? = this[key]?.asObject(key)
