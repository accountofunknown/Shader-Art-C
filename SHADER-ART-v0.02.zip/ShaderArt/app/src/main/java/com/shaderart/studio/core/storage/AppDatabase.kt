package com.shaderart.studio.core.storage

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import com.shaderart.studio.core.model.ProjectType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Project metadata only. Shader sources and parameter values live in app-private files. */
@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val createdAt: Long,
    val modifiedAt: Long,
    val lastOpenedAt: Long,
    val favorite: Boolean,
    val presetOrigin: String?,
    val hasThumbnail: Boolean,
)

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects")
    fun observeAll(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun get(id: String): ProjectEntity?

    @Upsert
    suspend fun upsert(entity: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun delete(id: String)
}

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
}

class RoomProjectIndex(private val dao: ProjectDao) : ProjectIndex {
    override fun observeAll(): Flow<List<ProjectRow>> = dao.observeAll().map { list -> list.map { it.toRow() } }
    override suspend fun get(id: String): ProjectRow? = dao.get(id)?.toRow()
    override suspend fun upsert(row: ProjectRow) = dao.upsert(row.toEntity())
    override suspend fun delete(id: String) = dao.delete(id)

    private fun ProjectEntity.toRow() = ProjectRow(
        id, name, ProjectType.parse(type) ?: ProjectType.CODE, createdAt, modifiedAt, lastOpenedAt, favorite, presetOrigin, hasThumbnail,
    )

    private fun ProjectRow.toEntity() = ProjectEntity(
        id, name, type.name, createdAt, modifiedAt, lastOpenedAt, favorite, presetOrigin, hasThumbnail,
    )
}
