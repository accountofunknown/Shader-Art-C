package com.shaderart.studio.core.importing

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.json.asList
import com.shaderart.studio.core.json.asObject
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.security.ImportLimits

/** Result of converting a Shadertoy shader. [warnings] lists everything that could not be carried over. */
class ShadertoyResult(
    val name: String,
    val imageSource: String,
    val buffers: List<PassSpec>,
    val imageChannels: List<ChannelBinding>,
    val warnings: List<String>,
    val usesAudio: Boolean,
)

/**
 * Converts Shadertoy code (a plain `mainImage` function, or the JSON that Shadertoy exports) into SHADER ART passes.
 *
 * Supported: Image and Buffer A-D passes, Common code, buffer/noise/audio inputs, `iTime`, `iResolution`, `iMouse`,
 * `iFrame`, `iTimeDelta`, `iDate`, `iChannelN`, `iChannelResolution`.
 * Not supported (warned about): cubemaps, volumes, video/webcam, keyboard, sound shaders, picture textures
 * (pictures cannot be downloaded: the app has no internet access, so a noise texture is bound instead).
 *
 * Only shaders you have the right to use should be imported; many Shadertoy shaders carry licences with conditions.
 */
object ShadertoyImporter {
    class ShadertoyException(message: String) : Exception(message)

    private val HEADER_DEFINES = """
        #define iTime u_time
        #define iResolution vec3(u_resolution, 1.0)
        #define iTimeDelta u_deltaTime
        #define iFrame u_frame
        #define iFrameRate (1.0 / max(u_deltaTime, 0.0001))
        #define iMouse u_mousePx
        #define iDate u_date
        #define iSampleRate 44100.0
        #define iChannel0 u_channel0
        #define iChannel1 u_channel1
        #define iChannel2 u_channel2
        #define iChannel3 u_channel3
        #define iChannelResolution u_channelResolution
        #define texture2D texture
    """.trimIndent()

    private val UNIFORMS = """
        precision highp float;
        precision highp int;
        precision highp sampler2D;
        out vec4 fragColor;
        uniform vec2 u_resolution;
        uniform float u_time;
        uniform float u_deltaTime;
        uniform int u_frame;
        uniform vec4 u_mousePx;
        uniform vec4 u_date;
        uniform sampler2D u_channel0;
        uniform sampler2D u_channel1;
        uniform sampler2D u_channel2;
        uniform sampler2D u_channel3;
        uniform vec3 u_channelResolution[4];
    """.trimIndent()

    /** Wraps one pass body (a `mainImage` function) into a complete ES 3.00 fragment shader. */
    fun wrap(code: String, common: String, isImage: Boolean): String {
        val sb = StringBuilder()
        sb.append("#version 300 es\n").append(UNIFORMS).append('\n').append(HEADER_DEFINES).append('\n')
        if (common.isNotBlank()) sb.append("// ---- Common ----\n").append(common.trim()).append('\n')
        sb.append("// ---- Shader ----\n").append(code.trim()).append('\n')
        sb.append("void main() {\n  vec4 c = vec4(0.0, 0.0, 0.0, 1.0);\n  mainImage(c, gl_FragCoord.xy);\n")
        sb.append(if (isImage) "  fragColor = vec4(c.rgb, 1.0);\n" else "  fragColor = c;\n").append("}\n")
        return sb.toString()
    }

    fun convert(text: String): ShadertoyResult {
        val t = text.trim()
        if (t.isEmpty()) throw ShadertoyException("Nothing to import: the text is empty.")
        if (t.toByteArray(Charsets.UTF_8).size > ImportLimits.MAX_SOURCE_BYTES * 3) throw ShadertoyException("The Shadertoy text is too large.")
        return if (t.startsWith("{") || t.startsWith("[")) fromJson(t) else fromCode(t)
    }

    private fun fromCode(code: String): ShadertoyResult {
        val warnings = ArrayList<String>()
        if (!Regex("""void\s+mainImage\s*\(""").containsMatchIn(code)) {
            throw ShadertoyException("This does not look like Shadertoy code: no 'void mainImage(out vec4 fragColor, in vec2 fragCoord)' function was found.")
        }
        val channelUse = (0..3).filter { Regex("""\biChannel$it\b""").containsMatchIn(code) }
        val channels = ChannelBinding.noneChannels().toMutableList()
        if (channelUse.isNotEmpty()) {
            warnings += "The code reads iChannel${channelUse.joinToString(", iChannel")}, but pasted code carries no information about what they were connected to. They are bound to a noise texture; change them under Inputs."
            for (c in channelUse) channels[c] = ChannelBinding.NOISE
        }
        if (Regex("""\bmainVR\b""").containsMatchIn(code)) warnings += "mainVR (VR output) is ignored."
        warnings += scanCode(code)
        return ShadertoyResult("Shadertoy import", wrap(code, "", true), emptyList(), channels, warnings, false)
    }

    private fun scanCode(code: String): List<String> {
        val w = ArrayList<String>()
        if (Regex("""\bsamplerCube\b""").containsMatchIn(code)) w += "This shader uses a cube map (samplerCube), which is not supported. It will not compile."
        if (Regex("""\bsampler3D\b""").containsMatchIn(code)) w += "This shader uses a 3D texture (sampler3D), which is not supported. It will not compile."
        if (Regex("""\biChannelTime\b""").containsMatchIn(code)) w += "iChannelTime is not supported."
        return w
    }

    @Suppress("UNCHECKED_CAST")
    private fun fromJson(text: String): ShadertoyResult {
        val root = try { MiniJson.parse(text) } catch (e: JsonException) { throw ShadertoyException("The JSON could not be read: ${e.message}") }
        var obj: Map<String, Any?> = when (root) {
            is List<*> -> (root.firstOrNull() ?: throw ShadertoyException("The JSON list is empty.")).asObject("shader")
            else -> root.asObject("shader")
        }
        (obj["Shader"] as? Map<String, Any?>)?.let { obj = it }
        val info = obj["info"] as? Map<String, Any?>
        val name = (info?.get("name") as? String)?.trim()?.take(ImportLimits.MAX_NAME_LENGTH)?.ifEmpty { null } ?: "Shadertoy import"
        val passes = (obj["renderpass"] ?: throw ShadertoyException("The JSON has no 'renderpass' list.")).asList("renderpass")
        if (passes.isEmpty()) throw ShadertoyException("The shader has no render passes.")

        val warnings = ArrayList<String>()
        class RawPass(val type: String, val name: String, val code: String, val inputs: List<Map<String, Any?>>, val outputId: String?)
        val raw = passes.mapIndexed { i, p ->
            val m = p.asObject("renderpass[$i]")
            val ins = (m["inputs"] as? List<*>)?.mapNotNull { it as? Map<String, Any?> } ?: emptyList()
            val outId = ((m["outputs"] as? List<*>)?.firstOrNull() as? Map<String, Any?>)?.get("id")?.toString()
            RawPass((m["type"] as? String ?: "image").lowercase(), m["name"] as? String ?: "", m["code"] as? String ?: "", ins, outId)
        }
        val image = raw.firstOrNull { it.type == "image" } ?: throw ShadertoyException("The shader has no Image pass.")
        val common = raw.filter { it.type == "common" }.joinToString("\n") { it.code }
        for (p in raw) {
            when (p.type) {
                "sound" -> warnings += "The Sound pass is ignored (sound shaders are not supported)."
                "cubemap" -> warnings += "A Cubemap pass is ignored (not supported)."
            }
        }

        // Buffer passes in order, mapped to A-D by name when it says so, otherwise in order.
        val bufferRaw = raw.filter { it.type == "buffer" }
        if (bufferRaw.size > 4) throw ShadertoyException("The shader has ${bufferRaw.size} buffers; SHADER ART supports 4 (A-D).")
        val assigned = HashMap<RawPass, PassId>()
        val used = HashSet<PassId>()
        for (p in bufferRaw) {
            val byName = Regex("""buffer\s*([a-d])""", RegexOption.IGNORE_CASE).find(p.name)?.groupValues?.get(1)?.let { PassId.parseKey(it) }
            if (byName != null && byName !in used) { assigned[p] = byName; used += byName }
        }
        for (p in bufferRaw) if (p !in assigned) {
            val free = PassId.BUFFERS.first { it !in used }
            assigned[p] = free; used += free
        }
        // Shadertoy identifies a buffer input by the output id of the pass (257.. for Buffer A..D).
        val idToPass = HashMap<String, PassId>()
        for (p in bufferRaw) p.outputId?.let { idToPass[it] = assigned[p]!! }
        for ((i, id) in PassId.BUFFERS.withIndex()) idToPass.putIfAbsent((257 + i).toString(), id)

        var usesAudio = false
        fun bindings(p: RawPass, label: String): List<ChannelBinding> {
            val ch = ChannelBinding.noneChannels().toMutableList()
            for (inp in p.inputs) {
                val idx = (inp["channel"] as? Number)?.toInt() ?: continue
                if (idx !in 0..3) continue
                val ctype = (inp["ctype"] as? String ?: "").lowercase()
                val inputId = inp["id"]?.toString()
                val src = inp["src"] as? String ?: ""
                when (ctype) {
                    "buffer" -> {
                        val target = idToPass[inputId] ?: Regex("""buffer0?(\d)""").find(src)?.groupValues?.get(1)?.toIntOrNull()?.let { PassId.BUFFERS.getOrNull(it) }
                        if (target != null && target in used) ch[idx] = ChannelBinding.buffer(target)
                        else warnings += "$label channel $idx refers to a buffer that does not exist."
                    }
                    "texture" -> { ch[idx] = ChannelBinding.NOISE; warnings += "$label channel $idx used a picture texture. It cannot be downloaded (no internet), so noise is bound instead; import your own image under Inputs." }
                    "mic", "music", "musicstream" -> { ch[idx] = ChannelBinding.AUDIO; usesAudio = true }
                    "cubemap" -> warnings += "$label channel $idx uses a cube map, which is not supported. The shader will probably not compile."
                    "volume" -> warnings += "$label channel $idx uses a 3D volume texture, which is not supported."
                    "webcam", "video" -> warnings += "$label channel $idx used a video or webcam. Not supported; left empty."
                    "keyboard" -> warnings += "$label channel $idx used the keyboard texture. Not supported; left empty."
                    else -> warnings += "$label channel $idx has an unknown input type '${ctype.take(20)}'. Left empty."
                }
            }
            return ch
        }

        val buffers = bufferRaw.map { p ->
            val id = assigned[p]!!
            warnings += scanCode(p.code).map { "${id.label}: $it" }
            PassSpec(id, wrap(p.code, common, false), bindings(p, id.label))
        }.sortedBy { it.id.ordinal }
        warnings += scanCode(image.code + common).map { "Image: $it" }
        val imageChannels = bindings(image, "Image")
        return ShadertoyResult(name, wrap(image.code, common, true), buffers, imageChannels, warnings.distinct(), usesAudio)
    }
}
