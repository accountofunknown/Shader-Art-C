package com.shaderart.studio.core.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** In-place radix-2 FFT. [size] must be a power of two. Reusable and allocation-free after construction. */
class Fft(val size: Int) {
    private val cosT = FloatArray(size / 2)
    private val sinT = FloatArray(size / 2)
    private val rev = IntArray(size)

    init {
        require(size >= 2 && (size and (size - 1)) == 0) { "FFT size must be a power of two" }
        for (i in 0 until size / 2) {
            val a = -2.0 * PI * i / size
            cosT[i] = cos(a).toFloat()
            sinT[i] = sin(a).toFloat()
        }
        val bits = Integer.numberOfTrailingZeros(size)
        for (i in 0 until size) rev[i] = Integer.reverse(i) ushr (32 - bits)
    }

    fun transform(re: FloatArray, im: FloatArray) {
        require(re.size == size && im.size == size)
        for (i in 0 until size) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= size) {
            val half = len / 2
            val step = size / len
            var i = 0
            while (i < size) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]
                    val wi = sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                i += len
            }
            len *= 2
        }
    }

    /** Hann window of this transform's size. */
    fun hann(): FloatArray = FloatArray(size) { (0.5 - 0.5 * cos(2.0 * PI * it / (size - 1))).toFloat() }

    companion object {
        fun magnitude(re: Float, im: Float): Float = sqrt(re * re + im * im)
    }
}
