package com.shaderart.studio.core.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.gpu.GpuInfo
import com.shaderart.studio.core.pipeline.PassPipeline
import java.io.File
import java.io.IOException
import java.util.concurrent.CancellationException

/**
 * Records a scene to an H.264 MP4 file (video only, no sound track).
 *
 * Frames are drawn with fixed time steps (frame i at i / fps), straight into the MediaCodec encoder's input surface, so the
 * video is exactly as smooth as asked regardless of how fast the GPU is. Must run on a thread of its own, like all GPU work.
 */
class VideoExporter {

    /** Returns an explanation if this device cannot encode [config], or null if it probably can. */
    fun checkSupport(config: VideoConfig): String? {
        val w = AnimationLimits.even(config.width)
        val h = AnimationLimits.even(config.height)
        val format = format(w, h, config)
        val name = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(format)
        return if (name == null) "This device has no H.264 encoder for ${w}×$h at ${config.fps} fps. Try a smaller size or a lower frame rate." else null
    }

    fun export(
        scene: SceneData,
        config: VideoConfig,
        outFile: File,
        onProgress: (Float) -> Unit,
        isCancelled: () -> Boolean,
    ) {
        val w = AnimationLimits.even(config.width)
        val h = AnimationLimits.even(config.height)
        checkSupport(config)?.let { throw ExportException(it) }

        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var inputSurface: Surface? = null
        var egl: EglCore? = null
        var pipeline: PassPipeline? = null
        var finished = false
        try {
            encoder = try {
                MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            } catch (e: IOException) {
                throw ExportException("The video encoder could not be started: ${e.message}")
            }
            try {
                encoder.configure(format(w, h, config), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            } catch (e: IllegalArgumentException) {
                throw ExportException("The video encoder rejected these settings (${w}×$h, ${config.fps} fps). Try a smaller size.")
            } catch (e: MediaCodec.CodecException) {
                throw ExportException("The video encoder could not be configured (${e.diagnosticInfo}). Try a smaller size.")
            }
            inputSurface = encoder.createInputSurface()
            encoder.start()
            muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            egl = EglCore.createWindow(inputSurface)
            val caps = GpuInfo.query()
            if (w > caps.maxViewportWidth || h > caps.maxViewportHeight) throw ExportException("This GPU cannot render ${w}×$h frames.")

            val build = PassPipeline.build(scene.spec())
            pipeline = build.pipeline ?: throw ExportException(
                "The shader does not compile: " + (build.diagnostics.firstOrNull { it.severity == Severity.ERROR }?.message ?: "unknown error"),
                build.diagnostics,
            )

            val state = DrainState()
            val usesAudio = scene.spec().usesAudio
            val dt = 1f / config.fps
            val frames = config.frames
            for (i in 0 until frames) {
                if (isCancelled()) throw CancellationException("Export cancelled")
                val t = config.startTime + i * dt * scene.speed
                pipeline.render(scene.frame(t, dt, i, w, h, usesAudio), scene.params, scene.valuesAt(t), 0, w, h, postStack = scene.post)
                egl.setPresentationTime(i * 1_000_000_000L / config.fps)
                if (!egl.swapBuffers()) throw ExportException("The video frame could not be delivered to the encoder.")
                drain(encoder, muxer, state, endOfStream = false)
                onProgress(0.97f * (i + 1) / frames)
            }
            encoder.signalEndOfInputStream()
            drain(encoder, muxer, state, endOfStream = true)
            if (!state.muxerStarted) throw ExportException("The encoder produced no video data.")
            muxer.stop()
            finished = true
            onProgress(1f)
        } catch (e: MediaCodec.CodecException) {
            throw ExportException("The video encoder failed (${e.diagnosticInfo}). Try a smaller size or lower frame rate.")
        } catch (e: IllegalStateException) {
            throw ExportException("The video encoder stopped unexpectedly: ${e.message}")
        } finally {
            try { pipeline?.release() } catch (_: Throwable) { }
            try { egl?.release() } catch (_: Throwable) { }
            try { inputSurface?.release() } catch (_: Throwable) { }
            try { encoder?.stop() } catch (_: Throwable) { }
            try { encoder?.release() } catch (_: Throwable) { }
            try { muxer?.release() } catch (_: Throwable) { }
            if (!finished) outFile.delete()
        }
    }

    private class DrainState {
        var track = -1
        var muxerStarted = false
    }

    private fun drain(encoder: MediaCodec, muxer: MediaMuxer, state: DrainState, endOfStream: Boolean) {
        val info = MediaCodec.BufferInfo()
        var idleRounds = 0
        while (true) {
            val index = encoder.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!endOfStream) return
                    if (++idleRounds > 500) throw ExportException("The video encoder did not finish (timeout).")
                }
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (state.muxerStarted) throw ExportException("The encoder changed its format unexpectedly.")
                    state.track = muxer.addTrack(encoder.outputFormat)
                    muxer.start()
                    state.muxerStarted = true
                }
                index >= 0 -> {
                    idleRounds = 0
                    val buf = encoder.getOutputBuffer(index) ?: throw ExportException("The encoder returned an empty buffer.")
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0) {
                        if (!state.muxerStarted) throw ExportException("The encoder produced data before its format was known.")
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer.writeSampleData(state.track, buf, info)
                    }
                    encoder.releaseOutputBuffer(index, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }

    private fun format(w: Int, h: Int, c: VideoConfig): MediaFormat =
        MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, c.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, c.fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
}
