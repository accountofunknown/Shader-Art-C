package com.shaderart.studio.feature.codeeditor

enum class TokenKind { COMMENT, KEYWORD, TYPE, BUILTIN, NUMBER, PREPROCESSOR }

data class Token(val start: Int, val end: Int, val kind: TokenKind)

object GlslVocabulary {
    val KEYWORDS = setOf(
        "const", "uniform", "in", "out", "inout", "layout", "flat", "smooth", "centroid", "highp", "mediump", "lowp",
        "precision", "if", "else", "for", "while", "do", "switch", "case", "default", "break", "continue", "return",
        "discard", "struct", "true", "false", "invariant",
    )
    val TYPES = setOf(
        "void", "bool", "int", "uint", "float", "vec2", "vec3", "vec4", "ivec2", "ivec3", "ivec4", "uvec2", "uvec3", "uvec4",
        "bvec2", "bvec3", "bvec4", "mat2", "mat3", "mat4", "mat2x3", "mat2x4", "mat3x2", "mat3x4", "mat4x2", "mat4x3",
        "sampler2D", "sampler3D", "samplerCube", "sampler2DShadow", "isampler2D", "usampler2D",
    )
    val FUNCTIONS = setOf(
        "radians", "degrees", "sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh", "asinh", "acosh", "atanh",
        "pow", "exp", "log", "exp2", "log2", "sqrt", "inversesqrt", "abs", "sign", "floor", "trunc", "round", "roundEven",
        "ceil", "fract", "mod", "modf", "min", "max", "clamp", "mix", "step", "smoothstep", "isnan", "isinf",
        "length", "distance", "dot", "cross", "normalize", "faceforward", "reflect", "refract",
        "matrixCompMult", "outerProduct", "transpose", "determinant", "inverse",
        "lessThan", "lessThanEqual", "greaterThan", "greaterThanEqual", "equal", "notEqual", "any", "all", "not",
        "texture", "textureLod", "textureSize", "texelFetch", "textureGrad", "textureProj",
        "dFdx", "dFdy", "fwidth", "floatBitsToInt", "intBitsToFloat", "packHalf2x16", "unpackHalf2x16",
    )
    val BUILTIN_VARS = setOf("gl_FragCoord", "gl_FragDepth", "gl_VertexID", "gl_InstanceID", "gl_Position", "gl_PointSize", "gl_PointCoord", "gl_FrontFacing")
    val UNIFORMS = listOf("u_time", "u_resolution", "u_mouse", "u_deltaTime", "u_frame", "u_speed", "u_zoom")
    val BUILTINS: Set<String> = FUNCTIONS + BUILTIN_VARS

    /** Multi-line completions offered as snippets (inserted verbatim). */
    val SNIPPETS = mapOf(
        "for" to "for (int i = 0; i < 8; i++) {\n  \n}",
        "main" to "void main() {\n  \n}",
    )
}

/** Splits GLSL into highlight tokens. Anything not listed (identifiers, operators) is left unstyled. */
object GlslTokenizer {
    fun tokenize(text: String): List<Token> {
        val out = ArrayList<Token>()
        val n = text.length
        var i = 0
        var lineStart = true
        while (i < n) {
            val c = text[i]
            when {
                c == '\n' -> { lineStart = true; i++ }
                c == ' ' || c == '\t' || c == '\r' -> i++
                c == '/' && i + 1 < n && text[i + 1] == '/' -> {
                    val e = text.indexOf('\n', i).let { if (it < 0) n else it }
                    out += Token(i, e, TokenKind.COMMENT); i = e; lineStart = false
                }
                c == '/' && i + 1 < n && text[i + 1] == '*' -> {
                    val close = text.indexOf("*/", i + 2)
                    val e = if (close < 0) n else close + 2
                    out += Token(i, e, TokenKind.COMMENT); i = e; lineStart = false
                }
                c == '#' && lineStart -> {
                    val e = text.indexOf('\n', i).let { if (it < 0) n else it }
                    out += Token(i, e, TokenKind.PREPROCESSOR); i = e
                }
                c.isDigit() || (c == '.' && i + 1 < n && text[i + 1].isDigit()) -> {
                    var j = i
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '.' ||
                            ((text[j] == '+' || text[j] == '-') && (text[j - 1] == 'e' || text[j - 1] == 'E') && !text.startsWith("0x", i)))) j++
                    out += Token(i, j, TokenKind.NUMBER); i = j; lineStart = false
                }
                c.isLetter() || c == '_' -> {
                    var j = i
                    while (j < n && (text[j].isLetterOrDigit() || text[j] == '_')) j++
                    val w = text.substring(i, j)
                    val kind = when {
                        w in GlslVocabulary.KEYWORDS -> TokenKind.KEYWORD
                        w in GlslVocabulary.TYPES -> TokenKind.TYPE
                        w in GlslVocabulary.BUILTINS -> TokenKind.BUILTIN
                        else -> null
                    }
                    if (kind != null) out += Token(i, j, kind)
                    i = j; lineStart = false
                }
                else -> { i++; lineStart = false }
            }
        }
        return out
    }
}
