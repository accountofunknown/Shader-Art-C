package com.shaderart.studio.core.export

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.GLES30
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.gpu.GpuException
import com.shaderart.studio.core.gpu.GpuInfo
import com.shaderart.studio.core.gpu.RenderTarget
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.pipeline.PassPipeline
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CancellationException
import kotlin.math.ceil

/** An export failed. The message is safe to show to the user; [diagnostics] holds compiler output if relevant. */
class ExportException(message: String, val diagnostics: List<ShaderDiagnostic> = emptyList()) : Exception(message)

class OffscreenRequest(
    val scene: SceneData,
    val width: Int,
    val height: Int,
    val timeSeconds: Float,
    val alphaMode: AlphaMode = AlphaMode.OPAQUE,
) {
    /** Convenience for a plain single-pass shader. */
    constructor(
        vertexSource: String,
        fragmentSource: String,
        params: List<ParamDef>,
        values: Map<String, List<Float>>,
        width: Int,
        height: Int,
        timeSeconds: Float,
        zoom: Float = 1f,
        speed: Float = 1f,
    ) : this(SceneData.simple(vertexSource, fragmentSource, params, values, zoom, speed), width, height, timeSeconds)
}

/**
 * Renders a scene at an exact pixel size using its own EGL context and a pbuffer, so it never touches the on-screen
 * renderer. Must always be called from the same single thread.
 *
 * Plain single-pass shaders are rendered in tiles with the scissor test while the viewport stays full-size, so
 * gl_FragCoord and u_resolution describe the whole image and each tile is pixel-identical to one full render. Tiling keeps
 * each GPU job short, which avoids driver watchdog resets on heavy shaders. Projects with buffers, inputs or post effects
 * cannot be tiled (every pass needs the full frame), so they render in one go; feedback projects first run simulated
 * warm-up frames so the picture matches what the preview shows at that time.
 */
class OffscreenRenderer {

    fun render(
        request: OffscreenRequest,
        onProgress: (Float) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ): Bitmap {
        val env = EglCore.createPbuffer()
        try {
            val caps = GpuInfo.query()
            checkSize(request.width, request.height, caps)
            return renderInContext(request, onProgress, isCancelled)
        } finally {
            env.release()
        }
    }

    /**
     * Renders [frames] frames at [fps] and hands each to [onFrame] as top-down ARGB ints (reused array: copy if you keep it).
     * Frame i is drawn at shader time `startTime + i / fps * speed`, with fixed time steps, so the result never depends on how
     * fast the GPU is.
     */
    fun renderSequence(
        scene: SceneData,
        width: Int,
        height: Int,
        frames: Int,
        fps: Float,
        startTime: Float,
        onFrame: (Int, IntArray) -> Unit,
        onProgress: (Float) -> Unit = {},
        isCancelled: () -> Boolean = { false },
    ) {
        val env = EglCore.createPbuffer()
        try {
            checkSize(width, height, GpuInfo.query())
            val spec = scene.spec()
            val pipeline = buildOrThrow(scene)
            val target = RenderTarget(width, height)
            try {
                try { target.create() } catch (e: GpuException) { throw ExportException(e.message ?: "Could not create the render target.") }
                val pixels = IntArray(width * height)
                val dt = 1f / fps
                for (i in 0 until frames) {
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    val t = startTime + i * dt * scene.speed
                    drawFrame(pipeline, scene, target, t, dt, i, width, height, spec.usesAudio, false)
                    GLES30.glFinish()
                    checkErrors()
                    readBack(width, height, AlphaMode.OPAQUE) { yTop, rows, band -> System.arraycopy(band, 0, pixels, yTop * width, rows * width) }
                    onFrame(i, pixels)
                    onProgress((i + 1) / frames.toFloat())
                }
            } finally {
                target.release()
                pipeline.release()
            }
        } finally {
            env.release()
        }
    }

    /** Largest image side this GPU can render, determined with a real context. Null if no context could be created. */
    fun queryMaxSide(): Int? {
        val env = try { EglCore.createPbuffer() } catch (e: ExportException) { return null }
        return try { GpuInfo.query().maxImageSide } finally { env.release() }
    }

    private fun checkSize(w: Int, h: Int, caps: ShaderCapabilities) {
        if (w > caps.maxImageSide || h > caps.maxImageSide) {
            throw ExportException("This GPU supports images up to ${caps.maxImageSide} px per side (requested ${w}×$h).")
        }
    }

    private fun buildOrThrow(scene: SceneData): PassPipeline {
        val build = PassPipeline.build(scene.spec())
        return build.pipeline ?: throw ExportException(
            "The shader does not compile: " + (build.diagnostics.firstOrNull { it.severity == Severity.ERROR }?.let { d -> (d.pass?.let { "$it: " } ?: "") + d.message } ?: "unknown error"),
            build.diagnostics,
        )
    }

    private fun drawFrame(
        pipeline: PassPipeline, scene: SceneData, target: RenderTarget, t: Float, dt: Float, index: Int,
        w: Int, h: Int, audio: Boolean, transparent: Boolean, scissor: IntArray? = null,
    ) {
        pipeline.render(scene.frame(t, dt, index, w, h, audio), scene.params, scene.valuesAt(t), target.framebufferId, w, h, clearAlpha = transparent, postStack = scene.post, scissor = scissor)
    }

    private fun renderInContext(r: OffscreenRequest, onProgress: (Float) -> Unit, isCancelled: () -> Boolean): Bitmap {
        val w = r.width
        val h = r.height
        val scene = r.scene
        val spec = scene.spec()
        val transparent = r.alphaMode != AlphaMode.OPAQUE
        val pipeline = buildOrThrow(scene)
        val target = RenderTarget(w, h)
        try {
            try { target.create() } catch (e: GpuException) { throw ExportException(e.message ?: "Could not create the render target.") }
            target.bind()
            GLES30.glViewport(0, 0, w, h)

            val bands = bandCount(w, h)
            var totalSteps: Int
            var done = 0
            if (spec.isSimple) {
                val tilesX = (w + TILE - 1) / TILE
                val tilesY = (h + TILE - 1) / TILE
                totalSteps = tilesX * tilesY + bands
                if (transparent) {
                    GLES30.glClearColor(0f, 0f, 0f, 0f)
                    GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
                }
                for (ty in 0 until tilesY) for (tx in 0 until tilesX) {
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    val x = tx * TILE
                    val y = ty * TILE
                    drawFrame(pipeline, scene, target, r.timeSeconds, 1f / 60f, 0, w, h, false, false, intArrayOf(x, y, minOf(TILE, w - x), minOf(TILE, h - y)))
                    GLES30.glFinish()
                    onProgress(++done / totalSteps.toFloat())
                }
            } else {
                val warm = if (spec.hasFeedback && r.timeSeconds > 0f) minOf(MAX_WARMUP_FRAMES, ceil(r.timeSeconds * 60f).toInt()) else 0
                totalSteps = warm + 1 + bands
                val dt = if (warm > 0) r.timeSeconds / warm else 1f / 60f
                for (i in 0 until warm) {
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    drawFrame(pipeline, scene, target, i * dt, dt, i, w, h, spec.usesAudio, false)
                    if (i % 4 == 3) GLES30.glFinish()
                    onProgress(++done / totalSteps.toFloat())
                }
                drawFrame(pipeline, scene, target, r.timeSeconds, dt, warm, w, h, spec.usesAudio, transparent)
                GLES30.glFinish()
                onProgress(++done / totalSteps.toFloat())
            }
            checkErrors()

            val bitmap = try {
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            } catch (e: OutOfMemoryError) {
                throw ExportException("Not enough memory for a ${w}×$h image. Choose a smaller size.")
            }
            bitmap.setHasAlpha(transparent)
            try {
                readBack(w, h, r.alphaMode) { yTop, rows, band ->
                    if (isCancelled()) throw CancellationException("Export cancelled")
                    bitmap.setPixels(band, 0, w, 0, yTop, w, rows)
                    onProgress(++done / totalSteps.toFloat())
                }
            } catch (t: Throwable) {
                bitmap.recycle()
                throw t
            }
            return bitmap
        } finally {
            target.release()
            pipeline.release()
        }
    }

    private fun bandRows(w: Int): Int = (BAND_BYTES / (w * 4)).coerceIn(1, 256)

    private fun bandCount(w: Int, h: Int): Int = (h + bandRows(w) - 1) / bandRows(w)

    /**
     * Reads the bound framebuffer in horizontal bands (bounded memory). [sink] receives top-down ARGB bands
     * (un-premultiplied, as Bitmap.setPixels expects): the band's first row, its row count and the pixels.
     */
    private fun readBack(w: Int, h: Int, alpha: AlphaMode, sink: (Int, Int, IntArray) -> Unit) {
        val rows = bandRows(w)
        val buffer = ByteBuffer.allocateDirect(w * rows * 4).order(ByteOrder.nativeOrder())
        val ints = buffer.asIntBuffer()
        val line = IntArray(w)
        val out = IntArray(w * rows)
        val littleEndian = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN
        var y0 = 0
        while (y0 < h) {
            val bh = minOf(rows, h - y0)
            buffer.clear()
            GLES30.glReadPixels(0, y0, w, bh, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, buffer)
            val err = GLES30.glGetError()
            if (err != GLES30.GL_NO_ERROR) throw ExportException("Reading pixels from the GPU failed (GL error 0x${Integer.toHexString(err)}).")
            // OpenGL rows run bottom-to-top; bitmap rows run top-to-bottom.
            for (r in 0 until bh) {
                ints.position((bh - 1 - r) * w)
                ints.get(line, 0, w)
                val base = r * w
                for (x in 0 until w) {
                    val v = line[x]
                    val rr: Int; val gg: Int; val bb: Int; val aa: Int
                    if (littleEndian) { rr = v and 0xFF; gg = (v ushr 8) and 0xFF; bb = (v ushr 16) and 0xFF; aa = (v ushr 24) and 0xFF }
                    else { rr = (v ushr 24) and 0xFF; gg = (v ushr 16) and 0xFF; bb = (v ushr 8) and 0xFF; aa = v and 0xFF }
                    out[base + x] = when (alpha) {
                        AlphaMode.OPAQUE -> (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
                        AlphaMode.SHADER -> (aa shl 24) or (rr shl 16) or (gg shl 8) or bb
                        AlphaMode.KEY_BLACK -> keyBlack(rr, gg, bb)
                    }
                }
            }
            sink(y0, bh, out)
            y0 += bh
        }
    }

    private fun checkErrors() {
        val err = GLES30.glGetError()
        if (err == GLES30.GL_NO_ERROR) return
        val egl = EGL14.eglGetError()
        if (err == GLES30.GL_OUT_OF_MEMORY) throw ExportException("The GPU ran out of memory while rendering.")
        if (egl == EGL14.EGL_CONTEXT_LOST) throw ExportException("The GPU context was lost while rendering. Try again.")
        throw ExportException("The GPU reported an error while rendering (GL error 0x${Integer.toHexString(err)}).")
    }

    companion object {
        private const val TILE = 512
        private const val BAND_BYTES = 4_000_000
        const val MAX_WARMUP_FRAMES = 900

        /** Alpha = brightest channel; colour divided by alpha, so compositing over black gives back the original picture. */
        internal fun keyBlack(r: Int, g: Int, b: Int): Int {
            val a = maxOf(r, maxOf(g, b))
            if (a == 0) return 0
            val rr = minOf(255, (r * 255 + a / 2) / a)
            val gg = minOf(255, (g * 255 + a / 2) / a)
            val bb = minOf(255, (b * 255 + a / 2) / a)
            return (a shl 24) or (rr shl 16) or (gg shl 8) or bb
        }
    }
}
