package com.shaderart.studio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.PerformanceOverlay
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.ScreenTitle
import com.shaderart.studio.ui.components.SectionLabel
import com.shaderart.studio.ui.components.ShaderCanvas
import com.shaderart.studio.ui.components.TextPromptDialog
import com.shaderart.studio.ui.theme.ShaderArtColors
import java.util.Locale

/** Title row of both studios: project name, save state, rename and save. */
@Composable
fun StudioHeader(vm: StudioViewModel, extraActions: @Composable () -> Unit = {}) {
    val ui = vm.ui
    var renaming by remember { mutableStateOf(false) }
    val state = when {
        ui.needsRun -> "Imported · not run"
        !ui.saved -> "Unsaved draft"
        ui.dirty -> "Unsaved changes"
        else -> "Saved"
    }
    ScreenTitle(
        title = ui.name.ifEmpty { "Untitled" },
        subtitle = "${if (ui.type == ProjectType.CODE) "Code" else "Preset"} · $state",
    ) {
        extraActions()
        SIconButton(R.drawable.ic_edit, "Rename project", { renaming = true })
        SIconButton(R.drawable.ic_save, "Save project", { vm.save() }, enabled = !ui.saved || ui.dirty)
    }
    if (renaming) {
        TextPromptDialog(
            title = "Rename project", initial = ui.name, confirmLabel = "Rename", maxLength = 80,
            onConfirm = { vm.rename(it); renaming = false },
            onDismiss = { renaming = false },
        )
    }
}

/** Live preview with play/pause and restart on top of it. */
@Composable
fun StudioPreview(vm: StudioViewModel, showPerformance: Boolean, modifier: Modifier = Modifier) {
    val ui = vm.ui
    val stats = vm.session.stats.collectAsStateWithLifecycle()
    val caps = vm.session.capabilities.collectAsStateWithLifecycle()
    Box(modifier = modifier.background(Color.Black)) {
        ShaderCanvas(session = vm.session, quality = ui.quality, onPinch = vm::onPinch, modifier = Modifier.fillMaxSize())
        if (ui.needsRun) {
            Column(
                Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
            ) {
                Text("Imported shader", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Imported code is not run automatically. Review it in Code Studio, then press Run.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                PrimaryButton("Run", { vm.run() }, icon = R.drawable.ic_play)
            }
        }
        if (showPerformance && !ui.needsRun) {
            PerformanceOverlay(stats.value, caps.value, ui.quality, Modifier.align(Alignment.TopStart).padding(8.dp))
        }
        Row(Modifier.align(Alignment.BottomEnd).padding(4.dp)) {
            SIconButton(R.drawable.ic_refresh, "Restart animation", { vm.restart() }, enabled = !ui.needsRun)
            SIconButton(
                if (ui.playing) R.drawable.ic_pause else R.drawable.ic_play,
                if (ui.playing) "Pause animation" else "Play animation",
                { vm.togglePlay() },
                enabled = !ui.needsRun,
            )
        }
    }
}

/** Speed, zoom and render-quality controls. */
@Composable
fun ViewControls(vm: StudioViewModel) {
    val ui = vm.ui
    Column(Modifier.fillMaxWidth()) {
        SectionLabel("View")
        LabeledValueSlider("Animation speed", ui.speed, 0f, 4f, "×%.2f".format(Locale.US, ui.speed)) { vm.setSpeed(it) }
        LabeledValueSlider("Zoom (pinch the preview)", ui.zoom, 0.25f, 8f, "×%.2f".format(Locale.US, ui.zoom)) { vm.setZoom(it) }
        Text(
            "Render quality",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(start = 16.dp, top = 8.dp),
        )
        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.25f to "25%", 0.5f to "50%", 0.75f to "75%", 1f to "100%").forEach { (q, label) ->
                Pill(label, ui.quality == q, { vm.setQuality(q) })
            }
        }
        Text(
            "Lower quality draws fewer pixels, which keeps heavy shaders smooth. Exports are always full size.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
    }
}

@Composable
fun LabeledValueSlider(label: String, value: Float, min: Float, max: Float, valueText: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        Row {
            Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            Text(valueText, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Slider(
            value = value.coerceIn(min, max),
            onValueChange = onChange,
            valueRange = min..max,
            colors = SliderDefaults.colors(thumbColor = Color.White, activeTrackColor = Color.White, inactiveTrackColor = ShaderArtColors.Border),
            modifier = Modifier.semantics { contentDescription = label },
        )
    }
}
