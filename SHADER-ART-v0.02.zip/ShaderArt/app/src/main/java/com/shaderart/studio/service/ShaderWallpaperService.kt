package com.shaderart.studio.service

import android.opengl.GLSurfaceView
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder
import com.shaderart.studio.app.ShaderArtApp
import com.shaderart.studio.core.pipeline.PostAssets
import com.shaderart.studio.core.pipeline.TextureDecoder
import com.shaderart.studio.core.renderer.RenderSession
import com.shaderart.studio.core.renderer.RenderSurface
import com.shaderart.studio.core.renderer.TouchAdapter
import com.shaderart.studio.core.renderer.loadPreset
import com.shaderart.studio.core.renderer.loadProject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Live wallpaper that draws the chosen preset or saved project with the same renderer as the studio.
 * It draws only while visible, at a capped frame rate, and reacts to touches. Sound and sensors are off in a wallpaper.
 */
class ShaderWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = GlEngine()

    private inner class GlEngine : Engine() {
        private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
        private val session = RenderSession()
        private var view: WallpaperGlView? = null
        private var touch: TouchAdapter? = null
        private var surfaceW = 0
        private var surfaceH = 0
        private var visible = false

        /** A GLSurfaceView that draws into this engine's surface instead of its own: the standard live-wallpaper technique. */
        private inner class WallpaperGlView : GLSurfaceView(this@ShaderWallpaperService), RenderSurface {
            override fun getHolder(): SurfaceHolder = surfaceHolder

            fun destroy() {
                super.onDetachedFromWindow()
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            setTouchEventsEnabled(true)
            val v = WallpaperGlView()
            v.setEGLContextClientVersion(3)
            v.setEGLConfigChooser(8, 8, 8, 8, 0, 0)
            v.preserveEGLContextOnPause = true
            v.setRenderer(session.renderer)
            v.renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY
            session.renderer.surface = v
            view = v
            touch = TouchAdapter(session.renderer)
            session.setMaxFps(WallpaperSelection(applicationContext).fps)
            load()
        }

        private fun load() {
            val app = application as? ShaderArtApp ?: return
            val container = app.container
            val choice = WallpaperSelection(applicationContext).get()
            val post = PostAssets(applicationContext.assets)
            scope.launch {
                try {
                    when (choice?.kind) {
                        WallpaperSelection.Kind.PROJECT -> {
                            val p = container.projects.load(choice.id)
                            session.loadProject(p, { name -> TextureDecoder.loadForGpu(container.projects.textureFile(p.id, name)) }, post::load)
                        }
                        WallpaperSelection.Kind.PRESET, null -> {
                            val preset = (choice?.let { container.presets.get(it.id) }) ?: container.presets.presets.firstOrNull()
                            if (preset != null) session.loadPreset(preset, post::load)
                        }
                    }
                    session.setPlaying(visible)
                } catch (e: Exception) {
                    // A deleted or damaged project: fall back to the first preset rather than showing nothing.
                    container.presets.presets.firstOrNull()?.let { session.loadPreset(it, post::load) }
                }
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            this.visible = visible
            if (visible) {
                view?.onResume()
                session.setPlaying(true)
                session.requestFrame()
            } else {
                session.setPlaying(false)
                view?.onPause()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            surfaceW = width
            surfaceH = height
        }

        override fun onTouchEvent(event: MotionEvent) {
            touch?.onEvent(event, surfaceW, surfaceH)
            session.requestFrame()
        }

        override fun onDestroy() {
            super.onDestroy()
            scope.cancel()
            session.setPlaying(false)
            session.renderer.surface = null
            view?.destroy()
            view = null
        }
    }
}
