package com.shaderart.studio.core.importing

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import java.io.ByteArrayOutputStream
import java.io.IOException

/** Storage Access Framework helpers: bounded reads, display names and writes. */
class UriIO(private val resolver: ContentResolver) {

    fun displayName(uri: Uri): String {
        runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) c.getString(i)?.let { return it }
                }
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "imported"
    }

    /** Reads at most [limit] bytes; throws [ImportException] if the file is larger. Never trusts a declared size. */
    fun readLimited(uri: Uri, limit: Int): ByteArray {
        val input = try {
            resolver.openInputStream(uri)
        } catch (e: Exception) {
            throw ImportException("The file could not be opened: ${e.message ?: "unknown error"}")
        } ?: throw ImportException("The file could not be opened.")
        input.use { stream ->
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            var total = 0
            try {
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > limit) throw ImportException("The file is larger than the allowed ${limit / 1024} KB.")
                    out.write(buf, 0, n)
                }
            } catch (e: IOException) {
                throw ImportException("The file could not be read: ${e.message ?: "unknown error"}")
            }
            return out.toByteArray()
        }
    }

    fun openOutput(uri: Uri): java.io.OutputStream =
        resolver.openOutputStream(uri, "wt") ?: throw IOException("The destination could not be opened for writing.")

    fun openInput(uri: Uri) = resolver.openInputStream(uri) ?: throw ImportException("The file could not be opened.")

    /** Writes [bytes] to [uri]; throws on failure so callers never report a save that did not happen. */
    fun write(uri: Uri, bytes: ByteArray) {
        val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("The destination could not be opened for writing.")
        out.use {
            it.write(bytes)
            it.flush()
        }
    }

    /** Streams [file] into [uri]; throws on any failure. */
    fun copyFrom(file: java.io.File, uri: Uri) {
        val out = resolver.openOutputStream(uri, "wt") ?: throw IOException("The destination could not be opened for writing.")
        out.use { o ->
            file.inputStream().use { it.copyTo(o) }
            o.flush()
        }
    }
}
