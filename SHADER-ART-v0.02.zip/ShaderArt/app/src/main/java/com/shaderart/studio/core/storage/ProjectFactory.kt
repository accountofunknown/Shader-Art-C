package com.shaderart.studio.core.storage

import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.shader.ShaderMetadataParser
import java.util.UUID

object ProjectIds {
    fun newId(): String = UUID.randomUUID().toString()
}

object ProjectFactory {
    fun fromPreset(preset: Preset, id: String, now: Long): ShaderProject = ShaderProject(
        id = id,
        name = preset.name,
        type = ProjectType.VISUAL,
        createdAt = now,
        modifiedAt = now,
        vertexSource = preset.vertexSource,
        fragmentSource = preset.fragmentSource,
        params = preset.params,
        values = ParamLogic.defaults(preset.params),
        animation = AnimationConfig(playing = true, speed = 1f, time = 0f),
        render = RenderSettings(),
        presetOrigin = preset.id,
        buffers = preset.buffers,
        imageChannels = preset.imageChannels,
    )

    fun newCode(
        name: String, id: String, now: Long, vertex: String, fragment: String,
        buffers: List<PassSpec> = emptyList(),
        imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
    ): ShaderProject {
        val params = paramsFor(fragment, buffers)
        return ShaderProject(
            id = id,
            name = name,
            type = ProjectType.CODE,
            createdAt = now,
            modifiedAt = now,
            vertexSource = vertex,
            fragmentSource = fragment,
            params = params,
            values = ParamLogic.defaults(params),
            buffers = buffers,
            imageChannels = imageChannels,
        )
    }

    /** Controls declared by annotations in the Image pass and in every buffer pass; the first declaration of a uniform wins. */
    fun paramsFor(fragment: String, buffers: List<PassSpec>): List<ParamDef> {
        val declared = ShaderMetadataParser.declaredUniforms(fragment) +
            buffers.sortedBy { it.id.ordinal }.flatMap { ShaderMetadataParser.declaredUniforms(it.fragmentSource) }
        return ShaderMetadataParser.toParamDefs(declared.distinctBy { it.name })
    }
}
