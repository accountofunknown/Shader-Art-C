package com.shaderart.studio.core.model

/** Kind of control a shader parameter produces. COLOR maps to a GLSL vec3 uniform. */
enum class ParamType {
    FLOAT, INT, BOOL, COLOR;

    companion object {
        fun parse(s: String): ParamType? = entries.firstOrNull { it.name.equals(s.trim(), ignoreCase = true) }
    }
}

/**
 * Metadata for one shader parameter. The UI is generated from these definitions; there is no
 * per-preset hand-written control screen.
 */
data class ParamDef(
    val id: String,
    val name: String,
    val uniform: String,
    val type: ParamType,
    val defaults: List<Float>,
    val min: Float,
    val max: Float,
    val step: Float,
    val description: String = "",
    val group: String? = null,
)

enum class ProjectType {
    VISUAL, CODE;

    companion object {
        fun parse(s: String): ProjectType? = entries.firstOrNull { it.name.equals(s.trim(), ignoreCase = true) }
    }
}

enum class Performance { LIGHT, MEDIUM, HEAVY }

enum class PresetCategory(val label: String) {
    FLUID("Fluid & Organic"),
    MATH("Mathematical"),
    GEOMETRIC("Geometric"),
    RAYMARCH("3D & Raymarching"),
    DIGITAL("Digital & Artistic"),
    REFLECTIVE("Reflective & Metallic"),
    ENVIRONMENT("Environments"),
    RECURSIVE("Recursive & Fractal 3D"),
    AUDIO("Audio-reactive"),
    INTERACTIVE("Interactive & Feedback");

    companion object {
        fun parse(s: String): PresetCategory? = entries.firstOrNull { it.name.equals(s.trim(), ignoreCase = true) }
    }
}

/** A built-in, read-only shader preset loaded from assets. */
data class Preset(
    val id: String,
    val name: String,
    val category: PresetCategory,
    val description: String,
    val performance: Performance,
    val performanceNote: String,
    val version: Int,
    val seed: Float,
    val previewTime: Float,
    val animated: Boolean,
    val vertexSource: String,
    val fragmentSource: String,
    val params: List<ParamDef>,
    /** Buffer passes of a multipass preset (v0.02). */
    val buffers: List<PassSpec> = emptyList(),
    val imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
    /** Tags such as "audio" or "touch" shown in Explore. */
    val tags: List<String> = emptyList(),
) {
    val isMultipass: Boolean get() = buffers.isNotEmpty() || imageChannels.any { it.kind != ChannelKind.NONE }
}

data class AnimationConfig(
    val playing: Boolean = true,
    /** Animation speed multiplier. */
    val speed: Float = 1f,
    /** Shader time in seconds at the moment of saving (used for thumbnails and export). */
    val time: Float = 0f,
)

data class RenderSettings(
    /** 0.25..1.0: fraction of the screen resolution used for on-screen rendering. */
    val qualityScale: Float = 1f,
    val previewWidth: Int = 0,
    val previewHeight: Int = 0,
    /** Pinch-zoom factor, 1.0 = none. */
    val zoom: Float = 1f,
)

/** A complete shader project. Sources live in app-private files, metadata in Room. */
data class ShaderProject(
    val id: String,
    val name: String,
    val type: ProjectType,
    val createdAt: Long,
    val modifiedAt: Long,
    val vertexSource: String,
    val fragmentSource: String,
    val shaderVersion: String = "300 es",
    val params: List<ParamDef>,
    /** Parameter id -> current values (1 value, or 3 for colors). */
    val values: Map<String, List<Float>>,
    val animation: AnimationConfig = AnimationConfig(),
    val render: RenderSettings = RenderSettings(),
    val presetOrigin: String? = null,
    val formatVersion: Int = 2,
    /** Offscreen buffer passes A-D (v2). Empty for a classic single-pass project. */
    val buffers: List<PassSpec> = emptyList(),
    /** Inputs of the final Image pass (always 4 entries). */
    val imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
    val textures: List<TextureAsset> = emptyList(),
    val timeline: Timeline = Timeline(),
    val postStack: List<PostEffectInstance> = emptyList(),
) {
    val isMultipass: Boolean
        get() = buffers.isNotEmpty() || imageChannels.any { it.kind != ChannelKind.NONE }
}

/** Row shown in the gallery and on the home screen. */
data class ProjectSummary(
    val id: String,
    val name: String,
    val type: ProjectType,
    val createdAt: Long,
    val modifiedAt: Long,
    val lastOpenedAt: Long,
    val favorite: Boolean,
    val presetOrigin: String?,
    val hasThumbnail: Boolean,
)
