package com.shaderart.studio.core.security

/** Hard limits applied to everything imported from outside the app. Imported content is untrusted. */
object ImportLimits {
    const val MAX_ARCHIVE_BYTES = 16_000_000L
    const val MAX_ENTRIES = 24
    const val MAX_MANIFEST_BYTES = 262_144
    const val MAX_SOURCE_BYTES = 262_144
    const val MAX_PREVIEW_BYTES = 2_000_000
    const val MAX_TOTAL_UNCOMPRESSED = 24_000_000L
    const val MAX_NAME_LENGTH = 80
    const val MAX_SOURCE_LINES = 6_000
    const val MAX_RENDER_DIMENSION = 8192

    val ALLOWED_ENTRIES = setOf("manifest.json", "vertex.vert", "fragment.frag", "preview.png", "preview.jpg")

    private val BUFFER_ENTRY = Regex("^buffer_[abcd]\\.frag$")
    private val TEXTURE_ENTRY = Regex("^tex_[a-z0-9_]{1,24}\\.png$")

    fun isBufferEntry(name: String) = BUFFER_ENTRY.matches(name)
    fun isTextureEntry(name: String) = TEXTURE_ENTRY.matches(name)
    fun bufferEntryName(key: String) = "buffer_$key.frag"
    fun textureEntryName(name: String) = "tex_$name.png"

    /** Entry names must be one of the fixed file names: no directories, no separators, no traversal. */
    fun isSafeEntryName(name: String): Boolean {
        if (name.isEmpty() || name.length > 64) return false
        if (name.contains('/') || name.contains('\\') || name.contains("..") || name.contains('\u0000')) return false
        if (name.startsWith(".") || name.contains(':')) return false
        return name in ALLOWED_ENTRIES || isBufferEntry(name) || isTextureEntry(name)
    }

    private val SAFE_ID = Regex("^[A-Za-z0-9_-]{1,64}$")

    /** Project ids become directory names, so they must not contain path characters. */
    fun isSafeProjectId(id: String): Boolean = SAFE_ID.matches(id)
}
