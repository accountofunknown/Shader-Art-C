package com.shaderart.studio.core.storage

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

object AtomicFiles {
    /**
     * Writes to a temporary sibling, flushes it to disk, then renames over the target. A crash leaves
     * either the complete old file or the complete new file, never a half-written one.
     */
    fun write(target: File, bytes: ByteArray) {
        val dir = target.parentFile ?: throw IOException("No parent directory for $target")
        if (!dir.exists() && !dir.mkdirs()) throw IOException("Cannot create directory $dir")
        val tmp = File(dir, target.name + ".tmp")
        FileOutputStream(tmp).use { out ->
            out.write(bytes)
            out.flush()
            out.fd.sync()
        }
        try {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE)
        } catch (e: AtomicMoveNotSupportedException) {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        } catch (e: IOException) {
            // Some file systems refuse ATOMIC_MOVE onto an existing file; fall back to replace.
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    fun writeText(target: File, text: String) = write(target, text.toByteArray(Charsets.UTF_8))

    fun deleteRecursively(file: File) {
        if (file.exists() && !file.deleteRecursively()) throw IOException("Could not delete $file")
    }
}
