package com.shaderart.studio.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ChannelKind
import com.shaderart.studio.core.model.Easing
import com.shaderart.studio.core.model.MultipassLimits
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.TimelineEval
import com.shaderart.studio.feature.live.AudioSource
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.SecondaryButton
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SectionLabel
import com.shaderart.studio.ui.components.StatusBanner
import com.shaderart.studio.ui.theme.ShaderArtColors
import java.util.Locale

/** Things only the Activity can do for the tools: permission prompts and file pickers. */
class StudioToolsHost(
    /** Asks for the microphone permission if needed, then runs the action. */
    val requestMicThen: (() -> Unit) -> Unit,
    val pickAudioFile: () -> Unit,
    val pickPicture: () -> Unit,
    /** Lets the person choose a text file; the callback receives its text. */
    val pickTextFile: ((String) -> Unit) -> Unit,
    val setWallpaper: () -> Unit,
)

enum class ToolsTab(val label: String) {
    INPUTS("Inputs"), POST("Post effects"), TIMELINE("Timeline"), PASSES("Passes"), WALLPAPER("Wallpaper")
}

private val TRACK_COLORS = listOf(Color(0xFF4FC3F7), Color(0xFFFF8A65), Color(0xFFAED581), Color(0xFFBA68C8), Color(0xFFFFD54F))

/**
 * Sound and sensor inputs, post effects, keyframe timeline, passes/pictures and the live wallpaper, in one inline panel.
 * The caller provides the scrolling and keeps the live preview visible next to it, so effects can be tuned by eye.
 */
@Composable
fun StudioToolsPanel(vm: StudioViewModel, host: StudioToolsHost, modifier: Modifier = Modifier) {
    val ui = vm.ui
    var tab by remember { mutableStateOf(ToolsTab.INPUTS) }
    val tabs = remember(ui.type) { if (ui.type == ProjectType.CODE) ToolsTab.entries.toList() else ToolsTab.entries.filter { it != ToolsTab.PASSES } }
    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            tabs.forEach { t -> Pill(t.label, tab == t, { tab = t }) }
        }
        when (if (tab in tabs) tab else ToolsTab.INPUTS) {
            ToolsTab.INPUTS -> InputsTools(vm, host)
            ToolsTab.POST -> PostTools(vm)
            ToolsTab.TIMELINE -> TimelineTools(vm)
            ToolsTab.PASSES -> PassesTools(vm, host)
            ToolsTab.WALLPAPER -> WallpaperTools(vm, host)
        }
    }
}

@Composable
private fun SmallNote(text: String) {
    Text(
        text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
    )
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = Color.White,
                uncheckedThumbColor = ShaderArtColors.TextSecondary, uncheckedTrackColor = ShaderArtColors.Graphite,
            ),
            modifier = Modifier.semantics { contentDescription = label },
        )
    }
}

// ------------------------------------------------------------------------------------------ inputs

@Composable
private fun InputsTools(vm: StudioViewModel, host: StudioToolsHost) {
    val ui = vm.ui
    SectionLabel("Sound")
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Pill("Off", ui.audio == AudioSource.OFF, { vm.setAudioSource(AudioSource.OFF) })
        Pill("Demo beat", ui.audio == AudioSource.DEMO, { vm.setAudioSource(AudioSource.DEMO) })
        Pill("Microphone", ui.audio == AudioSource.MIC, {
            if (vm.hasMicPermission()) vm.setAudioSource(AudioSource.MIC) else host.requestMicThen { vm.setAudioSource(AudioSource.MIC) }
        })
        Pill("Audio file", ui.audio == AudioSource.FILE, {
            if (vm.hasMicPermission()) host.pickAudioFile() else host.requestMicThen { host.pickAudioFile() }
        })
    }
    val status = when (ui.audio) {
        AudioSource.OFF -> "No sound is analysed. Shaders that use u_audio, u_beat or an Audio channel see silence."
        AudioSource.DEMO -> "A built-in 120 BPM beat drives the shader. No permission needed."
        AudioSource.MIC -> "Listening to the microphone. It is switched off when you leave the studio."
        AudioSource.FILE -> "Playing ${ui.audioFile ?: "your file"} and analysing it."
    }
    SmallNote(status)
    SmallNote(
        "Microphone and audio-file analysis use Android's microphone permission (the file analyser needs it too). Sound is analysed on this device only; " +
            "nothing is recorded, stored or sent anywhere, and the app has no internet permission. Capturing other apps' playback is not part of this version.",
    )

    SectionLabel("Motion sensors")
    val (hasGyro, hasAccel) = vm.sensorsAvailable
    SwitchRow("Use gyroscope and accelerometer", ui.sensors) { vm.setSensors(it) }
    SmallNote(
        "Fills u_tilt, u_gyro and u_accel. This device has: ${listOfNotNull("gyroscope".takeIf { hasGyro }, "accelerometer".takeIf { hasAccel }).ifEmpty { listOf("no motion sensors") }.joinToString(" and ")}. " +
            "Sensors only run while this screen is open.",
    )

    SectionLabel("Touch")
    SmallNote(
        "Always on: u_mouse (first finger), u_touches[10] and u_touchCount (multi-touch), u_pressure, u_touchVel and u_taps[8] (recent taps with their time). " +
            "Try the Touch Ripples and Feedback Trails presets.",
    )
}

// ------------------------------------------------------------------------------------------ post effects

@Composable
private fun PostTools(vm: StudioViewModel) {
    val ui = vm.ui
    SectionLabel("Effects applied to the final picture, top to bottom")
    if (ui.postStack.isEmpty()) SmallNote("No effects yet. Add one below.")
    ui.postStack.forEachIndexed { index, inst ->
        val def = PostEffects.find(inst.effectId) ?: return@forEachIndexed
        androidx.compose.runtime.key(index, inst.effectId) {
            Column(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(ShaderArtColors.Charcoal).padding(bottom = 6.dp)) {
                Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(def.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                    SIconButton(R.drawable.ic_expand_less, "Move ${def.name} up", { vm.movePostEffect(index, -1) }, enabled = index > 0)
                    SIconButton(R.drawable.ic_expand_more, "Move ${def.name} down", { vm.movePostEffect(index, 1) }, enabled = index < ui.postStack.lastIndex)
                    Switch(
                        checked = inst.enabled,
                        onCheckedChange = { vm.setPostEnabled(index, it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black, checkedTrackColor = Color.White,
                            uncheckedThumbColor = ShaderArtColors.TextSecondary, uncheckedTrackColor = ShaderArtColors.Graphite,
                        ),
                        modifier = Modifier.semantics { contentDescription = "Enable ${def.name}" },
                    )
                    SIconButton(R.drawable.ic_delete, "Remove ${def.name}", { vm.removePostEffect(index) })
                }
                if (inst.enabled) {
                    def.params.forEachIndexed { pi, p ->
                        val v = inst.values.getOrElse(pi) { p.default }
                        LabeledValueSlider(p.name, v, p.min, p.max, String.format(Locale.US, "%.2f", v)) { vm.setPostValue(index, pi, it) }
                    }
                }
            }
        }
    }
    SectionLabel("Add effect")
    if (ui.postStack.size >= MultipassLimits.MAX_POST) {
        SmallNote("The stack is full (${MultipassLimits.MAX_POST} effects).")
    } else {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PostEffects.all.forEach { d -> Pill(d.name, false, { vm.addPostEffect(d.id) }) }
        }
    }
    SmallNote("Blur and bloom use several GPU passes each, so stacking many of them costs speed. Adding, removing, reordering or switching an effect restarts feedback buffers; moving a slider does not.")
}

// ------------------------------------------------------------------------------------------ timeline

private fun componentName(def: ParamDef, component: Int): String =
    if (def.type == ParamType.COLOR) "${def.name} ${"RGB".getOrElse(component) { '?' }}" else def.name

@Composable
private fun TimelineTools(vm: StudioViewModel) {
    val ui = vm.ui
    val tl = ui.timeline
    val stats = vm.session.stats.collectAsStateWithLifecycle()
    var selParam by remember { mutableStateOf<String?>(null) }
    var selComp by remember { mutableStateOf(0) }
    var selKey by remember { mutableStateOf(0) }

    val animatable = ui.params.filter { it.type != ParamType.BOOL }
    val def = animatable.firstOrNull { it.id == selParam } ?: animatable.firstOrNull()
    val comp = if (def != null && def.type == ParamType.COLOR) selComp.coerceIn(0, 2) else 0

    SectionLabel("Keyframe timeline")
    SwitchRow("Timeline on", tl.enabled) { vm.setTimelineEnabled(it) }
    SwitchRow("Loop", tl.loop) { vm.setTimelineLoop(it) }
    LabeledValueSlider("Length", tl.durationSeconds, 1f, 60f, String.format(Locale.US, "%.1f s", tl.durationSeconds)) { vm.setTimelineDuration(it) }

    // Lanes: one row per animated value, with its keys and the playhead.
    val localT = TimelineEval.localTime(tl, stats.value.timeSeconds)
    if (tl.tracks.isEmpty()) {
        SmallNote("Nothing is animated yet. Pick a control below and add keys at different moments; values glide between them.")
    } else {
        tl.tracks.forEachIndexed { ti, tr ->
            val d = ui.params.firstOrNull { it.id == tr.paramId }
            val color = TRACK_COLORS[ti % TRACK_COLORS.size]
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (d != null) componentName(d, tr.component) else tr.paramId,
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.weight(0.4f), maxLines = 1,
                )
                Canvas(Modifier.weight(0.6f).height(26.dp).background(ShaderArtColors.Charcoal)) {
                    val w = size.width
                    val h = size.height
                    val dur = tl.durationSeconds.coerceAtLeast(0.01f)
                    drawLine(ShaderArtColors.Border, Offset(0f, h / 2), Offset(w, h / 2), 1f)
                    tr.keys.forEach { k -> drawCircle(color, 5f, Offset((k.t / dur).coerceIn(0f, 1f) * w, h / 2)) }
                    val x = (localT / dur).coerceIn(0f, 1f) * w
                    drawLine(Color.White, Offset(x, 0f), Offset(x, h), 2f)
                }
            }
        }
    }

    SectionLabel("Add a key at the playhead (${String.format(Locale.US, "%.2f", localT)} s)")
    if (animatable.isEmpty()) {
        SmallNote("This project has no controls to animate.")
    } else {
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            animatable.forEach { p -> Pill(p.name, def?.id == p.id, { selParam = p.id; selKey = 0 }) }
        }
        if (def != null) {
            if (def.type == ParamType.COLOR) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Red", "Green", "Blue").forEachIndexed { i, n -> Pill(n, comp == i, { selComp = i; selKey = 0 }) }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("Add key", { vm.addKey(def.id, comp) }, Modifier.height(40.dp), icon = R.drawable.ic_add)
                SecondaryButton("Clear all", { vm.clearTimeline() }, Modifier.height(40.dp), enabled = tl.tracks.isNotEmpty())
            }
            SmallNote("A new key takes the control's current value. Drag the preview time with Restart/Pause to place keys at different moments.")

            val track = tl.track(def.id, comp)
            if (track != null && track.keys.isNotEmpty()) {
                val k = selKey.coerceIn(0, track.keys.lastIndex)
                SectionLabel("Keys of ${componentName(def, comp)}")
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    track.keys.forEachIndexed { i, key -> Pill(String.format(Locale.US, "%.1fs", key.t), i == k, { selKey = i }) }
                }
                val key = track.keys[k]
                LabeledValueSlider("Time", key.t, 0f, tl.durationSeconds, String.format(Locale.US, "%.2f s", key.t)) { vm.editKey(def.id, comp, k, time = it) }
                val lo = def.min
                val hi = if (def.max > def.min) def.max else def.min + 1f
                LabeledValueSlider("Value", key.v, lo, hi, String.format(Locale.US, "%.3f", key.v)) { vm.editKey(def.id, comp, k, value = it) }
                Text("Easing into the next key", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(start = 16.dp, top = 4.dp))
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Easing.entries.forEach { e ->
                        Pill(e.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }, key.easing == e, { vm.editKey(def.id, comp, k, easing = e) })
                    }
                }
                SecondaryButton("Delete this key", { vm.removeKey(def.id, comp, k); selKey = 0 }, Modifier.padding(horizontal = 12.dp).height(40.dp), icon = R.drawable.ic_delete)
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ passes and pictures

private fun bindingLabel(b: ChannelBinding): String = when (b.kind) {
    ChannelKind.NONE -> "None (black)"
    ChannelKind.BUFFER -> "Buffer ${b.ref.uppercase()}"
    ChannelKind.TEXTURE -> "Picture “${b.ref}”"
    ChannelKind.NOISE -> "Noise"
    ChannelKind.AUDIO -> "Audio (spectrum + wave)"
}

@Composable
private fun PassesTools(vm: StudioViewModel, host: StudioToolsHost) {
    val ui = vm.ui
    SectionLabel("Passes")
    SmallNote(
        "The Image pass draws what you see. Buffers A–D draw into hidden images that any pass can read as a channel. A buffer that reads itself remembers the previous frame (feedback). " +
            "Buffers run first, in order A, B, C, D, then Image.",
    )
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        PassId.BUFFERS.forEach { id ->
            if (id in ui.bufferText) Pill("Remove ${id.label}", false, { vm.removeBuffer(id) }) else Pill("Add ${id.label}", false, { vm.addBuffer(id) })
        }
    }

    val passes = listOf(PassId.IMAGE) + PassId.BUFFERS.filter { it in ui.bufferText }
    passes.forEach { pass ->
        val channels = if (pass == PassId.IMAGE) ui.imageChannels else ui.bufferChannels[pass] ?: ChannelBinding.noneChannels()
        SectionLabel("Inputs of ${pass.label}")
        channels.forEachIndexed { i, binding ->
            ChannelRow(vm, pass, i, binding)
        }
    }

    SectionLabel("Pictures")
    if (ui.textures.isEmpty()) SmallNote("No pictures yet. Add one, then choose it in a channel above.")
    ui.textures.forEach { t ->
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${t.name}  ·  ${t.width}×${t.height}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
            SIconButton(R.drawable.ic_delete, "Remove picture ${t.name}", { vm.removeTexture(t.name) })
        }
    }
    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        SecondaryButton(
            if (ui.busy) "Adding…" else "Add picture",
            host.pickPicture,
            Modifier.height(40.dp),
            enabled = !ui.busy && ui.textures.size < MultipassLimits.MAX_TEXTURES,
            icon = R.drawable.ic_import,
        )
    }
    SmallNote(
        "Pictures are shrunk to at most ${MultipassLimits.MAX_TEXTURE_SIDE} px and stored inside the project (up to ${MultipassLimits.MAX_TEXTURES}). " +
            "Channel samplers are u_channel0 … u_channel3; their sizes are in u_channelResolution[i].",
    )
}

@Composable
private fun ChannelRow(vm: StudioViewModel, pass: PassId, index: Int, binding: ChannelBinding) {
    val ui = vm.ui
    var open by remember(pass, index) { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("u_channel$index", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(0.4f))
        Box(Modifier.weight(0.6f)) {
            SecondaryButton(bindingLabel(binding), { open = true }, Modifier.fillMaxWidth().height(40.dp))
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                val options = buildList {
                    add(ChannelBinding.NONE)
                    add(ChannelBinding.NOISE)
                    add(ChannelBinding.AUDIO)
                    PassId.BUFFERS.filter { it in ui.bufferText }.forEach { add(ChannelBinding.buffer(it)) }
                    ui.textures.forEach { add(ChannelBinding.texture(it.name)) }
                }
                options.forEach { o ->
                    DropdownMenuItem(text = { Text(bindingLabel(o)) }, onClick = { open = false; vm.setChannel(pass, index, o) })
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ wallpaper

@Composable
private fun WallpaperTools(vm: StudioViewModel, host: StudioToolsHost) {
    val ui = vm.ui
    var fps by remember { mutableStateOf(vm.wallpaperFps) }
    SectionLabel("Live wallpaper")
    SmallNote(
        "Shows this shader as your phone's animated wallpaper. It draws only while the wallpaper is visible, at the frame rate below, and reacts to touches. " +
            "Sound and motion sensors are off in the wallpaper. The project is saved to My Shaders first, and the wallpaper keeps showing that saved version.",
    )
    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf(15, 24, 30, 60).forEach { f -> Pill("$f fps", fps == f, { fps = f; vm.setWallpaperFps(f) }) }
    }
    Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
        PrimaryButton("Set as live wallpaper", host.setWallpaper, enabled = !ui.needsRun, icon = R.drawable.ic_play)
    }
    if (ui.needsRun) StatusBanner("Run the imported shader once before using it as a wallpaper.", ShaderArtColors.Warning, R.drawable.ic_warning, Modifier.padding(16.dp))
    SmallNote("Heavy shaders drain the battery. Light presets (Truchet Weave, Touch Ripples, Kaleidoscope) at 15–30 fps are gentle.")
}

/**
 * Tells the view-model that a studio screen is visible. Sound and sensors run only while one is: the microphone,
 * sensors and the demo beat stop when the screen is left or the app goes to the background.
 */
@Composable
fun StudioInputLifecycle(vm: StudioViewModel) {
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, vm) {
        var attached = false
        fun attach() { if (!attached) { attached = true; vm.hostAttached() } }
        fun detach() { if (attached) { attached = false; vm.hostDetached() } }
        if (owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) attach()
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) attach() else if (event == Lifecycle.Event.ON_PAUSE) detach()
        }
        owner.lifecycle.addObserver(observer)
        onDispose {
            owner.lifecycle.removeObserver(observer)
            detach()
        }
    }
}
