package com.shaderart.studio.core.export

import android.graphics.Bitmap
import com.shaderart.studio.core.audio.DemoAudio
import com.shaderart.studio.core.input.LiveInputs
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.model.TimelineEval
import com.shaderart.studio.core.pipeline.PassSource
import com.shaderart.studio.core.pipeline.PipelineSpec
import com.shaderart.studio.core.uniforms.FrameUniforms
import java.util.Calendar

/** A complete, renderable description of a project or preset at export time. */
class SceneData(
    val vertex: String,
    val image: PassSource,
    val buffers: List<PassSource>,
    val post: List<PostEffectInstance>,
    val params: List<ParamDef>,
    val values: Map<String, List<Float>>,
    val timeline: Timeline,
    val zoom: Float,
    val speed: Float,
    val textureLoader: (String) -> Bitmap?,
    val postSourceLoader: (String) -> String?,
) {
    fun spec() = PipelineSpec(vertex, image, buffers, post, textureLoader, postSourceLoader)

    /**
     * Uniform values for the frame at shader time [time]. Exports have no touches or sensors; audio-reactive projects get the
     * deterministic demo beat, so an exported file is reproducible.
     */
    fun frame(time: Float, dt: Float, index: Int, w: Int, h: Int, usesAudio: Boolean): FrameUniforms {
        val c = Calendar.getInstance()
        val date = floatArrayOf(
            c.get(Calendar.YEAR).toFloat(), c.get(Calendar.MONTH).toFloat(), c.get(Calendar.DAY_OF_MONTH).toFloat(),
            c.get(Calendar.HOUR_OF_DAY) * 3600f + c.get(Calendar.MINUTE) * 60f + c.get(Calendar.SECOND),
        )
        val live = if (usesAudio) LiveInputs(audio = DemoAudio.featuresAt(time)) else LiveInputs.NONE
        return FrameUniforms(time, w, h, 0.5f, 0.5f, false, dt, index, speed, zoom, 0.5f, 0.5f, live, date)
    }

    fun valuesAt(time: Float): Map<String, List<Float>> = TimelineEval.apply(timeline, params, values, time)

    companion object {
        /** A plain single-pass shader. */
        fun simple(vertex: String, fragment: String, params: List<ParamDef>, values: Map<String, List<Float>>, zoom: Float, speed: Float) = SceneData(
            vertex, PassSource(PassId.IMAGE, fragment, ChannelBinding.noneChannels()), emptyList(), emptyList(),
            params, values, Timeline(), zoom, speed, { null }, { null },
        )
    }
}
