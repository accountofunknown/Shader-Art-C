package com.shaderart.studio.app

import android.app.Application
import kotlinx.coroutines.launch

class ShaderArtApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        // Files shared earlier are no longer needed after a restart.
        container.appScope.launch { container.export.clearExportCache() }
    }
}
