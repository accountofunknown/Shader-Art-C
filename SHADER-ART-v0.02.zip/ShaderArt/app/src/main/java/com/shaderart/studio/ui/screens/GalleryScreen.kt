package com.shaderart.studio.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ProjectSummary
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.ui.components.ConfirmDialog
import com.shaderart.studio.ui.components.EmptyState
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.ScreenTitle
import com.shaderart.studio.ui.components.SecondaryButton
import com.shaderart.studio.ui.components.TextPromptDialog
import com.shaderart.studio.ui.components.clickableWithRole

private enum class GalleryFilter(val label: String) { ALL("All"), FAVORITES("Favorites"), VISUAL("Visual"), CODE("Code") }
private enum class GallerySort(val label: String) { RECENT("Recent"), CREATED("Created"), NAME("Name") }

@Composable
fun GalleryScreen(
    lib: LibraryViewModel,
    onOpen: (String) -> Unit,
    onExportImage: (String) -> Unit,
    onExportArchive: (id: String, name: String) -> Unit,
    onImport: () -> Unit,
) {
    val projects by lib.projects.collectAsStateWithLifecycle()
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf(GalleryFilter.ALL) }
    var sort by rememberSaveable { mutableStateOf(GallerySort.RECENT) }
    var renaming by remember { mutableStateOf<ProjectSummary?>(null) }
    var deleting by remember { mutableStateOf<ProjectSummary?>(null) }

    val shown = projects
        .filter { p ->
            when (filter) {
                GalleryFilter.ALL -> true
                GalleryFilter.FAVORITES -> p.favorite
                GalleryFilter.VISUAL -> p.type == ProjectType.VISUAL
                GalleryFilter.CODE -> p.type == ProjectType.CODE
            }
        }
        .filter { query.isBlank() || it.name.contains(query.trim(), ignoreCase = true) }
        .let { list ->
            when (sort) {
                GallerySort.RECENT -> list.sortedByDescending { maxOf(it.lastOpenedAt, it.modifiedAt) }
                GallerySort.CREATED -> list.sortedByDescending { it.createdAt }
                GallerySort.NAME -> list.sortedBy { it.name.lowercase() }
            }
        }

    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Gallery", subtitle = "${projects.size} saved") {
            SIconButton(R.drawable.ic_import, "Import a shader file", onImport)
        }
        if (projects.isEmpty()) {
            EmptyState(
                icon = R.drawable.ic_gallery,
                title = "Your gallery is empty",
                body = "Projects you save appear here with a thumbnail. You can also import .shaderart, .glsl, .frag or .vert files.",
            ) { PrimaryButton("Import a file", onImport, icon = R.drawable.ic_import) }
            return@Column
        }

        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search projects") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        )
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GalleryFilter.entries.forEach { f -> item(key = "f_${f.name}") { Pill(f.label, filter == f, { filter = f }) } }
            item(key = "sep") { Text("Sort", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 8.dp, top = 10.dp)) }
            GallerySort.entries.forEach { s -> item(key = "s_${s.name}") { Pill(s.label, sort == s, { sort = s }) } }
        }

        if (shown.isEmpty()) {
            EmptyState(icon = R.drawable.ic_search, title = "Nothing matches", body = "Change the search or filter.")
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(160.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(shown, key = { it.id }) { p ->
                    ProjectTile(
                        lib, p,
                        onOpen = { onOpen(p.id) },
                        onRename = { renaming = p },
                        onDelete = { deleting = p },
                        onExportImage = { onExportImage(p.id) },
                        onExportArchive = { onExportArchive(p.id, p.name) },
                    )
                }
            }
        }
    }

    renaming?.let { p ->
        TextPromptDialog("Rename project", p.name, "Rename", 80, onConfirm = { lib.rename(p.id, it); renaming = null }, onDismiss = { renaming = null })
    }
    deleting?.let { p ->
        ConfirmDialog(
            title = "Delete “${p.name}”?",
            body = "This removes the project and its thumbnail from this device. It cannot be undone.",
            confirmLabel = "Delete",
            onConfirm = { lib.delete(p.id); deleting = null },
            onDismiss = { deleting = null },
        )
    }
}

@Composable
private fun ProjectTile(
    lib: LibraryViewModel,
    p: ProjectSummary,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onExportImage: () -> Unit,
    onExportArchive: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    Column {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clickableWithRole(onOpen)
                .semantics { contentDescription = "Open project ${p.name}" },
        ) {
            ProjectThumb(lib, p, Modifier.fillMaxSize())
            Box(Modifier.align(Alignment.TopEnd)) {
                SIconButton(
                    if (p.favorite) R.drawable.ic_star else R.drawable.ic_star_outline,
                    if (p.favorite) "Remove ${p.name} from favorites" else "Add ${p.name} to favorites",
                    { lib.setFavorite(p.id, !p.favorite) },
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(top = 6.dp)) {
                Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text(
                    (if (p.type == ProjectType.CODE) "Code" else "Visual") + " · " + formatDate(p.modifiedAt),
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                )
            }
            Box {
                SIconButton(R.drawable.ic_more, "More actions for ${p.name}", { menu = true })
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Open") }, onClick = { menu = false; onOpen() })
                    DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text("Duplicate") }, onClick = { menu = false; lib.duplicate(p.id) })
                    DropdownMenuItem(text = { Text("Export image…") }, onClick = { menu = false; onExportImage() })
                    DropdownMenuItem(text = { Text("Export project file…") }, onClick = { menu = false; onExportArchive() })
                    HorizontalDivider()
                    DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}
