package com.shaderart.studio.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role

/** Clickable with the Button role so screen readers announce it correctly. */
fun Modifier.clickableWithRole(onClick: () -> Unit): Modifier = clickable(role = Role.Button, onClick = onClick)
