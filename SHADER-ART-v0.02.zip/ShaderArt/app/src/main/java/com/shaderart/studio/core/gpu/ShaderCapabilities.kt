package com.shaderart.studio.core.gpu

import android.app.ActivityManager
import android.content.Context
import android.opengl.GLES20
import android.opengl.GLES30

/** Values reported by the real GL driver. Nothing here is invented or estimated. */
data class ShaderCapabilities(
    val glVersion: String,
    val glslVersion: String,
    val renderer: String,
    val vendor: String,
    val maxTextureSize: Int,
    val maxRenderbufferSize: Int,
    val maxFragmentUniformVectors: Int,
    val maxViewportWidth: Int,
    val maxViewportHeight: Int,
) {
    /** Largest image side usable for offscreen rendering on this GPU. */
    val maxImageSide: Int get() = minOf(maxTextureSize, maxRenderbufferSize)
}

object GpuInfo {
    /** Must be called on a thread with a current OpenGL ES context. */
    fun query(): ShaderCapabilities {
        fun int(pname: Int): Int {
            val a = IntArray(1)
            GLES30.glGetIntegerv(pname, a, 0)
            return a[0]
        }
        val viewport = IntArray(2)
        GLES30.glGetIntegerv(GLES20.GL_MAX_VIEWPORT_DIMS, viewport, 0)
        return ShaderCapabilities(
            glVersion = GLES30.glGetString(GLES30.GL_VERSION) ?: "unknown",
            glslVersion = GLES30.glGetString(GLES30.GL_SHADING_LANGUAGE_VERSION) ?: "unknown",
            renderer = GLES30.glGetString(GLES30.GL_RENDERER) ?: "unknown",
            vendor = GLES30.glGetString(GLES30.GL_VENDOR) ?: "unknown",
            maxTextureSize = int(GLES30.GL_MAX_TEXTURE_SIZE),
            maxRenderbufferSize = int(GLES30.GL_MAX_RENDERBUFFER_SIZE),
            maxFragmentUniformVectors = int(GLES30.GL_MAX_FRAGMENT_UNIFORM_VECTORS),
            maxViewportWidth = viewport[0],
            maxViewportHeight = viewport[1],
        )
    }
}

object DeviceGles {
    /** Highest OpenGL ES version the device claims to support, as reported by Android (0x30000 = ES 3.0). */
    fun reportedVersion(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0
        return am.deviceConfigurationInfo.reqGlEsVersion
    }

    fun supportsEs3(context: Context): Boolean = reportedVersion(context) >= 0x30000

    fun describe(version: Int): String = "${version ushr 16}.${version and 0xFFFF}"
}
