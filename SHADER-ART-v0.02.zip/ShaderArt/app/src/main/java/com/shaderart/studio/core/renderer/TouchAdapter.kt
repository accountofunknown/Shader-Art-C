package com.shaderart.studio.core.renderer

import android.view.MotionEvent
import com.shaderart.studio.core.input.TouchState

/**
 * Turns Android touch events into the touch uniforms of a [ShaderRenderer]: the single-finger u_mouse, and the multi-touch
 * u_touches / u_touchCount / u_pressure / u_touchVel / u_taps. Shared by the in-app view and the live wallpaper.
 *
 * Coordinates are 0..1 across the surface with the origin at the bottom-left, like gl_FragCoord / u_resolution.
 */
class TouchAdapter(private val renderer: ShaderRenderer) {
    // Taps are recorded on touch-down, not on release, so ripples start the instant the finger lands.
    private val state = TouchState(tapOnRelease = false) { renderer.shaderTime }

    /** @param trackMouse whether this event may move the single-finger u_mouse (false while a pinch is in progress). */
    fun onEvent(e: MotionEvent, width: Int, height: Int, trackMouse: Boolean = true) {
        if (width <= 0 || height <= 0) return
        fun nx(i: Int) = (e.getX(i) / width).coerceIn(0f, 1f)
        fun ny(i: Int) = (1f - e.getY(i) / height).coerceIn(0f, 1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                renderer.touchX = nx(0); renderer.touchY = ny(0); renderer.touchDown = true
                renderer.clickX = renderer.touchX; renderer.clickY = renderer.touchY
            }
            MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && trackMouse) {
                renderer.touchX = nx(0); renderer.touchY = ny(0); renderer.touchDown = true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> renderer.touchDown = false
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                state.down(e.getPointerId(i), nx(i), ny(i), e.getPressure(i))
                state.addTap(nx(i), ny(i), renderer.shaderTime, e.getPressure(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) state.move(e.getPointerId(i), nx(i), ny(i), e.getPressure(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> state.up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> state.cancelAll()
        }
        renderer.inputs.setTouch(state.snapshot())
    }
}
