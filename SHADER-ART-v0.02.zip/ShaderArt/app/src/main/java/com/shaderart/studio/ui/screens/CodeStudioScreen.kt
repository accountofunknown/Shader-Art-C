package com.shaderart.studio.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.R
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.compiler.ShaderStage
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.presets.ShaderTemplate
import com.shaderart.studio.core.shader.ShaderMetadataParser
import com.shaderart.studio.feature.studio.BottomTab
import com.shaderart.studio.feature.studio.EditorTab
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.CodeEditor
import com.shaderart.studio.ui.components.EmptyState
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.PrimaryButton
import com.shaderart.studio.ui.components.SIcon
import com.shaderart.studio.ui.components.SIconButton
import com.shaderart.studio.ui.components.SecondaryButton
import com.shaderart.studio.ui.components.StatusBanner
import com.shaderart.studio.ui.components.clickableWithRole
import com.shaderart.studio.ui.theme.CodeFont
import com.shaderart.studio.ui.theme.ShaderArtColors
import java.util.Locale

/** Hooks the screen needs from the host for things only the Activity can do (file pickers, navigation). */
class CodeStudioHost(
    val templates: List<ShaderTemplate>,
    val capabilities: () -> ShaderCapabilities?,
    val onImport: () -> Unit,
    val onExportSource: (extension: String, text: String) -> Unit,
    val onExportArchive: () -> Unit,
    val onExportImage: () -> Unit,
    val onNewFromTemplate: (templateId: String) -> Unit,
    val onOpenInCode: () -> Unit,
    val tools: StudioToolsHost,
)

@Composable
fun CodeStudioScreen(vm: StudioViewModel, host: CodeStudioHost, showPerformance: Boolean) {
    val ui = vm.ui
    var shadertoyOpen by remember { mutableStateOf(false) }
    var toolsOpen by remember { mutableStateOf(false) }
    StudioInputLifecycle(vm)
    if (shadertoyOpen) {
        ShadertoyDialog(
            onImport = { text -> shadertoyOpen = false; vm.requestOpen { vm.importShadertoy(text) } },
            onPickFile = host.tools.pickTextFile,
            onDismiss = { shadertoyOpen = false },
        )
    }
    if (!ui.hasProject) {
        EmptyState(
            icon = R.drawable.ic_code,
            title = "Code Studio",
            body = "Write GLSL ES 3.00 fragment shaders with live preview, diagnostics from your GPU driver, and parameter controls from annotations.",
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        ) {
            host.templates.forEach { t ->
                SecondaryButton("New: ${t.name}", { host.onNewFromTemplate(t.id) }, Modifier.fillMaxWidth())
            }
            SecondaryButton("Import a shader file", host.onImport, Modifier.fillMaxWidth(), icon = R.drawable.ic_import)
            SecondaryButton("Import from Shadertoy (paste code or JSON)", { shadertoyOpen = true }, Modifier.fillMaxWidth(), icon = R.drawable.ic_paste)
        }
        return
    }

    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val readOnly = ui.type == ProjectType.VISUAL
    val currentText = when (ui.tab) {
        EditorTab.FRAGMENT -> ui.fragment
        EditorTab.VERTEX -> ui.vertex
        else -> ui.bufferText[ui.tab.pass] ?: TextFieldValue("")
    }
    val stats = vm.session.stats.collectAsStateWithLifecycle()

    val lineSeverity = remember(ui.diagnostics, ui.tab) {
        val out = HashMap<Int, Severity>()
        for (d in ui.diagnostics) {
            val line = d.line ?: continue
            val onThisTab = when (ui.tab) {
                EditorTab.VERTEX -> d.stage == ShaderStage.VERTEX
                EditorTab.FRAGMENT -> d.stage == ShaderStage.FRAGMENT && d.pass == null
                else -> d.pass == ui.tab.label
            }
            if (!onThisTab) continue
            val prev = out[line]
            if (prev == null || (d.severity == Severity.ERROR && prev != Severity.ERROR)) out[line] = d.severity
        }
        out as Map<Int, Severity>
    }

    Column(Modifier.fillMaxSize().imePadding()) {
        StudioHeader(vm) { CodeMenu(vm, host, onShadertoy = { shadertoyOpen = true }) }

        if (!imeVisible) {
            StudioPreview(vm, showPerformance, Modifier.fillMaxWidth().height(180.dp))
        }

        Toolbar(vm)

        if (ui.type == ProjectType.VISUAL) {
            StatusBanner(
                "This is a built-in preset, so its code is read-only.",
                MaterialTheme.colorScheme.onSurfaceVariant, R.drawable.ic_info,
                action = { SecondaryButton("Edit copy", host.onOpenInCode, Modifier.height(36.dp)) },
            )
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Pill("Image", !toolsOpen && ui.tab == EditorTab.FRAGMENT, { toolsOpen = false; vm.selectTab(EditorTab.FRAGMENT) })
            ui.bufferText.keys.sortedBy { it.ordinal }.forEach { id ->
                val t = EditorTab.of(id)
                val hasError = ui.diagnostics.any { it.severity == Severity.ERROR && it.pass == id.label }
                Pill(t.label + if (hasError) " !" else "", !toolsOpen && ui.tab == t, { toolsOpen = false; vm.selectTab(t) })
            }
            Pill("Vertex", !toolsOpen && ui.tab == EditorTab.VERTEX, { toolsOpen = false; vm.selectTab(EditorTab.VERTEX) })
            Pill("Tools", toolsOpen, { toolsOpen = !toolsOpen })
        }

        if (toolsOpen) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                    StudioToolsPanel(vm, host.tools)
                    androidx.compose.foundation.layout.Spacer(Modifier.height(24.dp))
                }
            }
        } else {
            if (ui.find.visible) FindBar(vm)

            CodeEditor(
                value = currentText,
                onValueChange = vm::onEditorChange,
                lineSeverity = lineSeverity,
                matches = ui.find.matches,
                matchLength = ui.find.query.length,
                currentMatch = ui.find.current,
                scrollRequest = ui.scroll,
                readOnly = readOnly,
                modifier = Modifier.weight(1f).fillMaxWidth(),
            )

            if (!readOnly) SymbolBar(vm)
        }

        if (!imeVisible && !toolsOpen) {
            BottomPanel(vm, host, stats.value.let { Triple(it.timeSeconds, it.width to it.height, it.frame) }, Modifier.fillMaxWidth().heightIn(max = 220.dp))
        }
    }
}

@Composable
private fun Toolbar(vm: StudioViewModel) {
    val ui = vm.ui
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        PrimaryButton("Run", { vm.run() }, Modifier.height(40.dp).padding(horizontal = 4.dp), icon = R.drawable.ic_play)
        SecondaryButton("Stop", { vm.stop() }, Modifier.height(40.dp).padding(horizontal = 4.dp), enabled = ui.playing, icon = R.drawable.ic_stop)
        SIconButton(R.drawable.ic_undo, "Undo", { vm.undo() }, enabled = ui.canUndo)
        SIconButton(R.drawable.ic_redo, "Redo", { vm.redo() }, enabled = ui.canRedo)
        SIconButton(R.drawable.ic_format, "Format code", { vm.format() })
        SIconButton(R.drawable.ic_search, "Find in code", { vm.toggleFind() })
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 8.dp)) {
            Text("Auto", style = MaterialTheme.typography.labelMedium)
            Switch(
                checked = ui.autoCompile,
                onCheckedChange = vm::setAutoCompile,
                modifier = Modifier.padding(start = 6.dp).semantics { contentDescription = "Compile automatically while typing" },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black, checkedTrackColor = Color.White,
                    uncheckedThumbColor = ShaderArtColors.TextSecondary, uncheckedTrackColor = ShaderArtColors.Graphite,
                ),
            )
        }
    }
}

@Composable
private fun CodeMenu(vm: StudioViewModel, host: CodeStudioHost, onShadertoy: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        SIconButton(R.drawable.ic_more, "More actions", { open = true })
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("Import shader file") }, onClick = { open = false; host.onImport() })
            DropdownMenuItem(text = { Text("Import from Shadertoy…") }, onClick = { open = false; onShadertoy() })
            DropdownMenuItem(text = { Text("Export Image pass (.frag)") }, onClick = { open = false; host.onExportSource("frag", vm.ui.fragment.text) })
            DropdownMenuItem(text = { Text("Export Image pass (.glsl)") }, onClick = { open = false; host.onExportSource("glsl", vm.ui.fragment.text) })
            DropdownMenuItem(text = { Text("Export vertex (.vert)") }, onClick = { open = false; host.onExportSource("vert", vm.ui.vertex.text) })
            DropdownMenuItem(text = { Text("Export project (.shaderart)") }, onClick = { open = false; host.onExportArchive() })
            DropdownMenuItem(text = { Text("Export image, GIF or video…") }, onClick = { open = false; host.onExportImage() })
            HorizontalDivider()
            host.templates.forEach { t ->
                DropdownMenuItem(text = { Text("New from template: ${t.name}") }, onClick = { open = false; host.onNewFromTemplate(t.id) })
            }
        }
    }
}

@Composable
private fun FindBar(vm: StudioViewModel) {
    val f = vm.ui.find
    Row(
        Modifier.fillMaxWidth().background(ShaderArtColors.Charcoal).padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = f.query,
            onValueChange = { vm.updateFind(it) },
            singleLine = true,
            placeholder = { Text("Find") },
            modifier = Modifier.weight(1f).semantics { contentDescription = "Search text" },
            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Monospace),
        )
        Text(
            if (f.matches.isEmpty()) (if (f.query.isEmpty()) "" else "0") else "${f.current + 1}/${f.matches.size}",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(horizontal = 8.dp),
        )
        Pill("Aa", f.caseSensitive, { vm.updateFind(f.query, !f.caseSensitive) })
        SIconButton(R.drawable.ic_expand_less, "Previous match", { vm.findPrevious() }, enabled = f.matches.isNotEmpty())
        SIconButton(R.drawable.ic_expand_more, "Next match", { vm.findNext() }, enabled = f.matches.isNotEmpty())
        SIconButton(R.drawable.ic_close, "Close search", { vm.toggleFind() })
    }
}

private val SYMBOLS = listOf("{", "}", "(", ")", "[", "]", ";", ",", ".", "=", "+", "-", "*", "/", "<", ">", "?", ":", "!", "&", "|")

/** Completion suggestions followed by quick-insert symbols for the phone keyboard. */
@Composable
private fun SymbolBar(vm: StudioViewModel) {
    val ui = vm.ui
    LazyRow(
        modifier = Modifier.fillMaxWidth().background(ShaderArtColors.Charcoal).padding(vertical = 4.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        items(ui.suggestions, key = { "s_$it" }) { s ->
            Pill(s, true, { vm.applySuggestion(s) })
        }
        item(key = "tab") { Pill("Tab", false, { vm.insertText("  ") }) }
        items(SYMBOLS, key = { "y_$it" }) { sym -> Pill(sym, false, { vm.insertText(sym) }) }
    }
}

@Composable
private fun BottomPanel(vm: StudioViewModel, host: CodeStudioHost, live: Triple<Float, Pair<Int, Int>, Long>, modifier: Modifier) {
    val ui = vm.ui
    Column(modifier.background(ShaderArtColors.NearBlack)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val errors = ui.diagnostics.count { it.severity == Severity.ERROR }
            val warnings = ui.diagnostics.count { it.severity == Severity.WARNING }
            Pill("Output" + if (errors > 0) " ($errors)" else if (warnings > 0) " ($warnings)" else "", ui.bottom == BottomTab.OUTPUT, { vm.setBottom(BottomTab.OUTPUT) })
            Pill("Uniforms", ui.bottom == BottomTab.UNIFORMS, { vm.setBottom(BottomTab.UNIFORMS) })
            Pill("Info", ui.bottom == BottomTab.INFO, { vm.setBottom(BottomTab.INFO) })
        }
        when (ui.bottom) {
            BottomTab.OUTPUT -> OutputTab(vm)
            BottomTab.UNIFORMS -> UniformsTab(vm, live)
            BottomTab.INFO -> InfoTab(vm, host, live)
        }
    }
}

@Composable
private fun OutputTab(vm: StudioViewModel) {
    val ui = vm.ui
    val status = when {
        ui.needsRun -> "Not run yet. Press Run to compile."
        ui.compiling -> "Compiling…"
        ui.compileOk == true -> "Compiled and linked by the GPU driver in ${ui.lastCompileMs} ms."
        ui.compileOk == false -> "Compilation failed. The previous working shader keeps running."
        else -> "Waiting for the first compile."
    }
    val statusColor = when (ui.compileOk) {
        true -> ShaderArtColors.Success
        false -> ShaderArtColors.Error
        null -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        item(key = "status") {
            Text(status, style = MaterialTheme.typography.bodySmall, color = if (ui.needsRun || ui.compiling) MaterialTheme.colorScheme.onSurfaceVariant else statusColor, modifier = Modifier.padding(vertical = 4.dp))
        }
        if (ui.sourceChanged && !ui.compiling && !ui.autoCompile) {
            item(key = "stale") { Text("The code changed since the last compile.", style = MaterialTheme.typography.bodySmall, color = ShaderArtColors.Warning) }
        }
        items(ui.diagnostics.size, key = { "d$it" }) { i ->
            DiagnosticRow(ui.diagnostics[i]) { d -> d.line?.let { vm.goToLine(d.stage, it, d.pass) } }
        }
    }
}

@Composable
private fun DiagnosticRow(d: ShaderDiagnostic, onClick: (ShaderDiagnostic) -> Unit) {
    val color = when (d.severity) {
        Severity.ERROR -> ShaderArtColors.Error
        Severity.WARNING -> ShaderArtColors.Warning
        Severity.INFO -> ShaderArtColors.TextSecondary
    }
    val icon = when (d.severity) {
        Severity.ERROR -> R.drawable.ic_error
        Severity.WARNING -> R.drawable.ic_warning
        Severity.INFO -> R.drawable.ic_info
    }
    val where = (d.line?.let { "${d.stage.label} line $it" } ?: d.stage.label).let { w -> if (d.pass != null) "${d.pass} · $w" else w }
    Row(
        Modifier.fillMaxWidth().then(if (d.line != null) Modifier.clickableWithRole { onClick(d) } else Modifier).padding(vertical = 4.dp)
            .semantics { contentDescription = "${d.severity.name.lowercase()}, $where: ${d.message}" },
        verticalAlignment = Alignment.Top,
    ) {
        SIcon(icon, null, size = 18.dp, tint = color, modifier = Modifier.padding(top = 2.dp))
        Column(Modifier.padding(start = 8.dp)) {
            Text(where, style = MaterialTheme.typography.labelSmall, color = color)
            Text(d.message, style = MaterialTheme.typography.bodySmall.copy(fontFamily = CodeFont))
        }
    }
}

@Composable
private fun UniformsTab(vm: StudioViewModel, live: Triple<Float, Pair<Int, Int>, Long>) {
    val ui = vm.ui
    val source = when (ui.tab) {
        EditorTab.VERTEX -> ui.vertex.text
        EditorTab.FRAGMENT -> ui.fragment.text
        else -> ui.bufferText[ui.tab.pass]?.text ?: ""
    }
    val declared = remember(source) { ShaderMetadataParser.declaredUniforms(source) }
    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        if (declared.isEmpty()) {
            item(key = "none") { Text("No uniforms are declared in this pass.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 8.dp)) }
        }
        items(declared.size, key = { "u$it" }) { i ->
            val u = declared[i]
            val def = ui.params.firstOrNull { it.uniform == u.name }
            val value = when {
                u.name == "u_time" -> "%.2f".format(Locale.US, live.first)
                u.name == "u_resolution" -> "${live.second.first} × ${live.second.second}"
                u.name == "u_frame" -> live.third.toString()
                u.name == "u_speed" -> "%.2f".format(Locale.US, ui.speed)
                u.name == "u_zoom" -> "%.2f".format(Locale.US, ui.zoom)
                u.name in ShaderMetadataParser.SYSTEM_UNIFORMS -> "set by the app"
                def != null -> (ui.values[def.id] ?: def.defaults).joinToString(", ") { "%.3f".format(Locale.US, it).trimEnd('0').trimEnd('.') }
                else -> "no control (unsupported type)"
            }
            val kind = when {
                u.name in ShaderMetadataParser.SYSTEM_UNIFORMS -> "system"
                def != null -> if (def.type == ParamType.COLOR) "colour control" else "control"
                else -> "unmapped"
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text("${u.type} ${u.name}", style = MaterialTheme.typography.bodySmall.copy(fontFamily = CodeFont))
                    Text("line ${u.line} · $kind", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(value, style = MaterialTheme.typography.bodySmall.copy(fontFamily = CodeFont), modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@Composable
private fun InfoTab(vm: StudioViewModel, host: CodeStudioHost, live: Triple<Float, Pair<Int, Int>, Long>) {
    val ui = vm.ui
    val caps = host.capabilities()
    val lines = remember(ui.fragment.text) { ui.fragment.text.count { it == '\n' } + 1 }
    val rows = buildList {
        add("Shader language" to "GLSL ES 3.00 (#version 300 es)")
        add("Fragment" to "$lines lines · ${ui.fragment.text.toByteArray().size} bytes")
        add("Last compile" to if (ui.compileOk == null) "not yet" else "${ui.lastCompileMs} ms")
        add("Render size" to "${live.second.first} × ${live.second.second} px at ${(ui.quality * 100).toInt()}%")
        if (caps != null) {
            add("GPU" to caps.renderer)
            add("OpenGL ES" to caps.glVersion)
            add("GLSL" to caps.glslVersion)
        } else {
            add("GPU" to "available after the first frame")
        }
    }
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 12.dp)) {
        rows.forEach { (k, v) ->
            Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                Text(k, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(110.dp))
                Text(v, style = MaterialTheme.typography.bodySmall)
            }
        }
        ViewControls(vm)
    }
}

/** Paste Shadertoy code or its exported JSON, or choose a text file. Nothing is run until the person presses Run. */
@Composable
private fun ShadertoyDialog(onImport: (String) -> Unit, onPickFile: ((String) -> Unit) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ShaderArtColors.Charcoal,
        title = { Text("Import from Shadertoy") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Paste a Shadertoy shader's code (a mainImage function, optionally with Common and Buffer A–D code) or its exported JSON. " +
                        "Buffers, noise and sound inputs are converted; cubemaps, video, webcam, keyboard and sound shaders are not supported and are reported as warnings. " +
                        "Shaders on Shadertoy carry their authors' licences (by default CC BY-NC-SA 3.0): check them before you reuse or share the result.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedTextField(
                    value = text,
                    onValueChange = { if (it.length <= 400_000) text = it },
                    placeholder = { Text("void mainImage(out vec4 fragColor, in vec2 fragCoord) { … }") },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 240.dp).semantics { contentDescription = "Shadertoy code" },
                    textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                )
                SecondaryButton("Choose a text or JSON file", { onPickFile { picked -> text = picked } }, Modifier.fillMaxWidth(), icon = R.drawable.ic_import)
            }
        },
        confirmButton = { androidx.compose.material3.TextButton(onClick = { onImport(text) }, enabled = text.isNotBlank()) { Text("Import") } },
        dismissButton = { androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
