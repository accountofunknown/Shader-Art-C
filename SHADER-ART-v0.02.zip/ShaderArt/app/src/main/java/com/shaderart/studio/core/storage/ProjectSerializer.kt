package com.shaderart.studio.core.storage

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.json.asFloat
import com.shaderart.studio.core.json.asList
import com.shaderart.studio.core.json.asObject
import com.shaderart.studio.core.json.optBool
import com.shaderart.studio.core.json.optFloat
import com.shaderart.studio.core.json.optObject
import com.shaderart.studio.core.json.optString
import com.shaderart.studio.core.json.reqLong
import com.shaderart.studio.core.json.reqString
import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.Easing
import com.shaderart.studio.core.model.Keyframe
import com.shaderart.studio.core.model.MultipassCheck
import com.shaderart.studio.core.model.MultipassLimits
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.model.TextureAsset
import com.shaderart.studio.core.model.TextureNames
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.model.TimelineTrack
import com.shaderart.studio.core.model.ParamJson
import com.shaderart.studio.core.model.ParamValidator
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck

/** Reads and writes the project manifest. Shader sources are stored beside it as separate files. */
object ProjectSerializer {
    const val CURRENT_FORMAT = ProjectMigrations.CURRENT_FORMAT

    fun toManifestMap(p: ShaderProject): Map<String, Any?> = linkedMapOf(
        "formatVersion" to CURRENT_FORMAT,
        "id" to p.id,
        "name" to p.name,
        "type" to p.type.name,
        "createdAt" to p.createdAt,
        "modifiedAt" to p.modifiedAt,
        "shaderVersion" to p.shaderVersion,
        "presetOrigin" to p.presetOrigin,
        "params" to p.params.map { ParamJson.toMap(it) },
        "values" to p.values,
        "animation" to linkedMapOf(
            "playing" to p.animation.playing,
            "speed" to p.animation.speed,
            "time" to p.animation.time,
        ),
        "render" to linkedMapOf(
            "qualityScale" to p.render.qualityScale,
            "previewWidth" to p.render.previewWidth,
            "previewHeight" to p.render.previewHeight,
            "zoom" to p.render.zoom,
        ),
        "buffers" to p.buffers.map { b -> linkedMapOf("id" to b.id.key, "channels" to b.channels.map { it.toText() }) },
        "imageChannels" to p.imageChannels.map { it.toText() },
        "textures" to p.textures.map { linkedMapOf("name" to it.name, "width" to it.width, "height" to it.height) },
        "timeline" to linkedMapOf(
            "duration" to p.timeline.durationSeconds,
            "loop" to p.timeline.loop,
            "enabled" to p.timeline.enabled,
            "tracks" to p.timeline.tracks.map { t ->
                linkedMapOf(
                    "param" to t.paramId,
                    "component" to t.component,
                    "keys" to t.keys.map { k -> linkedMapOf("t" to k.t, "v" to k.v, "easing" to k.easing.name) },
                )
            },
        ),
        "postStack" to p.postStack.map { linkedMapOf("effect" to it.effectId, "enabled" to it.enabled, "values" to it.values) },
    )

    fun toManifestJson(p: ShaderProject, pretty: Boolean = true): String = MiniJson.write(toManifestMap(p), pretty)

    /**
     * Parses and fully validates a manifest. Throws [ProjectFormatException] (or the
     * [UnsupportedProjectVersionException] subclass) for anything malformed or out of range.
     */
    fun fromManifestJson(
        text: String,
        vertexSource: String,
        fragmentSource: String,
        /** Buffer sources keyed by pass key ("a".."d"). Required for every buffer the manifest lists. */
        bufferSources: Map<String, String> = emptyMap(),
    ): ShaderProject {
        try {
            val raw = MiniJson.parseObject(text)
            val m = ProjectMigrations.migrate(raw)

            val id = m.reqString("id")
            if (!ImportLimits.isSafeProjectId(id)) throw ProjectFormatException("Project id contains unsafe characters")
            val name = m.reqString("name").trim()
            if (name.isEmpty() || name.length > ImportLimits.MAX_NAME_LENGTH) {
                throw ProjectFormatException("Project name must be 1-${ImportLimits.MAX_NAME_LENGTH} characters")
            }
            val typeName = m.reqString("type")
            val type = ProjectType.parse(typeName) ?: throw ProjectFormatException("Unknown project type '$typeName'")
            val created = m.reqLong("createdAt")
            val modified = m.reqLong("modifiedAt")
            val shaderVersion = m.optString("shaderVersion") ?: "300 es"
            if (shaderVersion != "300 es") throw ProjectFormatException("Unsupported shader version '$shaderVersion'")
            val origin = m.optString("presetOrigin")
            if ((origin?.length ?: 0) > 64) throw ProjectFormatException("Preset origin is too long")

            val paramList = m["params"].asList("params")
            if (paramList.size > ParamValidator.MAX_PARAMS) throw ProjectFormatException("Too many parameters")
            val params = paramList.mapIndexed { i, e -> ParamJson.fromMap(e.asObject("params[$i]")) }
            val paramErrors = ParamValidator.validate(params)
            if (paramErrors.isNotEmpty()) throw ProjectFormatException(paramErrors.first())

            val valuesObj = m["values"]?.asObject("values") ?: emptyMap()
            val values = LinkedHashMap<String, List<Float>>()
            for ((k, v) in valuesObj) values[k] = v.asList("values.$k").map { it.asFloat("values.$k") }
            val valueErrors = ParamValidator.validateValues(params, values)
            if (valueErrors.isNotEmpty()) throw ProjectFormatException(valueErrors.first())
            for (p in params) values.putIfAbsent(p.id, p.defaults)

            val anim = m.optObject("animation")
            val speed = anim?.optFloat("speed", 1f) ?: 1f
            val time = anim?.optFloat("time", 0f) ?: 0f
            if (speed < 0f || speed > 10f) throw ProjectFormatException("Animation speed must be between 0 and 10")
            if (time < 0f || time > 1.0e7f) throw ProjectFormatException("Animation time is out of range")
            val animation = AnimationConfig(anim?.optBool("playing", true) ?: true, speed, time)

            val r = m.optObject("render")
            val quality = r?.optFloat("qualityScale", 1f) ?: 1f
            val pw = r?.optFloat("previewWidth", 0f) ?: 0f
            val ph = r?.optFloat("previewHeight", 0f) ?: 0f
            val zoom = r?.optFloat("zoom", 1f) ?: 1f
            if (quality < 0.25f || quality > 1f) throw ProjectFormatException("Quality scale must be between 0.25 and 1")
            if (pw < 0f || ph < 0f || pw > ImportLimits.MAX_RENDER_DIMENSION || ph > ImportLimits.MAX_RENDER_DIMENSION) {
                throw ProjectFormatException("Preview dimensions are out of range")
            }
            if (zoom < 0.01f || zoom > 1000f) throw ProjectFormatException("Zoom is out of range")
            val render = RenderSettings(quality, pw.toInt(), ph.toInt(), zoom)

            val sourceProblems = GlslSourceCheck.check(vertexSource, "Vertex") + GlslSourceCheck.check(fragmentSource, "Fragment")
            if (sourceProblems.isNotEmpty()) throw ProjectFormatException(sourceProblems.first())

            val buffers = parseBuffers(m, bufferSources)
            val imageChannels = parseChannels(m["imageChannels"], "imageChannels")
            val textures = parseTextures(m)
            val multipassProblems = MultipassCheck.check(buffers, imageChannels, textures)
            if (multipassProblems.isNotEmpty()) throw ProjectFormatException(multipassProblems.first())
            val timeline = parseTimeline(m, params)
            val post = parsePost(m)

            return ShaderProject(
                id = id,
                name = name,
                type = type,
                createdAt = created,
                modifiedAt = modified,
                vertexSource = vertexSource,
                fragmentSource = fragmentSource,
                shaderVersion = shaderVersion,
                params = params,
                values = values,
                animation = animation,
                render = render,
                presetOrigin = origin,
                formatVersion = CURRENT_FORMAT,
                buffers = buffers,
                imageChannels = imageChannels,
                textures = textures,
                timeline = timeline,
                postStack = post,
            )
        } catch (e: JsonException) {
            throw ProjectFormatException(e.message ?: "Invalid project data")
        }
    }

    private fun parseChannels(raw: Any?, what: String): List<ChannelBinding> {
        if (raw == null) return ChannelBinding.noneChannels()
        val list = raw.asList(what)
        if (list.size != ChannelBinding.CHANNEL_COUNT) throw ProjectFormatException("$what must have exactly ${ChannelBinding.CHANNEL_COUNT} entries")
        return list.mapIndexed { i, e ->
            val text = e as? String ?: throw ProjectFormatException("$what[$i] must be text")
            ChannelBinding.parse(text) ?: throw ProjectFormatException("$what[$i] has an unknown input '${text.take(30)}'")
        }
    }

    private fun parseBuffers(m: Map<String, Any?>, sources: Map<String, String>): List<PassSpec> {
        val list = m["buffers"]?.asList("buffers") ?: return emptyList()
        if (list.size > PassId.BUFFERS.size) throw ProjectFormatException("Too many buffers")
        return list.mapIndexed { i, e ->
            val o = e.asObject("buffers[$i]")
            val key = o.reqString("id")
            val id = PassId.parseKey(key)?.takeIf { it.isBuffer } ?: throw ProjectFormatException("Unknown buffer '${key.take(10)}'")
            val src = sources[id.key] ?: throw ProjectFormatException("The source of ${id.label} is missing")
            val problems = GlslSourceCheck.check(src, id.label)
            if (problems.isNotEmpty()) throw ProjectFormatException(problems.first())
            PassSpec(id, src, parseChannels(o["channels"], "buffers[$i].channels"))
        }
    }

    private fun parseTextures(m: Map<String, Any?>): List<TextureAsset> {
        val list = m["textures"]?.asList("textures") ?: return emptyList()
        if (list.size > MultipassLimits.MAX_TEXTURES) throw ProjectFormatException("Too many textures")
        return list.mapIndexed { i, e ->
            val o = e.asObject("textures[$i]")
            val name = o.reqString("name")
            if (!TextureNames.isValid(name)) throw ProjectFormatException("Texture name '${name.take(30)}' is not allowed")
            val w = o.reqLong("width").toInt()
            val h = o.reqLong("height").toInt()
            if (w !in 1..MultipassLimits.MAX_TEXTURE_SIDE || h !in 1..MultipassLimits.MAX_TEXTURE_SIDE) throw ProjectFormatException("Texture '$name' has an invalid size")
            TextureAsset(name, w, h)
        }
    }

    private fun parseTimeline(m: Map<String, Any?>, params: List<com.shaderart.studio.core.model.ParamDef>): Timeline {
        val o = m.optObject("timeline") ?: return Timeline()
        val duration = o.optFloat("duration", 8f)
        if (!(duration in 0.5f..600f)) throw ProjectFormatException("Timeline duration must be between 0.5 and 600 seconds")
        val tracksRaw = o["tracks"]?.asList("timeline.tracks") ?: emptyList()
        if (tracksRaw.size > MultipassLimits.MAX_TRACKS) throw ProjectFormatException("Too many timeline tracks")
        val tracks = ArrayList<TimelineTrack>()
        for ((i, e) in tracksRaw.withIndex()) {
            val t = e.asObject("timeline.tracks[$i]")
            val paramId = t.reqString("param")
            val def = params.firstOrNull { it.id == paramId } ?: continue // a parameter that no longer exists is dropped
            val component = t.optFloat("component", 0f).toInt()
            if (component !in def.defaults.indices) throw ProjectFormatException("Timeline track '$paramId' has an invalid component")
            val keysRaw = t["keys"]?.asList("timeline.tracks[$i].keys") ?: emptyList()
            if (keysRaw.size > MultipassLimits.MAX_KEYS) throw ProjectFormatException("Too many keyframes on '$paramId'")
            val keys = keysRaw.mapIndexed { j, ke ->
                val k = ke.asObject("keys[$j]")
                val time = k.optFloat("t", 0f)
                val v = k.optFloat("v", 0f)
                if (!time.isFinite() || !v.isFinite() || time < 0f || time > duration + 0.001f) throw ProjectFormatException("Keyframe $j of '$paramId' is out of range")
                Keyframe(time, v, Easing.parse(k.optString("easing") ?: "SMOOTH") ?: Easing.SMOOTH)
            }.sortedBy { it.t }
            tracks += TimelineTrack(paramId, component, keys)
        }
        return Timeline(duration, o.optBool("loop", true), o.optBool("enabled", true), tracks)
    }

    private fun parsePost(m: Map<String, Any?>): List<PostEffectInstance> {
        val list = m["postStack"]?.asList("postStack") ?: return emptyList()
        if (list.size > MultipassLimits.MAX_POST) throw ProjectFormatException("Too many post effects")
        return list.mapIndexedNotNull { i, e ->
            val o = e.asObject("postStack[$i]")
            val inst = PostEffectInstance(
                o.reqString("effect"),
                o.optBool("enabled", true),
                (o["values"]?.asList("postStack[$i].values") ?: emptyList()).map { it.asFloat("postStack[$i].values") },
            )
            PostEffects.normalized(inst) // unknown effect ids (from a newer app) are skipped
        }
    }
}
