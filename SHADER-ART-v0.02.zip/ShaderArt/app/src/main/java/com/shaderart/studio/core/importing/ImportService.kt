package com.shaderart.studio.core.importing

import android.net.Uri
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.storage.ProjectRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Marker stored in ShaderProject.presetOrigin for imported projects. They are never run until the user presses Run. */
const val ORIGIN_IMPORTED = "imported"

data class ImportResult(val id: String, val type: ProjectType, val name: String)

class ImportService(
    private val io: UriIO,
    private val repo: ProjectRepository,
    private val presets: PresetRepository,
    private val clock: () -> Long = { System.currentTimeMillis() },
) {
    /** Imports a `.shaderart`, `.glsl`, `.frag` or `.vert` file. Throws [ImportException] with a readable message. */
    suspend fun import(uri: Uri): ImportResult = withContext(Dispatchers.IO) {
        val name = io.displayName(uri)
        val ext = SourceImport.extensionOf(name)
        val saved: ShaderProject = if (ext == "shaderart") {
            val archive = io.openInput(uri).use { ShaderArchive.read(it) }
            repo.importProject(untrusted(archive.project), archive.preview, archive.textures)
        } else {
            val bytes = io.readLimited(uri, ImportLimits.MAX_SOURCE_BYTES)
            val project = SourceImport.fromBytes(
                fileName = name,
                bytes = bytes,
                defaultVertex = presets.vertexSource,
                defaultFragment = presets.templateSource("default"),
                now = clock(),
            )
            repo.importProject(untrusted(project), null)
        }
        ImportResult(saved.id, saved.type, saved.name)
    }

    /** Imported projects start paused and flagged, so imported GLSL only runs after an explicit Run. */
    private fun untrusted(p: ShaderProject) = p.copy(
        presetOrigin = ORIGIN_IMPORTED,
        animation = p.animation.copy(playing = false),
    )
}
