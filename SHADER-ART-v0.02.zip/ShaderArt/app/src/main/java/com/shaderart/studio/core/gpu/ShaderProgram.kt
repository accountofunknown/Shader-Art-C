package com.shaderart.studio.core.gpu

import android.opengl.GLES20
import android.opengl.GLES30

/** A uniform the linker kept in the program (unused uniforms are optimised away and never appear). */
class ActiveUniform(val name: String, val type: Int, val size: Int, val location: Int)

/** A linked GL program plus the uniforms it actually uses. Must only be touched on the GL thread. */
class ShaderProgram(val id: Int, val uniforms: Map<String, ActiveUniform>) {
    fun use() = GLES30.glUseProgram(id)

    fun delete() {
        GLES30.glDeleteProgram(id)
    }

    fun has(name: String): Boolean = uniforms.containsKey(name)
}

object GlTypes {
    fun name(type: Int): String = when (type) {
        GLES20.GL_FLOAT -> "float"
        GLES20.GL_FLOAT_VEC2 -> "vec2"
        GLES20.GL_FLOAT_VEC3 -> "vec3"
        GLES20.GL_FLOAT_VEC4 -> "vec4"
        GLES20.GL_INT -> "int"
        GLES20.GL_INT_VEC2 -> "ivec2"
        GLES20.GL_INT_VEC3 -> "ivec3"
        GLES20.GL_INT_VEC4 -> "ivec4"
        GLES30.GL_UNSIGNED_INT -> "uint"
        GLES20.GL_BOOL -> "bool"
        GLES20.GL_FLOAT_MAT2 -> "mat2"
        GLES20.GL_FLOAT_MAT3 -> "mat3"
        GLES20.GL_FLOAT_MAT4 -> "mat4"
        GLES20.GL_SAMPLER_2D -> "sampler2D"
        GLES20.GL_SAMPLER_CUBE -> "samplerCube"
        else -> "type 0x" + Integer.toHexString(type)
    }
}
