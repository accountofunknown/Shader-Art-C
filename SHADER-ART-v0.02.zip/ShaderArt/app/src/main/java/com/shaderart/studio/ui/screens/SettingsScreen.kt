package com.shaderart.studio.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.shaderart.studio.BuildConfig
import com.shaderart.studio.core.gpu.DeviceGles
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.ui.components.Pill
import com.shaderart.studio.ui.components.ScreenTitle
import com.shaderart.studio.ui.components.SectionLabel
import com.shaderart.studio.ui.theme.ShaderArtColors

@Composable
fun SettingsScreen(lib: LibraryViewModel) {
    val settings by lib.settings.collectAsStateWithLifecycle()
    val caps by lib.lastCapabilities.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
        ScreenTitle("Settings")

        SectionLabel("Rendering quality")
        Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0.25f to "25%", 0.5f to "50%", 0.75f to "75%", 1f to "100%").forEach { (q, label) ->
                Pill(label, settings.qualityScale == q, { lib.setQuality(q) })
            }
        }
        Text(
            "Default for new projects. Lower values draw fewer pixels, which helps heavy shaders on older phones. You can change it per project in the studios. Exported images are always rendered at full size.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )

        SectionLabel("Performance")
        SwitchRow("Show performance panel", "FPS, frame time and render size over the preview.", settings.showPerformance, lib::setShowPerformance)
        SwitchRow("Limit to 30 FPS", "Uses less battery and heat.", settings.limitTo30Fps, lib::setLimitTo30Fps)

        SectionLabel("This device")
        val reported = DeviceGles.describe(lib.reportedGlesVersion)
        InfoRow("Device", "${Build.MANUFACTURER} ${Build.MODEL}")
        InfoRow("Android", "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        InfoRow("OpenGL ES (reported)", reported + if (lib.gles3Supported) "" else " — below the required 3.0")
        val c = caps
        if (c != null) {
            InfoRow("GPU", c.renderer)
            InfoRow("Vendor", c.vendor)
            InfoRow("GL version", c.glVersion)
            InfoRow("GLSL version", c.glslVersion)
            InfoRow("Max texture size", "${c.maxTextureSize} px")
            InfoRow("Max export side", "${c.maxImageSide} px")
            InfoRow("Fragment uniform vectors", c.maxFragmentUniformVectors.toString())
        } else {
            Text(
                "GPU details appear here after a preview or export has run once on this device.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }

        SectionLabel("About")
        InfoRow("Version", "v${BuildConfig.VERSION_NAME} (build ${BuildConfig.VERSION_CODE})")
        InfoRow("Package", BuildConfig.APPLICATION_ID)
        Text(
            "SHADER ART works fully offline. It has no internet permission, no accounts, no analytics and no ads. Your shaders and images stay on this device unless you export or share them.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )

        SectionLabel("Permissions")
        Text(
            listOf(
                "Microphone: only if you choose the Microphone or Audio file sound source. Audio is analysed on the device, never recorded or sent.",
                "No internet, storage or location permission. Pictures, audio files and exports use Android's file picker.",
            ).joinToString("\n") { "• $it" },
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )

        SectionLabel("Not in v0.02")
        Text(
            listOf(
                "Capturing other apps' sound (system-wide playback)",
                "A sound track in exported videos (video is picture only)",
                "Cubemap, volume and video inputs; picture inputs from Shadertoy are replaced by noise",
                "Cloud sync and sharing",
            ).joinToString("\n") { "• $it" },
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
    }
}

@Composable
private fun SwitchRow(title: String, body: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black, checkedTrackColor = Color.White,
                uncheckedThumbColor = ShaderArtColors.TextSecondary, uncheckedTrackColor = ShaderArtColors.Graphite,
            ),
            modifier = Modifier.semantics { contentDescription = title },
        )
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 3.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(140.dp))
        Text(value, style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
    }
}
