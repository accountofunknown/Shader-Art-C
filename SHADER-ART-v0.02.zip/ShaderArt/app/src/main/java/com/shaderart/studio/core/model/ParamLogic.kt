package com.shaderart.studio.core.model

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

/** Pure helpers for parameter values: defaults, clamping, randomize and variation. */
object ParamLogic {
    const val GROUP_POST = "Post effects"
    const val GROUP_QUALITY = "Quality"
    const val GROUP_VIEW = "View"

    fun defaults(params: List<ParamDef>): Map<String, List<Float>> = params.associate { it.id to it.defaults }

    /** Clamps to the parameter range and snaps to its step. Non-finite input falls back to the default. */
    fun snap(def: ParamDef, raw: Float, index: Int = 0): Float {
        if (!raw.isFinite()) return def.defaults.getOrElse(index) { def.min }
        var v = raw.coerceIn(def.min, def.max)
        when (def.type) {
            ParamType.INT -> v = v.roundToInt().toFloat()
            ParamType.BOOL -> v = if (v >= 0.5f) 1f else 0f
            ParamType.FLOAT -> if (def.step > 0f) v = ((v - def.min) / def.step).roundToInt() * def.step + def.min
            ParamType.COLOR -> {}
        }
        v = v.coerceIn(def.min, def.max)
        return (v * 10000f).roundToInt() / 10000f
    }

    fun withValue(values: Map<String, List<Float>>, def: ParamDef, index: Int, raw: Float): Map<String, List<Float>> {
        val current = values[def.id] ?: def.defaults
        val next = current.toMutableList()
        while (next.size < def.defaults.size) next.add(def.defaults[next.size])
        if (index !in next.indices) return values
        next[index] = snap(def, raw, index)
        return values + (def.id to next)
    }

    /** Fills missing entries with defaults, drops unknown ids, repairs size and range. */
    fun normalize(params: List<ParamDef>, values: Map<String, List<Float>>): Map<String, List<Float>> {
        val out = LinkedHashMap<String, List<Float>>()
        for (p in params) {
            val v = values[p.id]
            out[p.id] = if (v == null || v.size != p.defaults.size) p.defaults
            else v.mapIndexed { i, x -> snap(p, x, i) }
        }
        return out
    }

    /** Parameters that Randomize / Variation may change. Post effects, quality and view stay put. */
    fun isRandomizable(def: ParamDef): Boolean =
        def.group != GROUP_POST && def.group != GROUP_QUALITY && def.group != GROUP_VIEW &&
            def.type != ParamType.BOOL && !def.name.startsWith("Background")

    fun randomize(params: List<ParamDef>, values: Map<String, List<Float>>, random: Random): Map<String, List<Float>> {
        val out = LinkedHashMap(values)
        for (p in params) {
            if (!isRandomizable(p)) continue
            out[p.id] = when (p.type) {
                ParamType.COLOR -> {
                    val h = random.nextFloat()
                    val rgb = hsvToRgb(h, 0.55f + 0.4f * random.nextFloat(), 0.75f + 0.25f * random.nextFloat())
                    rgb.map { snap(p, it) }
                }
                ParamType.FLOAT, ParamType.INT -> {
                    val span = p.max - p.min
                    val v = if (p.uniform == "u_seed") p.min + span * random.nextFloat()
                    else p.min + span * (0.1f + 0.65f * random.nextFloat())
                    listOf(snap(p, v))
                }
                ParamType.BOOL -> out[p.id] ?: p.defaults
            }
        }
        return out
    }

    /** A gentle random variation of the current look, with a fresh seed. */
    fun variation(params: List<ParamDef>, values: Map<String, List<Float>>, random: Random): Map<String, List<Float>> {
        val out = LinkedHashMap(values)
        for (p in params) {
            if (!isRandomizable(p)) continue
            val cur = values[p.id] ?: p.defaults
            out[p.id] = when (p.type) {
                ParamType.COLOR -> {
                    if (cur.size < 3) cur else {
                        val hsv = rgbToHsv(cur[0], cur[1], cur[2])
                        val h = (hsv[0] + (random.nextFloat() - 0.5f) * 0.12f + 1f) % 1f
                        val s = (hsv[1] + (random.nextFloat() - 0.5f) * 0.16f).coerceIn(0f, 1f)
                        val v = (hsv[2] + (random.nextFloat() - 0.5f) * 0.16f).coerceIn(0.2f, 1f)
                        hsvToRgb(h, s, v).map { snap(p, it) }
                    }
                }
                else -> {
                    if (p.uniform == "u_seed") listOf(snap(p, p.min + (p.max - p.min) * random.nextFloat()))
                    else listOf(snap(p, cur[0] + (random.nextFloat() - 0.5f) * 2f * (p.max - p.min) * 0.08f))
                }
            }
        }
        return out
    }

    fun rgbToHsv(r: Float, g: Float, b: Float): FloatArray {
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        val h = when {
            d == 0f -> 0f
            mx == r -> (((g - b) / d) % 6f) / 6f
            mx == g -> (((b - r) / d) + 2f) / 6f
            else -> (((r - g) / d) + 4f) / 6f
        }
        return floatArrayOf(if (h < 0f) h + 1f else h, if (mx == 0f) 0f else d / mx, mx)
    }

    fun hsvToRgb(h: Float, s: Float, v: Float): List<Float> {
        val hh = (h - Math.floor(h.toDouble()).toFloat()) * 6f
        val i = hh.toInt()
        val f = hh - i
        val p = v * (1f - s)
        val q = v * (1f - s * f)
        val t = v * (1f - s * (1f - f))
        return when (i % 6) {
            0 -> listOf(v, t, p)
            1 -> listOf(q, v, p)
            2 -> listOf(p, v, t)
            3 -> listOf(p, q, v)
            4 -> listOf(t, p, v)
            else -> listOf(v, p, q)
        }
    }

    fun approxEqual(a: Float, b: Float, eps: Float = 1e-4f): Boolean = abs(a - b) <= eps
}
