package com.shaderart.studio.core.export

import java.io.OutputStream

/**
 * Writes an animated GIF89a. Every frame gets its own 256-colour palette (median cut on a 15-bit histogram) with
 * optional ordered dithering, so shaders whose colours change over time keep their colours.
 *
 * Frames are added as ARGB int arrays (alpha is ignored). Memory use is one frame plus small tables.
 */
class GifEncoder(
    private val out: OutputStream,
    private val width: Int,
    private val height: Int,
    /** Frame delay in hundredths of a second (GIF's unit). 2 = 50 fps, 3 = ~33 fps, 4 = 25 fps. */
    private val delayCentis: Int,
    private val loop: Boolean = true,
    private val dither: Boolean = true,
) {
    private var started = false
    private var finished = false
    private val indices = ByteArray(width * height)
    private val histogram = IntArray(32768)
    private val lut = IntArray(32768)
    private val palette = ByteArray(256 * 3)
    private val lzw = LzwWriter()

    init {
        require(width in 1..65535 && height in 1..65535) { "Invalid GIF size" }
        require(delayCentis in 1..65535) { "Invalid GIF delay" }
    }

    fun addFrame(argb: IntArray) {
        check(!finished) { "GIF already finished" }
        require(argb.size == width * height) { "Frame has the wrong size" }
        if (!started) { writeHeader(); started = true }
        quantize(argb)
        writeFrame()
    }

    fun finish() {
        if (finished) return
        if (!started) throw IllegalStateException("A GIF needs at least one frame")
        out.write(0x3B)
        out.flush()
        finished = true
    }

    // ---- file structure ----

    private fun writeHeader() {
        out.write("GIF89a".toByteArray(Charsets.US_ASCII))
        writeShort(width); writeShort(height)
        out.write(0x70) // no global colour table, 8 bits colour resolution
        out.write(0); out.write(0)
        if (loop) {
            out.write(0x21); out.write(0xFF); out.write(11)
            out.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
            out.write(3); out.write(1); writeShort(0); out.write(0)
        }
    }

    private fun writeFrame() {
        // Graphic control extension
        out.write(0x21); out.write(0xF9); out.write(4)
        out.write(0x04) // disposal: do not dispose; no transparency
        writeShort(delayCentis)
        out.write(0); out.write(0)
        // Image descriptor with a 256-entry local colour table
        out.write(0x2C)
        writeShort(0); writeShort(0); writeShort(width); writeShort(height)
        out.write(0x87)
        out.write(palette)
        out.write(8) // LZW minimum code size
        lzw.encode(indices, out)
        out.write(0)
    }

    private fun writeShort(v: Int) { out.write(v and 0xFF); out.write((v ushr 8) and 0xFF) }

    // ---- quantization ----

    private fun quantize(argb: IntArray) {
        histogram.fill(0)
        for (i in argb.indices) {
            val c = argb[i]
            histogram[((c shr 19) and 0x1F shl 10) or ((c shr 11) and 0x1F shl 5) or ((c shr 3) and 0x1F)]++
        }
        buildPalette()
        for (y in 0 until height) {
            val row = y * width
            for (x in 0 until width) {
                var r = (argb[row + x] shr 16) and 0xFF
                var g = (argb[row + x] shr 8) and 0xFF
                var b = argb[row + x] and 0xFF
                if (dither) {
                    val d = BAYER[(y and 3) * 4 + (x and 3)] // -4..+3 in 8-bit units
                    r = (r + d).coerceIn(0, 255); g = (g + d).coerceIn(0, 255); b = (b + d).coerceIn(0, 255)
                }
                indices[row + x] = lut[((r shr 3) shl 10) or ((g shr 3) shl 5) or (b shr 3)].toByte()
            }
        }
    }

    private class Box(val colors: IntArray, var count: Long) {
        var rMin = 31; var rMax = 0; var gMin = 31; var gMax = 0; var bMin = 31; var bMax = 0
        fun measure() {
            rMin = 31; rMax = 0; gMin = 31; gMax = 0; bMin = 31; bMax = 0
            for (c in colors) {
                val r = c shr 10; val g = (c shr 5) and 31; val b = c and 31
                if (r < rMin) rMin = r; if (r > rMax) rMax = r
                if (g < gMin) gMin = g; if (g > gMax) gMax = g
                if (b < bMin) bMin = b; if (b > bMax) bMax = b
            }
        }
        val longest: Int get() = maxOf(rMax - rMin, gMax - gMin, bMax - bMin)
    }

    private fun buildPalette() {
        var n = 0
        for (i in histogram.indices) if (histogram[i] > 0) n++
        val all = IntArray(n)
        var k = 0
        var total = 0L
        for (i in histogram.indices) if (histogram[i] > 0) { all[k++] = i; total += histogram[i] }
        val boxes = ArrayList<Box>()
        boxes += Box(all, total).also { it.measure() }
        while (boxes.size < 256) {
            // Split the most populated box that still has more than one colour.
            var best = -1
            var bestScore = -1L
            for ((i, b) in boxes.withIndex()) {
                if (b.colors.size < 2) continue
                val score = b.count * (b.longest + 1)
                if (score > bestScore) { bestScore = score; best = i }
            }
            if (best < 0) break
            val box = boxes[best]
            val axis = when (box.longest) {
                box.rMax - box.rMin -> 0
                box.gMax - box.gMin -> 1
                else -> 2
            }
            fun key(c: Int) = when (axis) { 0 -> c shr 10; 1 -> (c shr 5) and 31; else -> c and 31 }
            val sorted = box.colors.sortedBy { key(it) }
            // Split at the population median.
            var acc = 0L
            var cut = 1
            val half = box.count / 2
            for ((i, c) in sorted.withIndex()) {
                acc += histogram[c]
                if (acc >= half) { cut = (i + 1).coerceIn(1, sorted.size - 1); break }
            }
            val a = sorted.subList(0, cut).toIntArray()
            val b = sorted.subList(cut, sorted.size).toIntArray()
            val ca = a.sumOf { histogram[it].toLong() }
            boxes[best] = Box(a, ca).also { it.measure() }
            boxes += Box(b, box.count - ca).also { it.measure() }
        }
        palette.fill(0)
        for ((i, b) in boxes.withIndex()) {
            var sr = 0L; var sg = 0L; var sb = 0L
            for (c in b.colors) {
                val w = histogram[c].toLong()
                sr += w * (c shr 10); sg += w * ((c shr 5) and 31); sb += w * (c and 31)
                lut[c] = i
            }
            val cnt = maxOf(1L, b.count)
            palette[i * 3] = expand5(sr / cnt)
            palette[i * 3 + 1] = expand5(sg / cnt)
            palette[i * 3 + 2] = expand5(sb / cnt)
        }
        // Colours that only appear through dithering offsets map to the nearest used neighbour.
        fillUnusedLut(boxes.size)
    }

    private fun expand5(v: Long): Byte = ((v.toInt() shl 3) or (v.toInt() shr 2)).coerceIn(0, 255).toByte()

    /** lut entries for 15-bit colours absent from the histogram: nearest palette colour (computed lazily, only for hits). */
    private fun fillUnusedLut(paletteSize: Int) {
        for (c in 0 until 32768) {
            if (histogram[c] > 0) continue
            lut[c] = nearest(c, paletteSize)
        }
    }

    private fun nearest(c: Int, size: Int): Int {
        val r = ((c shr 10) shl 3) or ((c shr 12) and 7)
        val g = (((c shr 5) and 31) shl 3) or (((c shr 7) and 7))
        val b = ((c and 31) shl 3) or ((c shr 2) and 7)
        var best = 0
        var bd = Int.MAX_VALUE
        for (i in 0 until size) {
            val dr = (palette[i * 3].toInt() and 0xFF) - r
            val dg = (palette[i * 3 + 1].toInt() and 0xFF) - g
            val db = (palette[i * 3 + 2].toInt() and 0xFF) - b
            val d = dr * dr * 3 + dg * dg * 4 + db * db * 2
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    // ---- LZW ----

    private class LzwWriter {
        private val hashKeys = IntArray(HASH_SIZE)
        private val hashCodes = IntArray(HASH_SIZE)
        private val block = ByteArray(255)
        private var blockLen = 0
        private var bitBuf = 0
        private var bitCount = 0

        fun encode(pixels: ByteArray, out: OutputStream) {
            val clear = 256
            val eoi = 257
            var next = 258
            var codeSize = 9
            hashKeys.fill(-1)
            blockLen = 0; bitBuf = 0; bitCount = 0

            fun emit(code: Int) {
                bitBuf = bitBuf or (code shl bitCount)
                bitCount += codeSize
                while (bitCount >= 8) {
                    block[blockLen++] = (bitBuf and 0xFF).toByte()
                    bitBuf = bitBuf ushr 8
                    bitCount -= 8
                    if (blockLen == 255) { out.write(255); out.write(block, 0, 255); blockLen = 0 }
                }
            }

            emit(clear)
            var prefix = pixels[0].toInt() and 0xFF
            for (i in 1 until pixels.size) {
                val c = pixels[i].toInt() and 0xFF
                val key = (prefix shl 8) or c
                var h = ((key * 2654435761L ushr 7).toInt() and 0x7FFFFFFF) % HASH_SIZE
                var found = -1
                while (hashKeys[h] != -1) {
                    if (hashKeys[h] == key) { found = hashCodes[h]; break }
                    h = if (h + 1 == HASH_SIZE) 0 else h + 1
                }
                if (found >= 0) {
                    prefix = found
                } else {
                    emit(prefix)
                    if (next < 4096) {
                        hashKeys[h] = key
                        hashCodes[h] = next
                        if (next == (1 shl codeSize) && codeSize < 12) codeSize++
                        next++
                    } else {
                        emit(clear)
                        hashKeys.fill(-1)
                        next = 258
                        codeSize = 9
                    }
                    prefix = c
                }
            }
            emit(prefix)
            // The decoder has added one entry per code after the first, so it is one entry ahead of this
            // encoder at this point and may already have widened its codes for the end-of-information code.
            if (next == (1 shl codeSize) && codeSize < 12) codeSize++
            emit(eoi)
            if (bitCount > 0) { block[blockLen++] = (bitBuf and 0xFF).toByte(); bitBuf = 0; bitCount = 0 }
            if (blockLen > 0) { out.write(blockLen); out.write(block, 0, blockLen); blockLen = 0 }
        }

        companion object { const val HASH_SIZE = 16411 }
    }

    private companion object {
        // 4x4 Bayer matrix scaled to about +-4 (8-bit units).
        val BAYER = intArrayOf(-4, 0, -3, 1, 2, -2, 3, -1, -3, 1, -4, 0, 3, -1, 2, -2)
    }
}
