package com.shaderart.studio.core.input

import kotlin.math.max
import kotlin.math.sqrt

/**
 * Multi-touch state published to shaders. Coordinates are 0..1 across the view, origin bottom-left.
 * Not thread-safe: the UI thread mutates it and publishes an immutable [TouchSnapshot] via [snapshot].
 */
class TouchState(private val tapOnRelease: Boolean = true, private val clock: () -> Float) {
    private class Pointer(var id: Int, var x: Float, var y: Float, var pressure: Float)

    private val pointers = ArrayList<Pointer>()
    private val taps = ArrayDeque<FloatArray>() // x, y, startTime, strength
    private var velX = 0f
    private var velY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0f
    private var hasLast = false
    private var downTime = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    fun down(id: Int, x: Float, y: Float, pressure: Float) {
        if (pointers.size >= MAX_POINTERS) return
        pointers.removeAll { it.id == id }
        pointers += Pointer(id, x, y, normPressure(pressure))
        if (pointers.size == 1) {
            downTime = clock(); downX = x; downY = y; moved = false
            lastX = x; lastY = y; lastT = downTime; hasLast = true
        }
    }

    fun move(id: Int, x: Float, y: Float, pressure: Float) {
        val p = pointers.firstOrNull { it.id == id } ?: return
        p.x = x; p.y = y; p.pressure = normPressure(pressure)
        if (pointers.first() === p) {
            val now = clock()
            val dt = now - lastT
            if (hasLast && dt > 1e-4f) {
                val vx = (x - lastX) / dt
                val vy = (y - lastY) / dt
                velX += (vx - velX) * 0.5f
                velY += (vy - velY) * 0.5f
            }
            lastX = x; lastY = y; lastT = now; hasLast = true
            val dx = x - downX
            val dy = y - downY
            if (sqrt(dx * dx + dy * dy) > 0.03f) moved = true
        }
    }

    fun up(id: Int) {
        val idx = pointers.indexOfFirst { it.id == id }
        if (idx < 0) return
        val p = pointers.removeAt(idx)
        val now = clock()
        if (tapOnRelease && idx == 0 && !moved && now - downTime < TAP_MAX_SECONDS) {
            addTap(p.x, p.y, now, p.pressure)
        }
        if (pointers.isEmpty()) { velX = 0f; velY = 0f; hasLast = false }
    }

    fun cancelAll() { pointers.clear(); velX = 0f; velY = 0f; hasLast = false }

    /** A tap also records on touch-down so ripples start immediately rather than on release. */
    fun addTap(x: Float, y: Float, time: Float, strength: Float) {
        taps.addLast(floatArrayOf(x, y, time, strength.coerceIn(0.2f, 1f)))
        while (taps.size > MAX_TAPS) taps.removeFirst()
    }

    fun snapshot(): TouchSnapshot {
        val pts = FloatArray(MAX_POINTERS * 4)
        for ((i, p) in pointers.withIndex()) {
            pts[i * 4] = p.x; pts[i * 4 + 1] = p.y; pts[i * 4 + 2] = p.pressure; pts[i * 4 + 3] = 1f
        }
        val tp = FloatArray(MAX_TAPS * 4)
        for ((i, t) in taps.withIndex()) {
            tp[i * 4] = t[0]; tp[i * 4 + 1] = t[1]; tp[i * 4 + 2] = t[2]; tp[i * 4 + 3] = t[3]
        }
        val first = pointers.firstOrNull()
        return TouchSnapshot(
            pointerCount = pointers.size,
            points = pts,
            pressure = first?.pressure ?: 0f,
            velX = if (first != null) velX else 0f,
            velY = if (first != null) velY else 0f,
            tapCount = taps.size,
            taps = tp,
        )
    }

    private fun normPressure(p: Float): Float = if (p.isFinite()) max(0.05f, p.coerceIn(0f, 1f)) else 0.5f

    companion object {
        const val MAX_POINTERS = 10
        const val MAX_TAPS = 8
        const val TAP_MAX_SECONDS = 0.35f
    }
}

/** Immutable touch data for one frame: [points] holds 10 vec4 (x, y, pressure, active), [taps] 8 vec4 (x, y, startTime, strength). */
class TouchSnapshot(
    val pointerCount: Int,
    val points: FloatArray,
    val pressure: Float,
    val velX: Float,
    val velY: Float,
    val tapCount: Int,
    val taps: FloatArray,
) {
    companion object {
        val EMPTY = TouchSnapshot(0, FloatArray(TouchState.MAX_POINTERS * 4), 0f, 0f, 0f, 0, FloatArray(TouchState.MAX_TAPS * 4))
    }
}
