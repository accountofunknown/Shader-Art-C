package com.shaderart.studio.feature.export

import android.net.Uri
import com.shaderart.studio.app.AppContainer
import com.shaderart.studio.core.export.AlphaMode
import com.shaderart.studio.core.export.AnimationLimits
import com.shaderart.studio.core.export.ExportConfig
import com.shaderart.studio.core.export.ExportException
import com.shaderart.studio.core.export.ExportLimits
import com.shaderart.studio.core.export.FileNaming
import com.shaderart.studio.core.export.GifConfig
import com.shaderart.studio.core.export.VideoConfig
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.core.model.ShaderProject
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class ExportKind(val label: String) { IMAGE("Image"), GIF("GIF"), VIDEO("Video (MP4)") }

data class ExportUi(
    val kind: ExportKind = ExportKind.IMAGE,
    /** Transparency of PNG images (JPEG is always opaque). */
    val alpha: AlphaMode = AlphaMode.OPAQUE,
    val gifFps: Int = 15,
    val gifSeconds: Float = 3f,
    val videoFps: Int = 30,
    val videoSeconds: Float = 8f,
    val resultMime: String = "image/png",
    val width: Int = 1080,
    val height: Int = 1920,
    val presetId: String? = "wp_916",
    val format: ImageFormat = ImageFormat.PNG,
    val quality: Int = 92,
    val timeSeconds: Float = 0f,
    val running: Boolean = false,
    val progress: Float = 0f,
    /** A finished export waiting in the share cache. Saving or sharing never re-renders. */
    val resultFile: File? = null,
    val resultName: String? = null,
    val resultWidth: Int = 0,
    val resultHeight: Int = 0,
    val error: String? = null,
    val info: String? = null,
    /** Real GPU limit, null until it has been queried. */
    val gpuMaxSide: Int? = null,
)

/**
 * Drives one image export at a time. The render itself runs in [com.shaderart.studio.core.export.ExportEngine];
 * this class holds the settings and the result between screens.
 */
class ExportController(
    private val container: AppContainer,
    private val scope: CoroutineScope,
    private val projectProvider: () -> ShaderProject?,
) {
    private val _ui = MutableStateFlow(ExportUi())
    val ui: StateFlow<ExportUi> = _ui.asStateFlow()
    private var job: Job? = null

    /** Looks up the GPU limits once. Safe to call repeatedly. */
    fun loadLimits() {
        if (_ui.value.gpuMaxSide != null) return
        scope.launch {
            val side = try { container.export.maxImageSide() } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
            if (side != null) _ui.update { it.copy(gpuMaxSide = side) }
        }
    }

    fun selectPreset(id: String) {
        val p = ExportLimits.PRESETS.firstOrNull { it.id == id } ?: return
        _ui.update { it.copy(width = p.width, height = p.height, presetId = id, error = null) }
    }

    fun setSize(width: Int, height: Int) {
        _ui.update { it.copy(width = width, height = height, presetId = null, error = null) }
    }

    fun setFormat(format: ImageFormat) = _ui.update { it.copy(format = format, error = null) }
    fun setKind(kind: ExportKind) = _ui.update { it.copy(kind = kind, error = null, info = null) }
    fun setAlpha(alpha: AlphaMode) = _ui.update { it.copy(alpha = alpha, error = null) }
    fun setGifFps(fps: Int) = _ui.update { it.copy(gifFps = fps.coerceIn(5, 30), error = null) }
    fun setGifSeconds(s: Float) = _ui.update { it.copy(gifSeconds = if (s.isFinite()) s.coerceIn(AnimationLimits.MIN_SECONDS, 30f) else 3f, error = null) }
    fun setVideoFps(fps: Int) = _ui.update { it.copy(videoFps = fps.coerceIn(1, 60), error = null) }
    fun setVideoSeconds(s: Float) = _ui.update { it.copy(videoSeconds = if (s.isFinite()) s.coerceIn(AnimationLimits.MIN_SECONDS, AnimationLimits.VIDEO_MAX_SECONDS) else 8f, error = null) }

    /** The size a GIF will really have: the chosen size scaled down to the GIF limit. */
    fun gifSize(): Pair<Int, Int> = _ui.value.let { AnimationLimits.fitGif(it.width, it.height) }

    /** The size a video will really have: within the video limits and even (H.264 needs even sizes). */
    fun videoSize(): Pair<Int, Int> {
        val s = _ui.value
        val scale = minOf(1.0, AnimationLimits.VIDEO_MAX_SIDE.toDouble() / s.width, AnimationLimits.VIDEO_MAX_SIDE.toDouble() / s.height)
        val w = AnimationLimits.even(maxOf(AnimationLimits.VIDEO_MIN_SIDE, (s.width * scale).toInt()))
        val h = AnimationLimits.even(maxOf(AnimationLimits.VIDEO_MIN_SIDE, (s.height * scale).toInt()))
        return w to h
    }
    fun setQuality(q: Int) = _ui.update { it.copy(quality = q.coerceIn(1, 100)) }
    fun setTime(seconds: Float) = _ui.update { it.copy(timeSeconds = if (seconds.isFinite()) seconds.coerceAtLeast(0f) else 0f) }
    fun clearResult() {
        _ui.value.resultFile?.delete()
        _ui.update { it.copy(resultFile = null, resultName = null, info = null) }
    }
    fun dismissMessages() = _ui.update { it.copy(error = null, info = null) }

    /** Reduces the requested size to the largest one this device can really render. */
    fun fitToDevice() {
        val s = _ui.value
        val (w, h) = ExportLimits.fit(s.width, s.height, s.gpuMaxSide)
        _ui.update { it.copy(width = w, height = h, presetId = null, error = null) }
    }

    fun start() {
        if (_ui.value.running) return
        val project = projectProvider()
        if (project == null) {
            _ui.update { it.copy(error = "There is nothing to export yet. Open a preset or project first. An imported shader must be run once in Code Studio before it can be exported.") }
            return
        }
        val s = _ui.value
        when (s.kind) {
            ExportKind.IMAGE -> startImage(project, s)
            ExportKind.GIF -> startGif(project, s)
            ExportKind.VIDEO -> startVideo(project, s)
        }
    }

    private fun begin(resultName: String) {
        _ui.value.resultFile?.delete()
        _ui.update { it.copy(running = true, progress = 0f, error = null, info = null, resultFile = null, resultName = null) }
    }

    private fun launchExport(describe: String, mime: String, name: String, w: Int, h: Int, work: suspend ((Float) -> Unit) -> File) {
        begin(name)
        job = scope.launch {
            try {
                val file = work { p -> _ui.update { it.copy(progress = p) } }
                _ui.update {
                    it.copy(
                        running = false, progress = 1f, resultFile = file, resultName = name, resultMime = mime,
                        resultWidth = w, resultHeight = h, info = "Rendered $describe.",
                    )
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(running = false, progress = 0f, info = "Export cancelled.") }
                throw e
            } catch (e: ExportException) {
                _ui.update { it.copy(running = false, progress = 0f, error = e.message ?: "Export failed.") }
            } catch (e: OutOfMemoryError) {
                _ui.update { it.copy(running = false, progress = 0f, error = "The device ran out of memory at this size. Choose a smaller size.") }
            } catch (e: Exception) {
                _ui.update { it.copy(running = false, progress = 0f, error = "Export failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    private fun startImage(project: ShaderProject, s: ExportUi) {
        val config = ExportConfig(s.width, s.height, s.format, s.quality, s.timeSeconds, s.alpha)
        ExportLimits.problem(config, s.gpuMaxSide)?.let { problem ->
            _ui.update { it.copy(error = problem) }
            return
        }
        val name = FileNaming.imageName(project.name, config, System.currentTimeMillis())
        val alphaNote = if (config.format == ImageFormat.PNG && config.alpha != AlphaMode.OPAQUE) " with transparency" else ""
        launchExport("${config.width}×${config.height} ${config.format.label}$alphaNote", config.format.mime, name, config.width, config.height) { progress ->
            container.export.exportImage(project, config, name, progress)
        }
    }

    private fun startGif(project: ShaderProject, s: ExportUi) {
        val (w, h) = gifSize()
        val config = GifConfig(w, h, s.gifFps, s.gifSeconds, s.timeSeconds)
        AnimationLimits.gifProblem(config)?.let { problem ->
            _ui.update { it.copy(error = problem) }
            return
        }
        val name = FileNaming.animationName(project.name, w, h, "gif", System.currentTimeMillis())
        launchExport("a ${w}×${h} GIF (${config.frames} frames)", "image/gif", name, w, h) { progress ->
            container.export.exportGif(project, config, name, progress)
        }
    }

    private fun startVideo(project: ShaderProject, s: ExportUi) {
        val (w, h) = videoSize()
        val config = VideoConfig(w, h, s.videoFps, s.videoSeconds, s.timeSeconds)
        AnimationLimits.videoProblem(config)?.let { problem ->
            _ui.update { it.copy(error = problem) }
            return
        }
        val name = FileNaming.animationName(project.name, w, h, "mp4", System.currentTimeMillis())
        begin(name)
        job = scope.launch {
            // Ask the device's encoder first, so an unsupported size fails with a clear reason instead of halfway through.
            val unsupported = try { container.export.videoSupport(config) } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
            if (unsupported != null) {
                _ui.update { it.copy(running = false, error = unsupported) }
                return@launch
            }
            try {
                val file = container.export.exportVideo(project, config, name) { p -> _ui.update { it.copy(progress = p) } }
                _ui.update {
                    it.copy(
                        running = false, progress = 1f, resultFile = file, resultName = name, resultMime = "video/mp4",
                        resultWidth = w, resultHeight = h, info = "Rendered a ${w}×${h} MP4 (${config.frames} frames, no sound track).",
                    )
                }
            } catch (e: CancellationException) {
                _ui.update { it.copy(running = false, progress = 0f, info = "Export cancelled.") }
                throw e
            } catch (e: ExportException) {
                _ui.update { it.copy(running = false, progress = 0f, error = e.message ?: "Export failed.") }
            } catch (e: Exception) {
                _ui.update { it.copy(running = false, progress = 0f, error = "Export failed: ${e.message ?: e.javaClass.simpleName}") }
            }
        }
    }

    fun cancel() { job?.cancel() }

    /** Copies the rendered file to a location chosen with the system file picker. */
    fun saveTo(uri: Uri) {
        val file = _ui.value.resultFile
        if (file == null || !file.isFile) {
            _ui.update { it.copy(error = "The exported file is no longer available. Export it again.") }
            return
        }
        scope.launch {
            try {
                withContext(Dispatchers.IO) { container.uriIO.copyFrom(file, uri) }
                _ui.update { it.copy(info = "Saved.", error = null) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _ui.update { it.copy(error = "Could not save the file: ${e.message ?: "unknown error"}") }
            }
        }
    }
}
