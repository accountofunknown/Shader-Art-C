package com.shaderart.studio.feature.library

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shaderart.studio.app.AppContainer
import com.shaderart.studio.core.export.FileNaming
import com.shaderart.studio.core.importing.ImportException
import com.shaderart.studio.core.importing.ImportResult
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ProjectSummary
import com.shaderart.studio.feature.settings.AppSettings
import java.io.File
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Library operations (gallery, presets, import, settings) that do not need the live renderer. */
class LibraryViewModel(private val container: AppContainer) : ViewModel() {

    val projects: StateFlow<List<ProjectSummary>> =
        container.projects.observeProjects().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val settings: StateFlow<AppSettings> =
        container.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    val lastCapabilities = container.lastCapabilities

    val gles3Supported: Boolean get() = container.gles3Supported
    val reportedGlesVersion: Int get() = container.reportedGlesVersion

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    /** Null if the catalog could not be loaded: the message is for the user. */
    val catalogProblem: String? = container.presets.catalog.exceptionOrNull()?.let { "The preset catalog could not be loaded: ${it.message}" }
    val presets: List<Preset> get() = container.presets.presets
    val templates get() = container.presets.templates

    fun thumbnailFile(id: String): File = container.projects.thumbnailFile(id)

    private fun say(text: String) { _messages.tryEmit(text) }

    private inline fun launchReporting(failure: String, crossinline block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: ImportException) {
                say(e.message ?: failure)
            } catch (e: Exception) {
                say("$failure: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    // ---- presets

    /** Cached preview of a preset rendered with its real shader; null if rendering is not possible. */
    suspend fun presetThumbnail(preset: Preset): File? =
        try { container.export.presetThumbnail(preset) } catch (e: CancellationException) { throw e } catch (_: Exception) { null }

    fun toggleFavoritePreset(id: String) = launchReporting("Could not update favorites") { container.settings.toggleFavoritePreset(id) }

    // ---- gallery

    fun setFavorite(id: String, favorite: Boolean) = launchReporting("Could not update the project") { container.projects.setFavorite(id, favorite) }

    fun rename(id: String, name: String) = launchReporting("Could not rename the project") { container.projects.rename(id, name) }

    fun duplicate(id: String) = launchReporting("Could not duplicate the project") {
        container.projects.duplicate(id)
        say("Duplicated.")
    }

    fun delete(id: String) = launchReporting("Could not delete the project") {
        container.projects.delete(id)
        say("Deleted.")
    }

    // ---- import / export of project files

    fun importFile(uri: Uri, onDone: (ImportResult) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val r = container.importer.import(uri)
                say("Imported “${r.name}”. It will not run until you press Run.")
                onDone(r)
            } catch (e: CancellationException) {
                throw e
            } catch (e: ImportException) {
                say(e.message ?: "The file could not be imported.")
            } catch (e: Exception) {
                say("Import failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun suggestedArchiveName(projectName: String) = FileNaming.sourceName(projectName, "shaderart")

    /** Writes a `.shaderart` archive of a saved project to [uri]. */
    fun writeArchive(projectId: String, uri: Uri) = launchReporting("Could not export the project") {
        withContext(Dispatchers.IO) {
            val out = container.uriIO.let { io -> io.openOutput(uri) }
            out.use { container.projects.writeArchive(projectId, it) }
        }
        say("Project file saved.")
    }

    fun writeText(text: String, uri: Uri) = launchReporting("Could not save the file") {
        withContext(Dispatchers.IO) { container.uriIO.write(uri, text.toByteArray(Charsets.UTF_8)) }
        say("File saved.")
    }

    // ---- settings

    fun setQuality(scale: Float) = launchReporting("Could not save the setting") { container.settings.setQuality(scale) }
    fun setShowPerformance(show: Boolean) = launchReporting("Could not save the setting") { container.settings.setShowPerformance(show) }
    fun setLimitTo30Fps(limit: Boolean) = launchReporting("Could not save the setting") { container.settings.setLimitTo30Fps(limit) }
}
