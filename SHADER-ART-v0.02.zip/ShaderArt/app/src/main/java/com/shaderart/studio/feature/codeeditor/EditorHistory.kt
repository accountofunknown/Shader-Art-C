package com.shaderart.studio.feature.codeeditor

/**
 * Undo/redo for a text buffer. Rapid typing is coalesced: edits within [coalesceMs] of each other
 * share one undo step, so Undo removes a burst of typing rather than a single character.
 */
class EditorHistory(private val limit: Int = 200, private val coalesceMs: Long = 700L) {
    data class Snapshot(val text: String, val cursor: Int)

    private val undoStack = ArrayList<Snapshot>()
    private val redoStack = ArrayList<Snapshot>()
    private var lastEditAt = Long.MIN_VALUE

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    /** Call with the buffer state *before* applying a change. */
    fun beforeChange(old: Snapshot, nowMs: Long, forceBreak: Boolean = false) {
        redoStack.clear()
        val coalesce = !forceBreak && undoStack.isNotEmpty() && nowMs - lastEditAt < coalesceMs
        lastEditAt = nowMs
        if (coalesce) return
        undoStack.add(old)
        if (undoStack.size > limit) undoStack.removeAt(0)
    }

    fun undo(current: Snapshot): Snapshot? {
        if (undoStack.isEmpty()) return null
        redoStack.add(current)
        lastEditAt = Long.MIN_VALUE
        return undoStack.removeAt(undoStack.lastIndex)
    }

    fun redo(current: Snapshot): Snapshot? {
        if (redoStack.isEmpty()) return null
        undoStack.add(current)
        lastEditAt = Long.MIN_VALUE
        return redoStack.removeAt(redoStack.lastIndex)
    }

    fun clear() {
        undoStack.clear(); redoStack.clear(); lastEditAt = Long.MIN_VALUE
    }
}
