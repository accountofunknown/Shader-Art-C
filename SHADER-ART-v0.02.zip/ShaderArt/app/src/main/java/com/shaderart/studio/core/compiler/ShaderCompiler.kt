package com.shaderart.studio.core.compiler

import android.opengl.GLES20
import android.opengl.GLES30
import com.shaderart.studio.core.gpu.ActiveUniform
import com.shaderart.studio.core.gpu.ShaderProgram

class CompileResult(
    val program: ShaderProgram?,
    val diagnostics: List<ShaderDiagnostic>,
    val millis: Long,
) {
    val success: Boolean get() = program != null
}

/**
 * Compiles and links GLSL ES 3.00 programs with the real driver and returns the driver's own logs.
 * Success is decided only by GL_COMPILE_STATUS / GL_LINK_STATUS, never by the absence of a log.
 * Must run on a thread with a current GL context.
 */
class ShaderCompiler {
    fun compile(vertexSource: String, fragmentSource: String): CompileResult {
        val start = System.nanoTime()
        val diags = ArrayList<ShaderDiagnostic>()
        val vs = compileStage(GLES30.GL_VERTEX_SHADER, vertexSource, ShaderStage.VERTEX, diags)
        val fs = compileStage(GLES30.GL_FRAGMENT_SHADER, fragmentSource, ShaderStage.FRAGMENT, diags)
        if (vs == 0 || fs == 0) {
            if (vs != 0) GLES30.glDeleteShader(vs)
            if (fs != 0) GLES30.glDeleteShader(fs)
            return CompileResult(null, diags, millisSince(start))
        }

        val program = GLES30.glCreateProgram()
        if (program == 0) {
            GLES30.glDeleteShader(vs)
            GLES30.glDeleteShader(fs)
            diags += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.ERROR, null, "glCreateProgram failed (GL error 0x${Integer.toHexString(GLES30.glGetError())}). The GL context may have been lost.")
            return CompileResult(null, diags, millisSince(start))
        }
        GLES30.glAttachShader(program, vs)
        GLES30.glAttachShader(program, fs)
        GLES30.glLinkProgram(program)
        val status = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_LINK_STATUS, status, 0)
        val log = GLES30.glGetProgramInfoLog(program) ?: ""
        val parsed = GlslLogParser.parse(ShaderStage.LINK, log)

        GLES30.glDetachShader(program, vs)
        GLES30.glDetachShader(program, fs)
        GLES30.glDeleteShader(vs)
        GLES30.glDeleteShader(fs)

        if (status[0] == 0) {
            if (parsed.none { it.severity == Severity.ERROR }) {
                diags += ShaderDiagnostic(ShaderStage.LINK, Severity.ERROR, null, "Program linking failed (the driver returned no log).")
            }
            diags += parsed
            GLES30.glDeleteProgram(program)
            return CompileResult(null, diags, millisSince(start))
        }
        diags += parsed.map { if (it.severity == Severity.ERROR) it.copy(severity = Severity.WARNING) else it }
        return CompileResult(ShaderProgram(program, readUniforms(program)), diags, millisSince(start))
    }

    private fun compileStage(type: Int, source: String, stage: ShaderStage, diags: MutableList<ShaderDiagnostic>): Int {
        val shader = GLES30.glCreateShader(type)
        if (shader == 0) {
            diags += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.ERROR, null, "glCreateShader failed for the ${stage.label.lowercase()} shader (GL error 0x${Integer.toHexString(GLES30.glGetError())}). The GL context may have been lost.")
            return 0
        }
        GLES30.glShaderSource(shader, source)
        GLES30.glCompileShader(shader)
        val status = IntArray(1)
        GLES30.glGetShaderiv(shader, GLES30.GL_COMPILE_STATUS, status, 0)
        val log = GLES30.glGetShaderInfoLog(shader) ?: ""
        val parsed = GlslLogParser.parse(stage, log)
        if (status[0] == 0) {
            if (parsed.none { it.severity == Severity.ERROR }) {
                diags += ShaderDiagnostic(stage, Severity.ERROR, null, "${stage.label} shader compilation failed (the driver returned no log).")
            }
            diags += parsed
            GLES30.glDeleteShader(shader)
            return 0
        }
        diags += parsed.map { if (it.severity == Severity.ERROR) it.copy(severity = Severity.WARNING) else it }
        return shader
    }

    private fun readUniforms(program: Int): Map<String, ActiveUniform> {
        val count = IntArray(1)
        GLES30.glGetProgramiv(program, GLES30.GL_ACTIVE_UNIFORMS, count, 0)
        val size = IntArray(1)
        val type = IntArray(1)
        val out = HashMap<String, ActiveUniform>()
        for (i in 0 until count[0]) {
            val raw = GLES20.glGetActiveUniform(program, i, size, 0, type, 0) ?: continue
            val location = GLES30.glGetUniformLocation(program, raw)
            if (location < 0) continue // members of uniform blocks have no location
            val name = raw.removeSuffix("[0]")
            out[name] = ActiveUniform(name, type[0], size[0], location)
        }
        return out
    }

    private fun millisSince(startNanos: Long): Long = (System.nanoTime() - startNanos) / 1_000_000L
}
