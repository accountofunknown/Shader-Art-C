package com.shaderart.studio.core.pipeline

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import com.shaderart.studio.core.model.MultipassLimits
import java.io.ByteArrayOutputStream
import java.io.File

/** An imported picture, ready to be stored: PNG bytes plus its size. */
class ImportedTexture(val pngBytes: ByteArray, val width: Int, val height: Int)

/** Raised for pictures that cannot be used. The message is safe to show. */
class TextureException(message: String) : Exception(message)

object TextureDecoder {
    /**
     * Decodes any picture Android can read, shrinks it to at most [MultipassLimits.MAX_TEXTURE_SIDE] on the longest side and
     * re-encodes it as PNG no larger than [MultipassLimits.MAX_TEXTURE_BYTES]. Re-encoding strips metadata and normalises the format.
     */
    fun import(bytes: ByteArray): ImportedTexture {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw TextureException("This file is not a picture Android can read.")
        if (bounds.outWidth.toLong() * bounds.outHeight > 100_000_000L) throw TextureException("This picture is too large to import.")
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MultipassLimits.MAX_TEXTURE_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: throw TextureException("This picture could not be decoded.")
        try {
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > MultipassLimits.MAX_TEXTURE_SIDE) bmp = scaled(bmp, MultipassLimits.MAX_TEXTURE_SIDE.toFloat() / longest)
            while (true) {
                val out = ByteArrayOutputStream()
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw TextureException("The picture could not be converted.")
                if (out.size() <= MultipassLimits.MAX_TEXTURE_BYTES) return ImportedTexture(out.toByteArray(), bmp.width, bmp.height)
                if (minOf(bmp.width, bmp.height) < 64) throw TextureException("This picture is too detailed to store; try a simpler one.")
                bmp = scaled(bmp, 0.75f) // photos compress poorly as PNG: shrink until it fits
            }
        } finally {
            bmp.recycle()
        }
    }

    /** Loads a stored texture PNG for the GPU, flipped vertically so it appears upright in shader coordinates (origin bottom-left). */
    fun loadForGpu(file: File): Bitmap? {
        if (!file.isFile) return null
        val raw = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }) ?: return null
        val flipped = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, Matrix().apply { preScale(1f, -1f) }, false)
        if (flipped !== raw) raw.recycle()
        return flipped
    }

    private fun scaled(src: Bitmap, factor: Float): Bitmap {
        val w = maxOf(1, (src.width * factor).toInt())
        val h = maxOf(1, (src.height * factor).toInt())
        val out = Bitmap.createScaledBitmap(src, w, h, true)
        if (out !== src) src.recycle()
        return out
    }
}
