package com.shaderart.studio.core.renderer

import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.gpu.ShaderCapabilities
import android.graphics.Bitmap
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.pipeline.PassSource

/**
 * Immutable snapshot of everything the render thread needs. The UI publishes a new snapshot; the render
 * thread reads the latest one at the start of each frame. A new [generation] triggers a recompile.
 */
data class RenderRequest(
    val generation: Int = 0,
    val vertexSource: String = "",
    val fragmentSource: String = "",
    val params: List<ParamDef> = emptyList(),
    val values: Map<String, List<Float>> = emptyMap(),
    val playing: Boolean = true,
    val speed: Float = 1f,
    val zoom: Float = 1f,
    /** 0 = unlimited. */
    val maxFps: Int = 0,
    /** Changing this id makes the renderer jump to [timeSeconds]. */
    val timeCommandId: Int = 0,
    val timeSeconds: Float = 0f,
    /** Inputs of the Image pass (v0.02). */
    val imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
    /** Buffer passes A-D (v0.02). */
    val buffers: List<PassSource> = emptyList(),
    /** Post-effect stack. Changing which effects are enabled needs a new generation; changing only values does not. */
    val post: List<PostEffectInstance> = emptyList(),
    /** Keyframe animation of parameters. Evaluated on the GL thread against the shader clock. */
    val timeline: Timeline = Timeline(),
    val textureLoader: (String) -> Bitmap? = { null },
    val postSourceLoader: (String) -> String? = { null },
)

/** Outcome of one compile/link attempt on the GL thread. */
data class CompileReport(
    val generation: Int,
    val success: Boolean,
    val diagnostics: List<ShaderDiagnostic>,
    val millis: Long,
)

data class RenderStats(
    val fps: Float = 0f,
    val frameMs: Float = 0f,
    val frame: Long = 0L,
    val timeSeconds: Float = 0f,
    val width: Int = 0,
    val height: Int = 0,
    /** How many times a GL context was created for this renderer (more than 1 means a context was lost/recreated). */
    val contextCount: Int = 0,
)

/** Messages from the render thread to the UI. */
sealed class RenderNotice {
    /** The shader made frames so slow that animation was stopped to keep the app responsive. */
    data class AutoPaused(val frameSeconds: Float) : RenderNotice()
    data class GlError(val message: String) : RenderNotice()
}

interface RendererListener {
    fun onCapabilities(capabilities: ShaderCapabilities)
    fun onCompile(report: CompileReport)
    fun onStats(stats: RenderStats)
    fun onNotice(notice: RenderNotice)
}

/** What the renderer needs from its host view. Implemented by [ShaderSurfaceView]. */
interface RenderSurface {
    fun requestRender()
}
