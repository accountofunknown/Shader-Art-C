package com.shaderart.studio.core.pipeline

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLUtils
import com.shaderart.studio.core.audio.AudioFeatures
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderCompiler
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.compiler.ShaderStage
import com.shaderart.studio.core.gpu.FullscreenTriangle
import com.shaderart.studio.core.gpu.GpuException
import com.shaderart.studio.core.gpu.PingPong
import com.shaderart.studio.core.gpu.RenderTarget
import com.shaderart.studio.core.gpu.ShaderProgram
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ChannelKind
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.uniforms.FrameUniforms
import com.shaderart.studio.core.uniforms.ShaderUniformManager
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * The shared GPU pipeline: Buffer A-D passes (with ping-pong feedback), the Image pass, then the post-effect stack.
 * The on-screen renderer, image export, GIF and video export, thumbnails and the live wallpaper all draw through this
 * one class, so a project looks the same everywhere.
 *
 * All methods must run on the GL thread that built the pipeline. After a GL context loss, discard the instance (call
 * [forget]) and build a new one: nothing here survives a lost context.
 */
class PassPipeline private constructor(
    private val spec: PipelineSpec,
    private val image: PassRuntime,
    private val buffers: List<PassRuntime>,
    private val postPrograms: Map<String, ShaderProgram>,
    private val textures: Map<String, Tex>,
) {
    private class Tex(val id: Int, val width: Int, val height: Int)

    private class PassRuntime(val source: PassSource, val program: ShaderProgram) {
        var targets: PingPong? = null
    }

    private val triangle = FullscreenTriangle()
    private val uniforms = ShaderUniformManager()
    private var width = 0
    private var height = 0
    private var pool: List<RenderTarget> = emptyList()
    private var floatTargets = false
    private var noise = 0
    private var black = 0
    private var audioTex = 0
    private val audioBuffer: ByteBuffer = ByteBuffer.allocateDirect(AudioFeatures.TEXTURE_WIDTH * 2).order(ByteOrder.nativeOrder())
    private var released = false

    val usesAudio: Boolean = spec.usesAudio
    val isSimple: Boolean = spec.isSimple

    /** True when colour buffers are 16-bit float (HDR-capable feedback). Valid after the first [render]. */
    val usesFloatBuffers: Boolean get() = floatTargets

    /** Warnings about uniform type mismatches, filled while rendering. Read and clear from the host. */
    val warnings = ArrayList<String>()

    init {
        triangle.create()
        createFixedTextures()
    }

    // ------------------------------------------------------------------ rendering

    /**
     * Draws one frame.
     * @param finalFbo framebuffer receiving the result (0 = the window surface).
     * @param outW,outH size of that framebuffer. Buffers and post passes are allocated at this size.
     * @param clearAlpha if true, the final target is cleared to transparent black first (for transparent PNG export).
     */
    fun render(
        frame: FrameUniforms,
        params: List<ParamDef>,
        values: Map<String, List<Float>>,
        finalFbo: Int,
        outW: Int,
        outH: Int,
        clearAlpha: Boolean = false,
        /** Live post stack (values may change every frame; the set of enabled effects must match the one built). */
        postStack: List<PostEffectInstance> = spec.post,
        /** x, y, w, h of a scissor rectangle (tiled export of single-pass projects only). */
        scissor: IntArray? = null,
    ) {
        check(!released) { "Pipeline released" }
        ensureSize(outW, outH)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
        if (usesAudio) uploadAudio(frame.inputs.audio)

        // 1. Buffers, in order A..D. Each is swapped right after it is drawn, so later passes see this frame's result
        //    while a pass that reads itself (or a later buffer) sees the previous frame.
        for (b in buffers) {
            val pp = b.targets!!
            pp.write.bind()
            GLES30.glViewport(0, 0, outW, outH)
            drawPass(b, frame, params, values)
            pp.swap()
        }

        // 2. Image pass: straight to the output, or into the first pool target when post effects follow.
        val post = postStack.filter { it.enabled }.mapNotNull { PostEffects.normalized(it) }.filter { e -> PostEffects.find(e.effectId)!!.passes.all { postPrograms.containsKey(it) } }
        if (post.isEmpty()) {
            bindFinal(finalFbo, outW, outH, clearAlpha)
            if (scissor != null) {
                GLES30.glEnable(GLES30.GL_SCISSOR_TEST)
                GLES30.glScissor(scissor[0], scissor[1], scissor[2], scissor[3])
            }
            drawPass(image, frame, params, values)
            if (scissor != null) GLES30.glDisable(GLES30.GL_SCISSOR_TEST)
            return
        }
        var cur = pool[0]
        cur.bind()
        GLES30.glViewport(0, 0, outW, outH)
        drawPass(image, frame, params, values)

        // 3. Post stack. Every effect reads the previous result; the last pass of the last effect writes the output.
        for ((ei, inst) in post.withIndex()) {
            val def = PostEffects.find(inst.effectId)!!
            val orig = cur
            var src = cur
            val passes = def.passes.filter { postPrograms.containsKey(it) }
            for ((pi, passName) in passes.withIndex()) {
                val prog = postPrograms.getValue(passName)
                val isOutputPass = ei == post.size - 1 && pi == passes.size - 1
                if (isOutputPass) {
                    bindFinal(finalFbo, outW, outH, clearAlpha)
                    drawPost(prog, src, if (def.usesOriginal) orig else null, inst, frame)
                } else {
                    val dst = pool.first { it !== src && it !== orig }
                    dst.bind()
                    GLES30.glViewport(0, 0, outW, outH)
                    drawPost(prog, src, if (def.usesOriginal) orig else null, inst, frame)
                    src = dst
                }
            }
            cur = src
        }
    }

    private fun bindFinal(fbo: Int, w: Int, h: Int, clear: Boolean) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fbo)
        GLES30.glViewport(0, 0, w, h)
        if (clear) {
            GLES30.glClearColor(0f, 0f, 0f, 0f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        }
    }

    private fun drawPass(p: PassRuntime, frame: FrameUniforms, params: List<ParamDef>, values: Map<String, List<Float>>) {
        p.program.use()
        bindChannels(p)
        val res = channelResolution(p.source)
        uniforms.bindFrame(p.program, frame.copy(channelResolution = res), warnings.takeIf { it.size < 32 })
        uniforms.bindParams(p.program, params, values, warnings.takeIf { it.size < 32 })
        triangle.draw()
    }

    private fun bindChannels(p: PassRuntime) {
        for (i in 0 until ChannelBinding.CHANNEL_COUNT) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + i)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, textureFor(p.source.channels[i]))
            p.program.uniforms["u_channel$i"]?.let { GLES30.glUniform1i(it.location, i) }
        }
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
    }

    private fun textureFor(c: ChannelBinding): Int = when (c.kind) {
        ChannelKind.NONE -> black
        ChannelKind.NOISE -> noise
        ChannelKind.AUDIO -> audioTex
        ChannelKind.TEXTURE -> textures[c.ref]?.id ?: black
        ChannelKind.BUFFER -> {
            val pass = c.bufferPass
            buffers.firstOrNull { it.source.id == pass }?.targets?.read?.textureId ?: black
        }
    }

    private fun channelResolution(src: PassSource): FloatArray {
        val out = FloatArray(12)
        for (i in 0 until 4) {
            val c = src.channels[i]
            val (w, h) = when (c.kind) {
                ChannelKind.NONE -> 0 to 0
                ChannelKind.NOISE -> NOISE_SIZE to NOISE_SIZE
                ChannelKind.AUDIO -> AudioFeatures.TEXTURE_WIDTH to 2
                ChannelKind.TEXTURE -> (textures[c.ref]?.let { it.width to it.height } ?: (0 to 0))
                ChannelKind.BUFFER -> width to height
            }
            out[i * 3] = w.toFloat(); out[i * 3 + 1] = h.toFloat(); out[i * 3 + 2] = 1f
        }
        return out
    }

    private fun drawPost(prog: ShaderProgram, src: RenderTarget, orig: RenderTarget?, inst: PostEffectInstance, frame: FrameUniforms) {
        prog.use()
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, src.textureId)
        prog.uniforms["u_input"]?.let { GLES30.glUniform1i(it.location, 0) }
        if (orig != null) {
            GLES30.glActiveTexture(GLES30.GL_TEXTURE1)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, orig.textureId)
            prog.uniforms["u_orig"]?.let { GLES30.glUniform1i(it.location, 1) }
            GLES30.glActiveTexture(GLES30.GL_TEXTURE0)
        }
        prog.uniforms["u_resolution"]?.let { GLES30.glUniform2f(it.location, width.toFloat(), height.toFloat()) }
        prog.uniforms["u_time"]?.let { GLES30.glUniform1f(it.location, frame.time) }
        for (i in 0 until 4) prog.uniforms["u_p$i"]?.let { GLES30.glUniform1f(it.location, inst.values.getOrElse(i) { 0f }) }
        triangle.draw()
    }

    // ------------------------------------------------------------------ resources

    private fun ensureSize(w: Int, h: Int) {
        if (sizedOnce && w == width && h == height) return
        releaseTargets()
        width = w
        height = h
        val wantFloat = floatBufferSupport
        val newBuffers = buffers.map { b -> PingPong(w, h, wantFloat).also { it.create(); clearPingPong(it) } }
        buffers.forEachIndexed { i, b -> b.targets = newBuffers[i] }
        floatTargets = newBuffers.firstOrNull()?.isFloat ?: false
        val needsPool = spec.enabledPost.isNotEmpty()
        pool = if (needsPool) List(3) { RenderTarget(w, h, wantFloat, linear = true).also { it.create() } } else emptyList()
        sizedOnce = true
    }

    private var sizedOnce = false

    private fun clearPingPong(pp: PingPong) {
        for (t in listOf(pp.read, pp.write)) {
            t.bind()
            GLES30.glClearColor(0f, 0f, 0f, 0f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        }
    }

    private fun releaseTargets() {
        buffers.forEach { it.targets?.release(); it.targets = null }
        pool.forEach { it.release() }
        pool = emptyList()
    }

    private fun createFixedTextures() {
        val ids = IntArray(3)
        GLES30.glGenTextures(3, ids, 0)
        black = ids[0]; noise = ids[1]; audioTex = ids[2]

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, black)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, 1, 1, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, ByteBuffer.allocateDirect(4).put(byteArrayOf(0, 0, 0, -1)).also { it.position(0) })
        setParams(GLES30.GL_NEAREST, GLES30.GL_NEAREST, GLES30.GL_CLAMP_TO_EDGE)

        val nb = ByteBuffer.allocateDirect(NOISE_SIZE * NOISE_SIZE * 4)
        var s = 0x12345678
        for (i in 0 until NOISE_SIZE * NOISE_SIZE * 4) {
            s = s * 1664525 + 1013904223 // deterministic LCG: the same noise on every device
            nb.put(i, (s ushr 24).toByte())
        }
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, noise)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA8, NOISE_SIZE, NOISE_SIZE, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, nb)
        setParams(GLES30.GL_LINEAR, GLES30.GL_LINEAR, GLES30.GL_REPEAT)

        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, audioTex)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_R8, AudioFeatures.TEXTURE_WIDTH, 2, 0, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, null)
        setParams(GLES30.GL_LINEAR, GLES30.GL_LINEAR, GLES30.GL_CLAMP_TO_EDGE)
    }

    private fun uploadAudio(a: AudioFeatures) {
        audioBuffer.clear()
        audioBuffer.put(a.toTextureBytes())
        audioBuffer.position(0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, audioTex)
        GLES30.glPixelStorei(GLES30.GL_UNPACK_ALIGNMENT, 1)
        GLES30.glTexSubImage2D(GLES30.GL_TEXTURE_2D, 0, 0, 0, AudioFeatures.TEXTURE_WIDTH, 2, GLES30.GL_RED, GLES30.GL_UNSIGNED_BYTE, audioBuffer)
    }

    // ------------------------------------------------------------------ lifecycle

    /** Frees every GL object. Valid only while the creating context is current. */
    fun release() {
        if (released) return
        released = true
        releaseTargets()
        (buffers + image).forEach { it.program.delete() }
        postPrograms.values.forEach { it.delete() }
        val ids = ArrayList<Int>()
        ids += listOf(black, noise, audioTex)
        textures.values.forEach { ids += it.id }
        GLES30.glDeleteTextures(ids.size, ids.toIntArray(), 0)
        triangle.release()
    }

    /** Drops all handles without touching GL (the context is gone). */
    fun forget() {
        released = true
        triangle.forget()
    }

    companion object {
        private const val NOISE_SIZE = 256
        private val floatBufferSupport: Boolean by lazy {
            val ext = GLES30.glGetString(GLES30.GL_EXTENSIONS) ?: ""
            ext.contains("GL_EXT_color_buffer_float") || ext.contains("GL_EXT_color_buffer_half_float")
        }

        private fun setParams(min: Int, mag: Int, wrap: Int) {
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, min)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, mag)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, wrap)
            GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, wrap)
        }

        /**
         * Compiles every pass. Succeeds only if all of them compile and link; otherwise nothing is kept and every
         * message (tagged with its pass) is returned, so the caller can keep running the previous pipeline.
         */
        fun build(spec: PipelineSpec): PipelineBuild {
            val start = System.nanoTime()
            val diags = ArrayList<ShaderDiagnostic>()
            val compiler = ShaderCompiler()
            val built = ArrayList<ShaderProgram>()
            var ok = true

            fun compilePass(vertex: String, fragment: String, label: String?): ShaderProgram? {
                val r = compiler.compile(vertex, fragment)
                diags += r.diagnostics.map { it.copy(pass = label) }
                if (r.program == null) ok = false else built += r.program
                return r.program
            }

            val imageProg = compilePass(spec.vertex, spec.image.fragment, null)
            val bufferProgs = spec.buffers.map { compilePass(spec.vertex, it.fragment, it.id.label) }
            val postProgs = HashMap<String, ShaderProgram>()
            for (inst in spec.enabledPost) {
                val def = PostEffects.find(inst.effectId) ?: continue
                for (pass in def.passes) {
                    if (pass in postProgs) continue
                    val src = spec.postSourceLoader(pass)
                    if (src == null) {
                        diags += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.ERROR, null, "The post-effect shader '$pass' is missing from the app.", pass = "Post: ${def.name}")
                        ok = false
                        continue
                    }
                    compilePass(PostShaders.VERTEX, src, "Post: ${def.name}")?.let { postProgs[pass] = it }
                }
            }
            if (!ok || imageProg == null) {
                built.forEach { it.delete() }
                return PipelineBuild(null, diags, (System.nanoTime() - start) / 1_000_000L)
            }

            val textures = HashMap<String, Tex>()
            try {
                for (src in spec.allPasses) for (c in src.channels) {
                    if (c.kind == ChannelKind.TEXTURE && c.ref !in textures) {
                        val bmp = spec.textureLoader(c.ref)
                        if (bmp == null) {
                            diags += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.WARNING, null, "Texture '${c.ref}' could not be loaded; a black image is used instead.", pass = src.id.label.takeIf { src.id.isBuffer })
                        } else {
                            textures[c.ref] = uploadBitmap(bmp)
                            bmp.recycle() // the loader hands over ownership of the bitmap
                        }
                    }
                }
            } catch (e: GpuException) {
                built.forEach { it.delete() }
                textures.values.forEach { GLES30.glDeleteTextures(1, intArrayOf(it.id), 0) }
                diags += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.ERROR, null, e.message ?: "A texture could not be uploaded.")
                return PipelineBuild(null, diags, (System.nanoTime() - start) / 1_000_000L)
            }

            val pipeline = PassPipeline(
                spec,
                PassRuntime(spec.image, imageProg),
                spec.buffers.mapIndexed { i, s -> PassRuntime(s, bufferProgs[i]!!) },
                postProgs,
                textures,
            )
            return PipelineBuild(pipeline, diags, (System.nanoTime() - start) / 1_000_000L)
        }

        private fun uploadBitmap(bmp: Bitmap): Tex {
            while (GLES30.glGetError() != GLES30.GL_NO_ERROR) { /* clear stale errors */ }
            val id = IntArray(1)
            GLES30.glGenTextures(1, id, 0)
            GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, id[0])
            GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
            val err = GLES30.glGetError()
            if (err != GLES30.GL_NO_ERROR) {
                GLES30.glDeleteTextures(1, id, 0)
                throw GpuException("A texture could not be uploaded (GL error 0x${Integer.toHexString(err)}).")
            }
            GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
            setParams(GLES30.GL_LINEAR_MIPMAP_LINEAR, GLES30.GL_LINEAR, GLES30.GL_REPEAT)
            return Tex(id[0], bmp.width, bmp.height)
        }
    }
}
