package com.shaderart.studio.app

import android.content.Context
import android.graphics.Bitmap
import androidx.room.Room
import com.shaderart.studio.core.export.ExportEngine
import com.shaderart.studio.core.gpu.DeviceGles
import com.shaderart.studio.core.gpu.ShaderCapabilities
import com.shaderart.studio.core.importing.ImportService
import com.shaderart.studio.core.importing.UriIO
import com.shaderart.studio.core.pipeline.PostAssets
import com.shaderart.studio.core.pipeline.TextureDecoder
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.service.WallpaperSelection
import com.shaderart.studio.core.storage.AppDatabase
import com.shaderart.studio.core.storage.FileProjectRepository
import com.shaderart.studio.core.storage.ProjectRepository
import com.shaderart.studio.core.storage.RoomProjectIndex
import com.shaderart.studio.feature.settings.SettingsRepository
import com.shaderart.studio.feature.settings.settingsDataStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Hand-wired dependencies (no DI framework). Created once by [ShaderArtApp]. */
class AppContainer(context: Context) {
    val app: Context = context.applicationContext

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val presets = PresetRepository(app.assets)
    private val database = Room.databaseBuilder(app, AppDatabase::class.java, "shaderart.db").build()
    val projects: ProjectRepository = FileProjectRepository(app.filesDir, RoomProjectIndex(database.projectDao()))
    val settings = SettingsRepository(app.settingsDataStore)
    /** Decodes the stored textures of a project for the GPU. Returns null for a missing or unreadable picture. */
    fun textureLoader(projectId: String): (String) -> Bitmap? = { name ->
        try { TextureDecoder.loadForGpu(projects.textureFile(projectId, name)) } catch (_: Exception) { null }
    }

    val postAssets = PostAssets(app.assets)
    val postSourceLoader: (String) -> String? = { postAssets.load(it) }
    val export = ExportEngine(
        app.cacheDir,
        textureLoader = { id, name -> try { TextureDecoder.loadForGpu(projects.textureFile(id, name)) } catch (_: Exception) { null } },
        postSourceLoader = postSourceLoader,
    )
    val wallpaper = WallpaperSelection(app)
    val uriIO = UriIO(app.contentResolver)
    val importer = ImportService(uriIO, projects, presets)

    /** False on devices that cannot run OpenGL ES 3.0: the app then shows a compatibility message. */
    val gles3Supported: Boolean = DeviceGles.supportsEs3(app)
    val reportedGlesVersion: Int = DeviceGles.reportedVersion(app)

    private val _lastCapabilities = MutableStateFlow<ShaderCapabilities?>(null)
    /** GPU information from the most recent real GL context (null until a studio or export has run). */
    val lastCapabilities: StateFlow<ShaderCapabilities?> = _lastCapabilities

    fun reportCapabilities(c: ShaderCapabilities) { _lastCapabilities.value = c }
}
