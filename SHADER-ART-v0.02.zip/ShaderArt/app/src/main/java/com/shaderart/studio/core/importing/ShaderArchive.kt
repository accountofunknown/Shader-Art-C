package com.shaderart.studio.core.importing

import com.shaderart.studio.core.model.MultipassLimits
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.storage.ProjectFormatException
import com.shaderart.studio.core.storage.ProjectSerializer
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** An import was rejected. The message is safe to show to the user. */
class ImportException(message: String) : Exception(message)

class ImportedArchive(
    val project: ShaderProject,
    val preview: ByteArray?,
    val previewIsJpeg: Boolean,
    /** Texture PNG bytes keyed by texture name. */
    val textures: Map<String, ByteArray> = emptyMap(),
)

/**
 * `.shaderart` archive reader/writer. Layout: manifest.json, vertex.vert, fragment.frag and an
 * optional preview.png/preview.jpg. Uniform metadata ("params"), parameter configuration
 * ("values"), animation and render settings are all inside manifest.json.
 *
 * Reading is defensive: only the fixed entry names above are accepted, sizes are counted while
 * reading (declared sizes are never trusted) and nothing from the archive is ever executed.
 */
object ShaderArchive {
    private val PNG_MAGIC = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47)
    private val JPEG_MAGIC = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())

    fun write(project: ShaderProject, preview: ByteArray?, previewIsJpeg: Boolean, out: OutputStream, textures: Map<String, ByteArray> = emptyMap()) {
        val zip = ZipOutputStream(out)
        fun put(name: String, bytes: ByteArray) {
            val e = ZipEntry(name)
            e.time = 0L // reproducible archives
            zip.putNextEntry(e)
            zip.write(bytes)
            zip.closeEntry()
        }
        put("manifest.json", ProjectSerializer.toManifestJson(project).toByteArray(Charsets.UTF_8))
        put("vertex.vert", project.vertexSource.toByteArray(Charsets.UTF_8))
        put("fragment.frag", project.fragmentSource.toByteArray(Charsets.UTF_8))
        for (b in project.buffers) put(ImportLimits.bufferEntryName(b.id.key), b.fragmentSource.toByteArray(Charsets.UTF_8))
        for (t in project.textures) {
            val bytes = textures[t.name] ?: continue
            put(ImportLimits.textureEntryName(t.name), bytes)
        }
        if (preview != null && preview.isNotEmpty() && preview.size <= ImportLimits.MAX_PREVIEW_BYTES) {
            put(if (previewIsJpeg) "preview.jpg" else "preview.png", preview)
        }
        zip.finish()
        zip.flush()
    }

    fun read(input: InputStream): ImportedArchive {
        val files = HashMap<String, ByteArray>()
        var total = 0L
        try {
            ZipInputStream(LimitedInputStream(input, ImportLimits.MAX_ARCHIVE_BYTES)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (files.size >= ImportLimits.MAX_ENTRIES) throw ImportException("The archive contains too many files.")
                    if (entry.isDirectory) throw ImportException("The archive contains a folder, which is not allowed.")
                    val name = entry.name
                    if (!ImportLimits.isSafeEntryName(name)) {
                        throw ImportException("The archive contains an unexpected or unsafe entry: '${name.take(40)}'.")
                    }
                    if (files.containsKey(name)) throw ImportException("The archive contains '$name' twice.")
                    val limit = when (name) {
                        "manifest.json" -> ImportLimits.MAX_MANIFEST_BYTES
                        "preview.png", "preview.jpg" -> ImportLimits.MAX_PREVIEW_BYTES
                        else -> if (ImportLimits.isTextureEntry(name)) MultipassLimits.MAX_TEXTURE_BYTES else ImportLimits.MAX_SOURCE_BYTES
                    }
                    val bytes = readBounded(zip, limit, name)
                    total += bytes.size
                    if (total > ImportLimits.MAX_TOTAL_UNCOMPRESSED) throw ImportException("The archive expands to too much data.")
                    files[name] = bytes
                }
            }
        } catch (e: ImportException) {
            throw e
        } catch (e: ZipException) {
            throw ImportException("This is not a valid .shaderart archive.")
        } catch (e: IOException) {
            throw ImportException(e.message ?: "The archive could not be read.")
        }

        val manifest = files["manifest.json"] ?: throw ImportException("The archive has no manifest.json.")
        val vertex = files["vertex.vert"] ?: throw ImportException("The archive has no vertex.vert.")
        val fragment = files["fragment.frag"] ?: throw ImportException("The archive has no fragment.frag.")

        val project = try {
            ProjectSerializer.fromManifestJson(
                GlslSourceCheck.decodeUtf8Strict(manifest),
                GlslSourceCheck.decodeUtf8Strict(vertex),
                GlslSourceCheck.decodeUtf8Strict(fragment),
                files.filterKeys { ImportLimits.isBufferEntry(it) }
                    .map { (k, v) -> k.removePrefix("buffer_").removeSuffix(".frag") to GlslSourceCheck.decodeUtf8Strict(v) }.toMap(),
            )
        } catch (e: ProjectFormatException) {
            throw ImportException(e.message ?: "The project data is invalid.")
        } catch (e: IllegalArgumentException) {
            throw ImportException(e.message ?: "The project data is invalid.")
        }

        var preview: ByteArray? = null
        var isJpeg = false
        for (name in listOf("preview.png", "preview.jpg")) {
            val b = files[name] ?: continue
            val ok = if (name.endsWith("png")) startsWith(b, PNG_MAGIC) else startsWith(b, JPEG_MAGIC)
            if (!ok) throw ImportException("The preview image is not a valid ${if (name.endsWith("png")) "PNG" else "JPEG"}.")
            preview = b
            isJpeg = name.endsWith("jpg")
            break
        }
        val textures = LinkedHashMap<String, ByteArray>()
        for (t in project.textures) {
            val b = files[ImportLimits.textureEntryName(t.name)] ?: throw ImportException("The archive is missing texture '${t.name}'.")
            if (!startsWith(b, PNG_MAGIC)) throw ImportException("Texture '${t.name}' is not a valid PNG.")
            textures[t.name] = b
        }
        return ImportedArchive(project, preview, isJpeg, textures)
    }

    private fun startsWith(bytes: ByteArray, magic: ByteArray): Boolean =
        bytes.size >= magic.size && magic.indices.all { bytes[it] == magic[it] }

    private fun readBounded(input: InputStream, limit: Int, name: String): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var n = 0
        while (true) {
            val r = input.read(buf)
            if (r < 0) break
            n += r
            if (n > limit) throw ImportException("'$name' is larger than the allowed ${limit / 1024} KB.")
            out.write(buf, 0, r)
        }
        return out.toByteArray()
    }

    /** Stops reading once more than [max] bytes were consumed (compressed size cap). */
    private class LimitedInputStream(private val inner: InputStream, private val max: Long) : InputStream() {
        private var count = 0L
        override fun read(): Int {
            val b = inner.read()
            if (b >= 0 && ++count > max) throw ImportException("The archive is larger than ${max / 1_000_000} MB.")
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            val r = inner.read(b, off, len)
            if (r > 0) {
                count += r
                if (count > max) throw ImportException("The archive is larger than ${max / 1_000_000} MB.")
            }
            return r
        }
    }
}
