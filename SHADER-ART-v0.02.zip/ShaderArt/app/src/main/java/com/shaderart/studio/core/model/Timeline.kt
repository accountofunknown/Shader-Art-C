package com.shaderart.studio.core.model

import kotlin.math.floor

enum class Easing {
    LINEAR, SMOOTH, EASE_IN, EASE_OUT, STEP;

    /** Maps segment progress 0..1 to eased progress 0..1. */
    fun apply(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return when (this) {
            LINEAR -> x
            SMOOTH -> x * x * (3f - 2f * x)
            EASE_IN -> x * x
            EASE_OUT -> 1f - (1f - x) * (1f - x)
            STEP -> if (x >= 1f) 1f else 0f
        }
    }

    companion object {
        fun parse(s: String): Easing? = entries.firstOrNull { it.name.equals(s.trim(), ignoreCase = true) }
    }
}

/** A value [v] at time [t] seconds. [easing] shapes the segment that starts at this key. */
data class Keyframe(val t: Float, val v: Float, val easing: Easing = Easing.SMOOTH)

/** Animates one component (0 for float/int/bool, 0..2 for colour r,g,b) of one parameter. */
data class TimelineTrack(val paramId: String, val component: Int, val keys: List<Keyframe>)

data class Timeline(
    val durationSeconds: Float = 8f,
    val loop: Boolean = true,
    val enabled: Boolean = true,
    val tracks: List<TimelineTrack> = emptyList(),
) {
    val isEmpty: Boolean get() = tracks.none { it.keys.isNotEmpty() }
    fun track(paramId: String, component: Int): TimelineTrack? = tracks.firstOrNull { it.paramId == paramId && it.component == component }
    fun animates(paramId: String): Boolean = enabled && tracks.any { it.paramId == paramId && it.keys.isNotEmpty() }

    fun withKey(paramId: String, component: Int, key: Keyframe): Timeline {
        val old = track(paramId, component)
        val keys = ((old?.keys ?: emptyList()).filterNot { kotlin.math.abs(it.t - key.t) < 0.01f } + key).sortedBy { it.t }
        val nt = TimelineTrack(paramId, component, keys)
        return copy(tracks = if (old == null) tracks + nt else tracks.map { if (it === old) nt else it })
    }

    fun withoutKey(paramId: String, component: Int, index: Int): Timeline {
        val old = track(paramId, component) ?: return this
        val keys = old.keys.filterIndexed { i, _ -> i != index }
        return copy(tracks = if (keys.isEmpty()) tracks.filter { it !== old } else tracks.map { if (it === old) old.copy(keys = keys) else it })
    }
}

object TimelineEval {
    /** Local timeline time for global time [t]: wrapped when looping, clamped otherwise. */
    fun localTime(tl: Timeline, t: Float): Float {
        val d = tl.durationSeconds.coerceAtLeast(0.01f)
        if (!tl.loop) return t.coerceIn(0f, d)
        val m = t - floor(t / d) * d
        return if (m.isFinite()) m else 0f
    }

    /** Value of a track at local time [t]; null if the track has no keys. */
    fun value(track: TimelineTrack, t: Float): Float? {
        val k = track.keys
        if (k.isEmpty()) return null
        if (t <= k.first().t) return k.first().v
        if (t >= k.last().t) return k.last().v
        var i = 0
        while (i < k.size - 1 && k[i + 1].t <= t) i++
        val a = k[i]
        val b = k[i + 1]
        val span = b.t - a.t
        if (span <= 0f) return b.v
        val e = a.easing.apply((t - a.t) / span)
        return a.v + (b.v - a.v) * e
    }

    /** Returns [values] with every animated component replaced by its value at [time], clamped to the parameter's range. */
    fun apply(tl: Timeline, params: List<ParamDef>, values: Map<String, List<Float>>, time: Float): Map<String, List<Float>> {
        if (!tl.enabled || tl.isEmpty) return values
        val lt = localTime(tl, time)
        var out: MutableMap<String, List<Float>>? = null
        for (tr in tl.tracks) {
            val p = params.firstOrNull { it.id == tr.paramId } ?: continue
            val raw = value(tr, lt) ?: continue
            val cur = (out ?: values)[p.id] ?: p.defaults
            if (tr.component !in cur.indices) continue
            val v = when (p.type) {
                ParamType.INT -> Math.round(raw.coerceIn(p.min, p.max)).toFloat()
                ParamType.BOOL -> if (raw >= 0.5f) 1f else 0f
                else -> raw.coerceIn(p.min, p.max)
            }
            val next = cur.toMutableList().also { it[tr.component] = v }
            if (out == null) out = LinkedHashMap(values)
            out[p.id] = next
        }
        return out ?: values
    }
}
