package com.shaderart.studio.ui.screens

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import com.shaderart.studio.R
import com.shaderart.studio.core.model.Preset
import com.shaderart.studio.core.model.ProjectSummary
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.ui.components.PreviewTile
import com.shaderart.studio.ui.components.rememberFileImage
import java.io.File
import java.text.DateFormat
import java.util.Date

/** Preview of a built-in preset, rendered by the real GPU shader on first use and then cached on disk. */
@Composable
fun PresetThumb(lib: LibraryViewModel, preset: Preset, modifier: Modifier = Modifier) {
    val file by produceState<File?>(initialValue = null, preset.id, preset.version) {
        value = lib.presetThumbnail(preset)
    }
    val image = rememberFileImage(file, preset.version, maxSide = 384)
    PreviewTile(image, modifier, description = "Preview of ${preset.name}", placeholderIcon = R.drawable.ic_sparkle)
}

@Composable
fun ProjectThumb(lib: LibraryViewModel, project: ProjectSummary, modifier: Modifier = Modifier) {
    val file = if (project.hasThumbnail) lib.thumbnailFile(project.id) else null
    val image = rememberFileImage(file, project.modifiedAt, maxSide = 384)
    PreviewTile(image, modifier, description = "Thumbnail of ${project.name}", placeholderIcon = R.drawable.ic_gallery)
}

fun formatDate(millis: Long): String = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(millis))
