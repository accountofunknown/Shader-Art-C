package com.shaderart.studio.feature.codeeditor

/** Re-indents GLSL by brace depth. Preprocessor lines stay at column 0. Idempotent. */
object CodeFormatter {
    fun format(text: String, indent: String = "  "): String {
        var depth = 0
        var inBlock = false
        val out = ArrayList<String>()
        for (raw in text.replace("\r\n", "\n").split('\n')) {
            val line = raw.trim()
            if (inBlock) {
                // Continuation of a block comment: re-indent but do not count braces.
                out += if (line.isEmpty()) "" else indent.repeat(depth) + " " + line.removePrefix("*").let { if (line.startsWith("*")) "*$it" else line }
                if (line.contains("*/")) inBlock = false
                continue
            }
            if (line.isEmpty()) { out += ""; continue }
            if (line.startsWith("#")) { out += line; continue }
            val code = stripComments(line)
            val closesFirst = code.startsWith("}")
            val lead = if (closesFirst) maxOf(depth - 1, 0) else depth
            out += indent.repeat(lead) + line
            for (ch in code) {
                if (ch == '{') depth++ else if (ch == '}') depth = maxOf(depth - 1, 0)
            }
            val open = line.lastIndexOf("/*")
            if (open >= 0 && line.indexOf("*/", open + 2) < 0) inBlock = true
        }
        // Collapse runs of more than two blank lines.
        val sb = StringBuilder()
        var blanks = 0
        for (l in out) {
            if (l.isEmpty()) { blanks++; if (blanks > 2) continue } else blanks = 0
            sb.append(l).append('\n')
        }
        return sb.toString().trimEnd('\n') + "\n"
    }

    /** Removes // and complete /* */ comments and string-like content so brace counting is not fooled. */
    internal fun stripComments(line: String): String {
        var s = line
        while (true) {
            val a = s.indexOf("/*")
            if (a < 0) break
            val b = s.indexOf("*/", a + 2)
            s = if (b < 0) s.substring(0, a) else s.substring(0, a) + " " + s.substring(b + 2)
        }
        val c = s.indexOf("//")
        if (c >= 0) s = s.substring(0, c)
        return s.trim()
    }
}

/** Smart typing helpers. They look at a single typed character and may return a corrected edit. */
object AutoIndent {
    data class Edit(val text: String, val cursor: Int)

    /**
     * @return the corrected buffer when [newText] is [oldText] plus exactly one typed character that
     * deserves special handling (Enter after '{' / indentation carry-over, or '}' on a blank line), else null.
     */
    fun onTyped(oldText: String, newText: String, newCursor: Int, indent: String = "  "): Edit? {
        if (newText.length != oldText.length + 1 || newCursor < 1 || newCursor > newText.length) return null
        val at = newCursor - 1
        if (newText.removeRange(at, at + 1) != oldText) return null
        val typed = newText[at]
        if (typed == '\n') {
            val lineStart = newText.lastIndexOf('\n', at - 1).let { if (it < 0) 0 else it + 1 }
            val prevLine = newText.substring(lineStart, at)
            val lead = prevLine.takeWhile { it == ' ' || it == '\t' }
            val extra = if (prevLine.trimEnd().endsWith("{")) indent else ""
            val before = newText.substring(0, newCursor)
            val after = newText.substring(newCursor)
            val nextIsClose = after.startsWith("}") && extra.isNotEmpty()
            return if (nextIsClose) {
                val mid = lead + extra
                Edit(before + mid + "\n" + lead + after, before.length + mid.length)
            } else {
                Edit(before + lead + extra + after, before.length + lead.length + extra.length)
            }
        }
        if (typed == '}') {
            val lineStart = newText.lastIndexOf('\n', at - 1).let { if (it < 0) 0 else it + 1 }
            val beforeBrace = newText.substring(lineStart, at)
            if (beforeBrace.isNotEmpty() && beforeBrace.isBlank() && beforeBrace.length >= indent.length) {
                val reduced = beforeBrace.substring(0, beforeBrace.length - indent.length)
                val text = newText.substring(0, lineStart) + reduced + "}" + newText.substring(newCursor)
                return Edit(text, lineStart + reduced.length + 1)
            }
        }
        return null
    }
}

object FindEngine {
    /** Start offsets of every occurrence of [query] (non-overlapping). Empty query finds nothing. */
    fun findAll(text: String, query: String, caseSensitive: Boolean = false): List<Int> {
        if (query.isEmpty()) return emptyList()
        val out = ArrayList<Int>()
        var from = 0
        while (true) {
            val i = text.indexOf(query, from, ignoreCase = !caseSensitive)
            if (i < 0) break
            out += i
            from = i + query.length
        }
        return out
    }

    /** Index into [matches] of the first match at or after [cursor], wrapping to the first. -1 if none. */
    fun nextIndex(matches: List<Int>, cursor: Int): Int {
        if (matches.isEmpty()) return -1
        val i = matches.indexOfFirst { it >= cursor }
        return if (i < 0) 0 else i
    }

    fun previousIndex(matches: List<Int>, cursor: Int): Int {
        if (matches.isEmpty()) return -1
        val i = matches.indexOfLast { it < cursor }
        return if (i < 0) matches.lastIndex else i
    }
}

object LineUtil {
    /** 1-based line number containing [offset]. */
    fun lineOfOffset(text: String, offset: Int): Int {
        val end = offset.coerceIn(0, text.length)
        var line = 1
        for (i in 0 until end) if (text[i] == '\n') line++
        return line
    }

    /** Offset of the first character of 1-based [line] (clamped to the text). */
    fun offsetOfLine(text: String, line: Int): Int {
        if (line <= 1) return 0
        var current = 1
        for (i in text.indices) {
            if (text[i] == '\n') {
                current++
                if (current == line) return i + 1
            }
        }
        return text.length
    }

    fun lineCount(text: String): Int = text.count { it == '\n' } + 1
}

object Completion {
    data class Result(val text: String, val cursor: Int)

    private val IDENT_CHAR = { c: Char -> c.isLetterOrDigit() || c == '_' }

    /** Word fragment immediately before [cursor]. */
    fun prefixAt(text: String, cursor: Int): String {
        val end = cursor.coerceIn(0, text.length)
        var s = end
        while (s > 0 && IDENT_CHAR(text[s - 1])) s--
        return text.substring(s, end)
    }

    /** Suggestions for the word being typed: GLSL vocabulary, standard uniforms and identifiers already in the file. */
    fun suggest(text: String, cursor: Int, limit: Int = 8): List<String> {
        val prefix = prefixAt(text, cursor)
        if (prefix.length < 2 || prefix[0].isDigit()) return emptyList()
        val pool = LinkedHashSet<String>()
        pool.addAll(GlslVocabulary.UNIFORMS)
        pool.addAll(GlslVocabulary.KEYWORDS)
        pool.addAll(GlslVocabulary.TYPES)
        pool.addAll(GlslVocabulary.BUILTINS)
        Regex("[A-Za-z_][A-Za-z0-9_]{2,}").findAll(text).forEach { pool.add(it.value) }
        return pool.filter { it.startsWith(prefix) && it != prefix }
            .sortedWith(compareBy({ it.length }, { it }))
            .take(limit)
    }

    fun apply(text: String, cursor: Int, suggestion: String): Result {
        val prefix = prefixAt(text, cursor)
        val start = cursor - prefix.length
        val isFunction = suggestion in GlslVocabulary.FUNCTIONS
        val insert = if (isFunction && !text.startsWith("(", cursor)) "$suggestion(" else suggestion
        return Result(text.substring(0, start) + insert + text.substring(cursor), start + insert.length)
    }
}
