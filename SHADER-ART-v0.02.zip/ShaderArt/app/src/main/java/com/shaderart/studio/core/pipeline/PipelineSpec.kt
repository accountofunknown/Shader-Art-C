package com.shaderart.studio.core.pipeline

import android.graphics.Bitmap
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ChannelKind
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PostEffectInstance

/** One shader pass with its four inputs. */
class PassSource(val id: PassId, val fragment: String, val channels: List<ChannelBinding>)

/**
 * Everything needed to build a [PassPipeline]. Plain data plus two loaders, so the pipeline itself knows nothing
 * about files or projects.
 */
class PipelineSpec(
    val vertex: String,
    val image: PassSource,
    val buffers: List<PassSource> = emptyList(),
    val post: List<PostEffectInstance> = emptyList(),
    /** Returns the decoded, already vertically flipped bitmap of a project texture, or null if it is unavailable. The pipeline recycles it after upload. */
    val textureLoader: (String) -> Bitmap? = { null },
    /** Returns the GLSL source of a post-effect pass asset (e.g. "bloom_a"), or null if missing. */
    val postSourceLoader: (String) -> String? = { null },
) {
    val enabledPost: List<PostEffectInstance> get() = post.filter { it.enabled }

    val allPasses: List<PassSource> get() = buffers + image

    /** True when a plain single draw call produces the image (no buffers, inputs or post): the tiled export path applies. */
    val isSimple: Boolean
        get() = buffers.isEmpty() && enabledPost.isEmpty() && image.channels.all { it.kind == ChannelKind.NONE }

    val usesAudio: Boolean
        get() = allPasses.any { p -> p.channels.any { it.kind == ChannelKind.AUDIO } }

    /** Whether the picture can change from one frame to the next without the clock moving (feedback loops). */
    val hasFeedback: Boolean
        get() = buffers.isNotEmpty()
}

class PipelineBuild(
    val pipeline: PassPipeline?,
    val diagnostics: List<ShaderDiagnostic>,
    val millis: Long,
)
