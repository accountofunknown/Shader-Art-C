package com.shaderart.studio.feature.params

import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ParamType

/** A named set of colours that can be applied to a shader's colour parameters, in order. */
data class Palette(val name: String, val colors: List<List<Float>>)

object Palettes {
    private fun hex(v: Int) = listOf(((v shr 16) and 0xFF) / 255f, ((v shr 8) and 0xFF) / 255f, (v and 0xFF) / 255f)

    val ALL: List<Palette> = listOf(
        Palette("Ember", listOf(hex(0x1B0B2E), hex(0xE4572E), hex(0xF3A712), hex(0xFFF1D0))),
        Palette("Ocean", listOf(hex(0x03045E), hex(0x0077B6), hex(0x00B4D8), hex(0xCAF0F8))),
        Palette("Forest", listOf(hex(0x0B2A1A), hex(0x2D6A4F), hex(0x95D5B2), hex(0xF1FAEE))),
        Palette("Neon", listOf(hex(0x0D0221), hex(0xFF2A6D), hex(0x05D9E8), hex(0xD1F7FF))),
        Palette("Sunset", listOf(hex(0x2B193D), hex(0xC8417A), hex(0xF8805F), hex(0xFFD88E))),
        Palette("Mono", listOf(hex(0x000000), hex(0x555555), hex(0xBBBBBB), hex(0xFFFFFF))),
        Palette("Candy", listOf(hex(0x5E2BFF), hex(0xFF6AC1), hex(0xFFD93D), hex(0x6BF0FF))),
        Palette("Earth", listOf(hex(0x2A1E14), hex(0x8C5E3C), hex(0xD9A066), hex(0xF2E8CF))),
    )

    /** Colour parameters a palette may recolour (post-effect/quality colours are left alone). */
    fun targets(params: List<ParamDef>): List<ParamDef> =
        params.filter { it.type == ParamType.COLOR && ParamLogic.isRandomizable(it) }

    fun apply(palette: Palette, params: List<ParamDef>, values: Map<String, List<Float>>): Map<String, List<Float>> {
        val targets = targets(params)
        if (targets.isEmpty() || palette.colors.isEmpty()) return values
        val out = LinkedHashMap(values)
        targets.forEachIndexed { i, def ->
            val c = palette.colors[i % palette.colors.size]
            out[def.id] = c.mapIndexed { k, x -> ParamLogic.snap(def, x, k) }
        }
        return out
    }
}
