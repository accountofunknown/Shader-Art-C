package com.shaderart.studio.core.renderer

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import com.shaderart.studio.core.gpu.GpuInfo
import com.shaderart.studio.core.input.LiveInputHub
import com.shaderart.studio.core.model.TimelineEval
import com.shaderart.studio.core.pipeline.PassPipeline
import com.shaderart.studio.core.pipeline.PassSource
import com.shaderart.studio.core.pipeline.PipelineSpec
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.uniforms.FrameUniforms
import java.util.Calendar
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * The on-screen renderer. All GL work happens on the GLSurfaceView render thread.
 *
 * Threading: the UI publishes [request] (an immutable snapshot) and touch values; this class reads them
 * at the start of each frame. Compile results and statistics travel back through [RendererListener].
 *
 * Rendering is demand-driven: while animation is playing each frame schedules the next one; when paused
 * a frame is drawn only when something changed, so a static shader costs no battery.
 */
class ShaderRenderer(private val listener: RendererListener) : GLSurfaceView.Renderer {

    @Volatile var request: RenderRequest = RenderRequest()
    @Volatile var surface: RenderSurface? = null
    @Volatile var touchX: Float = 0.5f
    @Volatile var touchY: Float = 0.5f
    @Volatile var touchDown: Boolean = false
    @Volatile var clickX: Float = 0.5f
    @Volatile var clickY: Float = 0.5f

    /** Sound, sensors and multi-touch, published by the host view and controllers. */
    val inputs = LiveInputHub()

    /** The shader clock (what u_time is), readable from any thread: touch taps are stamped with it. */
    @Volatile var shaderTime: Float = 0f

    private var pipeline: PassPipeline? = null
    private var compiledGeneration = Int.MIN_VALUE
    private var lastWarningsPipeline: PassPipeline? = null
    private var lastWarningsParams: List<*>? = null
    private val dateBuffer = FloatArray(4)

    private var width = 0
    private var height = 0
    private var animTime = 0f
    private var lastTimeCommand = Int.MIN_VALUE
    private var lastFrameNanos = 0L
    private var frame = 0L
    private var contextCount = 0

    private var fpsWindowStart = 0L
    private var fpsWindowFrames = 0
    private var fps = 0f
    private var lastStatsNanos = 0L

    private var slowFrames = 0
    private var autoPaused = false
    private var glErrorReported = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        contextCount++
        // A new context means every old GL object is gone. Forget the handles; never delete them
        // (a stale id could name a different object in the new context).
        pipeline?.forget()
        pipeline = null
        compiledGeneration = Int.MIN_VALUE
        lastWarningsPipeline = null
        lastFrameNanos = 0L
        glErrorReported = false
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glDisable(GLES30.GL_BLEND)
        listener.onCapabilities(GpuInfo.query())
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        width = w
        height = h
        GLES30.glViewport(0, 0, w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val req = request
        if (req.generation != compiledGeneration) compile(req)

        val frameStart = System.nanoTime()
        val rawDt = if (lastFrameNanos == 0L) 0f else (frameStart - lastFrameNanos) / 1e9f
        lastFrameNanos = frameStart
        // Never let a pause or a hitch teleport the animation.
        val dt = if (rawDt > 0.25f) 0.016f else rawDt

        if (req.timeCommandId != lastTimeCommand) {
            lastTimeCommand = req.timeCommandId
            animTime = req.timeSeconds
        }
        if (!req.playing) autoPaused = false
        val playing = req.playing && !autoPaused
        if (playing) animTime += dt * req.speed
        shaderTime = animTime

        // Watchdog: a shader that needs seconds per frame would make the whole device unresponsive.
        if (playing && rawDt > SLOW_FRAME_SECONDS) {
            slowFrames++
            if (slowFrames >= SLOW_FRAME_LIMIT) {
                slowFrames = 0
                autoPaused = true
                listener.onNotice(RenderNotice.AutoPaused(rawDt))
            }
        } else if (rawDt < SLOW_FRAME_SECONDS / 2f) {
            slowFrames = 0
        }

        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        GLES30.glViewport(0, 0, width, height)
        val p = pipeline
        if (p == null || width <= 0 || height <= 0) {
            GLES30.glClearColor(0f, 0f, 0f, 1f)
            GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT)
        } else {
            val reportWarnings = p !== lastWarningsPipeline || req.params !== lastWarningsParams
            if (reportWarnings) p.warnings.clear()
            val values = TimelineEval.apply(req.timeline, req.params, req.values, animTime)
            fillDate()
            p.render(
                FrameUniforms(
                    animTime, width, height, touchX, touchY, touchDown, dt, frame.toInt(), req.speed, req.zoom,
                    clickX, clickY, inputs.current, dateBuffer,
                ),
                req.params, values, finalFbo = 0, outW = width, outH = height, postStack = req.post,
            )
            if (reportWarnings) {
                lastWarningsPipeline = p
                lastWarningsParams = req.params
                if (p.warnings.isNotEmpty()) listener.onCompile(warningsReport(req.generation, p.warnings.toList()))
            }
        }
        frame++

        if (frame % GL_ERROR_CHECK_INTERVAL == 0L && !glErrorReported) {
            val err = GLES30.glGetError()
            if (err != GLES30.GL_NO_ERROR) {
                glErrorReported = true
                listener.onNotice(RenderNotice.GlError("OpenGL reported error 0x${Integer.toHexString(err)} while rendering."))
            }
        }

        updateStats(frameStart, playing, animTime)

        if (playing) {
            if (req.maxFps > 0) {
                val budget = 1_000_000_000L / req.maxFps
                val spent = System.nanoTime() - frameStart
                if (spent < budget) {
                    try {
                        Thread.sleep((budget - spent) / 1_000_000L)
                    } catch (_: InterruptedException) {
                        Thread.currentThread().interrupt()
                    }
                }
            }
            surface?.requestRender()
        } else {
            lastFrameNanos = 0L // a later resume must not see the paused time as one huge frame
        }
    }

    private fun compile(req: RenderRequest) {
        compiledGeneration = req.generation
        if (req.fragmentSource.isEmpty() || req.vertexSource.isEmpty()) return
        val spec = PipelineSpec(
            vertex = req.vertexSource,
            image = PassSource(PassId.IMAGE, req.fragmentSource, req.imageChannels),
            buffers = req.buffers,
            post = req.post,
            textureLoader = req.textureLoader,
            postSourceLoader = req.postSourceLoader,
        )
        val build = PassPipeline.build(spec)
        val fresh = build.pipeline
        if (fresh != null) {
            val old = pipeline
            pipeline = fresh
            old?.release()
            lastWarningsPipeline = null
        }
        listener.onCompile(CompileReport(req.generation, fresh != null, build.diagnostics, build.millis))
    }

    private fun fillDate() {
        val c = Calendar.getInstance()
        dateBuffer[0] = c.get(Calendar.YEAR).toFloat()
        dateBuffer[1] = c.get(Calendar.MONTH).toFloat()
        dateBuffer[2] = c.get(Calendar.DAY_OF_MONTH).toFloat()
        dateBuffer[3] = c.get(Calendar.HOUR_OF_DAY) * 3600f + c.get(Calendar.MINUTE) * 60f + c.get(Calendar.SECOND) + c.get(Calendar.MILLISECOND) / 1000f
    }

    private fun warningsReport(generation: Int, messages: List<String>) = CompileReport(
        generation = generation,
        success = true,
        diagnostics = messages.map {
            com.shaderart.studio.core.compiler.ShaderDiagnostic(
                com.shaderart.studio.core.compiler.ShaderStage.UNIFORM,
                com.shaderart.studio.core.compiler.Severity.WARNING,
                null,
                it,
            )
        },
        millis = -1L,
    )

    private fun updateStats(frameStart: Long, playing: Boolean, time: Float) {
        if (fpsWindowStart == 0L) fpsWindowStart = frameStart
        if (playing) {
            fpsWindowFrames++
            val elapsed = frameStart - fpsWindowStart
            if (elapsed >= 500_000_000L) {
                fps = fpsWindowFrames * 1e9f / elapsed
                fpsWindowFrames = 0
                fpsWindowStart = frameStart
            }
        } else {
            fps = 0f
            fpsWindowFrames = 0
            fpsWindowStart = 0L
        }
        if (frameStart - lastStatsNanos >= STATS_INTERVAL_NANOS || !playing) {
            lastStatsNanos = frameStart
            listener.onStats(
                RenderStats(
                    fps = fps,
                    frameMs = if (fps > 0f) 1000f / fps else 0f,
                    frame = frame,
                    timeSeconds = time,
                    width = width,
                    height = height,
                    contextCount = contextCount,
                ),
            )
        }
    }

    private companion object {
        const val SLOW_FRAME_SECONDS = 1.0f
        const val SLOW_FRAME_LIMIT = 3
        const val GL_ERROR_CHECK_INTERVAL = 60L
        const val STATS_INTERVAL_NANOS = 250_000_000L
    }
}
