package com.shaderart.studio.feature.studio

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shaderart.studio.app.AppContainer
import com.shaderart.studio.core.compiler.Severity
import com.shaderart.studio.core.compiler.ShaderDiagnostic
import com.shaderart.studio.core.compiler.ShaderStage
import com.shaderart.studio.core.importing.ORIGIN_IMPORTED
import android.net.Uri
import com.shaderart.studio.core.importing.ShadertoyImporter
import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ChannelKind
import com.shaderart.studio.core.model.Easing
import com.shaderart.studio.core.model.Keyframe
import com.shaderart.studio.core.model.MultipassCheck
import com.shaderart.studio.core.model.MultipassLimits
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.model.TextureAsset
import com.shaderart.studio.core.model.TextureNames
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.model.TimelineEval
import com.shaderart.studio.core.pipeline.PassSource
import com.shaderart.studio.core.pipeline.TextureDecoder
import com.shaderart.studio.core.pipeline.TextureException
import com.shaderart.studio.feature.live.AudioController
import com.shaderart.studio.feature.live.AudioSource
import com.shaderart.studio.feature.live.AudioStartException
import com.shaderart.studio.feature.live.SensorController
import com.shaderart.studio.service.WallpaperSelection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import com.shaderart.studio.core.renderer.CompileReport
import com.shaderart.studio.core.renderer.RenderNotice
import com.shaderart.studio.core.renderer.RenderSession
import com.shaderart.studio.core.security.ImportLimits
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.shader.ShaderMetadataParser
import com.shaderart.studio.core.storage.ProjectFactory
import com.shaderart.studio.core.storage.ProjectIds
import com.shaderart.studio.feature.codeeditor.AutoIndent
import com.shaderart.studio.feature.codeeditor.CodeFormatter
import com.shaderart.studio.feature.codeeditor.Completion
import com.shaderart.studio.feature.codeeditor.EditorHistory
import com.shaderart.studio.feature.codeeditor.FindEngine
import com.shaderart.studio.feature.codeeditor.LineUtil
import com.shaderart.studio.feature.export.ExportController
import com.shaderart.studio.feature.params.Palette
import com.shaderart.studio.feature.params.Palettes
import com.shaderart.studio.feature.settings.AppSettings
import kotlin.random.Random
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.launch

/** What the code editor is showing. FRAGMENT is the Image pass. */
enum class EditorTab(val pass: PassId?, val label: String) {
    FRAGMENT(PassId.IMAGE, "Image"),
    VERTEX(null, "Vertex"),
    BUFFER_A(PassId.A, "Buffer A"),
    BUFFER_B(PassId.B, "Buffer B"),
    BUFFER_C(PassId.C, "Buffer C"),
    BUFFER_D(PassId.D, "Buffer D");

    companion object {
        fun of(pass: PassId): EditorTab = entries.first { it.pass == pass }
    }
}
enum class BottomTab { OUTPUT, UNIFORMS, INFO }

data class FindState(
    val visible: Boolean = false,
    val query: String = "",
    val caseSensitive: Boolean = false,
    val matches: List<Int> = emptyList(),
    /** Index into [matches], -1 when there is none. */
    val current: Int = -1,
)

/** Asks the editor to scroll a line into view. A new [id] means a new request. */
data class ScrollRequest(val line: Int, val id: Int)

data class StudioUi(
    val hasProject: Boolean = false,
    val projectId: String? = null,
    val name: String = "",
    val type: ProjectType = ProjectType.VISUAL,
    val createdAt: Long = 0L,
    val presetOrigin: String? = null,
    /** True once the project exists in the library. Presets and templates start as unsaved drafts. */
    val saved: Boolean = false,
    val dirty: Boolean = false,
    /** Imported shaders do not run until the user presses Run. */
    val needsRun: Boolean = false,

    val params: List<ParamDef> = emptyList(),
    val values: Map<String, List<Float>> = emptyMap(),
    val playing: Boolean = true,
    val speed: Float = 1f,
    val zoom: Float = 1f,
    val quality: Float = 1f,

    val fragment: TextFieldValue = TextFieldValue(""),
    val vertex: TextFieldValue = TextFieldValue(""),
    val tab: EditorTab = EditorTab.FRAGMENT,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val suggestions: List<String> = emptyList(),
    val find: FindState = FindState(),
    val scroll: ScrollRequest? = null,

    val autoCompile: Boolean = true,
    val compiling: Boolean = false,
    /** null = not compiled yet. */
    val compileOk: Boolean? = null,
    val lastCompileMs: Long = 0L,
    val diagnostics: List<ShaderDiagnostic> = emptyList(),
    /** True when the text has changed since the last successful submit to the GPU. */
    val sourceChanged: Boolean = false,
    val bottom: BottomTab = BottomTab.OUTPUT,

    // ---- v0.02 ----
    /** Sources of buffer passes A-D that exist in this project. */
    val bufferText: Map<PassId, TextFieldValue> = emptyMap(),
    val bufferChannels: Map<PassId, List<ChannelBinding>> = emptyMap(),
    val imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
    val textures: List<TextureAsset> = emptyList(),
    val postStack: List<PostEffectInstance> = emptyList(),
    val timeline: Timeline = Timeline(),
    val audio: AudioSource = AudioSource.OFF,
    val audioFile: String? = null,
    val sensors: Boolean = false,
    /** True while a texture picture is being decoded. */
    val busy: Boolean = false,
)

/**
 * State and logic shared by Visual Studio and Code Studio. The editor text lives in Compose snapshot
 * state (not a Flow) because text fields must see their own writes synchronously. Everything here runs on
 * the main thread; GPU work happens on the renderer's thread behind [session].
 */
class StudioViewModel(private val container: AppContainer) : ViewModel() {

    val session = RenderSession()

    var ui by mutableStateOf(StudioUi())
        private set

    /** Settings mirror, used for defaults of new projects. */
    var appSettings by mutableStateOf(AppSettings())
        private set

    /** Set while a "discard unsaved changes?" question is open; holds what to do on confirmation. */
    var discardPrompt: (() -> Unit)? by mutableStateOf(null)
        private set

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    val export = ExportController(container, viewModelScope) { exportableProject() }

    private val histories = HashMap<EditorTab, EditorHistory>()
    private val audioController = AudioController(container.app, session.inputs)
    private val sensorController = SensorController(container.app, session.inputs)
    private var hosts = 0
    private var autoJob: Job? = null
    private var pendingGeneration = -1
    private var reportedGeneration = -2
    private var trusted = true
    private var scrollCounter = 0
    private val random = Random(System.nanoTime())

    /** What a "Save as" destination will receive; kept here so it survives a configuration change. */
    var pendingFileSave: PendingFileSave? = null

    init {
        viewModelScope.launch { session.compile.collect { onCompile(it) } }
        viewModelScope.launch { session.notices.collect { onNotice(it) } }
        viewModelScope.launch { session.capabilities.filterNotNull().collect { container.reportCapabilities(it) } }
        viewModelScope.launch {
            container.settings.settings.collect { s ->
                appSettings = s
                session.setMaxFps(if (s.limitTo30Fps) 30 else 0)
            }
        }
    }

    private fun say(text: String) { _messages.tryEmit(text) }

    /** Wallpaper settings (frame-rate cap) live in the container so the wallpaper service can read them too. */
    val wallpaperFps: Int get() = container.wallpaper.fps
    fun setWallpaperFps(fps: Int) { container.wallpaper.fps = fps }
    val sensorsAvailable: Pair<Boolean, Boolean> get() = sensorController.available
    fun hasMicPermission(): Boolean = audioController.hasMicPermission()

    // ------------------------------------------------------------------ opening projects

    /** Runs [action] now, or after the user agrees to drop unsaved changes. */
    fun requestOpen(action: () -> Unit) {
        if (ui.hasProject && ui.dirty) discardPrompt = action else action()
    }

    fun confirmDiscard() {
        val a = discardPrompt
        discardPrompt = null
        a?.invoke()
    }

    fun cancelDiscard() { discardPrompt = null }

    fun openPreset(presetId: String) {
        val preset = container.presets.get(presetId)
        if (preset == null) { say("That preset could not be found."); return }
        val base = ProjectFactory.fromPreset(preset, ProjectIds.newId(), System.currentTimeMillis())
        load(base.copy(render = base.render.copy(qualityScale = appSettings.qualityScale)), saved = false, trusted = true)
    }

    fun newCode(templateId: String) {
        val t = container.presets.templates.firstOrNull { it.id == templateId } ?: container.presets.templates.first()
        val source = try { container.presets.templateSource(t.id) } catch (e: Exception) { say("Could not load the template: ${e.message}"); return }
        val buffers = try { container.presets.templateBuffers(t.id) } catch (e: Exception) { say("Could not load the template: ${e.message}"); return }
        val base = ProjectFactory.newCode(
            "New ${t.name}", ProjectIds.newId(), System.currentTimeMillis(), container.presets.vertexSource, source,
            buffers = buffers, imageChannels = t.imageChannels,
        )
        load(base.copy(render = base.render.copy(qualityScale = appSettings.qualityScale)), saved = false, trusted = true)
    }

    /** Loads a saved project; [onLoaded] runs only after it has really been loaded (used to navigate). */
    fun openProject(id: String, onLoaded: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                val p = container.projects.load(id)
                container.projects.markOpened(id)
                load(p, saved = true, trusted = p.presetOrigin != ORIGIN_IMPORTED)
                onLoaded()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Could not open the project: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Turns the current visual project into an editable code project (a new unsaved draft). */
    fun openInCode() {
        val p = currentProject() ?: return
        val newId = ProjectIds.newId()
        for (tex in p.textures) {
            try { container.projects.textureFile(p.id, tex.name).copyTo(container.projects.textureFile(newId, tex.name), overwrite = true) } catch (_: Exception) { }
        }
        val copy = p.copy(
            id = newId,
            name = (p.name + " (code)").take(ImportLimits.MAX_NAME_LENGTH),
            type = ProjectType.CODE,
            createdAt = System.currentTimeMillis(),
        )
        load(copy, saved = false, trusted = trusted)
        // Keep it unsaved but flag it as changed so the user is asked before losing it.
        ui = ui.copy(dirty = true)
    }

    private fun load(p: ShaderProject, saved: Boolean, trusted: Boolean) {
        autoJob?.cancel()
        histories.values.forEach { it.clear() }
        histories.clear()
        this.trusted = trusted
        val values = ParamLogic.normalize(p.params, p.values)
        val playing = p.animation.playing && trusted
        ui = StudioUi(
            hasProject = true,
            projectId = p.id,
            name = p.name,
            type = p.type,
            createdAt = p.createdAt,
            presetOrigin = p.presetOrigin,
            saved = saved,
            dirty = false,
            needsRun = !trusted,
            params = p.params,
            values = values,
            playing = playing,
            speed = p.animation.speed,
            zoom = p.render.zoom,
            quality = p.render.qualityScale.coerceIn(0.25f, 1f),
            fragment = TextFieldValue(p.fragmentSource),
            vertex = TextFieldValue(p.vertexSource),
            bufferText = p.buffers.associate { it.id to TextFieldValue(it.fragmentSource) },
            bufferChannels = p.buffers.associate { it.id to it.channels },
            imageChannels = p.imageChannels,
            textures = p.textures,
            postStack = PostEffects.sanitize(p.postStack),
            timeline = p.timeline,
            audio = ui.audio,
            audioFile = ui.audioFile,
            sensors = ui.sensors,
            autoCompile = ui.autoCompile,
            diagnostics = if (trusted) emptyList() else listOf(
                ShaderDiagnostic(ShaderStage.CONTEXT, Severity.INFO, null, "This shader was imported. Read it first, then press Run to compile and start it."),
            ),
        )
        session.setSpeed(p.animation.speed)
        session.setZoom(p.render.zoom)
        session.setPlaying(playing)
        session.updateParams(p.params, values)
        session.setTimeline(p.timeline)
        session.seek(p.animation.time)
        if (trusted) submit() else session.requestFrame()
    }

    // ------------------------------------------------------------------ compiling

    fun run() {
        if (!ui.hasProject) return
        autoJob?.cancel()
        trusted = true
        if (ui.needsRun) {
            ui = ui.copy(needsRun = false, playing = true)
            session.setPlaying(true)
        }
        submit()
    }

    fun stop() {
        ui = ui.copy(playing = false)
        session.setPlaying(false)
    }

    fun setAutoCompile(on: Boolean) {
        ui = ui.copy(autoCompile = on)
        if (on) scheduleAutoCompile() else autoJob?.cancel()
    }

    private fun scheduleAutoCompile() {
        autoJob?.cancel()
        if (!ui.autoCompile || !trusted || ui.type != ProjectType.CODE) return
        autoJob = viewModelScope.launch {
            delay(AUTO_COMPILE_DELAY_MS)
            submit()
        }
    }

    private fun passSpecs(): List<PassSpec> =
        ui.bufferText.entries.sortedBy { it.key.ordinal }.map { (id, tf) -> PassSpec(id, tf.text, ui.bufferChannels[id] ?: ChannelBinding.noneChannels()) }

    private fun submit() {
        val frag = ui.fragment.text
        val vert = ui.vertex.text
        val buffers = passSpecs()
        val problems = ArrayList<ShaderDiagnostic>()
        GlslSourceCheck.check(vert, "Vertex").forEach { problems += ShaderDiagnostic(ShaderStage.VERTEX, Severity.ERROR, null, it) }
        GlslSourceCheck.check(frag, "Fragment").forEach { problems += ShaderDiagnostic(ShaderStage.FRAGMENT, Severity.ERROR, null, it) }
        for (b in buffers) {
            GlslSourceCheck.check(b.fragmentSource, b.id.label).forEach { problems += ShaderDiagnostic(ShaderStage.FRAGMENT, Severity.ERROR, null, it, pass = b.id.label) }
        }
        MultipassCheck.check(buffers, ui.imageChannels, ui.textures).forEach { problems += ShaderDiagnostic(ShaderStage.CONTEXT, Severity.ERROR, null, it) }
        if (problems.isNotEmpty()) {
            ui = ui.copy(compiling = false, compileOk = false, diagnostics = problems)
            return
        }
        if (ui.type == ProjectType.CODE) {
            val parsed = ProjectFactory.paramsFor(frag, buffers)
            val merged = mergeParams(ui.params, parsed)
            if (merged != ui.params) {
                ui = ui.copy(params = merged, values = ParamLogic.normalize(merged, ui.values))
            }
        }
        session.updateParams(ui.params, ui.values)
        session.setTimeline(ui.timeline)
        pendingGeneration = session.submitProject(
            vert, frag, ui.imageChannels,
            buffers.map { PassSource(it.id, it.fragmentSource, it.channels) },
            ui.postStack,
            container.textureLoader(ui.projectId ?: ""),
            container.postSourceLoader,
        )
        ui = ui.copy(compiling = true, sourceChanged = false)
    }

    /** Rebuilds the GPU pipeline after a structural change (post effects added or removed, a channel rebound). */
    private fun resubmit() {
        if (!ui.hasProject || ui.needsRun || !trusted) { ui = ui.copy(sourceChanged = true); return }
        if (ui.type == ProjectType.CODE) scheduleAutoCompile() else submit()
    }

    /**
     * Custom (annotation-derived) controls follow the source: their range and label update when the
     * annotation changes. Everything else keeps its definition, and so keeps the user's value.
     */
    private fun mergeParams(existing: List<ParamDef>, parsed: List<ParamDef>): List<ParamDef> {
        val byUniform = parsed.associateBy { it.uniform }
        val refreshed = existing.map { e -> if (e.group == "Custom") byUniform[e.uniform] ?: e else e }
        return ShaderMetadataParser.merge(refreshed, parsed)
    }

    private fun onCompile(r: CompileReport) {
        if (r.millis < 0) {
            // Uniform warnings for the program that is currently running.
            if (r.generation != reportedGeneration) return
            ui = ui.copy(diagnostics = ui.diagnostics.filter { it.stage != ShaderStage.UNIFORM } + r.diagnostics)
            return
        }
        if (r.generation < pendingGeneration) return // a newer compile is already on its way
        reportedGeneration = r.generation
        ui = ui.copy(compiling = false, compileOk = r.success, lastCompileMs = r.millis, diagnostics = r.diagnostics)
    }

    private fun onNotice(n: RenderNotice) {
        when (n) {
            is RenderNotice.AutoPaused -> {
                ui = ui.copy(playing = false)
                session.setPlaying(false)
                say("This shader is very slow on this device, so animation was paused. Lower the quality or simplify the shader.")
            }
            is RenderNotice.GlError -> say(n.message)
        }
    }

    // ------------------------------------------------------------------ parameters and playback

    private fun pushParams() = session.updateParams(ui.params, ui.values)

    fun setParam(def: ParamDef, index: Int, raw: Float) {
        ui = ui.copy(values = ParamLogic.withValue(ui.values, def, index, raw), dirty = true)
        pushParams()
    }

    fun randomize() { ui = ui.copy(values = ParamLogic.randomize(ui.params, ui.values, random), dirty = true); pushParams() }
    fun variation() { ui = ui.copy(values = ParamLogic.variation(ui.params, ui.values, random), dirty = true); pushParams() }
    fun resetParams() { ui = ui.copy(values = ParamLogic.defaults(ui.params), dirty = true); pushParams() }
    fun applyPalette(p: Palette) { ui = ui.copy(values = Palettes.apply(p, ui.params, ui.values), dirty = true); pushParams() }

    fun togglePlay() {
        val next = !ui.playing
        ui = ui.copy(playing = next)
        session.setPlaying(next)
    }

    fun restart() { session.seek(0f); session.requestFrame() }

    fun setSpeed(s: Float) {
        val v = s.coerceIn(0f, 4f)
        ui = ui.copy(speed = v, dirty = true)
        session.setSpeed(v)
    }

    fun setZoom(z: Float) {
        val v = z.coerceIn(0.25f, 8f)
        ui = ui.copy(zoom = v, dirty = true)
        session.setZoom(v)
    }

    fun onPinch(factor: Float) { if (factor.isFinite() && factor > 0f) setZoom(ui.zoom * factor) }

    fun setQuality(q: Float) { ui = ui.copy(quality = q.coerceIn(0.25f, 1f), dirty = true) }

    fun setBottom(tab: BottomTab) { ui = ui.copy(bottom = tab) }

    // ------------------------------------------------------------------ editor

    private fun buffer(tab: EditorTab): TextFieldValue = when (tab) {
        EditorTab.FRAGMENT -> ui.fragment
        EditorTab.VERTEX -> ui.vertex
        else -> ui.bufferText[tab.pass] ?: TextFieldValue("")
    }
    private fun history(tab: EditorTab): EditorHistory = histories.getOrPut(tab) { EditorHistory() }

    private fun setBuffer(tab: EditorTab, v: TextFieldValue) {
        ui = when (tab) {
            EditorTab.FRAGMENT -> ui.copy(fragment = v)
            EditorTab.VERTEX -> ui.copy(vertex = v)
            else -> tab.pass?.let { id -> if (id in ui.bufferText) ui.copy(bufferText = ui.bufferText + (id to v)) else ui } ?: ui
        }
    }

    fun selectTab(tab: EditorTab) {
        ui = ui.copy(tab = tab)
        refreshAfterEdit()
    }

    fun onEditorChange(new: TextFieldValue) {
        val tab = ui.tab
        val old = buffer(tab)
        if (new.text == old.text) {
            setBuffer(tab, new)
            ui = ui.copy(suggestions = suggestionsFor(new))
            return
        }
        if (new.text.length > ImportLimits.MAX_SOURCE_BYTES) {
            say("The shader is too large (limit ${ImportLimits.MAX_SOURCE_BYTES / 1024} KB).")
            return
        }
        var applied = new
        AutoIndent.onTyped(old.text, new.text, new.selection.start)?.let { applied = TextFieldValue(it.text, TextRange(it.cursor)) }
        history(tab).beforeChange(EditorHistory.Snapshot(old.text, old.selection.start), SystemClock.elapsedRealtime())
        setBuffer(tab, applied)
        afterTextChange()
    }

    private fun afterTextChange() {
        ui = ui.copy(dirty = true, sourceChanged = true)
        refreshAfterEdit()
        scheduleAutoCompile()
    }

    private fun refreshAfterEdit() {
        val tab = ui.tab
        val b = buffer(tab)
        val h = history(tab)
        var find = ui.find
        if (find.visible) {
            val matches = FindEngine.findAll(b.text, find.query, find.caseSensitive)
            find = find.copy(matches = matches, current = if (matches.isEmpty()) -1 else find.current.coerceIn(0, matches.lastIndex))
        }
        ui = ui.copy(canUndo = h.canUndo, canRedo = h.canRedo, suggestions = suggestionsFor(b), find = find)
    }

    private fun suggestionsFor(v: TextFieldValue): List<String> =
        if (v.selection.collapsed) Completion.suggest(v.text, v.selection.start) else emptyList()

    fun undo() {
        val tab = ui.tab
        val cur = buffer(tab)
        val snap = history(tab).undo(EditorHistory.Snapshot(cur.text, cur.selection.start)) ?: return
        setBuffer(tab, TextFieldValue(snap.text, TextRange(snap.cursor.coerceIn(0, snap.text.length))))
        afterTextChange()
    }

    fun redo() {
        val tab = ui.tab
        val cur = buffer(tab)
        val snap = history(tab).redo(EditorHistory.Snapshot(cur.text, cur.selection.start)) ?: return
        setBuffer(tab, TextFieldValue(snap.text, TextRange(snap.cursor.coerceIn(0, snap.text.length))))
        afterTextChange()
    }

    fun format() {
        val tab = ui.tab
        val cur = buffer(tab)
        val formatted = CodeFormatter.format(cur.text)
        if (formatted == cur.text) return
        history(tab).beforeChange(EditorHistory.Snapshot(cur.text, cur.selection.start), SystemClock.elapsedRealtime(), forceBreak = true)
        setBuffer(tab, TextFieldValue(formatted, TextRange(cur.selection.start.coerceIn(0, formatted.length))))
        afterTextChange()
    }

    fun insertText(text: String) {
        val tab = ui.tab
        val cur = buffer(tab)
        val s = cur.selection.min
        val e = cur.selection.max
        val next = cur.text.substring(0, s) + text + cur.text.substring(e)
        onEditorChange(TextFieldValue(next, TextRange(s + text.length)))
    }

    fun applySuggestion(s: String) {
        val tab = ui.tab
        val cur = buffer(tab)
        val r = Completion.apply(cur.text, cur.selection.start, s)
        history(tab).beforeChange(EditorHistory.Snapshot(cur.text, cur.selection.start), SystemClock.elapsedRealtime(), forceBreak = true)
        setBuffer(tab, TextFieldValue(r.text, TextRange(r.cursor)))
        afterTextChange()
    }

    /** Moves the cursor to the start of 1-based [line] in the tab that [stage] belongs to, and scrolls there. */
    fun goToLine(stage: ShaderStage, line: Int, pass: String? = null) {
        val passTab = PassId.entries.firstOrNull { it.label == pass && it.isBuffer }?.let { EditorTab.of(it) }
        val tab = passTab ?: if (stage == ShaderStage.VERTEX) EditorTab.VERTEX else EditorTab.FRAGMENT
        if (tab.pass != null && tab != EditorTab.FRAGMENT && tab.pass !in ui.bufferText) return
        val text = buffer(tab).text
        val offset = LineUtil.offsetOfLine(text, line.coerceAtLeast(1))
        ui = ui.copy(tab = tab)
        setBuffer(tab, TextFieldValue(text, TextRange(offset)))
        ui = ui.copy(scroll = ScrollRequest(line.coerceAtLeast(1), ++scrollCounter))
        refreshAfterEdit()
    }

    // ------------------------------------------------------------------ find

    fun toggleFind() {
        val visible = !ui.find.visible
        ui = ui.copy(find = ui.find.copy(visible = visible))
        if (visible) updateFind(ui.find.query, ui.find.caseSensitive)
    }

    fun updateFind(query: String, caseSensitive: Boolean = ui.find.caseSensitive) {
        val text = buffer(ui.tab).text
        val matches = FindEngine.findAll(text, query, caseSensitive)
        val cursor = buffer(ui.tab).selection.start
        val cur = FindEngine.nextIndex(matches, cursor)
        ui = ui.copy(find = ui.find.copy(query = query, caseSensitive = caseSensitive, matches = matches, current = cur))
        if (cur >= 0) selectMatch(cur)
    }

    fun findNext() {
        val f = ui.find
        if (f.matches.isEmpty()) return
        selectMatch((f.current + 1) % f.matches.size)
    }

    fun findPrevious() {
        val f = ui.find
        if (f.matches.isEmpty()) return
        selectMatch(if (f.current <= 0) f.matches.lastIndex else f.current - 1)
    }

    private fun selectMatch(index: Int) {
        val f = ui.find
        val start = f.matches.getOrNull(index) ?: return
        val tab = ui.tab
        val text = buffer(tab).text
        setBuffer(tab, TextFieldValue(text, TextRange(start, (start + f.query.length).coerceAtMost(text.length))))
        ui = ui.copy(
            find = f.copy(current = index),
            scroll = ScrollRequest(LineUtil.lineOfOffset(text, start), ++scrollCounter),
        )
    }

    // ------------------------------------------------------------------ project data

    fun rename(name: String) {
        val n = name.trim().take(ImportLimits.MAX_NAME_LENGTH)
        if (n.isEmpty()) return
        ui = ui.copy(name = n, dirty = true)
    }

    /** The project as currently edited (not necessarily saved). Null when nothing is open. */
    fun currentProject(): ShaderProject? {
        val u = ui
        val id = u.projectId ?: return null
        if (!u.hasProject) return null
        val stats = session.stats.value
        return ShaderProject(
            id = id,
            name = u.name,
            type = u.type,
            createdAt = u.createdAt,
            modifiedAt = System.currentTimeMillis(),
            vertexSource = u.vertex.text,
            fragmentSource = u.fragment.text,
            params = u.params,
            values = ParamLogic.normalize(u.params, u.values),
            animation = AnimationConfig(playing = u.playing, speed = u.speed, time = stats.timeSeconds),
            render = RenderSettings(qualityScale = u.quality, previewWidth = stats.width, previewHeight = stats.height, zoom = u.zoom),
            presetOrigin = u.presetOrigin,
            buffers = passSpecs(),
            imageChannels = u.imageChannels,
            textures = u.textures,
            timeline = u.timeline,
            postStack = u.postStack,
        )
    }

    /** Like [currentProject], but null while an imported shader has not been run (it must not execute unasked). */
    private fun exportableProject(): ShaderProject? = if (ui.needsRun) null else currentProject()

    fun save() {
        val p = currentProject() ?: return
        viewModelScope.launch {
            try {
                val saved = container.projects.save(p)
                ui = ui.copy(saved = true, dirty = false, projectId = saved.id)
                say("Saved “${saved.name}”.")
                if (!ui.needsRun) {
                    try {
                        container.projects.saveThumbnail(saved.id, container.export.renderThumbnail(saved))
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        say("Saved, but the thumbnail could not be created: ${e.message ?: "unknown error"}")
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                say("Could not save: ${e.message ?: "unknown error"}")
            }
        }
    }

    /** Saves the project (if needed) and returns its id, for actions that need it in the library. */
    suspend fun ensureSaved(): String? {
        val p = currentProject() ?: return null
        if (ui.saved && !ui.dirty) return p.id
        return try {
            val saved = container.projects.save(p)
            ui = ui.copy(saved = true, dirty = false, projectId = saved.id)
            saved.id
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            say("Could not save: ${e.message ?: "unknown error"}")
            null
        }
    }

    // ------------------------------------------------------------------ passes, channels, textures (code projects)

    private fun editable(): Boolean {
        if (ui.type != ProjectType.CODE) { say("Edit a copy of the preset first to change its passes."); return false }
        return true
    }

    fun addBuffer(id: PassId) {
        if (!editable() || !id.isBuffer || id in ui.bufferText) return
        ui = ui.copy(
            bufferText = ui.bufferText + (id to TextFieldValue(container.presets.bufferTemplate)),
            bufferChannels = ui.bufferChannels + (id to ChannelBinding.noneChannels()),
            tab = EditorTab.of(id),
        )
        afterTextChange()
    }

    fun removeBuffer(id: PassId) {
        if (!editable() || id !in ui.bufferText) return
        fun unbind(list: List<ChannelBinding>) = list.map { if (it.kind == ChannelKind.BUFFER && it.ref == id.key) ChannelBinding.NONE else it }
        histories.remove(EditorTab.of(id))
        ui = ui.copy(
            bufferText = ui.bufferText - id,
            bufferChannels = (ui.bufferChannels - id).mapValues { unbind(it.value) },
            imageChannels = unbind(ui.imageChannels),
            tab = if (ui.tab == EditorTab.of(id)) EditorTab.FRAGMENT else ui.tab,
        )
        afterTextChange()
    }

    /** Binds channel [index] (0-3) of [pass] to [binding]. */
    fun setChannel(pass: PassId, index: Int, binding: ChannelBinding) {
        if (!editable() || index !in 0 until ChannelBinding.CHANNEL_COUNT) return
        if (pass == PassId.IMAGE) {
            ui = ui.copy(imageChannels = ui.imageChannels.toMutableList().also { it[index] = binding })
        } else {
            val cur = ui.bufferChannels[pass] ?: return
            ui = ui.copy(bufferChannels = ui.bufferChannels + (pass to cur.toMutableList().also { it[index] = binding }))
        }
        ui = ui.copy(dirty = true, sourceChanged = true)
        resubmit()
    }

    /** Reads a picture the person chose, shrinks it, stores it with the project and makes it available as a channel input. */
    fun importTexture(uri: Uri) {
        if (!editable()) return
        val projectId = ui.projectId ?: return
        if (ui.textures.size >= MultipassLimits.MAX_TEXTURES) { say("A project can hold at most ${MultipassLimits.MAX_TEXTURES} pictures."); return }
        ui = ui.copy(busy = true)
        viewModelScope.launch {
            try {
                val name = container.uriIO.displayName(uri)
                val imported = withContext(Dispatchers.Default) {
                    TextureDecoder.import(container.uriIO.readLimited(uri, TEXTURE_SOURCE_LIMIT))
                }
                val texName = TextureNames.fromFileName(name, ui.textures.map { it.name }.toSet())
                container.projects.saveTexture(projectId, texName, imported.pngBytes)
                ui = ui.copy(textures = ui.textures + TextureAsset(texName, imported.width, imported.height), dirty = true, busy = false)
                say("Added picture “$texName” (${imported.width}×${imported.height}). Bind it to a channel to use it.")
            } catch (e: CancellationException) {
                ui = ui.copy(busy = false)
                throw e
            } catch (e: TextureException) {
                ui = ui.copy(busy = false)
                say(e.message ?: "This picture could not be used.")
            } catch (e: Exception) {
                ui = ui.copy(busy = false)
                say("Could not add the picture: ${e.message ?: "unknown error"}")
            }
        }
    }

    fun removeTexture(name: String) {
        if (!editable()) return
        fun unbind(list: List<ChannelBinding>) = list.map { if (it.kind == ChannelKind.TEXTURE && it.ref == name) ChannelBinding.NONE else it }
        ui = ui.copy(
            textures = ui.textures.filterNot { it.name == name },
            imageChannels = unbind(ui.imageChannels),
            bufferChannels = ui.bufferChannels.mapValues { unbind(it.value) },
            dirty = true, sourceChanged = true,
        )
        resubmit()
    }

    // ------------------------------------------------------------------ post-effect stack

    fun addPostEffect(effectId: String) {
        val def = PostEffects.find(effectId) ?: return
        if (ui.postStack.size >= MultipassLimits.MAX_POST) { say("A project can have at most ${MultipassLimits.MAX_POST} post effects."); return }
        ui = ui.copy(postStack = ui.postStack + PostEffects.newInstance(def), dirty = true)
        pushPostStructure()
    }

    fun removePostEffect(index: Int) {
        if (index !in ui.postStack.indices) return
        ui = ui.copy(postStack = ui.postStack.filterIndexed { i, _ -> i != index }, dirty = true)
        pushPostStructure()
    }

    fun movePostEffect(index: Int, delta: Int) {
        val to = index + delta
        if (index !in ui.postStack.indices || to !in ui.postStack.indices) return
        val list = ui.postStack.toMutableList()
        list.add(to, list.removeAt(index))
        ui = ui.copy(postStack = list, dirty = true)
        pushPostStructure()
    }

    fun setPostEnabled(index: Int, enabled: Boolean) {
        val cur = ui.postStack.getOrNull(index) ?: return
        ui = ui.copy(postStack = ui.postStack.toMutableList().also { it[index] = cur.copy(enabled = enabled) }, dirty = true)
        pushPostStructure()
    }

    /** Changes one slider of one effect. Does not recompile anything. */
    fun setPostValue(index: Int, param: Int, value: Float) {
        val cur = ui.postStack.getOrNull(index) ?: return
        if (param !in cur.values.indices || !value.isFinite()) return
        val inst = PostEffects.normalized(cur.copy(values = cur.values.toMutableList().also { it[param] = value })) ?: return
        ui = ui.copy(postStack = ui.postStack.toMutableList().also { it[index] = inst }, dirty = true)
        session.updatePostValues(ui.postStack)
    }

    private fun pushPostStructure() {
        if (ui.needsRun || !trusted) { session.requestFrame(); return }
        submit()
    }

    // ------------------------------------------------------------------ keyframe timeline

    private fun updateTimeline(t: Timeline) {
        ui = ui.copy(timeline = t, dirty = true)
        session.setTimeline(t)
    }

    /** Adds a key for one component of [paramId] at the shader's current time, with the control's current value. */
    fun addKey(paramId: String, component: Int) {
        val def = ui.params.firstOrNull { it.id == paramId } ?: return
        val tl = ui.timeline
        val track = tl.track(paramId, component)
        if (track == null && tl.tracks.size >= MultipassLimits.MAX_TRACKS) { say("A timeline can have at most ${MultipassLimits.MAX_TRACKS} animated values."); return }
        if ((track?.keys?.size ?: 0) >= MultipassLimits.MAX_KEYS) { say("A track can have at most ${MultipassLimits.MAX_KEYS} keys."); return }
        val t = TimelineEval.localTime(tl, session.stats.value.timeSeconds).coerceIn(0f, tl.durationSeconds)
        val value = (ui.values[paramId] ?: def.defaults).getOrElse(component) { def.defaults.firstOrNull() ?: 0f }
        updateTimeline(tl.withKey(paramId, component, Keyframe(t, value, Easing.SMOOTH)))
    }

    fun editKey(paramId: String, component: Int, index: Int, time: Float? = null, value: Float? = null, easing: Easing? = null) {
        val tl = ui.timeline
        val track = tl.track(paramId, component) ?: return
        val old = track.keys.getOrNull(index) ?: return
        val def = ui.params.firstOrNull { it.id == paramId } ?: return
        val key = Keyframe(
            t = (time ?: old.t).coerceIn(0f, tl.durationSeconds),
            v = (value ?: old.v).coerceIn(def.min, def.max),
            easing = easing ?: old.easing,
        )
        if (!key.t.isFinite() || !key.v.isFinite()) return
        updateTimeline(tl.withoutKey(paramId, component, index).withKey(paramId, component, key))
    }

    fun removeKey(paramId: String, component: Int, index: Int) = updateTimeline(ui.timeline.withoutKey(paramId, component, index))

    fun setTimelineDuration(seconds: Float) {
        if (!seconds.isFinite()) return
        val d = seconds.coerceIn(0.5f, 600f)
        val tl = ui.timeline
        updateTimeline(
            tl.copy(
                durationSeconds = d,
                tracks = tl.tracks.map { tr -> tr.copy(keys = tr.keys.map { k -> k.copy(t = k.t.coerceAtMost(d)) }) },
            ),
        )
    }

    fun setTimelineLoop(loop: Boolean) = updateTimeline(ui.timeline.copy(loop = loop))
    fun setTimelineEnabled(on: Boolean) = updateTimeline(ui.timeline.copy(enabled = on))
    fun clearTimeline() = updateTimeline(ui.timeline.copy(tracks = emptyList()))

    // ------------------------------------------------------------------ live inputs (sound, sensors)

    /** Called by each studio screen while it is on screen. Inputs run only while at least one is. */
    fun hostAttached() {
        if (++hosts == 1) resumeInputs()
    }

    fun hostDetached() {
        if (hosts > 0) hosts--
        if (hosts == 0) pauseInputs()
    }

    private fun resumeInputs() {
        if (ui.sensors) sensorController.start()
        audioController.setForeground(true)
        if (ui.audio == AudioSource.DEMO && audioController.source == AudioSource.OFF) {
            try { audioController.start(AudioSource.DEMO) } catch (_: AudioStartException) { }
        }
    }

    private fun pauseInputs() {
        sensorController.stop()
        audioController.setForeground(false)
        when (ui.audio) {
            AudioSource.DEMO -> audioController.stop()
            AudioSource.MIC -> {
                // The microphone is never left open in the background.
                audioController.stop()
                ui = ui.copy(audio = AudioSource.OFF)
                say("The microphone was switched off because the studio is no longer on screen.")
            }
            else -> Unit
        }
    }

    /** Starts a sound source. For MIC the caller must already hold the RECORD_AUDIO permission. */
    fun setAudioSource(source: AudioSource, file: Uri? = null, fileName: String? = null) {
        if ((source == AudioSource.MIC || source == AudioSource.FILE) && !audioController.hasMicPermission()) {
            say("Android needs the microphone permission to analyse sound. It is only used on this device.")
            return
        }
        try {
            audioController.start(source, file)
            ui = ui.copy(audio = source, audioFile = if (source == AudioSource.FILE) fileName else null)
        } catch (e: AudioStartException) {
            ui = ui.copy(audio = AudioSource.OFF, audioFile = null)
            say(e.message ?: "The sound source could not be started.")
        } catch (e: SecurityException) {
            ui = ui.copy(audio = AudioSource.OFF, audioFile = null)
            say("Android refused access to the sound source.")
        }
    }

    fun setSensors(on: Boolean) {
        ui = ui.copy(sensors = on)
        if (on) {
            val (gyro, accel) = sensorController.available
            if (!gyro && !accel) say("This device has no motion sensors.") else if (hosts > 0) sensorController.start()
        } else {
            sensorController.stop()
        }
    }

    // ------------------------------------------------------------------ Shadertoy import and wallpaper

    /** Converts pasted Shadertoy code or JSON into a new code project. Like every import, it must be run by the person first. */
    fun importShadertoy(text: String) {
        val result = try {
            ShadertoyImporter.convert(text)
        } catch (e: Exception) {
            say(e.message ?: "This does not look like Shadertoy code.")
            return
        }
        val now = System.currentTimeMillis()
        val project = ProjectFactory.newCode(
            result.name.take(ImportLimits.MAX_NAME_LENGTH), ProjectIds.newId(), now, container.presets.vertexSource, result.imageSource,
            buffers = result.buffers, imageChannels = result.imageChannels,
        )
        load(project.copy(render = project.render.copy(qualityScale = appSettings.qualityScale)), saved = false, trusted = false)
        val notes = result.warnings.map { ShaderDiagnostic(ShaderStage.CONTEXT, Severity.WARNING, null, it) }
        if (notes.isNotEmpty()) ui = ui.copy(diagnostics = ui.diagnostics + notes)
        if (result.usesAudio) say("This shader listens to sound. Start a sound source with the Inputs button.")
    }

    /** Saves the project, remembers it as the wallpaper source and returns true when the system wallpaper picker may be opened. */
    suspend fun prepareWallpaper(): Boolean {
        val id = ensureSaved() ?: return false
        container.wallpaper.set(WallpaperSelection.Choice(WallpaperSelection.Kind.PROJECT, id, ui.name))
        return true
    }

    fun message(text: String) = say(text)

    override fun onCleared() {
        autoJob?.cancel()
        export.cancel()
        audioController.stop()
        sensorController.stop()
        super.onCleared()
    }

    private companion object {
        const val AUTO_COMPILE_DELAY_MS = 700L
        const val TEXTURE_SOURCE_LIMIT = 20_000_000
    }
}

/** What the next system "create document" result should write. */
sealed class PendingFileSave {
    data class Source(val text: String) : PendingFileSave()
    data object Archive : PendingFileSave()
}
