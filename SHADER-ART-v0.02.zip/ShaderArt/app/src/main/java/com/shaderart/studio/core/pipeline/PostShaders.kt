package com.shaderart.studio.core.pipeline

/** The fixed vertex shader used by post-effect passes: one oversized triangle, no vertex buffer. */
object PostShaders {
    const val VERTEX = """#version 300 es
out vec2 v_uv;
void main() {
    vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2));
    v_uv = p;
    gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0);
}
"""
}
