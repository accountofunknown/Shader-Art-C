package com.shaderart.studio.core.model

/** One entry of a project's post-effect stack. [values] has one entry per parameter of the effect. */
data class PostEffectInstance(val effectId: String, val enabled: Boolean = true, val values: List<Float> = emptyList())

data class PostParam(val name: String, val min: Float, val max: Float, val default: Float)

/**
 * A post effect: one or more fullscreen passes (asset files in assets/post/) applied to the project's final image.
 * Pass shaders read `u_input`; passes of effects with [usesOriginal] can also read the effect's own input as `u_orig`.
 * Parameters arrive as `u_p0`..`u_p3`.
 */
data class PostEffectDef(
    val id: String,
    val name: String,
    val params: List<PostParam>,
    val passes: List<String>,
    val usesOriginal: Boolean = false,
) {
    fun defaults(): List<Float> = params.map { it.default }
}

object PostEffects {
    val all: List<PostEffectDef> = listOf(
        PostEffectDef("vignette", "Vignette", listOf(PostParam("Strength", 0f, 1.5f, 0.6f), PostParam("Softness", 0.05f, 1f, 0.5f)), listOf("vignette")),
        PostEffectDef("blur", "Gaussian blur", listOf(PostParam("Radius (px)", 0f, 40f, 6f)), listOf("blur_h", "blur_v")),
        PostEffectDef(
            "bloom", "Bloom",
            listOf(PostParam("Threshold", 0f, 1f, 0.6f), PostParam("Intensity", 0f, 3f, 1f), PostParam("Radius (px)", 1f, 40f, 12f)),
            listOf("bloom_a", "bloom_b", "bloom_c"), usesOriginal = true,
        ),
        PostEffectDef(
            "grade", "Colour grade",
            listOf(PostParam("Exposure", -2f, 2f, 0f), PostParam("Contrast", 0.2f, 2.5f, 1f), PostParam("Saturation", 0f, 2.5f, 1f), PostParam("Hue shift", -0.5f, 0.5f, 0f)),
            listOf("grade"),
        ),
        PostEffectDef("chroma", "Chromatic aberration", listOf(PostParam("Amount (px)", 0f, 30f, 4f)), listOf("chroma")),
        PostEffectDef("lens", "Lens distortion", listOf(PostParam("Distortion", -1f, 1f, 0.25f)), listOf("lens")),
        PostEffectDef("sharpen", "Sharpen", listOf(PostParam("Amount", 0f, 3f, 0.8f)), listOf("sharpen")),
        PostEffectDef("filmgrain", "Film grain", listOf(PostParam("Amount", 0f, 0.5f, 0.12f), PostParam("Size", 1f, 6f, 1.5f)), listOf("filmgrain")),
        PostEffectDef("pixelate", "Pixelate", listOf(PostParam("Block size (px)", 1f, 64f, 8f)), listOf("pixelate")),
        PostEffectDef("posterize", "Posterize", listOf(PostParam("Levels", 2f, 16f, 5f)), listOf("posterize")),
        PostEffectDef("invert", "Invert", listOf(PostParam("Amount", 0f, 1f, 1f)), listOf("invert")),
        PostEffectDef("duotone", "Duotone", listOf(PostParam("Shadow hue", 0f, 1f, 0.62f), PostParam("Light hue", 0f, 1f, 0.08f), PostParam("Mix", 0f, 1f, 1f)), listOf("duotone")),
        PostEffectDef("kaleido", "Mirror / kaleidoscope", listOf(PostParam("Segments", 1f, 16f, 6f), PostParam("Rotation", -3.1416f, 3.1416f, 0f), PostParam("Mix", 0f, 1f, 1f)), listOf("kaleido")),
        PostEffectDef("edges", "Edge detect", listOf(PostParam("Strength", 0f, 6f, 2f), PostParam("Mix", 0f, 1f, 1f)), listOf("edges")),
    )

    fun find(id: String): PostEffectDef? = all.firstOrNull { it.id == id }

    fun newInstance(def: PostEffectDef) = PostEffectInstance(def.id, true, def.defaults())

    /** Values padded or clamped to the definition: always exactly one finite value per parameter. */
    fun normalized(inst: PostEffectInstance): PostEffectInstance? {
        val def = find(inst.effectId) ?: return null
        val v = def.params.mapIndexed { i, p ->
            val x = inst.values.getOrNull(i)?.takeIf { it.isFinite() } ?: p.default
            x.coerceIn(p.min, p.max)
        }
        return inst.copy(values = v)
    }

    /** Unknown effects are dropped; the rest are normalized. */
    fun sanitize(stack: List<PostEffectInstance>): List<PostEffectInstance> =
        stack.mapNotNull { normalized(it) }.take(MultipassLimits.MAX_POST)
}
