package com.shaderart.studio.feature.live

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import com.shaderart.studio.core.input.LiveInputHub

/**
 * Feeds the motion sensors into u_gyro (rotation rate), u_accel (movement without gravity) and u_tilt (gravity direction).
 * Registered only while [start] has been called (the screen calls it while a shader that uses them is visible), so the
 * sensors cost nothing otherwise. Sensor data never leaves the device.
 */
class SensorController(context: Context, private val hub: LiveInputHub) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val gyro = FloatArray(3)
    private val accel = FloatArray(3)
    private val gravity = FloatArray(3)
    private val tilt = FloatArray(2)
    private var gravityReady = false
    private var running = false

    /** What this device has: (gyroscope, accelerometer). */
    val available: Pair<Boolean, Boolean>
        get() = (manager?.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null) to (manager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null)

    fun start() {
        if (running) return
        val m = manager ?: return
        m.getDefaultSensor(Sensor.TYPE_GYROSCOPE)?.let { m.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        m.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { m.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        running = true
    }

    fun stop() {
        if (!running) return
        manager?.unregisterListener(this)
        running = false
        gravityReady = false
        gyro.fill(0f); accel.fill(0f); gravity.fill(0f); tilt.fill(0f)
        hub.clearSensors()
    }

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GYROSCOPE -> for (i in 0 until 3) gyro[i] = e.values[i]
            Sensor.TYPE_ACCELEROMETER -> {
                if (!gravityReady) { for (i in 0 until 3) gravity[i] = e.values[i]; gravityReady = true }
                for (i in 0 until 3) {
                    gravity[i] = GRAVITY_FILTER * gravity[i] + (1f - GRAVITY_FILTER) * e.values[i]
                    accel[i] = e.values[i] - gravity[i]
                }
                tilt[0] = (gravity[0] / SensorManager.GRAVITY_EARTH).coerceIn(-1f, 1f)
                tilt[1] = (gravity[1] / SensorManager.GRAVITY_EARTH).coerceIn(-1f, 1f)
            }
            else -> return
        }
        hub.setSensors(gyro, accel, tilt)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    companion object {
        private const val GRAVITY_FILTER = 0.9f

        /** True if any of the sources' text reads a sensor uniform: the host registers sensors only then. */
        fun usesSensors(vararg sources: String): Boolean = sources.any { s -> SENSOR_NAMES.any { s.contains(it) } }
        private val SENSOR_NAMES = listOf("u_gyro", "u_accel", "u_tilt")
    }
}
