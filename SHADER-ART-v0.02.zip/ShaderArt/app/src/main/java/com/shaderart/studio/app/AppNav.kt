package com.shaderart.studio.app

import android.Manifest
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shaderart.studio.R
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.feature.live.AudioSource
import com.shaderart.studio.service.ShaderWallpaperService
import com.shaderart.studio.ui.screens.StudioToolsHost
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import com.shaderart.studio.feature.library.LibraryViewModel
import com.shaderart.studio.feature.studio.PendingFileSave
import com.shaderart.studio.feature.studio.StudioViewModel
import com.shaderart.studio.ui.components.ConfirmDialog
import com.shaderart.studio.ui.components.EmptyState
import com.shaderart.studio.ui.components.SIcon
import com.shaderart.studio.ui.screens.CodeStudioHost
import com.shaderart.studio.ui.screens.CodeStudioScreen
import com.shaderart.studio.ui.screens.ExploreScreen
import com.shaderart.studio.ui.screens.ExportHost
import com.shaderart.studio.ui.screens.ExportScreen
import com.shaderart.studio.ui.screens.GalleryScreen
import com.shaderart.studio.ui.screens.HomeScreen
import com.shaderart.studio.ui.screens.SettingsScreen
import com.shaderart.studio.ui.screens.VisualStudioScreen
import com.shaderart.studio.ui.theme.ShaderArtColors
import kotlinx.coroutines.launch

private object Routes {
    const val HOME = "home"
    const val EXPLORE = "explore"
    const val VISUAL = "visual"
    const val CODE = "code"
    const val GALLERY = "gallery"
    const val SETTINGS = "settings"
    const val EXPORT = "export"
}

private class Destination(val route: String, val label: String, @DrawableRes val icon: Int)

private val DESTINATIONS = listOf(
    Destination(Routes.HOME, "Home", R.drawable.ic_home),
    Destination(Routes.EXPLORE, "Explore", R.drawable.ic_explore),
    Destination(Routes.VISUAL, "Visual", R.drawable.ic_tune),
    Destination(Routes.CODE, "Code", R.drawable.ic_code),
    Destination(Routes.GALLERY, "Gallery", R.drawable.ic_gallery),
    Destination(Routes.SETTINGS, "Settings", R.drawable.ic_settings),
)

private class AppViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when {
        modelClass.isAssignableFrom(StudioViewModel::class.java) -> StudioViewModel(container) as T
        modelClass.isAssignableFrom(LibraryViewModel::class.java) -> LibraryViewModel(container) as T
        else -> throw IllegalArgumentException("Unknown ViewModel ${modelClass.name}")
    }
}

@Composable
fun ShaderArtRoot(container: AppContainer) {
    val factory = remember(container) { AppViewModelFactory(container) }
    val studio: StudioViewModel = viewModel(factory = factory)
    val lib: LibraryViewModel = viewModel(factory = factory)
    val settings by lib.settings.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route ?: Routes.HOME
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(studio) { studio.messages.collect { snackbar.showSnackbar(it) } }
    LaunchedEffect(lib) { lib.messages.collect { snackbar.showSnackbar(it) } }

    fun navTop(dest: String) {
        nav.navigate(dest) {
            popUpTo(nav.graph.findStartDestination().id)
            launchSingleTop = true
        }
    }

    fun openProject(id: String, then: String? = null) {
        val type = lib.projects.value.firstOrNull { it.id == id }?.type
        studio.requestOpen {
            studio.openProject(id) {
                val target = then ?: if (type == ProjectType.CODE) Routes.CODE else Routes.VISUAL
                if (target == Routes.EXPORT) nav.navigate(Routes.EXPORT) else navTop(target)
            }
        }
    }

    // ---- system file pickers ----
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            lib.importFile(uri) { r ->
                // The new project may not be in the gallery list yet, so use the type the import reported.
                val target = if (r.type == ProjectType.CODE) Routes.CODE else Routes.VISUAL
                studio.requestOpen { studio.openProject(r.id) { navTop(target) } }
            }
        }
    }
    val sourceSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        val pending = studio.pendingFileSave
        studio.pendingFileSave = null
        if (uri != null && pending is PendingFileSave.Source) lib.writeText(pending.text, uri)
    }
    // "" means the project currently open in the studio; anything else is a gallery project id.
    var archiveTarget by rememberSaveable { mutableStateOf("") }
    val archiveSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) {
            scope.launch {
                val id = if (archiveTarget.isEmpty()) studio.ensureSaved() else archiveTarget
                if (id != null) lib.writeArchive(id, uri)
            }
        }
    }
    val gifSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/gif")) { uri ->
        if (uri != null) studio.export.saveTo(uri)
    }
    val mp4Saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if (uri != null) studio.export.saveTo(uri)
    }
    val pngSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) studio.export.saveTo(uri)
    }
    val jpegSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) studio.export.saveTo(uri)
    }

    val exportHost = remember(studio) {
        ExportHost(
            onBack = { nav.popBackStack() },
            onSaveAs = { name, mime ->
                when (mime) {
                    "image/png" -> pngSaver.launch(name)
                    "image/gif" -> gifSaver.launch(name)
                    "video/mp4" -> mp4Saver.launch(name)
                    else -> jpegSaver.launch(name)
                }
            },
            onShare = { file, mime ->
                try {
                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = mime
                        putExtra(Intent.EXTRA_STREAM, uri)
                        clipData = ClipData.newRawUri(file.name, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(send, "Share"))
                } catch (e: ActivityNotFoundException) {
                    studio.message("No app is available to share this file.")
                } catch (e: IllegalArgumentException) {
                    studio.message("The file could not be shared: ${e.message}")
                }
            },
        )
    }

    // ---- pickers and permission for the studio tools (sound, pictures, Shadertoy files, wallpaper) ----
    var micThen by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val then = micThen
        micThen = null
        if (granted) then?.invoke()
        else studio.message("Without the microphone permission, microphone and audio-file analysis cannot start. The demo beat works without it.")
    }
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) studio.setAudioSource(AudioSource.FILE, uri, container.uriIO.displayName(uri))
    }
    val picturePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) studio.importTexture(uri)
    }
    var textThen by remember { mutableStateOf<((String) -> Unit)?>(null) }
    val textPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val then = textThen
        textThen = null
        if (uri != null && then != null) {
            scope.launch {
                try {
                    val text = withContext(Dispatchers.IO) { String(container.uriIO.readLimited(uri, 1_000_000), Charsets.UTF_8) }
                    then(text)
                } catch (e: Exception) {
                    studio.message("Could not read the file: ${e.message ?: "unknown error"}")
                }
            }
        }
    }
    val toolsHost = remember(studio) {
        StudioToolsHost(
            requestMicThen = { action ->
                if (studio.hasMicPermission()) action() else { micThen = action; micPermission.launch(Manifest.permission.RECORD_AUDIO) }
            },
            pickAudioFile = { audioPicker.launch(arrayOf("audio/*")) },
            pickPicture = { picturePicker.launch(arrayOf("image/*")) },
            pickTextFile = { callback -> textThen = callback; textPicker.launch(arrayOf("text/*", "application/json", "application/octet-stream")) },
            setWallpaper = {
                scope.launch {
                    if (studio.prepareWallpaper()) {
                        val component = ComponentName(context, ShaderWallpaperService::class.java)
                        val direct = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)
                        try {
                            context.startActivity(direct)
                        } catch (e: ActivityNotFoundException) {
                            try {
                                context.startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                                studio.message("Choose SHADER ART in the list.")
                            } catch (e2: ActivityNotFoundException) {
                                studio.message("This device has no live-wallpaper picker.")
                            }
                        }
                    }
                }
            },
        )
    }

    val codeHost = CodeStudioHost(
        templates = lib.templates,
        capabilities = { lib.lastCapabilities.value },
        onImport = { importLauncher.launch(arrayOf("*/*")) },
        onExportSource = { ext, text ->
            studio.pendingFileSave = PendingFileSave.Source(text)
            sourceSaver.launch(com.shaderart.studio.core.export.FileNaming.sourceName(studio.ui.name, ext))
        },
        onExportArchive = {
            archiveTarget = ""
            archiveSaver.launch(lib.suggestedArchiveName(studio.ui.name))
        },
        onExportImage = { nav.navigate(Routes.EXPORT) },
        onNewFromTemplate = { id -> studio.requestOpen { studio.newCode(id); navTop(Routes.CODE) } },
        onOpenInCode = { studio.openInCode() },
        tools = toolsHost,
    )

    val imeVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val showBottomBar = route != Routes.EXPORT && !imeVisible

    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(containerColor = Color.Black, contentColor = Color.White) {
                    DESTINATIONS.forEach { d ->
                        NavigationBarItem(
                            selected = route == d.route,
                            onClick = { if (route != d.route) navTop(d.route) },
                            icon = { SIcon(d.icon, null, tint = if (route == d.route) Color.Black else ShaderArtColors.TextSecondary) },
                            label = { Text(d.label, maxLines = 1, style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                            alwaysShowLabel = true,
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black, selectedTextColor = Color.White,
                                unselectedIconColor = ShaderArtColors.TextSecondary, unselectedTextColor = ShaderArtColors.TextSecondary,
                                indicatorColor = Color.White,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding).fillMaxSize()) {
            composable(Routes.HOME) {
                HomeScreen(
                    lib = lib,
                    onNewVisual = { navTop(Routes.VISUAL) },
                    onNewCode = { studio.requestOpen { studio.newCode("default"); navTop(Routes.CODE) } },
                    onExplore = { navTop(Routes.EXPLORE) },
                    onGallery = { navTop(Routes.GALLERY) },
                    onImport = { importLauncher.launch(arrayOf("*/*")) },
                    onOpenProject = { id -> openProject(id) },
                    onOpenPreset = { id -> studio.requestOpen { studio.openPreset(id); navTop(Routes.VISUAL) } },
                )
            }
            composable(Routes.EXPLORE) {
                Gated(lib) { ExploreScreen(lib) { id -> studio.requestOpen { studio.openPreset(id); navTop(Routes.VISUAL) } } }
            }
            composable(Routes.VISUAL) {
                Gated(lib) {
                    VisualStudioScreen(
                        vm = studio,
                        showPerformance = settings.showPerformance,
                        onBrowsePresets = { navTop(Routes.EXPLORE) },
                        onOpenGallery = { navTop(Routes.GALLERY) },
                        onOpenInCode = { studio.openInCode(); navTop(Routes.CODE) },
                        onExport = { nav.navigate(Routes.EXPORT) },
                        tools = toolsHost,
                    )
                }
            }
            composable(Routes.CODE) {
                Gated(lib) { CodeStudioScreen(studio, codeHost, settings.showPerformance) }
            }
            composable(Routes.GALLERY) {
                GalleryScreen(
                    lib = lib,
                    onOpen = { id -> openProject(id) },
                    onExportImage = { id -> openProject(id, then = Routes.EXPORT) },
                    onExportArchive = { id, name ->
                        archiveTarget = id
                        archiveSaver.launch(lib.suggestedArchiveName(name))
                    },
                    onImport = { importLauncher.launch(arrayOf("*/*")) },
                )
            }
            composable(Routes.SETTINGS) { SettingsScreen(lib) }
            composable(Routes.EXPORT) { Gated(lib) { ExportScreen(studio, exportHost) } }
        }
    }

    studio.discardPrompt?.let {
        ConfirmDialog(
            title = "Discard unsaved changes?",
            body = "The project you are editing has changes that were not saved. Opening something else will lose them.",
            confirmLabel = "Discard",
            onConfirm = { studio.confirmDiscard() },
            onDismiss = { studio.cancelDiscard() },
        )
    }
}

/** Shows [content] only on devices that can run OpenGL ES 3.0; otherwise explains why not. */
@Composable
private fun Gated(lib: LibraryViewModel, content: @Composable () -> Unit) {
    if (lib.gles3Supported) {
        content()
    } else {
        EmptyState(
            icon = R.drawable.ic_error,
            title = "OpenGL ES 3.0 is required",
            body = "This device reports OpenGL ES ${com.shaderart.studio.core.gpu.DeviceGles.describe(lib.reportedGlesVersion)}. The previews, studios and image export need OpenGL ES 3.0 or newer. Your gallery and settings still work.",
            modifier = Modifier.fillMaxSize(),
        )
    }
}
