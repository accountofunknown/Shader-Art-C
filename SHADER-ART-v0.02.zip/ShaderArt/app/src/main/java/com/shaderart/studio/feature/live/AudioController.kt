package com.shaderart.studio.feature.live

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.audiofx.Visualizer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.shaderart.studio.core.audio.AudioAnalyzer
import com.shaderart.studio.core.audio.AudioFeatures
import com.shaderart.studio.core.audio.DemoAudio
import com.shaderart.studio.core.input.LiveInputHub

/** Where shader audio comes from. */
enum class AudioSource(val label: String) {
    OFF("Off"),
    DEMO("Demo beat"),
    MIC("Microphone"),
    FILE("Audio file"),
}

/** Why a source could not start. The message is safe to show. */
class AudioStartException(message: String) : Exception(message)

/**
 * Feeds sound into the shaders' audio uniforms and texture.
 *
 * - DEMO: a built-in 120 BPM beat; needs no permission.
 * - MIC: the microphone, via AudioRecord. Needs the RECORD_AUDIO permission, which the caller must have asked for.
 * - FILE: plays an audio file the person picked and analyses what is playing through android.media.audiofx.Visualizer
 *   (which also needs RECORD_AUDIO, as Android requires for any audio analysis).
 *
 * Whatever is captured is analysed on the device and never stored or sent anywhere (the app has no internet permission).
 * Not thread-safe: call from the main thread.
 */
class AudioController(private val context: Context, private val hub: LiveInputHub) {
    var source: AudioSource = AudioSource.OFF
        private set

    private val main = Handler(Looper.getMainLooper())
    private var micThread: Thread? = null
    @Volatile private var micRunning = false
    private var record: AudioRecord? = null
    private var player: MediaPlayer? = null
    private var visualizer: Visualizer? = null
    private var demoRunnable: Runnable? = null
    private var demoStart = 0L

    fun hasMicPermission(): Boolean =
        context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    /**
     * Switches to [next]. For FILE pass the picked [fileUri]. Throws [AudioStartException] if it cannot start; the previous
     * source is stopped either way.
     */
    fun start(next: AudioSource, fileUri: Uri? = null) {
        stop()
        when (next) {
            AudioSource.OFF -> Unit
            AudioSource.DEMO -> startDemo()
            AudioSource.MIC -> startMic()
            AudioSource.FILE -> startFile(fileUri ?: throw AudioStartException("Choose an audio file first."))
        }
        source = next
    }

    fun stop() {
        demoRunnable?.let { main.removeCallbacks(it) }
        demoRunnable = null
        micRunning = false
        micThread?.let { t -> try { t.join(300) } catch (_: InterruptedException) { } }
        micThread = null
        try { record?.stop() } catch (_: Throwable) { }
        try { record?.release() } catch (_: Throwable) { }
        record = null
        try { visualizer?.enabled = false } catch (_: Throwable) { }
        try { visualizer?.release() } catch (_: Throwable) { }
        visualizer = null
        try { player?.stop() } catch (_: Throwable) { }
        try { player?.release() } catch (_: Throwable) { }
        player = null
        source = AudioSource.OFF
        hub.clearAudio()
    }

    /** Pauses file playback while the preview is hidden, resumes it afterwards. Other sources keep their own lifecycle. */
    fun setForeground(foreground: Boolean) {
        val p = player ?: return
        try { if (foreground) p.start() else if (p.isPlaying) p.pause() } catch (_: IllegalStateException) { }
    }

    // ---- demo ----
    private fun startDemo() {
        demoStart = SystemClock.elapsedRealtime()
        val r = object : Runnable {
            override fun run() {
                hub.setAudio(DemoAudio.featuresAt((SystemClock.elapsedRealtime() - demoStart) / 1000f))
                main.postDelayed(this, 16L)
            }
        }
        demoRunnable = r
        r.run()
    }

    // ---- microphone ----
    private fun startMic() {
        if (!hasMicPermission()) throw AudioStartException("Microphone permission is needed. Allow it when asked, or use the demo beat.")
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) throw AudioStartException("This device cannot record audio at 44.1 kHz.")
        val rec = try {
            @Suppress("MissingPermission")
            AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2)
        } catch (e: SecurityException) {
            throw AudioStartException("Microphone permission was denied.")
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            throw AudioStartException("The microphone could not be opened. Another app may be using it.")
        }
        try { rec.startRecording() } catch (e: IllegalStateException) {
            rec.release()
            throw AudioStartException("The microphone could not start recording.")
        }
        record = rec
        micRunning = true
        val analyzer = AudioAnalyzer(rate)
        micThread = Thread({
            val buf = ShortArray(1024)
            while (micRunning) {
                val n = try { rec.read(buf, 0, buf.size) } catch (_: Throwable) { -1 }
                if (n <= 0) { if (n < 0) break else continue }
                hub.setAudio(analyzer.pushShorts(buf, n))
            }
        }, "shaderart-mic").also { it.isDaemon = true; it.start() }
    }

    // ---- audio file ----
    private fun startFile(uri: Uri) {
        if (!hasMicPermission()) throw AudioStartException("Android requires microphone permission to analyse sound that is playing, even from a file. Allow it, or use the demo beat.")
        val mp = MediaPlayer()
        try {
            mp.setDataSource(context, uri)
            mp.isLooping = true
            mp.prepare()
        } catch (e: Exception) {
            mp.release()
            throw AudioStartException("That file could not be played as audio.")
        }
        val vis = try {
            Visualizer(mp.audioSessionId)
        } catch (e: Exception) {
            mp.release()
            throw AudioStartException("The sound analyser is not available on this device (${e.javaClass.simpleName}).")
        }
        try {
            vis.enabled = false
            vis.captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
            val rateMilliHz = vis.samplingRate
            val analyzer = AudioAnalyzer(if (rateMilliHz > 8_000_000) rateMilliHz / 1000 else 44100)
            vis.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(v: Visualizer?, waveform: ByteArray?, samplingRate: Int) {
                    if (waveform != null) hub.setAudio(analyzer.pushUnsignedBytes(waveform))
                }

                override fun onFftDataCapture(v: Visualizer?, fft: ByteArray?, samplingRate: Int) = Unit
            }, Visualizer.getMaxCaptureRate(), true, false)
            vis.enabled = true
        } catch (e: Exception) {
            try { vis.release() } catch (_: Throwable) { }
            mp.release()
            throw AudioStartException("The sound analyser could not start: ${e.message ?: e.javaClass.simpleName}")
        }
        mp.start()
        player = mp
        visualizer = vis
    }

    companion object {
        val SILENCE: AudioFeatures = AudioFeatures.SILENCE
    }
}
