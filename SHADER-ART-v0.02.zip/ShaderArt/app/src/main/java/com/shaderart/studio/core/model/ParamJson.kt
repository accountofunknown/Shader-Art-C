package com.shaderart.studio.core.model

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.asFloat
import com.shaderart.studio.core.json.asList
import com.shaderart.studio.core.json.optFloat
import com.shaderart.studio.core.json.optString
import com.shaderart.studio.core.json.reqFloat
import com.shaderart.studio.core.json.reqString

/** JSON schema for a parameter definition. Shared by the preset catalog and project manifests. */
object ParamJson {
    fun toMap(p: ParamDef): Map<String, Any?> = linkedMapOf(
        "id" to p.id,
        "uniform" to p.uniform,
        "name" to p.name,
        "type" to p.type.name.lowercase(),
        "default" to p.defaults,
        "min" to p.min,
        "max" to p.max,
        "step" to p.step,
        "group" to p.group,
        "description" to p.description,
    )

    fun fromMap(m: Map<String, Any?>): ParamDef {
        val typeName = m.reqString("type")
        val type = ParamType.parse(typeName) ?: throw JsonException("Unknown parameter type '$typeName'")
        val rawDefault = m["default"] ?: throw JsonException("Missing field 'default'")
        val defaults = if (rawDefault is List<*>) rawDefault.asList("default").map { it.asFloat("default") }
        else listOf(rawDefault.asFloat("default"))
        val defStep = if (type == ParamType.INT || type == ParamType.BOOL) 1f else 0.01f
        return ParamDef(
            id = m.reqString("id"),
            name = m.reqString("name"),
            uniform = m.reqString("uniform"),
            type = type,
            defaults = defaults,
            min = m.reqFloat("min"),
            max = m.reqFloat("max"),
            step = m.optFloat("step", defStep),
            description = m.optString("description") ?: "",
            group = m.optString("group"),
        )
    }
}
