package com.shaderart.studio.core.presets

import android.content.res.AssetManager
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.model.Preset

/** A buffer pass that ships with a template. */
data class TemplateBuffer(val id: PassId, val asset: String, val channels: List<ChannelBinding>)

data class ShaderTemplate(
    val id: String,
    val name: String,
    val description: String,
    val asset: String,
    val buffers: List<TemplateBuffer> = emptyList(),
    val imageChannels: List<ChannelBinding> = ChannelBinding.noneChannels(),
)

/** Loads the bundled preset catalog and code templates. Everything works offline from app assets. */
class PresetRepository(private val assets: AssetManager) {
    val templates = listOf(
        ShaderTemplate("default", "Default", "Gradient wave with touch glow. Shows every standard uniform.", "templates/default.frag"),
        ShaderTemplate("plasma", "Plasma", "Classic animated sine plasma with colour controls.", "templates/plasma.frag"),
        ShaderTemplate("sphere", "Raymarched sphere", "A lit sphere found by sphere tracing (64 step cap).", "templates/sphere.frag"),
        ShaderTemplate("clouds", "Noise clouds", "Fractal value noise with drifting motion.", "templates/clouds.frag"),
        ShaderTemplate(
            "audio", "Audio reactive", "Spectrum bars and a beat-driven ring. Use Inputs to start a sound source.", "templates/audio.frag",
            imageChannels = listOf(ChannelBinding.AUDIO, ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE),
        ),
        ShaderTemplate("touch", "Touch reaction", "Ripples on tap and glow under every finger.", "templates/touch.frag"),
        ShaderTemplate("sensors", "Motion sensors", "A light that follows tilt and flares when you shake the phone.", "templates/sensors.frag"),
        ShaderTemplate(
            "picture", "Picture input", "Shows a picture you import, with a small wobble. Also shows how channels work.", "templates/texture.frag",
            imageChannels = listOf(ChannelBinding.NOISE, ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE),
        ),
        ShaderTemplate(
            "feedback", "Multi-pass feedback", "Image + Buffer A: Buffer A remembers the last frame to draw trails.", "templates/feedback.frag",
            buffers = listOf(TemplateBuffer(PassId.A, "templates/feedback_a.frag", listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE))),
            imageChannels = listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE),
        ),
    )

    /** Source of a freshly added buffer pass. */
    val bufferTemplate: String by lazy { read("templates/buffer.frag") }

    /** The buffer passes of a template, with their sources loaded. */
    fun templateBuffers(id: String): List<PassSpec> =
        templates.firstOrNull { it.id == id }?.buffers.orEmpty().map { PassSpec(it.id, read(it.asset), it.channels) }

    private val loaded: Result<List<Preset>> by lazy {
        runCatching { PresetCatalogParser.parse(read("presets/catalog.json")) { read(it) } }
    }

    /** All presets, or the reason the catalog could not be loaded. */
    val catalog: Result<List<Preset>> get() = loaded

    val presets: List<Preset> get() = loaded.getOrDefault(emptyList())

    fun get(id: String): Preset? = presets.firstOrNull { it.id == id }

    val vertexSource: String by lazy { read("shaders/fullscreen.vert") }

    fun templateSource(id: String): String {
        val t = templates.firstOrNull { it.id == id } ?: templates.first()
        return read(t.asset)
    }

    private fun read(path: String): String = assets.open(path).bufferedReader(Charsets.UTF_8).use { it.readText() }
}
