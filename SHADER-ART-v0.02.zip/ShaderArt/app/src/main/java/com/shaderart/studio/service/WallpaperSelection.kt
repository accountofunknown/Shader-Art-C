package com.shaderart.studio.service

import android.content.Context

/** Which shader the live wallpaper shows: a built-in preset or a saved project. Stored privately on the device. */
class WallpaperSelection(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("wallpaper", Context.MODE_PRIVATE)

    enum class Kind { PRESET, PROJECT }

    data class Choice(val kind: Kind, val id: String, val name: String)

    fun get(): Choice? {
        val kind = prefs.getString("kind", null)?.let { k -> Kind.entries.firstOrNull { it.name == k } } ?: return null
        val id = prefs.getString("id", null) ?: return null
        return Choice(kind, id, prefs.getString("name", id) ?: id)
    }

    fun set(choice: Choice) {
        prefs.edit().putString("kind", choice.kind.name).putString("id", choice.id).putString("name", choice.name).apply()
    }

    /** Frames per second the wallpaper may draw (battery): 15, 24 or 30. */
    var fps: Int
        get() = prefs.getInt("fps", 30).coerceIn(10, 60)
        set(v) { prefs.edit().putInt("fps", v.coerceIn(10, 60)).apply() }
}
