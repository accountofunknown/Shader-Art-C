package com.shaderart.studio.feature.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    /** Default render scale for new projects (0.25..1). */
    val qualityScale: Float = 1f,
    val showPerformance: Boolean = false,
    val limitTo30Fps: Boolean = false,
    val favoritePresets: Set<String> = emptySet(),
)

class SettingsRepository(private val store: DataStore<Preferences>) {
    private val keyQuality = floatPreferencesKey("quality_scale")
    private val keyPerf = booleanPreferencesKey("show_performance")
    private val keyFps = booleanPreferencesKey("limit_30_fps")
    private val keyFavorites = stringSetPreferencesKey("favorite_presets")

    val settings: Flow<AppSettings> = store.data
        .catch { e -> if (e is IOException) emit(emptyPreferences()) else throw e }
        .map { p ->
            AppSettings(
                qualityScale = (p[keyQuality] ?: 1f).coerceIn(0.25f, 1f),
                showPerformance = p[keyPerf] ?: false,
                limitTo30Fps = p[keyFps] ?: false,
                favoritePresets = p[keyFavorites] ?: emptySet(),
            )
        }

    suspend fun setQuality(scale: Float) { store.edit { it[keyQuality] = scale.coerceIn(0.25f, 1f) } }
    suspend fun setShowPerformance(show: Boolean) { store.edit { it[keyPerf] = show } }
    suspend fun setLimitTo30Fps(limit: Boolean) { store.edit { it[keyFps] = limit } }

    suspend fun toggleFavoritePreset(id: String) {
        store.edit { p ->
            val cur = p[keyFavorites] ?: emptySet()
            p[keyFavorites] = if (id in cur) cur - id else cur + id
        }
    }
}
