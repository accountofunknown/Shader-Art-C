package com.shaderart.studio.core.model

/** Validates parameter metadata and parameter values. Returns human-readable problems (empty = valid). */
object ParamValidator {
    const val MAX_PARAMS = 64
    private val IDENT = Regex("^[A-Za-z_][A-Za-z0-9_]{0,63}$")

    fun validate(params: List<ParamDef>): List<String> {
        val errors = ArrayList<String>()
        if (params.size > MAX_PARAMS) errors += "Too many parameters (${params.size}, maximum $MAX_PARAMS)"
        val ids = HashSet<String>()
        val uniforms = HashSet<String>()
        for (p in params.take(MAX_PARAMS)) {
            errors += validateOne(p)
            if (!ids.add(p.id)) errors += "Duplicate parameter id '${p.id}'"
            if (!uniforms.add(p.uniform)) errors += "Duplicate uniform '${p.uniform}'"
        }
        return errors
    }

    fun validateOne(p: ParamDef): List<String> {
        val e = ArrayList<String>()
        val tag = "Parameter '${p.id}'"
        if (!IDENT.matches(p.id)) e += "$tag has an invalid id"
        if (!IDENT.matches(p.uniform) || p.uniform.startsWith("gl_") || p.uniform.contains("__")) {
            e += "$tag has an invalid uniform name '${p.uniform}'"
        }
        if (p.name.isBlank() || p.name.length > 60) e += "$tag needs a display name of 1-60 characters"
        if (p.description.length > 200) e += "$tag description is longer than 200 characters"
        if ((p.group?.length ?: 0) > 40) e += "$tag group name is longer than 40 characters"
        val expected = if (p.type == ParamType.COLOR) 3 else 1
        if (p.defaults.size != expected) e += "$tag needs $expected default value(s), found ${p.defaults.size}"
        val nums = p.defaults + listOf(p.min, p.max, p.step)
        if (nums.any { !it.isFinite() }) {
            e += "$tag contains a non-finite number"
            return e
        }
        if (p.min > p.max) e += "$tag has min greater than max"
        if ((p.type == ParamType.FLOAT || p.type == ParamType.INT) && p.step <= 0f) e += "$tag needs a step greater than 0"
        if (p.type == ParamType.INT && (p.min != Math.floor(p.min.toDouble()).toFloat() || p.max != Math.floor(p.max.toDouble()).toFloat())) {
            e += "$tag is an integer but has fractional limits"
        }
        if (p.type == ParamType.BOOL && (p.min != 0f || p.max != 1f)) e += "$tag toggle must use range 0..1"
        if (p.type == ParamType.COLOR && (p.min != 0f || p.max != 1f)) e += "$tag color must use range 0..1"
        if (p.defaults.any { it < p.min || it > p.max }) e += "$tag default is outside ${p.min}..${p.max}"
        return e
    }

    /** Checks stored values against their definitions. Unknown ids, wrong sizes and out-of-range values are errors. */
    fun validateValues(params: List<ParamDef>, values: Map<String, List<Float>>): List<String> {
        val e = ArrayList<String>()
        val byId = params.associateBy { it.id }
        for ((id, v) in values) {
            val def = byId[id]
            if (def == null) { e += "Value given for unknown parameter '$id'"; continue }
            if (v.size != def.defaults.size) { e += "Parameter '$id' needs ${def.defaults.size} value(s), found ${v.size}"; continue }
            for (x in v) {
                if (!x.isFinite()) e += "Parameter '$id' contains a non-finite value"
                else if (x < def.min - 1e-4f || x > def.max + 1e-4f) e += "Parameter '$id' value $x is outside ${def.min}..${def.max}"
            }
        }
        return e
    }
}
