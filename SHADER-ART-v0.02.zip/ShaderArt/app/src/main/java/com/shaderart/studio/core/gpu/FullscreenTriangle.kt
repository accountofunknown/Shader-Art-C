package com.shaderart.studio.core.gpu

import android.opengl.GLES30

/**
 * Draws one oversized triangle that covers the viewport. The vertex shader derives positions from
 * gl_VertexID, so no vertex buffer is needed; only an (empty) vertex array object is bound.
 */
class FullscreenTriangle {
    private var vao = 0

    fun create() {
        val a = IntArray(1)
        GLES30.glGenVertexArrays(1, a, 0)
        vao = a[0]
    }

    fun draw() {
        GLES30.glBindVertexArray(vao)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, 3)
        GLES30.glBindVertexArray(0)
    }

    /** Deletes the GL object. Only valid while the context that created it is current. */
    fun release() {
        if (vao != 0) {
            GLES30.glDeleteVertexArrays(1, intArrayOf(vao), 0)
            vao = 0
        }
    }

    /** Forgets the handle without calling GL: used when the context was lost and the object no longer exists. */
    fun forget() {
        vao = 0
    }
}
