package com.shaderart.studio.core.renderer

import android.annotation.SuppressLint
import android.content.Context
import android.opengl.GLSurfaceView
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * GLSurfaceView hosting a [ShaderRenderer].
 *
 * Touch coordinate system (what shaders see in u_mouse): x and y are 0..1 across the view with the origin
 * at the bottom-left, matching gl_FragCoord / u_resolution. They are computed from the view's own size, so
 * they stay correct when the view is resized, rotated, or rendered at a reduced quality scale.
 */
class ShaderSurfaceView(context: Context) : GLSurfaceView(context), RenderSurface {
    private var attachedRenderer: ShaderRenderer? = null
    private var layoutW = 0
    private var layoutH = 0
    private var quality = 1f

    /** Called with the multiplicative change of a pinch gesture (1.05 = 5% zoom in). */
    var onPinch: ((Float) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(
        context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                onPinch?.invoke(detector.scaleFactor)
                return true
            }
        },
    )

    /** Must be called once, before the view is attached to a window. */
    fun attach(renderer: ShaderRenderer) {
        check(attachedRenderer == null) { "ShaderSurfaceView already has a renderer" }
        attachedRenderer = renderer
        setEGLContextClientVersion(3)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        preserveEGLContextOnPause = true
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        renderer.surface = this
    }

    /** Fraction (0.25..1) of the view size used for the drawing surface. The GPU scales it up to fill the view. */
    fun setQuality(scale: Float) {
        val clamped = scale.coerceIn(0.25f, 1f)
        if (clamped == quality) return
        quality = clamped
        applySurfaceSize()
    }

    private fun applySurfaceSize() {
        if (layoutW <= 0 || layoutH <= 0) return
        if (quality >= 0.999f) {
            holder.setSizeFromLayout()
        } else {
            holder.setFixedSize(max(64, (layoutW * quality).roundToInt()), max(64, (layoutH * quality).roundToInt()))
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutW = w
        layoutH = h
        applySurfaceSize()
    }

    private var touchAdapter: TouchAdapter? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        val r = attachedRenderer ?: return true
        if (event.actionMasked == MotionEvent.ACTION_DOWN) parent?.requestDisallowInterceptTouchEvent(true)
        val adapter = touchAdapter ?: TouchAdapter(r).also { touchAdapter = it }
        adapter.onEvent(event, width, height, trackMouse = !scaleDetector.isInProgress)
        requestRender() // show the effect of the touch even while paused
        return true
    }
}
