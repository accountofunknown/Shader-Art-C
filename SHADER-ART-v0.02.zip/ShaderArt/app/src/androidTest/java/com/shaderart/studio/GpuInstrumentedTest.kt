package com.shaderart.studio

import android.graphics.BitmapFactory
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.shaderart.studio.core.export.AlphaMode
import com.shaderart.studio.core.export.ExportConfig
import com.shaderart.studio.core.export.ExportEngine
import com.shaderart.studio.core.export.ExportException
import com.shaderart.studio.core.export.GifConfig
import com.shaderart.studio.core.export.ImageFormat
import com.shaderart.studio.core.export.VideoConfig
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.pipeline.PostAssets
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.core.storage.ProjectFactory
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * These tests need a real OpenGL ES 3.0 context, so they run on a device or emulator
 * (`./gradlew connectedDebugAndroidTest`). They are NOT run by the GitHub Actions workflow.
 */
@RunWith(AndroidJUnit4::class)
class GpuInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var cache: File
    private lateinit var engine: ExportEngine
    private lateinit var presets: PresetRepository

    @Before
    fun setUp() {
        cache = File(context.cacheDir, "gpu-test-${System.nanoTime()}").also { it.mkdirs() }
        engine = ExportEngine(cache, postSourceLoader = { name -> PostAssets(context.assets).load(name) })
        presets = PresetRepository(context.assets)
    }

    @After
    fun tearDown() {
        cache.deleteRecursively()
    }

    @Test
    fun catalogLoads(): Unit {
        assertTrue("catalog must load", presets.catalog.isSuccess)
        assertTrue("expected at least 28 presets", presets.presets.size >= 28)
    }

    /** The strongest check in the project: every bundled preset must compile and render on this GPU. */
    @Test
    fun everyPresetRendersAThumbnail(): Unit = runBlocking {
        val failures = mutableListOf<String>()
        for (preset in presets.presets) {
            try {
                val file = engine.presetThumbnail(preset)
                val bmp = BitmapFactory.decodeFile(file.path)
                if (bmp == null || bmp.width <= 0) failures += "${preset.id}: unreadable image"
            } catch (e: Exception) {
                failures += "${preset.id}: ${e.message}"
            }
        }
        assertTrue("Presets failed on this GPU:\n" + failures.joinToString("\n"), failures.isEmpty())
    }

    @Test
    fun exportsPngAtRequestedSize(): Unit = runBlocking {
        val preset = presets.presets.first()
        val project = ProjectFactory.fromPreset(preset, "test-id", 1L)
        val file = engine.exportImage(project, ExportConfig(300, 200, ImageFormat.PNG), "t.png") { }
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, opts)
        assertEquals(300, opts.outWidth)
        assertEquals(200, opts.outHeight)
    }

    @Test
    fun invalidShaderFailsWithDriverDiagnostics(): Unit = runBlocking {
        val bad = ProjectFactory.newCode(
            "bad", "bad-id", 1L, presets.vertexSource,
            "#version 300 es\nprecision highp float;\nout vec4 o;\nvoid main(){ o = vec4(undefined_symbol); }\n",
        )
        try {
            engine.exportImage(bad, ExportConfig(64, 64), "bad.png") { }
            throw AssertionError("expected ExportException")
        } catch (e: ExportException) {
            assertTrue("driver should report at least one diagnostic", e.diagnostics.isNotEmpty())
        }
    }

    @Test
    fun thumbnailIsJpeg(): Unit = runBlocking {
        val project = ProjectFactory.fromPreset(presets.presets.first(), "thumb-id", 1L)
        val bytes = engine.renderThumbnail(project)
        assertNotNull(bytes)
        assertEquals(0xFF, bytes[0].toInt() and 0xFF)
        assertEquals(0xD8, bytes[1].toInt() and 0xFF)
        assertEquals(ProjectType.VISUAL, project.type)
    }

    @Test
    fun maxImageSideIsReported(): Unit = runBlocking {
        val side = engine.maxImageSide()
        assertNotNull(side)
        assertTrue(side!! >= 2048)
    }

    private fun project(id: String) = ProjectFactory.fromPreset(presets.get(id) ?: error("missing preset $id"), "$id-test", 1L)

    @Test
    fun multipassPresetsRender(): Unit = runBlocking {
        for (id in listOf("feedback_trails", "reaction_diffusion")) {
            val file = engine.exportImage(project(id), ExportConfig(128, 128, ImageFormat.PNG, timeSeconds = 1f), "$id.png") { }
            assertTrue("$id rendered nothing", file.length() > 100)
        }
    }

    @Test
    fun blackKeyedPngHasTransparentPixels(): Unit = runBlocking {
        val file = engine.exportImage(project("kaleidoscope"), ExportConfig(96, 96, ImageFormat.PNG, alpha = AlphaMode.KEY_BLACK), "key.png") { }
        val bmp = BitmapFactory.decodeFile(file.path)
        assertNotNull(bmp)
        assertTrue("PNG should carry an alpha channel", bmp.hasAlpha())
        var transparent = false
        for (y in 0 until bmp.height) for (x in 0 until bmp.width) if ((bmp.getPixel(x, y) ushr 24) < 255) transparent = true
        assertTrue("expected some non-opaque pixels", transparent)
    }

    @Test
    fun gifExportWritesAGifFile(): Unit = runBlocking {
        val file = engine.exportGif(project("truchet_weave"), GifConfig(96, 96, fps = 10, durationSeconds = 1f), "t.gif") { }
        assertEquals("GIF89a", String(file.readBytes().copyOf(6), Charsets.US_ASCII))
    }

    @Test
    fun videoExportWorksOrReportsWhyNot(): Unit = runBlocking {
        val cfg = VideoConfig(160, 160, fps = 15, durationSeconds = 1f)
        val reason = engine.videoSupport(cfg)
        if (reason != null) return@runBlocking // this device cannot encode it; that is a valid, reported outcome
        val file = engine.exportVideo(project("plasma_dreams"), cfg, "t.mp4") { }
        assertTrue("mp4 should not be empty", file.length() > 1000)
    }

    @Test
    fun postEffectStackRenders(): Unit = runBlocking {
        val withPost = project("plasma_dreams").copy(
            postStack = listOf("bloom", "vignette", "chroma").map { PostEffects.newInstance(PostEffects.find(it)!!) },
        )
        val file = engine.exportImage(withPost, ExportConfig(128, 128, ImageFormat.PNG), "post.png") { }
        assertTrue(file.length() > 100)
    }
}
