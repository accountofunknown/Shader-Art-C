package com.shaderart.studio

import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.presets.PresetRepository
import com.shaderart.studio.core.storage.AppDatabase
import com.shaderart.studio.core.storage.FileProjectRepository
import com.shaderart.studio.core.storage.ProjectFactory
import com.shaderart.studio.core.storage.RoomProjectIndex
import java.io.ByteArrayOutputStream
import java.io.File
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/** Room + file storage on a real device: save, reload, duplicate, archive round trip, delete. */
@RunWith(AndroidJUnit4::class)
class StorageInstrumentedTest {
    private val context = InstrumentationRegistry.getInstrumentation().targetContext
    private lateinit var db: AppDatabase
    private lateinit var root: File
    private lateinit var repo: FileProjectRepository
    private lateinit var presets: PresetRepository

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        root = File(context.cacheDir, "storage-test-${System.nanoTime()}").also { it.mkdirs() }
        repo = FileProjectRepository(root, RoomProjectIndex(db.projectDao()))
        presets = PresetRepository(context.assets)
    }

    @After
    fun tearDown() {
        db.close()
        root.deleteRecursively()
    }

    @Test
    fun saveLoadDuplicateDelete(): Unit = runBlocking {
        val project = ProjectFactory.newCode("Test", "p1", 1L, presets.vertexSource, presets.templateSource("default"))
        repo.save(project)
        assertEquals(1, repo.observeProjects().first().size)
        assertEquals(project.fragmentSource, repo.load("p1").fragmentSource)

        val copyId = repo.duplicate("p1")
        assertEquals(2, repo.observeProjects().first().size)
        assertTrue(copyId != "p1")

        repo.delete("p1")
        assertFalse(repo.exists("p1"))
        assertEquals(1, repo.observeProjects().first().size)
    }

    @Test
    fun archiveRoundTripGetsFreshId(): Unit = runBlocking {
        val project = ProjectFactory.newCode("Round trip", "p2", 1L, presets.vertexSource, presets.templateSource("plasma"))
        repo.save(project)
        val out = ByteArrayOutputStream()
        repo.writeArchive("p2", out)
        val imported = com.shaderart.studio.core.importing.ShaderArchive.read(out.toByteArray().inputStream())
        val saved = repo.importProject(imported.project, imported.preview)
        assertTrue(saved.id != "p2")
        assertEquals(ProjectType.CODE, saved.type)
        assertEquals(project.fragmentSource, saved.fragmentSource)
    }
}
