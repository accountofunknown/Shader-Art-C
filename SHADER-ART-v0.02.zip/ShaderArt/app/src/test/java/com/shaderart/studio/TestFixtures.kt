package com.shaderart.studio

import com.shaderart.studio.core.model.AnimationConfig
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.core.model.ProjectType
import com.shaderart.studio.core.model.RenderSettings
import com.shaderart.studio.core.model.ShaderProject
import java.io.File

const val MIN_FRAGMENT = "#version 300 es\nprecision highp float;\nuniform float u_scale;\nuniform int u_iterations;\nuniform vec3 u_colorA;\nuniform bool u_invert;\nout vec4 c;\nvoid main() { c = vec4(u_colorA * u_scale, 1.0); }\n"
const val MIN_VERTEX = "#version 300 es\nvoid main() { gl_Position = vec4(0.0); }\n"

fun sampleParams(): List<ParamDef> = listOf(
    ParamDef("u_scale", "Scale", "u_scale", ParamType.FLOAT, listOf(1f), 0.2f, 6f, 0.05f, "Zoom", "Shape"),
    ParamDef("u_iterations", "Iterations", "u_iterations", ParamType.INT, listOf(48f), 8f, 128f, 1f, "", "Quality"),
    ParamDef("u_colorA", "Primary color", "u_colorA", ParamType.COLOR, listOf(0.1f, 0.6f, 1f), 0f, 1f, 0.01f, "", "Colors"),
    ParamDef("u_invert", "Invert", "u_invert", ParamType.BOOL, listOf(0f), 0f, 1f, 1f, "", "Look"),
)

fun sampleProject(id: String = "proj-1", name: String = "Sample"): ShaderProject {
    val params = sampleParams()
    return ShaderProject(
        id = id,
        name = name,
        type = ProjectType.VISUAL,
        createdAt = 1_000L,
        modifiedAt = 2_000L,
        vertexSource = MIN_VERTEX,
        fragmentSource = MIN_FRAGMENT,
        params = params,
        values = mapOf("u_scale" to listOf(2.5f), "u_iterations" to listOf(64f), "u_colorA" to listOf(0.2f, 0.4f, 0.8f), "u_invert" to listOf(1f)),
        animation = AnimationConfig(playing = false, speed = 1.5f, time = 12.25f),
        render = RenderSettings(0.75f, 720, 1280, 2f),
        presetOrigin = "liquid_flow",
    )
}

inline fun <reified T : Throwable> expectThrows(block: () -> Unit): T {
    try {
        block()
    } catch (e: Throwable) {
        if (e is T) return e
        throw AssertionError("Expected ${T::class.java.simpleName} but got $e", e)
    }
    throw AssertionError("Expected ${T::class.java.simpleName} but nothing was thrown")
}

/** Locates src/main/assets whether tests run from the module dir or the repo root. */
fun assetsDir(): File = listOf("src/main/assets", "app/src/main/assets").map { File(it) }.firstOrNull { it.isDirectory }
    ?: throw IllegalStateException("assets directory not found from ${File(".").absolutePath}")
