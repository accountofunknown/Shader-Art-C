package com.shaderart.studio.core

import com.shaderart.studio.MIN_FRAGMENT
import com.shaderart.studio.MIN_VERTEX
import com.shaderart.studio.expectThrows
import com.shaderart.studio.sampleParams
import com.shaderart.studio.sampleProject
import com.shaderart.studio.core.audio.AudioAnalyzer
import com.shaderart.studio.core.audio.AudioFeatures
import com.shaderart.studio.core.audio.DemoAudio
import com.shaderart.studio.core.audio.Fft
import com.shaderart.studio.core.importing.ShaderArchive
import com.shaderart.studio.core.importing.ShadertoyImporter
import com.shaderart.studio.core.input.TouchState
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.ChannelKind
import com.shaderart.studio.core.model.Easing
import com.shaderart.studio.core.model.Keyframe
import com.shaderart.studio.core.model.MultipassCheck
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.model.PostEffectInstance
import com.shaderart.studio.core.model.PostEffects
import com.shaderart.studio.core.model.TextureAsset
import com.shaderart.studio.core.model.TextureNames
import com.shaderart.studio.core.model.Timeline
import com.shaderart.studio.core.model.TimelineEval
import com.shaderart.studio.core.model.TimelineTrack
import com.shaderart.studio.core.storage.ProjectFormatException
import com.shaderart.studio.core.storage.ProjectMigrations
import com.shaderart.studio.core.storage.ProjectSerializer
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private val PNG = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
private const val BUF = "#version 300 es\nprecision highp float;\nout vec4 o;\nvoid main() { o = vec4(1.0); }\n"

class MultipassModelTest {
    @Test fun channelBindingTextRoundTrip() {
        for (c in listOf(ChannelBinding.NONE, ChannelBinding.NOISE, ChannelBinding.AUDIO, ChannelBinding.buffer(PassId.C), ChannelBinding.texture("my_pic_2"))) {
            assertEquals(c, ChannelBinding.parse(c.toText()))
        }
    }

    @Test fun badBindingsAreRejected() {
        for (bad in listOf("", "buffer:image", "buffer:z", "texture:Bad Name", "texture:", "video", "buffer:")) assertNull(bad, ChannelBinding.parse(bad))
    }

    @Test fun textureNamesFromFiles() {
        assertEquals("my_photo", TextureNames.fromFileName("My Photo.JPG", emptySet()))
        assertEquals("my_photo_2", TextureNames.fromFileName("My Photo.JPG", setOf("my_photo")))
        assertEquals("texture", TextureNames.fromFileName("###.png", emptySet()))
        assertTrue(TextureNames.isValid(TextureNames.fromFileName("a".repeat(100) + ".png", emptySet())))
    }

    @Test fun checkFindsMissingBuffersAndTextures() {
        val ok = MultipassCheck.check(
            listOf(PassSpec(PassId.A, BUF, listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE))),
            listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.texture("t"), ChannelBinding.NONE, ChannelBinding.NONE),
            listOf(TextureAsset("t", 4, 4)),
        )
        assertTrue(ok.isEmpty())
        val bad = MultipassCheck.check(emptyList(), listOf(ChannelBinding.buffer(PassId.B), ChannelBinding.texture("x"), ChannelBinding.NONE, ChannelBinding.NONE), emptyList())
        assertEquals(2, bad.size)
    }

    @Test fun passSpecRequiresBufferAndFourChannels() {
        expectThrows<IllegalArgumentException> { PassSpec(PassId.IMAGE, BUF) }
        expectThrows<IllegalArgumentException> { PassSpec(PassId.A, BUF, listOf(ChannelBinding.NONE)) }
    }
}

class TimelineTest {
    private val track = TimelineTrack("u_scale", 0, listOf(Keyframe(0f, 1f, Easing.LINEAR), Keyframe(2f, 3f, Easing.LINEAR), Keyframe(4f, 1f, Easing.STEP)))

    @Test fun interpolatesLinearly() {
        assertEquals(1f, TimelineEval.value(track, 0f)!!, 1e-5f)
        assertEquals(2f, TimelineEval.value(track, 1f)!!, 1e-5f)
        assertEquals(3f, TimelineEval.value(track, 2f)!!, 1e-5f)
    }

    @Test fun stepEasingHoldsThenJumps() {
        // Key at t=2 is LINEAR, key at t=4 is the last: after it, hold. Make a STEP segment explicitly:
        val t = TimelineTrack("x", 0, listOf(Keyframe(0f, 0f, Easing.STEP), Keyframe(1f, 5f)))
        assertEquals(0f, TimelineEval.value(t, 0.99f)!!, 1e-5f)
        assertEquals(5f, TimelineEval.value(t, 1f)!!, 1e-5f)
    }

    @Test fun clampsOutsideRangeAndHandlesEmpty() {
        assertEquals(1f, TimelineEval.value(track, -5f)!!, 1e-5f)
        assertEquals(1f, TimelineEval.value(track, 99f)!!, 1e-5f)
        assertNull(TimelineEval.value(TimelineTrack("x", 0, emptyList()), 1f))
    }

    @Test fun easingsAreMonotonicAndBounded() {
        for (e in Easing.entries) {
            assertEquals(0f, e.apply(0f), 1e-6f)
            assertEquals(1f, e.apply(1f), 1e-6f)
            var prev = -1f
            for (i in 0..20) { val v = e.apply(i / 20f); assertTrue(v >= prev - 1e-6f && v in 0f..1f); prev = v }
        }
    }

    @Test fun loopsAndClamps() {
        val loop = Timeline(durationSeconds = 4f, loop = true)
        assertEquals(1f, TimelineEval.localTime(loop, 5f), 1e-5f)
        assertEquals(3.5f, TimelineEval.localTime(loop, -0.5f), 1e-5f)
        val once = Timeline(durationSeconds = 4f, loop = false)
        assertEquals(4f, TimelineEval.localTime(once, 9f), 1e-5f)
    }

    @Test fun applyReplacesOnlyAnimatedValuesAndClamps() {
        val params = sampleParams()
        val values = mapOf("u_scale" to listOf(2.5f), "u_iterations" to listOf(64f), "u_colorA" to listOf(0.2f, 0.4f, 0.8f), "u_invert" to listOf(1f))
        val tl = Timeline(4f, true, true, listOf(
            TimelineTrack("u_scale", 0, listOf(Keyframe(0f, 100f), Keyframe(4f, 100f))), // beyond max 6 -> clamped
            TimelineTrack("u_colorA", 1, listOf(Keyframe(0f, 0f, Easing.LINEAR), Keyframe(4f, 1f, Easing.LINEAR))),
            TimelineTrack("u_iterations", 0, listOf(Keyframe(0f, 10.4f), Keyframe(4f, 10.4f))),
            TimelineTrack("ghost", 0, listOf(Keyframe(0f, 1f))),
        ))
        val out = TimelineEval.apply(tl, params, values, 2f)
        assertEquals(6f, out["u_scale"]!![0], 1e-5f)
        assertEquals(0.5f, out["u_colorA"]!![1], 1e-5f)
        assertEquals(0.2f, out["u_colorA"]!![0], 1e-5f) // untouched component
        assertEquals(10f, out["u_iterations"]!![0], 1e-5f) // INT rounds (and 10 is within 8..128)
        assertEquals(listOf(1f), out["u_invert"])
        assertNull(out["ghost"])
        // The input map is not mutated.
        assertEquals(listOf(2.5f), values["u_scale"])
    }

    @Test fun disabledOrEmptyReturnsSameMap() {
        val values = mapOf("u_scale" to listOf(2f))
        val tl = Timeline(4f, true, false, listOf(TimelineTrack("u_scale", 0, listOf(Keyframe(0f, 1f)))))
        assertTrue(TimelineEval.apply(tl, sampleParams(), values, 1f) === values)
        assertTrue(TimelineEval.apply(Timeline(), sampleParams(), values, 1f) === values)
    }

    @Test fun editingKeys() {
        var tl = Timeline()
        tl = tl.withKey("u_scale", 0, Keyframe(2f, 1f)).withKey("u_scale", 0, Keyframe(1f, 2f)).withKey("u_scale", 0, Keyframe(2.001f, 9f))
        val keys = tl.track("u_scale", 0)!!.keys
        assertEquals(listOf(1f, 2.001f), keys.map { it.t }) // near-duplicate time replaced
        assertTrue(tl.animates("u_scale"))
        tl = tl.withoutKey("u_scale", 0, 0).withoutKey("u_scale", 0, 0)
        assertTrue(tl.tracks.isEmpty())
        assertFalse(tl.animates("u_scale"))
    }
}

class PostStackTest {
    @Test fun catalogIsConsistent() {
        assertTrue(PostEffects.all.size >= 14)
        assertEquals(PostEffects.all.size, PostEffects.all.map { it.id }.toSet().size)
        for (e in PostEffects.all) {
            assertTrue(e.id, e.params.size in 1..4)
            assertTrue(e.passes.isNotEmpty())
            for (p in e.params) assertTrue("${e.id}/${p.name}", p.min <= p.default && p.default <= p.max)
        }
    }

    @Test fun everyPassHasAShaderAssetThatDeclaresItsUniforms() {
        val dir = com.shaderart.studio.assetsDir().resolve("post")
        val used = HashSet<String>()
        for (e in PostEffects.all) for (pass in e.passes) {
            used += pass
            val f = dir.resolve("$pass.frag")
            assertTrue("missing $pass.frag", f.isFile)
            val src = f.readText()
            assertTrue(src.startsWith("#version 300 es"))
            assertTrue("$pass reads u_input", src.contains("uniform sampler2D u_input;"))
            assertEquals("$pass u_orig use", e.usesOriginal && pass == e.passes.last(), src.contains("uniform sampler2D u_orig;"))
        }
        val extra = dir.listFiles()!!.map { it.name.removeSuffix(".frag") }.toSet() - used
        assertTrue("unused post shaders: $extra", extra.isEmpty())
    }

    @Test fun normalizationFixesBadValues() {
        val n = PostEffects.normalized(PostEffectInstance("vignette", true, listOf(Float.NaN, 99f)))!!
        assertEquals(2, n.values.size)
        assertEquals(0.6f, n.values[0], 1e-6f)
        assertEquals(1f, n.values[1], 1e-6f)
        assertNull(PostEffects.normalized(PostEffectInstance("no_such_effect")))
        assertEquals(1, PostEffects.sanitize(listOf(PostEffectInstance("invert"), PostEffectInstance("zzz"))).size)
    }
}

class ProjectV2Test {
    private fun multipass() = sampleProject().copy(
        buffers = listOf(PassSpec(PassId.A, BUF, listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.texture("pic"), ChannelBinding.AUDIO, ChannelBinding.NONE))),
        imageChannels = listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NOISE, ChannelBinding.NONE, ChannelBinding.NONE),
        textures = listOf(TextureAsset("pic", 64, 32)),
        timeline = Timeline(6f, false, true, listOf(TimelineTrack("u_scale", 0, listOf(Keyframe(0f, 1f, Easing.EASE_IN), Keyframe(3f, 4f, Easing.LINEAR))))),
        postStack = listOf(PostEffectInstance("bloom", true, listOf(0.5f, 1.5f, 10f)), PostEffectInstance("invert", false, listOf(1f))),
    )

    @Test fun manifestRoundTrip() {
        val p = multipass()
        assertTrue(p.isMultipass)
        val json = ProjectSerializer.toManifestJson(p)
        val back = ProjectSerializer.fromManifestJson(json, p.vertexSource, p.fragmentSource, mapOf("a" to BUF))
        assertEquals(p.buffers, back.buffers)
        assertEquals(p.imageChannels, back.imageChannels)
        assertEquals(p.textures, back.textures)
        assertEquals(p.timeline, back.timeline)
        assertEquals(p.postStack, back.postStack)
        assertEquals(2, back.formatVersion)
    }

    @Test fun v1ManifestLoadsWithEmptyV2Fields() {
        val v1 = ProjectSerializer.toManifestJson(sampleProject()).replace("\"formatVersion\": 2", "\"formatVersion\": 1")
        val p = ProjectSerializer.fromManifestJson(v1, MIN_VERTEX, MIN_FRAGMENT)
        assertTrue(p.buffers.isEmpty())
        assertEquals(4, p.imageChannels.size)
        assertFalse(p.isMultipass)
        assertTrue(p.timeline.isEmpty)
        assertTrue(p.postStack.isEmpty())
        assertEquals(2L, ProjectMigrations.migrate(mapOf("formatVersion" to 1L))["formatVersion"])
    }

    @Test fun missingBufferSourceAndDanglingReferencesAreRejected() {
        val p = multipass()
        val json = ProjectSerializer.toManifestJson(p)
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(json, p.vertexSource, p.fragmentSource, emptyMap()) }
        val noTex = json.replace("\"textures\": [", "\"textures\": [] , \"x\": [")
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(noTex, p.vertexSource, p.fragmentSource, mapOf("a" to BUF)) }
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(json, p.vertexSource, p.fragmentSource, mapOf("a" to "void main(){}")) }
    }

    @Test fun badTimelineIsRejectedButUnknownParamsAreDropped() {
        val p = multipass()
        val json = ProjectSerializer.toManifestJson(p)
        val ghost = json.replace("\"param\": \"u_scale\"", "\"param\": \"vanished\"")
        val back = ProjectSerializer.fromManifestJson(ghost, p.vertexSource, p.fragmentSource, mapOf("a" to BUF))
        assertTrue(back.timeline.tracks.isEmpty())
        val longer = json.replace("\"duration\": 6.0", "\"duration\": 6000.0")
        expectThrows<ProjectFormatException> { ProjectSerializer.fromManifestJson(longer, p.vertexSource, p.fragmentSource, mapOf("a" to BUF)) }
    }

    @Test fun unknownPostEffectIsSkipped() {
        val p = multipass()
        val json = ProjectSerializer.toManifestJson(p).replace("\"effect\": \"invert\"", "\"effect\": \"from_the_future\"")
        val back = ProjectSerializer.fromManifestJson(json, p.vertexSource, p.fragmentSource, mapOf("a" to BUF))
        assertEquals(listOf("bloom"), back.postStack.map { it.effectId })
    }

    @Test fun archiveRoundTripWithBuffersAndTextures() {
        val p = multipass()
        val out = ByteArrayOutputStream()
        ShaderArchive.write(p, null, false, out, mapOf("pic" to PNG + ByteArray(20)))
        val back = ShaderArchive.read(ByteArrayInputStream(out.toByteArray()))
        assertEquals(p.buffers, back.project.buffers)
        assertEquals(setOf("pic"), back.textures.keys)
        assertTrue(back.textures["pic"]!!.size == 28)
    }

    @Test fun archiveWithMissingOrFakeTextureIsRejected() {
        val p = multipass()
        val noTex = ByteArrayOutputStream().also { ShaderArchive.write(p, null, false, it, emptyMap()) }
        expectThrows<com.shaderart.studio.core.importing.ImportException> { ShaderArchive.read(ByteArrayInputStream(noTex.toByteArray())) }
        val fake = ByteArrayOutputStream().also { ShaderArchive.write(p, null, false, it, mapOf("pic" to ByteArray(30))) }
        expectThrows<com.shaderart.studio.core.importing.ImportException> { ShaderArchive.read(ByteArrayInputStream(fake.toByteArray())) }
    }
}

class AudioTest {
    private fun sine(freq: Float, n: Int, rate: Int = 44100, amp: Float = 0.8f) = FloatArray(n) { amp * sin(2.0 * PI * freq * it / rate).toFloat() }

    @Test fun fftFindsTheRightBin() {
        val size = 1024
        val fft = Fft(size)
        val re = FloatArray(size) { sin(2.0 * PI * 64 * it / size).toFloat() }
        val im = FloatArray(size)
        fft.transform(re, im)
        var best = 0; var bestMag = 0f
        for (i in 1 until size / 2) { val m = Fft.magnitude(re[i], im[i]); if (m > bestMag) { bestMag = m; best = i } }
        assertEquals(64, best)
        assertEquals(size / 2f, bestMag, 1f)
    }

    @Test fun fftRejectsNonPowerOfTwo() { expectThrows<IllegalArgumentException> { Fft(1000) } }

    @Test fun bassToneLightsBassNotTreble() {
        val a = AudioAnalyzer(44100)
        var f = AudioFeatures.SILENCE
        repeat(20) { f = a.push(sine(80f, 1024)) }
        assertTrue("bass ${f.bass}", f.bass > 0.5f)
        assertTrue("treble ${f.treble}", f.treble < 0.2f)
        assertTrue(f.level > 0.2f)
    }

    @Test fun highToneLightsTrebleNotBass() {
        val a = AudioAnalyzer(44100)
        var f = AudioFeatures.SILENCE
        repeat(20) { f = a.push(sine(6000f, 1024)) }
        assertTrue("treble ${f.treble}", f.treble > 0.5f)
        assertTrue("bass ${f.bass}", f.bass < 0.2f)
    }

    @Test fun silenceStaysQuietAndAllOutputsAreInRange() {
        val a = AudioAnalyzer(44100)
        var f = AudioFeatures.SILENCE
        repeat(10) { f = a.push(FloatArray(1024)) }
        assertTrue(f.level < 0.01f && f.bass < 0.05f && f.beat == 0f)
        val noise = java.util.Random(3)
        repeat(10) { f = a.push(FloatArray(1024) { (noise.nextFloat() * 2 - 1) * 3f }) } // over-range input is clamped
        for (arr in listOf(f.spectrum, f.waveform)) {
            assertEquals(512, arr.size)
            assertTrue(arr.all { it in 0f..1f && it.isFinite() })
        }
        assertTrue(listOf(f.level, f.bass, f.mid, f.treble, f.beat).all { it in 0f..1f })
        assertEquals(1024, f.toTextureBytes().size)
    }

    @Test fun kickDrumsTriggerBeats() {
        val a = AudioAnalyzer(44100)
        var beats = 0
        var wasHigh = false
        // 2 seconds of kick bursts every 0.5 s, pushed in 512-sample chunks.
        val chunk = 512
        val total = 44100 * 2 / chunk
        for (c in 0 until total) {
            val t0 = c * chunk
            val buf = FloatArray(chunk) { i ->
                val t = (t0 + i) / 44100f
                val phase = t % 0.5f
                (0.9f * sin(2.0 * PI * 60 * t) * Math.exp((-phase * 14f).toDouble())).toFloat()
            }
            val f = a.push(buf)
            val high = f.beat > 0.9f
            if (high && !wasHigh) beats++
            wasHigh = high
        }
        assertTrue("beats=$beats", beats in 3..6)
    }

    @Test fun unsignedBytesAndShortsAreAccepted() {
        val a = AudioAnalyzer(44100)
        val bytes = ByteArray(1024) { (128 + 100 * sin(2.0 * PI * 100 * it / 44100)).toInt().toByte() }
        assertTrue(a.pushUnsignedBytes(bytes).bass >= 0f)
        val shorts = ShortArray(1024) { (20000 * sin(2.0 * PI * 100 * it / 44100)).toInt().toShort() }
        assertTrue(a.pushShorts(shorts).bass >= 0f)
        a.reset()
        assertEquals(0f, a.features().level, 0f)
    }

    @Test fun demoAudioIsDeterministicBeatsOnTheBar() {
        val a = DemoAudio.featuresAt(10f); val b = DemoAudio.featuresAt(10f)
        assertEquals(a.bass, b.bass, 0f)
        assertTrue(DemoAudio.featuresAt(2.0f).beat > 0.95f) // 120 BPM: a beat every 0.5 s
        assertTrue(DemoAudio.featuresAt(2.4f).beat < 0.01f)
        assertTrue(DemoAudio.featuresAt(2.0f).bass > DemoAudio.featuresAt(2.4f).bass)
        for (t in listOf(0f, 0.1f, 3.3f, 1000f)) {
            val f = DemoAudio.featuresAt(t)
            assertTrue(f.spectrum.all { it in 0f..1f } && f.waveform.all { it in 0f..1f })
        }
    }
}

class TouchStateTest {
    private var now = 0f
    private val touch = TouchState(clock = { now })

    @Test fun tracksMultiplePointersAndReleases() {
        touch.down(1, 0.2f, 0.3f, 0.5f); touch.down(2, 0.8f, 0.9f, 1f)
        var s = touch.snapshot()
        assertEquals(2, s.pointerCount)
        assertEquals(0.8f, s.points[4], 1e-6f)
        assertEquals(1f, s.points[3], 0f)
        assertEquals(0f, s.points[11], 0f)
        touch.up(1); touch.up(2)
        s = touch.snapshot()
        assertEquals(0, s.pointerCount)
        assertEquals(0f, s.pressure, 0f)
    }

    @Test fun quickTouchBecomesATapButADragDoesNot() {
        now = 1f; touch.down(1, 0.5f, 0.5f, 0.6f); now = 1.1f; touch.up(1)
        assertEquals(1, touch.snapshot().tapCount)
        assertEquals(1.1f, touch.snapshot().taps[2], 1e-6f)
        now = 2f; touch.down(1, 0.1f, 0.1f, 0.6f); now = 2.05f; touch.move(1, 0.6f, 0.6f, 0.6f); now = 2.1f; touch.up(1)
        assertEquals(1, touch.snapshot().tapCount)
        now = 3f; touch.down(1, 0.5f, 0.5f, 0.6f); now = 4f; touch.up(1) // too slow: a hold, not a tap
        assertEquals(1, touch.snapshot().tapCount)
    }

    @Test fun tapRingKeepsTheNewestEight() {
        for (i in 0 until 12) touch.addTap(i / 12f, 0f, i.toFloat(), 1f)
        val s = touch.snapshot()
        assertEquals(8, s.tapCount)
        assertEquals(4f, s.taps[2], 0f) // oldest kept is the 5th added
        assertEquals(11f, s.taps[7 * 4 + 2], 0f)
    }

    @Test fun velocityFollowsMotionAndResets() {
        now = 0f; touch.down(1, 0.1f, 0.5f, 1f)
        now = 0.1f; touch.move(1, 0.2f, 0.5f, 1f)
        assertTrue(touch.snapshot().velX > 0.2f)
        touch.up(1)
        assertEquals(0f, touch.snapshot().velX, 0f)
    }

    @Test fun pointerLimitAndBadPressure() {
        for (i in 0 until 15) touch.down(i, 0.5f, 0.5f, Float.NaN)
        assertEquals(10, touch.snapshot().pointerCount)
        assertEquals(0.5f, touch.snapshot().pressure, 1e-6f)
        touch.cancelAll()
        assertEquals(0, touch.snapshot().pointerCount)
    }
}

class ShadertoyImporterTest {
    private val code = "void mainImage(out vec4 fragColor, in vec2 fragCoord) {\n  vec2 uv = fragCoord / iResolution.xy;\n  fragColor = vec4(uv, 0.5 + 0.5 * sin(iTime), 1.0);\n}\n"

    @Test fun rawCodeIsWrapped() {
        val r = ShadertoyImporter.convert(code)
        assertTrue(r.imageSource.startsWith("#version 300 es"))
        assertTrue(r.imageSource.contains("mainImage(c, gl_FragCoord.xy)"))
        assertTrue(r.imageSource.contains("#define iTime u_time"))
        assertTrue(r.buffers.isEmpty())
        assertTrue(r.warnings.isEmpty())
    }

    @Test fun rawCodeUsingChannelsGetsNoiseAndAWarning() {
        val r = ShadertoyImporter.convert(code.replace("iTime", "iTime + texture(iChannel1, uv).r"))
        assertEquals(ChannelBinding.NOISE, r.imageChannels[1])
        assertEquals(ChannelBinding.NONE, r.imageChannels[0])
        assertEquals(1, r.warnings.size)
    }

    @Test fun nonShadertoyTextIsRejected() {
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("hello world") }
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("   ") }
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("{ nope") }
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("{\"a\":1}") }
    }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")

    private fun json(): String = """
    {"Shader":{"info":{"name":"Feedback test"},"renderpass":[
      {"type":"common","name":"Common","code":"const float K = 2.0;","inputs":[],"outputs":[]},
      {"type":"buffer","name":"Buffer A","code":"${esc("void mainImage(out vec4 f, in vec2 p) { f = texture(iChannel0, p / iResolution.xy) * 0.9 + vec4(K * 0.01); }")}",
        "inputs":[{"channel":0,"ctype":"buffer","id":257,"src":"/media/previz/buffer00.png"}],"outputs":[{"id":257,"channel":0}]},
      {"type":"image","name":"Image","code":"${esc(code.replace("fragColor = vec4(uv", "fragColor = texture(iChannel0, uv) * texture(iChannel1, uv) + vec4(uv"))}",
        "inputs":[{"channel":0,"ctype":"buffer","id":"257"},{"channel":1,"ctype":"music"},{"channel":2,"ctype":"cubemap"},{"channel":3,"ctype":"texture"}],"outputs":[{"id":37,"channel":0}]},
      {"type":"sound","name":"Sound","code":"vec2 mainSound(int s, float t){return vec2(0.);}","inputs":[],"outputs":[]}
    ]}}"""

    @Test fun jsonMultipassConversion() {
        val r = ShadertoyImporter.convert(json())
        assertEquals("Feedback test", r.name)
        assertEquals(1, r.buffers.size)
        assertEquals(PassId.A, r.buffers[0].id)
        assertEquals(ChannelBinding.buffer(PassId.A), r.buffers[0].channels[0]) // self-reference = feedback
        assertEquals(ChannelBinding.buffer(PassId.A), r.imageChannels[0])
        assertEquals(ChannelBinding.AUDIO, r.imageChannels[1])
        assertEquals(ChannelBinding.NONE, r.imageChannels[2])
        assertEquals(ChannelBinding.NOISE, r.imageChannels[3])
        assertTrue(r.usesAudio)
        assertTrue(r.buffers[0].fragmentSource.contains("const float K = 2.0;"))
        assertTrue(r.buffers[0].fragmentSource.contains("fragColor = c;"))
        assertTrue(r.imageSource.contains("fragColor = vec4(c.rgb, 1.0);"))
        val w = r.warnings.joinToString("\n")
        assertTrue(w.contains("cube map")); assertTrue(w.contains("Sound pass")); assertTrue(w.contains("picture texture"))
    }

    @Test fun resultFitsTheProjectRules() {
        val r = ShadertoyImporter.convert(json())
        val p = sampleProject().copy(fragmentSource = r.imageSource, buffers = r.buffers, imageChannels = r.imageChannels, params = emptyList(), values = emptyMap())
        val back = ProjectSerializer.fromManifestJson(ProjectSerializer.toManifestJson(p), p.vertexSource, p.fragmentSource, r.buffers.associate { it.id.key to it.fragmentSource })
        assertEquals(1, back.buffers.size)
    }

    @Test fun tooManyBuffersAndMissingImageAreRejected() {
        val five = (0 until 5).joinToString(",") { """{"type":"buffer","name":"x$it","code":"void mainImage(out vec4 f,in vec2 p){f=vec4(0);}","inputs":[],"outputs":[]}""" }
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("""{"renderpass":[$five,{"type":"image","code":"void mainImage(out vec4 f,in vec2 p){f=vec4(0);}"}]}""") }
        expectThrows<ShadertoyImporter.ShadertoyException> { ShadertoyImporter.convert("""{"renderpass":[{"type":"buffer","name":"Buffer A","code":"x"}]}""") }
    }

    @Test fun exportFormatWithoutWrapperAndArrayInputAreAccepted() {
        val inner = """{"info":{"name":"N"},"renderpass":[{"type":"image","code":"${esc(code)}","inputs":[],"outputs":[]}]}"""
        assertEquals("N", ShadertoyImporter.convert(inner).name)
        assertEquals("N", ShadertoyImporter.convert("[$inner]").name)
    }
}

class AnimationExportConfigTest {
    private val ok = com.shaderart.studio.core.export.GifConfig(480, 270, 20, 4f)

    @Test fun gifDefaultsAreValid() {
        assertNull(com.shaderart.studio.core.export.AnimationLimits.gifProblem(ok))
        assertEquals(80, ok.frames)
        assertEquals(5, ok.delayCentis)
    }

    @Test fun gifLimits() {
        val l = com.shaderart.studio.core.export.AnimationLimits
        assertNotNull(l.gifProblem(ok.copy(width = 1080)))
        assertNotNull(l.gifProblem(ok.copy(width = 8)))
        assertNotNull(l.gifProblem(ok.copy(fps = 30, durationSeconds = 20f))) // 600 frames
        assertNotNull(l.gifProblem(ok.copy(durationSeconds = 0.1f)))
        assertNotNull(l.gifProblem(ok.copy(fps = 60)))
        assertEquals(2, ok.copy(fps = 60).delayCentis) // never below 2 cs: browsers treat 0/1 as 10
    }

    @Test fun videoLimitsAndBitrate() {
        val l = com.shaderart.studio.core.export.AnimationLimits
        val v = com.shaderart.studio.core.export.VideoConfig(1080, 1920, 30, 8f)
        assertNull(l.videoProblem(v))
        assertEquals(240, v.frames)
        assertTrue(v.bitrate in 2_000_000..40_000_000)
        assertNotNull(l.videoProblem(v.copy(durationSeconds = 120f)))
        assertNotNull(l.videoProblem(v.copy(width = 9000)))
        assertNotNull(l.videoProblem(v.copy(fps = 120)))
        assertEquals(5_000_000, v.copy(bitrateKbps = 5000).bitrate)
    }

    @Test fun evenSizesAndFit() {
        val l = com.shaderart.studio.core.export.AnimationLimits
        assertEquals(1080, l.even(1079)); assertEquals(1080, l.even(1080)); assertEquals(2, l.even(1))
        val (w, h) = l.fitGif(1080, 1920)
        assertTrue(w <= 720 && h <= 720 && h > w)
        assertEquals(l.GIF_MIN_SIDE to l.GIF_MIN_SIDE, l.fitGif(0, 5))
    }

    @Test fun animationFileNames() {
        val n = com.shaderart.studio.core.export.FileNaming.animationName("My Shader!", 720, 405, "gif", 0L)
        assertTrue(n.startsWith("My_Shader_720x405_") && n.endsWith(".gif"))
    }
}
