package com.shaderart.studio.core

import com.shaderart.studio.core.export.GifEncoder
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GifEncoderTest {
    private fun encode(w: Int, h: Int, frames: List<IntArray>, dither: Boolean = false): ByteArray {
        val out = ByteArrayOutputStream()
        val enc = GifEncoder(out, w, h, 4, loop = true, dither = dither)
        frames.forEach { enc.addFrame(it) }
        enc.finish()
        return out.toByteArray()
    }

    /** A decoded GIF frame (ARGB pixels). */
    private class Frame(val width: Int, val height: Int, val pixels: IntArray) {
        fun getRGB(x: Int, y: Int): Int = pixels[y * width + x]
    }

    /** Minimal independent GIF89a reader (global/local colour tables, LZW), so the tests do not depend on javax.imageio. */
    private fun decode(bytes: ByteArray): List<Frame> {
        fun u8(i: Int) = bytes[i].toInt() and 0xFF
        fun u16(i: Int) = u8(i) or (u8(i + 1) shl 8)
        require(String(bytes, 0, 6, Charsets.US_ASCII) == "GIF89a") { "bad header" }
        val sw = u16(6)
        val sh = u16(8)
        val flags = u8(10)
        var pos = 13
        var globalTable: IntArray? = null
        if (flags and 0x80 != 0) {
            val n = 1 shl ((flags and 7) + 1)
            globalTable = IntArray(n) { i -> (0xFF shl 24) or (u8(pos + i * 3) shl 16) or (u8(pos + i * 3 + 1) shl 8) or u8(pos + i * 3 + 2) }
            pos += n * 3
        }
        val frames = ArrayList<Frame>()
        while (pos < bytes.size) {
            when (val block = u8(pos++)) {
                0x3B -> return frames
                0x21 -> { // extension: skip label and sub-blocks
                    pos++
                    while (true) { val n = u8(pos++); if (n == 0) break; pos += n }
                }
                0x2C -> {
                    val w = u16(pos + 4)
                    val h = u16(pos + 6)
                    val f = u8(pos + 8)
                    pos += 9
                    var table = globalTable
                    if (f and 0x80 != 0) {
                        val n = 1 shl ((f and 7) + 1)
                        table = IntArray(n) { i -> (0xFF shl 24) or (u8(pos + i * 3) shl 16) or (u8(pos + i * 3 + 1) shl 8) or u8(pos + i * 3 + 2) }
                        pos += n * 3
                    }
                    require(f and 0x40 == 0) { "interlaced frames are not produced by the encoder" }
                    val minCode = u8(pos++)
                    val data = java.io.ByteArrayOutputStream()
                    while (true) { val n = u8(pos++); if (n == 0) break; data.write(bytes, pos, n); pos += n }
                    val indices = lzwDecode(data.toByteArray(), minCode, w * h)
                    val colors = requireNotNull(table) { "no colour table" }
                    frames += Frame(w, h, IntArray(w * h) { colors[indices[it].toInt() and 0xFF] })
                }
                else -> throw AssertionError("unexpected block 0x${block.toString(16)} (screen ${sw}x$sh)")
            }
        }
        throw AssertionError("missing trailer")
    }

    private fun lzwDecode(data: ByteArray, minCode: Int, expected: Int): ByteArray {
        val clear = 1 shl minCode
        val eoi = clear + 1
        val prefix = IntArray(4096)
        val suffix = ByteArray(4096)
        for (i in 0 until clear) suffix[i] = i.toByte()
        val out = ByteArray(expected)
        var outPos = 0
        var codeSize = minCode + 1
        var next = eoi + 1
        var prev = -1
        var bitPos = 0
        val tmp = ByteArray(4097)
        fun expand(code: Int): Int { // writes the string for [code] into tmp (reversed), returns its length
            var c = code
            var n = 0
            while (c >= clear) { tmp[n++] = suffix[c]; c = prefix[c] }
            tmp[n++] = suffix[c]
            return n
        }
        while (outPos < expected) {
            if (bitPos + codeSize > data.size * 8) break
            var code = 0
            for (b in 0 until codeSize) code = code or (((data[(bitPos + b) shr 3].toInt() shr ((bitPos + b) and 7)) and 1) shl b)
            bitPos += codeSize
            if (code == clear) { codeSize = minCode + 1; next = eoi + 1; prev = -1; continue }
            if (code == eoi) break
            val n: Int
            if (prev == -1) {
                n = expand(code)
            } else if (code < next) {
                n = expand(code)
                if (next < 4096) { prefix[next] = prev; suffix[next] = tmp[n - 1]; next++ }
            } else {
                require(code == next) { "corrupt LZW stream: code $code, next $next" }
                val pn = expand(prev)
                val first = tmp[pn - 1]
                prefix[next] = prev; suffix[next] = first; next++
                n = expand(code)
            }
            for (i in n - 1 downTo 0) if (outPos < expected) out[outPos++] = tmp[i]
            prev = code
            if (next == (1 shl codeSize) && codeSize < 12) codeSize++
        }
        require(outPos == expected) { "LZW stream ended after $outPos of $expected pixels" }
        return out
    }

    private fun solid(w: Int, h: Int, c: Int) = IntArray(w * h) { c }

    @Test fun headerAndTrailer() {
        val b = encode(8, 8, listOf(solid(8, 8, 0xFF112233.toInt())))
        assertEquals("GIF89a", String(b, 0, 6, Charsets.US_ASCII))
        assertEquals(0x3B, b.last().toInt())
        assertEquals(8, (b[6].toInt() and 0xFF) or ((b[7].toInt() and 0xFF) shl 8))
    }

    @Test fun solidFramesRoundTripWithinQuantizationError() {
        val colors = listOf(0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt())
        val gif = encode(16, 12, colors.map { solid(16, 12, it) })
        val frames = decode(gif)
        assertEquals(3, frames.size)
        for ((i, f) in frames.withIndex()) {
            assertEquals(16, f.width); assertEquals(12, f.height)
            val px = f.getRGB(5, 5)
            for (shift in intArrayOf(16, 8, 0)) {
                val want = (colors[i] shr shift) and 0xFF
                val got = (px shr shift) and 0xFF
                assertTrue("frame $i channel $shift want $want got $got", Math.abs(want - got) <= 8)
            }
        }
    }

    @Test fun gradientKeepsStructure() {
        val w = 128; val h = 96
        val img = IntArray(w * h) { i ->
            val x = i % w; val y = i / w
            (0xFF shl 24) or ((x * 2) shl 16) or ((y * 2) shl 8) or ((x + y) and 0xFF)
        }
        val frames = decode(encode(w, h, listOf(img), dither = true))
        var err = 0L
        for (y in 0 until h) for (x in 0 until w) {
            val a = img[y * w + x]; val b = frames[0].getRGB(x, y)
            for (shift in intArrayOf(16, 8, 0)) err += Math.abs(((a shr shift) and 0xFF) - ((b shr shift) and 0xFF))
        }
        val mean = err / (w * h * 3.0)
        assertTrue("mean error $mean", mean < 10.0)
    }

    @Test fun noisyLargeFrameExercisesDictionaryReset() {
        // Random noise fills the 4096-entry LZW dictionary many times over and forces code-size changes.
        val w = 200; val h = 200
        val r = java.util.Random(7)
        val img = IntArray(w * h) { (0xFF shl 24) or ((r.nextInt(6) * 51) shl 16) or ((r.nextInt(6) * 51) shl 8) or (r.nextInt(6) * 51) }
        val frames = decode(encode(w, h, listOf(img, img)))
        assertEquals(2, frames.size)
        var bad = 0
        for (y in 0 until h) for (x in 0 until w) {
            val a = img[y * w + x]; val b = frames[1].getRGB(x, y)
            for (shift in intArrayOf(16, 8, 0)) if (Math.abs(((a shr shift) and 0xFF) - ((b shr shift) and 0xFF)) > 12) bad++
        }
        assertEquals(0, bad)
    }

    @Test fun manySizesDecode() {
        // Odd sizes catch end-of-stream and code-width edge cases.
        for ((w, h) in listOf(1 to 1, 2 to 3, 17 to 5, 63 to 63, 64 to 65, 255 to 3)) {
            val r = java.util.Random(w * 31L + h)
            val img = IntArray(w * h) { (0xFF shl 24) or r.nextInt(0xFFFFFF) }
            val frames = decode(encode(w, h, listOf(img)))
            assertEquals(1, frames.size)
            assertEquals(w, frames[0].width)
        }
    }

    @Test fun wrongFrameSizeIsRejected() {
        val enc = GifEncoder(ByteArrayOutputStream(), 4, 4, 4)
        try { enc.addFrame(IntArray(3)); throw AssertionError("expected failure") } catch (_: IllegalArgumentException) { }
    }
}
