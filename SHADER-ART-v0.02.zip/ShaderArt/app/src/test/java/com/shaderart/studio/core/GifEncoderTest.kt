package com.shaderart.studio.core

import com.shaderart.studio.core.export.GifEncoder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GifEncoderTest {
    private fun encode(w: Int, h: Int, frames: List<IntArray>, dither: Boolean = false): ByteArray {
        val out = ByteArrayOutputStream()
        val enc = GifEncoder(out, w, h, 4, loop = true, dither = dither)
        frames.forEach { enc.addFrame(it) }
        enc.finish()
        return out.toByteArray()
    }

    private fun decode(bytes: ByteArray): List<java.awt.image.BufferedImage> {
        val readers = ImageIO.getImageReadersByFormatName("gif")
        val reader = readers.next()
        reader.input = ImageIO.createImageInputStream(ByteArrayInputStream(bytes))
        return (0 until reader.getNumImages(true)).map { reader.read(it) }
    }

    private fun solid(w: Int, h: Int, c: Int) = IntArray(w * h) { c }

    @Test fun headerAndTrailer() {
        val b = encode(8, 8, listOf(solid(8, 8, 0xFF112233.toInt())))
        assertEquals("GIF89a", String(b, 0, 6, Charsets.US_ASCII))
        assertEquals(0x3B, b.last().toInt())
        assertEquals(8, (b[6].toInt() and 0xFF) or ((b[7].toInt() and 0xFF) shl 8))
    }

    @Test fun solidFramesRoundTripWithinQuantizationError() {
        val colors = listOf(0xFFFF0000.toInt(), 0xFF00FF00.toInt(), 0xFF0000FF.toInt())
        val gif = encode(16, 12, colors.map { solid(16, 12, it) })
        val frames = decode(gif)
        assertEquals(3, frames.size)
        for ((i, f) in frames.withIndex()) {
            assertEquals(16, f.width); assertEquals(12, f.height)
            val px = f.getRGB(5, 5)
            for (shift in intArrayOf(16, 8, 0)) {
                val want = (colors[i] shr shift) and 0xFF
                val got = (px shr shift) and 0xFF
                assertTrue("frame $i channel $shift want $want got $got", Math.abs(want - got) <= 8)
            }
        }
    }

    @Test fun gradientKeepsStructure() {
        val w = 128; val h = 96
        val img = IntArray(w * h) { i ->
            val x = i % w; val y = i / w
            (0xFF shl 24) or ((x * 2) shl 16) or ((y * 2) shl 8) or ((x + y) and 0xFF)
        }
        val frames = decode(encode(w, h, listOf(img), dither = true))
        var err = 0L
        for (y in 0 until h) for (x in 0 until w) {
            val a = img[y * w + x]; val b = frames[0].getRGB(x, y)
            for (shift in intArrayOf(16, 8, 0)) err += Math.abs(((a shr shift) and 0xFF) - ((b shr shift) and 0xFF))
        }
        val mean = err / (w * h * 3.0)
        assertTrue("mean error $mean", mean < 10.0)
    }

    @Test fun noisyLargeFrameExercisesDictionaryReset() {
        // Random noise fills the 4096-entry LZW dictionary many times over and forces code-size changes.
        val w = 200; val h = 200
        val r = java.util.Random(7)
        val img = IntArray(w * h) { (0xFF shl 24) or ((r.nextInt(6) * 51) shl 16) or ((r.nextInt(6) * 51) shl 8) or (r.nextInt(6) * 51) }
        val frames = decode(encode(w, h, listOf(img, img)))
        assertEquals(2, frames.size)
        var bad = 0
        for (y in 0 until h) for (x in 0 until w) {
            val a = img[y * w + x]; val b = frames[1].getRGB(x, y)
            for (shift in intArrayOf(16, 8, 0)) if (Math.abs(((a shr shift) and 0xFF) - ((b shr shift) and 0xFF)) > 12) bad++
        }
        assertEquals(0, bad)
    }

    @Test fun manySizesDecode() {
        // Odd sizes catch end-of-stream and code-width edge cases.
        for ((w, h) in listOf(1 to 1, 2 to 3, 17 to 5, 63 to 63, 64 to 65, 255 to 3)) {
            val r = java.util.Random(w * 31L + h)
            val img = IntArray(w * h) { (0xFF shl 24) or r.nextInt(0xFFFFFF) }
            val frames = decode(encode(w, h, listOf(img)))
            assertEquals(1, frames.size)
            assertEquals(w, frames[0].width)
        }
    }

    @Test fun wrongFrameSizeIsRejected() {
        val enc = GifEncoder(ByteArrayOutputStream(), 4, 4, 4)
        try { enc.addFrame(IntArray(3)); throw AssertionError("expected failure") } catch (_: IllegalArgumentException) { }
    }
}
