package com.shaderart.studio.core

import com.shaderart.studio.assetsDir
import com.shaderart.studio.core.model.ChannelBinding
import com.shaderart.studio.core.model.MultipassCheck
import com.shaderart.studio.core.model.PassId
import com.shaderart.studio.core.model.PassSpec
import com.shaderart.studio.core.shader.GlslSourceCheck
import com.shaderart.studio.core.storage.ProjectFactory
import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TemplatesTest {
    private fun read(path: String) = File(assetsDir(), path).readText()

    @Test fun everyTemplateIsValidGlslSource() {
        val dir = File(assetsDir(), "templates")
        val files = dir.listFiles { f -> f.name.endsWith(".frag") }!!.toList()
        assertTrue(files.size >= 10)
        for (f in files) assertTrue(f.name, GlslSourceCheck.check(f.readText(), "Fragment").isEmpty())
    }

    @Test fun controlsFromBufferPassesAreMergedIntoTheProject() {
        val a = PassSpec(PassId.A, read("templates/feedback_a.frag"), listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE))
        val image = read("templates/feedback.frag")
        val params = ProjectFactory.paramsFor(image, listOf(a))
        assertTrue(params.any { it.uniform == "u_decay" })
        assertTrue(params.any { it.uniform == "u_colorA" })
        val project = ProjectFactory.newCode("t", "id", 1L, "#version 300 es\nvoid main(){}", image, listOf(a), listOf(ChannelBinding.buffer(PassId.A), ChannelBinding.NONE, ChannelBinding.NONE, ChannelBinding.NONE))
        assertTrue(project.isMultipass)
        assertEquals(emptyList<String>(), MultipassCheck.check(project.buffers, project.imageChannels, project.textures))
    }

    @Test fun firstDeclarationOfAUniformWins() {
        val image = "#version 300 es\nuniform float u_x; // @slider 0 1 0.5 \"From image\"\nvoid main(){}"
        val buf = PassSpec(PassId.B, "#version 300 es\nuniform float u_x; // @slider 0 9 4 \"From buffer\"\nvoid main(){}")
        val params = ProjectFactory.paramsFor(image, listOf(buf))
        assertEquals(1, params.count { it.uniform == "u_x" })
        assertEquals(1f, params.first { it.uniform == "u_x" }.max, 0f)
    }
}
