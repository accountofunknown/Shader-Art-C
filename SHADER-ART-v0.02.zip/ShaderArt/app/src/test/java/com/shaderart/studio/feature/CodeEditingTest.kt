package com.shaderart.studio.feature

import com.shaderart.studio.feature.codeeditor.AutoIndent
import com.shaderart.studio.feature.codeeditor.CodeFormatter
import com.shaderart.studio.feature.codeeditor.Completion
import com.shaderart.studio.feature.codeeditor.EditorHistory
import com.shaderart.studio.feature.codeeditor.EditorHistory.Snapshot
import com.shaderart.studio.feature.codeeditor.FindEngine
import com.shaderart.studio.feature.codeeditor.GlslTokenizer
import com.shaderart.studio.feature.codeeditor.LineUtil
import com.shaderart.studio.feature.codeeditor.TokenKind
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class EditorHistoryTest {
    @Test fun undoRedoWalkTheStack() {
        val h = EditorHistory(coalesceMs = 0)
        h.beforeChange(Snapshot("a", 1), 100)
        h.beforeChange(Snapshot("ab", 2), 200)
        assertTrue(h.canUndo); assertFalse(h.canRedo)
        val u1 = h.undo(Snapshot("abc", 3))!!
        assertEquals("ab", u1.text)
        val u2 = h.undo(u1)!!
        assertEquals("a", u2.text)
        assertNull(h.undo(u2).takeIf { !h.canUndo })
        assertEquals("ab", h.redo(u2)!!.text)
        assertEquals("abc", h.redo(Snapshot("ab", 2))!!.text)
    }

    @Test fun newEditClearsRedo() {
        val h = EditorHistory(coalesceMs = 0)
        h.beforeChange(Snapshot("a", 1), 1)
        h.undo(Snapshot("ab", 2))
        assertTrue(h.canRedo)
        h.beforeChange(Snapshot("a", 1), 2)
        assertFalse(h.canRedo)
    }

    @Test fun rapidTypingIsCoalescedIntoOneStep() {
        val h = EditorHistory(coalesceMs = 700)
        h.beforeChange(Snapshot("", 0), 1000)
        h.beforeChange(Snapshot("a", 1), 1100)
        h.beforeChange(Snapshot("ab", 2), 1200)
        assertEquals("", h.undo(Snapshot("abc", 3))!!.text)
        assertFalse(h.canUndo)
    }

    @Test fun pauseStartsANewStepAndForceBreakWorks() {
        val h = EditorHistory(coalesceMs = 700)
        h.beforeChange(Snapshot("", 0), 1000)
        h.beforeChange(Snapshot("a", 1), 5000)
        h.beforeChange(Snapshot("ab", 2), 5100, forceBreak = true)
        assertEquals("ab", h.undo(Snapshot("abc", 3))!!.text)
        assertEquals("a", h.undo(Snapshot("ab", 2))!!.text)
        assertEquals("", h.undo(Snapshot("a", 1))!!.text)
    }

    @Test fun historyIsBounded() {
        val h = EditorHistory(limit = 3, coalesceMs = 0)
        for (i in 1..10) h.beforeChange(Snapshot("s$i", 0), i.toLong())
        var steps = 0
        var cur = Snapshot("end", 0)
        while (true) { cur = h.undo(cur) ?: break; steps++ }
        assertEquals(3, steps)
    }
}

class CodeFormatterTest {
    @Test fun indentsByBraceDepth() {
        val out = CodeFormatter.format("void main() {\nif (x) {\ny = 1;\n}\n}\n")
        assertEquals("void main() {\n  if (x) {\n    y = 1;\n  }\n}\n", out)
    }

    @Test fun isIdempotent() {
        val src = "#version 300 es\nvoid f() {\nfor (int i=0;i<3;i++) {\n// } not a brace\nx += 1; /* { */\n}\n}\n\n\n\n\nvoid main() {\n}\n"
        val once = CodeFormatter.format(src)
        assertEquals(once, CodeFormatter.format(once))
    }

    @Test fun preprocessorStaysAtColumnZeroAndBlankRunsCollapse() {
        val out = CodeFormatter.format("void f() {\n#ifdef A\nx;\n#endif\n}\n\n\n\n\nint y;")
        assertTrue(out.contains("\n#ifdef A\n"))
        assertFalse(out.contains("\n\n\n\n"))
    }

    @Test fun bracesInCommentsAreIgnored() {
        val out = CodeFormatter.format("void f() {\n// }\nx;\n}\nint y;")
        assertTrue(out.contains("\n  x;\n"))
        assertTrue(out.contains("\nint y;"))
    }

    @Test fun extraClosingBracesNeverGoNegative() {
        val out = CodeFormatter.format("}\n}\nx;\n")
        assertEquals("}\n}\nx;\n", out)
    }
}

class AutoIndentTest {
    @Test fun newlineCarriesIndentation() {
        val old = "  a;"
        val typed = "  a;\n"
        val e = AutoIndent.onTyped(old, typed, typed.length)!!
        assertEquals("  a;\n  ", e.text)
        assertEquals(e.text.length, e.cursor)
    }

    @Test fun newlineAfterOpenBraceAddsIndent() {
        val e = AutoIndent.onTyped("void f() {", "void f() {\n", 11)!!
        assertEquals("void f() {\n  ", e.text)
    }

    @Test fun newlineBetweenBracesPutsCloserOnItsOwnLine() {
        val old = "void f() {}"
        val typed = "void f() {\n}"
        val e = AutoIndent.onTyped(old, typed, 11)!!
        assertEquals("void f() {\n  \n}", e.text)
        assertEquals("void f() {\n  ".length, e.cursor)
    }

    @Test fun closingBraceOnBlankLineDedents() {
        val old = "void f() {\n  "
        val typed = "void f() {\n  }"
        val e = AutoIndent.onTyped(old, typed, typed.length)!!
        assertEquals("void f() {\n}", e.text)
        assertEquals(e.text.length, e.cursor)
    }

    @Test fun otherEditsAreLeftAlone() {
        assertNull(AutoIndent.onTyped("ab", "abc", 3))
        assertNull(AutoIndent.onTyped("ab", "ab", 2))
        assertNull(AutoIndent.onTyped("abc", "ab", 2))
        assertNull(AutoIndent.onTyped("ab", "xyz", 3))
    }
}

class FindAndLineTest {
    @Test fun findsAllCaseInsensitively() {
        assertEquals(listOf(0, 4, 8), FindEngine.findAll("Foo foo FOO", "foo"))
        assertEquals(listOf(4), FindEngine.findAll("Foo foo FOO", "foo", caseSensitive = true))
        assertTrue(FindEngine.findAll("abc", "").isEmpty())
        assertTrue(FindEngine.findAll("abc", "z").isEmpty())
    }

    @Test fun nextAndPreviousWrapAround() {
        val m = listOf(5, 20, 40)
        assertEquals(1, FindEngine.nextIndex(m, 6))
        assertEquals(0, FindEngine.nextIndex(m, 41))
        assertEquals(1, FindEngine.previousIndex(m, 40))
        assertEquals(2, FindEngine.previousIndex(m, 5))
        assertEquals(-1, FindEngine.nextIndex(emptyList(), 0))
    }

    @Test fun lineMapping() {
        val t = "a\nbb\nccc"
        assertEquals(1, LineUtil.lineOfOffset(t, 0))
        assertEquals(2, LineUtil.lineOfOffset(t, 2))
        assertEquals(3, LineUtil.lineOfOffset(t, 8))
        assertEquals(0, LineUtil.offsetOfLine(t, 1))
        assertEquals(2, LineUtil.offsetOfLine(t, 2))
        assertEquals(5, LineUtil.offsetOfLine(t, 3))
        assertEquals(t.length, LineUtil.offsetOfLine(t, 99))
        assertEquals(3, LineUtil.lineCount(t))
    }
}

class CompletionAndTokenizerTest {
    @Test fun suggestsBuiltinsKeywordsUniformsAndLocalNames() {
        val text = "float myValue = 1.0;\nfloat q = smo"
        val s = Completion.suggest(text, text.length)
        assertTrue(s.toString(), "smoothstep" in s)
        assertTrue("myValue" in Completion.suggest("float myValue;\nmyV", "float myValue;\nmyV".length))
        assertTrue("u_resolution" in Completion.suggest("u_re", 4))
        assertTrue("uniform" in Completion.suggest("uni", 3))
    }

    @Test fun noSuggestionsForShortOrNumericPrefixes() {
        assertTrue(Completion.suggest("s", 1).isEmpty())
        assertTrue(Completion.suggest("1.0f", 4).isEmpty())
        assertTrue(Completion.suggest("x = ", 4).isEmpty())
    }

    @Test fun applyReplacesTheWordAndOpensCallsForFunctions() {
        val text = "a = smo;"
        val r = Completion.apply(text, 7, "smoothstep")
        assertEquals("a = smoothstep(;", r.text)
        assertEquals("a = smoothstep(".length, r.cursor)
        val k = Completion.apply("uni", 3, "uniform")
        assertEquals("uniform", k.text)
    }

    @Test fun tokenizerClassifiesCommonTokens() {
        val text = "#version 300 es\n// note\nuniform float u_x; /* b */ vec3 c = mix(a, b, 1.5e-3);\nint i = gl_VertexID;"
        val kinds = GlslTokenizer.tokenize(text).map { text.substring(it.start, it.end) to it.kind }
        assertTrue(kinds.contains("#version 300 es" to TokenKind.PREPROCESSOR))
        assertTrue(kinds.contains("// note" to TokenKind.COMMENT))
        assertTrue(kinds.contains("uniform" to TokenKind.KEYWORD))
        assertTrue(kinds.contains("float" to TokenKind.TYPE))
        assertTrue(kinds.contains("/* b */" to TokenKind.COMMENT))
        assertTrue(kinds.contains("mix" to TokenKind.BUILTIN))
        assertTrue(kinds.contains("1.5e-3" to TokenKind.NUMBER))
        assertTrue(kinds.contains("gl_VertexID" to TokenKind.BUILTIN))
        assertFalse(kinds.any { it.first == "u_x" })
    }

    @Test fun tokenizerHandlesUnterminatedCommentsAndTokensStayInBounds() {
        val text = "float a; /* never closed\nmore"
        val toks = GlslTokenizer.tokenize(text)
        assertNotNull(toks.lastOrNull { it.kind == TokenKind.COMMENT })
        assertTrue(toks.all { it.start >= 0 && it.end <= text.length && it.start < it.end })
    }

    @Test fun hashInsideCodeIsNotPreprocessor() {
        val text = "int a; # not at line start"
        assertTrue(GlslTokenizer.tokenize(text).none { it.kind == TokenKind.PREPROCESSOR })
    }
}
