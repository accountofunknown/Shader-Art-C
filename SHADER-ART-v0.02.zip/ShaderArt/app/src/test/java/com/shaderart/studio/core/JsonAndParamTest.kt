package com.shaderart.studio.core

import com.shaderart.studio.core.json.JsonException
import com.shaderart.studio.core.json.MiniJson
import com.shaderart.studio.core.model.ParamDef
import com.shaderart.studio.core.model.ParamLogic
import com.shaderart.studio.core.model.ParamType
import com.shaderart.studio.core.model.ParamValidator
import com.shaderart.studio.expectThrows
import com.shaderart.studio.sampleParams
import kotlin.random.Random
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MiniJsonTest {
    @Test fun parsesObjectsArraysAndNumbers() {
        val v = MiniJson.parseObject("""{"a":1,"b":[1.5,-2,3e2],"c":{"d":true,"e":null},"f":"x"}""")
        assertEquals(1L, v["a"])
        assertEquals(listOf(1.5, -2L, 300.0), v["b"])
        assertEquals(mapOf("d" to true, "e" to null), v["c"])
    }

    @Test fun parsesEscapes() {
        assertEquals("a\"b\\c\ndé", MiniJson.parse("\"a\\\"b\\\\c\\nd\\u00e9\""))
    }

    @Test fun rejectsDuplicateKeys() { expectThrows<JsonException> { MiniJson.parse("""{"a":1,"a":2}""") } }
    @Test fun rejectsTrailingGarbage() { expectThrows<JsonException> { MiniJson.parse("{} x") } }
    @Test fun rejectsUnterminated() { expectThrows<JsonException> { MiniJson.parse("{\"a\":") } }
    @Test fun rejectsNaNAndInfinityLiterals() {
        expectThrows<JsonException> { MiniJson.parse("NaN") }
        expectThrows<JsonException> { MiniJson.parse("[Infinity]") }
        expectThrows<JsonException> { MiniJson.parse("1e999") }
    }
    @Test fun rejectsLeadingZerosAndBareMinus() {
        expectThrows<JsonException> { MiniJson.parse("01") }
        expectThrows<JsonException> { MiniJson.parse("-") }
    }
    @Test fun rejectsControlCharactersInStrings() { expectThrows<JsonException> { MiniJson.parse("\"a\nb\"") } }

    @Test fun rejectsExcessiveNesting() {
        val deep = "[".repeat(MiniJson.MAX_DEPTH + 5) + "]".repeat(MiniJson.MAX_DEPTH + 5)
        expectThrows<JsonException> { MiniJson.parse(deep) }
        val ok = "[".repeat(MiniJson.MAX_DEPTH - 1) + "]".repeat(MiniJson.MAX_DEPTH - 1)
        MiniJson.parse(ok)
    }

    @Test fun writeThenParseRoundTrips() {
        val src = linkedMapOf("s" to "q\"\\\n\t\u0001é", "n" to listOf(1, 2.5f, 3L), "z" to null, "b" to false, "o" to emptyMap<String, Any?>())
        for (pretty in listOf(false, true)) {
            val back = MiniJson.parseObject(MiniJson.write(src, pretty))
            assertEquals("q\"\\\n\t\u0001é", back["s"])
            assertEquals(listOf(1L, 2.5, 3L), back["n"])
            assertEquals(null, back["z"])
            assertEquals(false, back["b"])
            assertEquals(emptyMap<String, Any?>(), back["o"])
        }
    }

    @Test fun refusesToWriteNonFiniteNumbers() {
        expectThrows<JsonException> { MiniJson.write(Float.NaN) }
        expectThrows<JsonException> { MiniJson.write(listOf(Double.POSITIVE_INFINITY)) }
    }
}

class ParamLogicTest {
    private val params = sampleParams()
    private fun def(id: String) = params.first { it.id == id }

    @Test fun snapClampsAndSteps() {
        assertEquals(6f, ParamLogic.snap(def("u_scale"), 99f), 0f)
        assertEquals(0.2f, ParamLogic.snap(def("u_scale"), -5f), 0f)
        assertEquals(1.05f, ParamLogic.snap(def("u_scale"), 1.04f), 1e-4f)
    }

    @Test fun snapRoundsIntegersAndToggles() {
        assertEquals(49f, ParamLogic.snap(def("u_iterations"), 48.6f), 0f)
        assertEquals(1f, ParamLogic.snap(def("u_invert"), 0.7f), 0f)
        assertEquals(0f, ParamLogic.snap(def("u_invert"), 0.2f), 0f)
    }

    @Test fun snapFallsBackToDefaultForNonFinite() {
        assertEquals(1f, ParamLogic.snap(def("u_scale"), Float.NaN), 0f)
        assertEquals(0.6f, ParamLogic.snap(def("u_colorA"), Float.POSITIVE_INFINITY, 1), 0f)
    }

    @Test fun withValueUpdatesOneComponent() {
        val v = ParamLogic.withValue(ParamLogic.defaults(params), def("u_colorA"), 2, 0.25f)
        assertEquals(listOf(0.1f, 0.6f, 0.25f), v["u_colorA"])
    }

    @Test fun withValueIgnoresBadIndex() {
        val d = ParamLogic.defaults(params)
        assertEquals(d, ParamLogic.withValue(d, def("u_scale"), 3, 1f))
    }

    @Test fun normalizeRepairsSizeAndRange() {
        val n = ParamLogic.normalize(params, mapOf("u_scale" to listOf(100f), "u_colorA" to listOf(1f), "ghost" to listOf(1f)))
        assertEquals(listOf(6f), n["u_scale"])
        assertEquals(def("u_colorA").defaults, n["u_colorA"])
        assertFalse(n.containsKey("ghost"))
        assertEquals(params.size, n.size)
    }

    @Test fun randomizeStaysInRangeAndSparesQualityToggleAndBackground() {
        val extra = params + ParamDef("u_bgColor", "Background color", "u_bgColor", ParamType.COLOR, listOf(0f, 0f, 0f), 0f, 1f, 0.01f, "", "Colors")
        val base = ParamLogic.defaults(extra)
        for (seed in 1..50) {
            val r = ParamLogic.randomize(extra, base, Random(seed))
            assertTrue(ParamValidator.validateValues(extra, r).isEmpty())
            assertEquals(base["u_iterations"], r["u_iterations"])
            assertEquals(base["u_invert"], r["u_invert"])
            assertEquals(base["u_bgColor"], r["u_bgColor"])
        }
        assertNotEquals(base["u_scale"], ParamLogic.randomize(extra, base, Random(7))["u_scale"])
    }

    @Test fun randomizeIsDeterministicForASeed() {
        val base = ParamLogic.defaults(params)
        assertEquals(ParamLogic.randomize(params, base, Random(5)), ParamLogic.randomize(params, base, Random(5)))
    }

    @Test fun variationStaysInRangeAndMovesValues() {
        val base = ParamLogic.defaults(params)
        var changed = false
        for (seed in 1..30) {
            val v = ParamLogic.variation(params, base, Random(seed))
            assertTrue(ParamValidator.validateValues(params, v).isEmpty())
            if (v["u_scale"] != base["u_scale"] || v["u_colorA"] != base["u_colorA"]) changed = true
        }
        assertTrue(changed)
    }

    @Test fun hsvRoundTrip() {
        val hsv = ParamLogic.rgbToHsv(0.2f, 0.5f, 0.9f)
        val rgb = ParamLogic.hsvToRgb(hsv[0], hsv[1], hsv[2])
        assertEquals(0.2f, rgb[0], 1e-3f); assertEquals(0.5f, rgb[1], 1e-3f); assertEquals(0.9f, rgb[2], 1e-3f)
    }
}

class ParamValidatorTest {
    private val ok = sampleParams()[0]

    @Test fun acceptsValidDefinitions() { assertTrue(ParamValidator.validate(sampleParams()).isEmpty()) }
    @Test fun rejectsMinGreaterThanMax() { assertFalse(ParamValidator.validateOne(ok.copy(min = 5f, max = 1f, defaults = listOf(2f))).isEmpty()) }
    @Test fun rejectsDefaultOutsideRange() { assertFalse(ParamValidator.validateOne(ok.copy(defaults = listOf(99f))).isEmpty()) }
    @Test fun rejectsNonFinite() { assertFalse(ParamValidator.validateOne(ok.copy(max = Float.POSITIVE_INFINITY)).isEmpty()) }
    @Test fun rejectsZeroStep() { assertFalse(ParamValidator.validateOne(ok.copy(step = 0f)).isEmpty()) }
    @Test fun rejectsReservedAndMalformedUniformNames() {
        assertFalse(ParamValidator.validateOne(ok.copy(uniform = "gl_Evil")).isEmpty())
        assertFalse(ParamValidator.validateOne(ok.copy(uniform = "u bad")).isEmpty())
        assertFalse(ParamValidator.validateOne(ok.copy(uniform = "1abc")).isEmpty())
        assertFalse(ParamValidator.validateOne(ok.copy(uniform = "a__b")).isEmpty())
    }
    @Test fun rejectsWrongColorArity() {
        val c = sampleParams()[2]
        assertFalse(ParamValidator.validateOne(c.copy(defaults = listOf(0.5f))).isEmpty())
    }
    @Test fun rejectsFractionalIntLimits() { assertFalse(ParamValidator.validateOne(sampleParams()[1].copy(min = 8.5f)).isEmpty()) }
    @Test fun rejectsDuplicateIdsAndUniforms() {
        assertTrue(ParamValidator.validate(listOf(ok, ok)).any { it.contains("Duplicate") })
    }
    @Test fun rejectsTooManyParameters() {
        val many = (0..ParamValidator.MAX_PARAMS).map { ok.copy(id = "p$it", uniform = "p$it") }
        assertTrue(ParamValidator.validate(many).any { it.contains("Too many") })
    }
    @Test fun valueValidationFlagsUnknownWrongSizeAndRange() {
        val p = sampleParams()
        assertFalse(ParamValidator.validateValues(p, mapOf("nope" to listOf(1f))).isEmpty())
        assertFalse(ParamValidator.validateValues(p, mapOf("u_colorA" to listOf(1f))).isEmpty())
        assertFalse(ParamValidator.validateValues(p, mapOf("u_scale" to listOf(50f))).isEmpty())
        assertFalse(ParamValidator.validateValues(p, mapOf("u_scale" to listOf(Float.NaN))).isEmpty())
        assertTrue(ParamValidator.validateValues(p, mapOf("u_scale" to listOf(2f))).isEmpty())
    }
}
