# SHADER ART v0.01 ships a debug APK, which is not minified, so no rules are needed yet.
# If release minification is enabled later, add keep rules here for Room entities and any reflection use.
